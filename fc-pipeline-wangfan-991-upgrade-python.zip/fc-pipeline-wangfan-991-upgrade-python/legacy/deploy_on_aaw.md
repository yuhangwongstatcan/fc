**Note**: This is legacy documentation about how the web application was deployed on the AAW environment early in the project.

# Running the Webapp

Currently, the webapp can either be run in a notebook server, or in a container operation in Kubeflow Pipelines. Each approach is documented below.

1. Create a new notebook server in the `aaw-fc` namespace called `webapp` (if it does not already exist).

2. Open a terminal and clone the `fc-pipeline` repository (`git clone https://gitlab.com/dsd4/frontier-counts/fc-pipeline.git`) - you will be prompted to enter your credentials.

## Notebook Server Approach

Navigate to `fc-pipeline/src` and run `start_webapp.sh` (i.e. `sh start_webapp.sh prod` for production and `sh start_webapp.sh dev` for development mode) - this script will automatically create and install your python virtual environment if it is not already set up.

## Kubeflow Pipeline approach

Navigate to `fc-pipeline/src` and run `python -m kubeflow_pipelines.run_webapp` - this will launch a Kubeflow Pipeline run that has a container operation that serves the web app.

Navigate to https://kubeflow.covid.cloud.statcan.ca/_/pipeline/#/experiments in the `aaw-fc` namespace, and click on the newly created pipeline run (under `frontier-counts-dev` then the most recently created run of the `run_webapp` pipeline). You can inspect the logs of the webapp through the logs tab of the UI.

Once the webapp is up and running, get the name of the pod that is running the newly created webapp pipeline run (i.e. do `kubectl get pods [-n aaw-fc]`). Once you have the name of the pod, do `kubectl port-forward [run-webapp-SOME-UID] 8000:8000`. This will start port forwarding all traffic to the current notebook server at port 8000 to port 8000 of the kubeflow pipeline container operation that is hosting the webapp.

## Notes

__Note:__ The form of the proxy URL is https://kubeflow.covid.cloud.statcan.ca/notebook/[namespace]/[notebook-server-name]/proxy/[port] - for what is currently set up, the correct proxy URL is https://kubeflow.covid.cloud.statcan.ca/notebook/aaw-fc/webapp/proxy/8000

__Note:__ In general, you can get the correct base URL by running:

```bash
echo https://kubeflow.covid.cloud.statcan.ca${JUPYTER_SERVER_URL:19}proxy/5000/
```