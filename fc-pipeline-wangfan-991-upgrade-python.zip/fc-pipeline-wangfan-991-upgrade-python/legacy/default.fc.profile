# This script contains a boilerplate for all of the environment variables/configuration settings
# that are used when deploying the Frontier Counts helm chart locally. 

#  _          _                           __ _
# | | ___   _| |__   ___  ___ ___  _ __  / _(_) __ _
# | |/ / | | | '_ \ / _ \/ __/ _ \| '_ \| |_| |/ _` |
# |   <| |_| | |_) |  __/ (_| (_) | | | |  _| | (_| |
# |_|\_\\__,_|_.__/ \___|\___\___/|_| |_|_| |_|\__, |
#                                              |___/

# Set kubeconfig - note that this assumes you have already connected to the SDLC kubernetes
# clusters (see the documentation site for details about how to do this).
export KUBECONFIG=$HOME/.kube/config:$HOME/.kube/sdlc/k8s-cancentral-01-development.json:$HOME/.kube/sdlc/k8s-cancentral-01-test.json:$HOME/.kube/sdlc/k8s-cancentral-01-production.json
#                                 _
#   __ _ _____   _ _ __ ___   ___| |_ ___  _ __ __ _  __ _  ___
#  / _` |_  / | | | '__/ _ \ / __| __/ _ \| '__/ _` |/ _` |/ _ \
# | (_| |/ /| |_| | | |  __/ \__ \ || (_) | | | (_| | (_| |  __/
#  \__,_/___|\__,_|_|  \___| |___/\__\___/|_|  \__,_|\__, |\___|
#                                                    |___/
#                                  _
#   __ _  ___ ___ ___  _   _ _ __ | |_ ___
#  / _` |/ __/ __/ _ \| | | | '_ \| __/ __|
# | (_| | (_| (_| (_) | |_| | | | | |_\__ \
#  \__,_|\___\___\___/ \__,_|_| |_|\__|___/

# These environment variables are used to initialize MinIO in the helm
# chart when deploying with the Makefile.
export AZURE_KEY_DEV=changeme
export AZURE_NAME_DEV=frontiercountsblobdev
# These accounts/keys are used to initialize the Argo Cron Workflow to use the
# az client to copy data from one storage account container to another. This
# feature is currently disabled at the time of writing this documentation,
# so there is no need to set these variables.
export AZURE_SOURCE_ACCOUNT_NAME_DEV=frontiercountsblobdev
export AZURE_SOURCE_ACCOUNT_KEY_DEV=changeme
export AZURE_DESTINATION_ACCOUNT_NAME_DEV=frontiercountsreldev
export AZURE_DESTINATION_ACCOUNT_KEY_DEV=changeme


export AZURE_KEY_TEST=changeme
export AZURE_NAME_TEST=frontiercountsblobtest

export AZURE_SOURCE_ACCOUNT_NAME_TEST=frontiercountsblobtest
export AZURE_SOURCE_ACCOUNT_KEY_TEST=changeme
export AZURE_DESTINATION_ACCOUNT_NAME_TEST=frontiercountsreltest
export AZURE_DESTINATION_ACCOUNT_KEY_TEST=changeme


export AZURE_KEY_PROD=changeme
export AZURE_NAME_PROD=frontiercountsblobprod

export AZURE_SOURCE_ACCOUNT_NAME_PROD=frontiercountsblobprod
export AZURE_SOURCE_ACCOUNT_KEY_PROD=changeme
export AZURE_DESTINATION_ACCOUNT_NAME_PROD=frontiercountsrelprod
export AZURE_DESTINATION_ACCOUNT_KEY_PROD=changeme

# These environment variables relate to the Argo cron job source/destination
# storage account containers. If this feature is ever enabled, these environment
# variables specify the src/dst locations for the az copy cron workflow.
export SOURCE_CONTAINER=fc-bucket
export SOURCE_BLOB=release
export DESTINATION_CONTAINER=release
export DESTINATION_BLOB="."

#  _   _  ____ ___ _   ___  __
# | \ | |/ ___|_ _| \ | \ \/ /
# |  \| | |  _ | ||  \| |\  /
# | |\  | |_| || || |\  |/  \
# |_| \_|\____|___|_| \_/_/\_\

# NGINX Password contents (this assumes the existence of a .nginx.htpasswd file
# in the project root)
export NGINX_HTPASSWD="`head -1 .nginx.htpasswd`"

# Flask webapp secret key
export FC_FLASK_SECRET_KEY=changeme
# Activate the Frontier Counts conda environment
conda activate frontier-counts
