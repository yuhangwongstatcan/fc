# NDM Historical Validations

## Purpose

This is partially complete legacy documentation that was created for the purpose of documenting how we verified that the NDM files produced by the old system are consistent with the NDM files produced by the new system. This was done by retroactively recreating historical NDM tables with the new system and comparing them to the corresponding values created by the old system.

## Data Dependencies

### `ndm_excluded`

### `ndm_

##


## Steps to Reproduce

0. Place the updated vehicles_main or travellers_main zip file into the appropriate staging area in MinIO:

__vehicles_main__: `/staging/vehicles_main/<year>/vehicles_main_<year>.zip`

__travellers_main__: `/staging/travellers_main/<year>/travellers_main_<year>.zip`

1. Stage the vehicles_main/travellers_main from the staging area of MinIO to the inbox, then check inbox

```bash
python staging.py --ndm_unadjusted_prep
```

```bash
python loader.py --check-inbox
```

2. Recreate `ndm_unadjusted` and `sa_in` from `vehicles_main` and `travellers_main` (note change the dates accordingly)

__Note:__ the ndm_unadjusted pipeline uses multiprocessing to parallelize some of the ndm processing workflow, so by spinning up multiple jupyter notebook servers on the AAW (each notebook server has a limit of 14 vCPU cores), this tasks can be sped up

```bash
time python bulk_wrapper.py --workflow ndm_unadjusted --start-date 2008-01 --end-date 2011-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_unadjusted"

time python bulk_wrapper.py --workflow ndm_unadjusted --start-date 2012-01 --end-date 2015-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_unadjusted"

time python bulk_wrapper.py --workflow ndm_unadjusted --start-date 2016-01 --end-date 2019-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_unadjusted"
```

3. Recreate `ndm_XXXXXXX` tables (i.e. one for each product ID)

```bash
time python bulk_wrapper.py --workflow ndm_adjusted --start-date 2008-01 --end-date 2008-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_adjusted"
```

4. Go to the [access data page](https://www150.statcan.gc.ca/n1/en/type/data?HPA=1) at https://www.statcan.gc.ca then download the appropriate table for as many years back as necessary. The following correspondance can be used to get the old NDM tables:

__Old -> New Table Mappings__

__IN SCOPE__
- 24100003 -> 24100050
- 24100002 -> 24100052
- 24100041 -> 24100053

__OUT OF SCOPE__
- 24100006 -> 24100051
- 24100043 -> 24100054

E.g. searching "24100003" will yield the "Non-resident travellers entering Canada, by country of residence (excluding the United States)" table.

Click the appropriate table, click the "Add/Remove Data" button, and select all available fields, and select the time range we want to download (e.g. 1980 - 2021 current month).

5. Once the various old NDM tables have been downloaded, place them in the `/inbox` location on MinIO.

> TODO: Need to move the logic from `partition_historical_ndm.py` to a `loader` function for each old NDM historical data source. This is currently implemented as an ad hoc CLI script.

6. Once all of the old NDM tables are in `/inbox`, run `python loader.py --check-inbox` to triage each old table to the appropriate `/validation/<table>/<year>/<month>/` location.

7. Generate the `vector_concordance` for each table: `python make_ndm_concordance.py --table [50, 52, 53]` (i.e. run for one of tables 50, 52, 53)

8. Generate the report containing which vectors did not match between the old and new NDM tables. `python generate_ndm_report.py` - this produces a set of files of the form `/validation/<table>/<year>/<month>/<YYYYMM>-compare.csv`.

## Notes

final_comparison_report



vector_new,year,month,status
v123,1980,1,1
v123,1980,2,1
..
v123,1999,10,0


vectors_to_exclude

vector_new,start_year, start_month,end_year,  end_month
v123,1999-10-01,2099-01-1


/VALIDATION/ndm_000050_exclude/ndm_000050_exclude.csv
/VALIDATION/ndm_000052_exclude/ndm_000050_exclude.csv
/VALIDATION/ndm_000053_exclude/ndm_000050_exclude.csv


Note: this doesn't apply to tables 51 and 54 because no comparison to make with old tables
