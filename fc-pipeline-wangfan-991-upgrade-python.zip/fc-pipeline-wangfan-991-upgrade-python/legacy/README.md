# Overview

This folder is a home for legacy code/scripts/documentation that were used for temporary/one-time tasks during development. There may be a need to refer back to these scripts and/or reuse them at some point. However, by default, they are not part of the system.