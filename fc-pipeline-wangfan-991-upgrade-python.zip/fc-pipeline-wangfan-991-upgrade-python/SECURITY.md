# Security

**Do not post any security issues on the public repository!** Security vulnerabilities must be reported by email to <insert appropriate email here>.

______________________

## Sécurité

**Ne publiez aucun problème de sécurité sur le dépôt publique!** Les vulnérabilités de sécurité doivent être signalées par courriel à <insert appropriate email here>.