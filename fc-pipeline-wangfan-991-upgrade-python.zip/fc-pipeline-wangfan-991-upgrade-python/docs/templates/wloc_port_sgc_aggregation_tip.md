!!! tip
    `port` is a more fine-grained level of aggregation than `sgc_code` (province code), but a more course-grained level of aggregation than `work_location`.

    I.e. many work locations exist under a port, and many ports exist under a province.