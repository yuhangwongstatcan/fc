This page details how to set up a development environment on the cloud main workstations.

# Install Windows Subsystem for Linux 2 (WSL2)

See [instructions to install WSL2](https://docs.microsoft.com/en-us/windows/wsl/install).

# Install conda

In order to install and manage the Python virtual environment for this project, we make use of [conda](https://docs.conda.io/en/latest/).

Please see the [instructions to install conda](https://docs.conda.io/projects/conda/en/latest/user-guide/install/linux.html).

# Install VSCode in client-server mode

Since WSL2 runs the linux operating system without a window manager, you need to use the Windows Client for VSCode along with VSCode server running in WSL2.

See [instructions to set up VSCode on WSL2](https://code.visualstudio.com/blogs/2019/09/03/wsl2) - this guide also covers setting up the WSL2 extension for VSCode.

!!! tip
    You should always open VSCode at the project root. You can do this easily by navigating to the root of the git repository and running `code .`. Certain IDE features (e.g. VSCode debugger) assume that VSCode was opened in the project root.

# Useful VSCode Extensions

There are a number of VScode extensions that make development easier. To install any of the extensions below, simply search for them in the VSCode Extensions tab and click "install".

- Bracket Pair Colorizer
- VSCode Python Extension
- ENV extension (for syntax highlighting in .env files)
- HashiCorp Terraform (for editing *.tf files)
- Makefile tools
- Rainbow CSV (makes it easier to see column structure in CSV files)
- Official Redhat extension (includes yaml syntax highlighting + autocomplete among other utilities)

# Connect to Dev/Test/Prod SDLC Kubernetes Clusters

See [instructions to connect to SDLC clusters]({{fc_baseurl.doc}}/getting_started/sdlc-k8s-clusters).

# Setting up Frontier Counts Development Environment

There are a few project-specific setup steps required to do development tasks in Frontier Counts.

## Set up `.env` file

In the `src` folder, there is a file called `default.env` that contains the environment variables without sensitive values set. The purpose of this file is to serve as a template for the real `.env` file for the project, which is gitignored by default (see the `.gitignore` file at the top of the project repo for list of gitignored files).

Note that our application creates [Pydantic](https://pydantic-docs.helpmanual.io/) models for the environment variables.

Environment variables already present in the process have the highest priority. If an environment variable is expected, but not set, then the application looks to the `.env` file to see if there is a value set. Finally, if there is a default specified in the Pydantic model, the default is used. If the environment variable is required and cannot be found anywhere, then Pydantic will crash the application, indicating the absence of a required environment variable.

See below for an explanation of what each environment variable does (also available in `src/default.env`).

```
--8<-- "src/default.env"
```

See the [kubernetes deployment documentation]({{fc_baseurl.doc}}/deployment/helm_chart) to see how each of these variables is set.

In order to set yourself up to have access to S3Proxy queries, you'll have to set up the S3PROXY_ACCESS_KEY and S3PROXY_SECRET_KEY variables. These access keys will be unique to everyone and should not be shared. You can generate your secret key and access key, if you have the proper permissions, with the following command: 

```
kubectl get secret -n frontiercounts frontier-counts-s3proxy -o jsonpath='{.data.access_key}' | base64 --decode && echo && kubectl get secret -n frontiercounts frontier-counts-s3proxy -o jsonpath='{.data.secret_key}' | base64 --decode && echo
```

Keep in mind that you'll need to have set up your access to the Kubernetes clusters and have made sure that kubectl works for you for this to work.

!!! note
    I recommend creating two blocks in the `.env` file: one for the dev cluster, and one for the prod cluster. That way, when you need to change contexts, you can simply comment/uncomment the appropriate block of the `.env` file rather than having to keep track of which changes need to be made.

## Set up launch.json file

See the [VSCode Debugger Docs](https://code.visualstudio.com/docs/editor/debugging) for more general information about debugging in VSCode.

The `.vscode/launch.json` file is used by VSCode to specify the entrypoint, arguments, and configuration to debug a particular program. In this project, we include a `.vscode/default.launch.json` file as a template for the most commonly used entrypoints. To make use of this, simply copy + paste the contents of `.vscode/default.launch.json` to a file called `.vscode/launch.json` and set/change any variables as appropriate.

!!! tip
    You will notice that each program is specifeid where `cwd` and `program` are respectively set to `${workspaceFolder}/src/` and the name of the CLI program entrypoint. All entrypoint programs in this project exist at the top level of the `src` folder, and the import structure of all of the project code assumes that the python process will start in the `src` folder. This setup adheres to the recommended way of writing Python programs. As long as you open VSCode in the project root (`fc-pipeline`) and make all entrypoint programs at the top-level of `src`, everything should work correctly.


Note that the intended workflow is that you change the `"args"` array to whatever CLI arguments are appropriate for the given debugging use case.

Additional less common/legacy debug configuration has been included in `.vscode/legacy.launch.json`. This configuration may never be needed. Nevertheless, it is included on the off-chance that these legacy programs need to be run again.

# Connect to Kubernetes from the Cloud Workstation.

See the documentation for [connecting to the SDLC kubernetes clusters clusters]({{fc_baseurl.doc}}/getting_started/sdlc-k8s-clusters) for instructions on how to connect to the SDLC clusters.

Once you have connected to the appropriate clusters, I recommend using the tool [k9s](https://k9scli.io/) for local kubernetes work. There are other Kubernetes development tools such as [Lens](https://k8slens.dev/), if you prefer a GUI-style IDE rather than a command-line environment for working with Kubernetes.

Additionally, I like to use a terminal multiplexor program like [Byobu](https://www.byobu.org/) to have many terminal windows open simultaneously. I include a screenshot below of my preferred terminal setup while working on the Frontier Counts system.

![k9s setup](../img/development_environment/k9s_setup.PNG)

Details around managing the Kubernetes deployment can be found in the [kubernetes documentation]({{fc_baseurl.doc}}/deployment/overview) for this project.
