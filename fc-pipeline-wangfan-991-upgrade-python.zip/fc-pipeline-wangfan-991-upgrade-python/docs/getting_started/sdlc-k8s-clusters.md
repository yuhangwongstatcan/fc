# Connect to the Cloud Main Kubernetes Clusters

**Related Jira Ticket(s)**: https://jirab.statcan.ca/browse/CLOUD-11326

## Instructions

In order to connect to the Cloud Main Kubernetes Clusters you will need to install:

- [Kubectl](https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/) (just follow the installation instructions, setup is below)
- [Kubelogin](https://azure.github.io/kubelogin/install.html)

See the JSON files at the following URLs for each of the dev/test/prod SDLC clusters

- [dev cluster](https://gitlab.k8s.cloud.statcan.ca/cloudnative/aks-engine/k8s-cancentral-01-dev-shared/-/blob/master/kubeconfig.canadacentral.json)
- [test cluster](https://gitlab.k8s.cloud.statcan.ca/cloudnative/aks-engine/k8s-cancentral-01-test-shared/-/blob/master/kubeconfig.canadacentral.json)
- [prod cluster](https://gitlab.k8s.cloud.statcan.ca/cloudnative/aks-engine/k8s-cancentral-01-production-shared/-/blob/master/kubeconfig.canadacentral.json)

Download these locally and add their paths to the [KUBECONFIG](https://kubernetes.io/docs/tasks/access-application-cluster/configure-access-multiple-clusters/#set-the-kubeconfig-environment-variable) variable. E.g.

```bash
export KUBECONFIG=$HOME/.kube/sdlc/k8s-cancentral-01-development.json:$HOME/.kube/sdlc/k8s-cancentral-01-test.json:$HOME/.kube/sdlc/k8s-cancentral-01-production.json
```

Once you have the `KUBECONFIG` environment variable pointing to each of the configuration files above, do something like

```bash
kubectl config view > $HOME/.kube/main_config
```

to get all of the configuration data into a single configuration file.


With the approach above, the configuration file will print the cluster certificate authority data fields as `DATA+OMITTED`. To fix this, go to the `main_config` file created above and replace the certificate authority values with those found in the three JSON files linked at the beginning of this page.

Last, add the following line to your `$HOME/.bashrc` file: `export KUBECONFIG=$HOME/.kube/main_config`. If you open a new terminal or `source $HOME/.bashrc`, the updated `KUBECONFIG` variable should be set to the correct value.

You will now need to use Kubelogin to convert your configuration file to a version compatible with the SDLC clusters. Follow the instructions [here](https://azure.github.io/kubelogin/concepts/login-modes/devicecode.html) to update your kubernetes configuration. 

!!! tip
    The methods necessary to update your configuration file might change as the Cloud Native team makes updates to the clusters. If you're having difficulty updating your configuration file or connecting to the clusters, submit a ticket to the Cloud Jira. 

If you do `kubectx` (if you have it installed, see [install kubectx](https://github.com/ahmetb/kubectx#installation)), or `kubectl config get-contexts`, you should now see a printout indicating the 3 clusters you can connect to.

!!! tip
    If you have permissions issues when trying to connect to the clusters you may be in the wrong namespace.
    
    You probably won't be given access to the default namespace and will only have permissions on the frontiercounts namespace. 
    
    Try setting your configuration properly using: `kubectl config set-context --curent --namespace=frontiercounts` 
