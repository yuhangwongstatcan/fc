Since Frontier Counts is a monthly survey, there are a series of recurring business events that the production team does each month. This section of the documentation outlines these events and their associated timelines so that development and maintenance activities can be planned accordingly.

There is a detailed schedule at the following file system location on the Network A filers:

```
\\fld8filer.statcan.ca\Frontier_Counts\1710_FC_Monthly_Processing\1722_Schedule_Production\Production Schedules.xlsx
```

The sections below highlight a few key dates on this schedule.

# Key Recurring Dates

- **4th of the Month**: The `ipil_hwy` raw data are received from CBSA.
- **15th of the Month**: The raw data for `nexus_air` and `nexus_hwy` are received from CBSA.
- **After 15th of the Month**: There is a **cutoff** day for `e311` data received from the OID division at StatCan.
- **After the cutoff day**: There is a window of time each month where it is acceptable for the `prod` and `prod-alpha` releases of the Frontier Counts system on the SDLC production cluster to be down for 1-2 business days. If any maintenance or feature development is required, this would be a good time to perform such activities.
- **After all of the above activities**: Once per month, the maintainer needs to synchronize the production instance of [MinIO]({{fc_baseurl.doc}}/minio/overview) with [Mock MinIO]({{fc_baseurl.doc}}/minio/mock_minio), and then push the reconciled data in Mock MinIO to the prod-alpha and development releases of MinIO. The Mock MinIO documentation linked above describes how to do this synchronization task.

# High-Level Monthly Production Overview

This section provides a high-level overview of the end-to-end monthly production process.

# Loading Step

The process starts when CBSA transfers files throughout the month from a variety of data sources from their network to StatCan’s internal network. When these files are received, they are moved from the Network A filesystem to MinIO by a Production user of the system via network attached storage on the cloud workstations.

Once files arrive in the inbox, they are triaged to the appropriate storage prefix based on one of
the following scenarios:

1. The file is in conflict with an existing file (in which case it is triaged to a conflicts location)

2. The name of the file does not match any of the expected naming patterns (in which case
it is triaged to an errors location)

3. The file is received successfully and moved to the appropriate storage location.


A basic versioning system is in place that maintains a set of “historical” locations that can be
used to view previous versions of the same file for previously resolved conflicts.

# Pipeline Steps

The bulk of data processing happens during this step, and each data source has its own data
processing pipelines.

Pipelines sit between different **stages** of processing. In particular, we define 4 such stages:

1. **RAW** - this is the data in the form that it is recieved by CBSA with minimal processing applied. Any data sources that arrive in unusual formats (e.g. Microsoft Excel, HTML reports, etc.) are converted into a **CSV** file with the equivalent data.
2. **CLEAN** - this is the RAW data with some basic pre-processing applied (e.g. removing records, recoding certain row/column combinations, statistical/deterministic imputation, etc.). CLEAN data maintain the original schema of the data that CBSA sent us for that data source.
3. **TRANSFORMED** - this has the contents of the corresponding CLEAN data, but with the schema and level of aggregation changed to the [vehicles]({{fc_baseurl.doc}}/datasource/vehicles/overview) and [travellers]({{fc_baseurl.doc}}/datasource/travellers/overview) tables that the Frontier Counts program produces. For example, the `ipil_hwy` data source contains a set of columns and rows at the microdata level (i.e. one row = one vehicle crossing at a port of entry), while the `nexus_hwy` data source contains a different set of columns and data are already aggregated. We create two TRANSFORMED files for each of these CLEAN files - one called `vehicles.csv.ipil_hwy` and `vehicles.csv.nexus_hwy`, where both of these files have the **same** schema and level of aggregation. The common level of aggregation is achieved by mapping all original data source columns to the standard `vehicles` and `travellers` columns, and then applying the `SUM` aggregation to the `count_of_entries` column, grouped by every other column.
4. **AGGREGATED** - this contains only data sources that have been aggregated to the level of the `vehicles`/`travellers` tables, or an even higher level of aggregation (e.g. NDM tables).

At a high level, the pipeline codebase consists of the following components:

1. For each data source:
    1. A set of business logic specific to each data source. Implemented as many functions that accept a main data frame, and return a mutated dataframe.
    2. A set of so-called validations that produce data about the processing job itself. The output of these validations are uploaded to a MinIO prefix called `/validation` through our MinIO client. The validation data corresponds to a particular validation for a given processing step in a given pipeline run.
    3. A pipeline function that accepts an input pandas DataFrame and a set of arguments, and returns the modified dataframe after all of the business logic functions have been applied. The main purpose of this pipeline function is to compose (pipe together) many small pieces of business logic.
    4. Various configuration data for various components of the application. The majority of configuration data in the application have a corresponding object layer to avoid hard-coding any configuration details throughout the application.
2. A command line interface (CLI) for the application that allows the caller to specify a data
source, a stage of processing, and a time period they want to run the pipeline for. This CLI is the
entrypoint to run the pipeline for any data source, for any stage, for any time period.
3. A series of utility functions that create and submit Argo Workflows for each data source/stage/date combination.
4. A MinIO python client to handle all communication with MinIO object storage in the
pipeline code. Given a data source and a date for the data source, the MinIO client
manages all details about which input data sources are used and where new data
should be written to.
5. A test suite containing unit tests and integration tests for each of the pipeline
components. There is a main test runner and some configuration data for each test.
6. A small web application that provides a non-programming user interface so that the production team can
interact with the various components of this system.

# Aggregation Steps

The aggregation steps are implemented with the same pipelines described above. However, we detail them in their own section as there is some aggregation-specific logic that happens.

Many data sources each run through their own data processing pipeline from RAW --> CLEAN and CLEAN --> TRANSFORMED. At the end of each data source’s pipeline, at least one of two output tables are produced: one called [vehicles]({{fc_baseurl.doc}}/datasource/vehicles/overview) and one called [travellers]({{fc_baseurl.doc}}/datasource/travellers/overview). The purpose of these two tables is to standardize each data source’s contribution to the two final tables produced by this system (also called `vehicles` and `travellers`). The vehicles table produces an aggregation over rows where the unit of observation is an individual vehicle. The travellers table produces an aggregation over rows where the unit of observation is an individual traveller.

Once all of the pipelines have finished running, all of the vehicles and travellers tables produced for each data source must be aggregated into a single table. In other words, the output will be one aggregated vehicles table that aggregates the contributions from all data sources, and one aggregated travellers table that aggregates the contributions from all data sources.

Note that these tables **can** be very large because many columns are included in the `GROUP BY` clause of the aggregation (e.g. 195 countries x 170 work locations x 30 days in a month x …). However, the overwhelming majority of combinations of variables won’t actually exist in the data, so the practical upper bound for the size of these tables is on the order of the number of rows in the source data.

While the aggregation procedure described above constitutes the primary workflow, there are additional aggregation steps required to provide specific "views" over these tables for
downstream business purposes. These views, however, are always based off of the vehicles and travellers tables described above. As a technical note, these "views" are not actually implemented as a logical view over a table the way one might do in a SQL RDBMS. Instead, they are actual data files that get created and stored separately in the system. For example, the [NDM tables]({{fc_baseurl.doc}}/datasource/ndm/overview) that are produced by the Frontier Counts system are separate data files that are stored in CSV format and exported from the system. There are some additional pieces of business logic that happen in this aggregation process, such as confidentiality requirements (censoring the two Windsor bridges into a single port of entry, for instance), but the core purpose of the aggregation steps is what is described above.

# Seasonal Adjustment Step

Once the final aggregated vehicles/travellers tables are produced, a table called [sa_in]({{fc_baseurl.doc}}/datasource/ndm/overview) is produced, and there is a seasonal adjustment step where a time series model is used to correct this data for seasonality. **Note**: the output of this seasonal adjustment is a separate set of tables that receives its own dedicated storage location (so-called [`ndm_adjusted`]({{fc_baseurl.doc}}/datasource/ndm/overview)).

There is a group within Statistics Canada (Time Series Resource Centre in ESMD) who is responsible for time series modelling, and their current implementation is written in SAS. We were told that it would be infeasible to re-implement this logic in the scope of the Frontier Counts system redesign project, and at the time of development, we could not run SAS in any cloud environment due to licensing issues.

Therefore, there is a manual step in this process where someone downloads the aggregated tables mentioned above onto an on-prem machine, runs the existing SAS code to perform this seasonal adjustment task, and re-uploads this dataset back to our MinIO object storage. At this point, the loader workflow ("check inbox") mentioned earlier in this document moves the seasonally adjusted dataset to its correct location.