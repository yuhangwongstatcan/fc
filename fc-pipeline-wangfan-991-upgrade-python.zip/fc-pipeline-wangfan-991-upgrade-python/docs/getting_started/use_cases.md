This documentation presents a high level overview of the primary use cases in the Frontier Counts system, along with the application components that are involved in each. Note that this documentation may make more sense if the reader has first viewed the [Monthly Production Overview]({{fc_baseurl.doc}}/getting_started/monthly_production_overview) documentation.

!!! note
    Any data shown on this page (e.g. in screenshots) are **synthetic** (fake) data that were generated for the purpose of testing the Frontier Counts system. No real (production) data are disclosed in this documentation.

The table below highlights each CLI program that is discussed in this document, for what purpose it is used, and links to relevant documentation where applicable.

| CLI Script Name                        | Description                                                                                                                                                                                                              | Related Documentation                                                                                                                                                                              |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `loader.py`                            | Implements the **Check Inbox** function shown in the diagram above.                                                                                                                                                      | The [Loader docs]({{fc_baseurl.doc}}/loaders/overview.md) explain how this CLI program works in greater detail.                                                                                       |
| `run_pipeline.py`                      | The main CLI program that runs all of the data processing pipelines in the Frontier Counts system.                                                                                                                       | The [Data Source]({{fc_baseurl.doc}}/datasource/overview.md) and [Test]({{fc_baseurl.doc}}/tests/unit_test_framework.md) documentation details how each piece of business/validation logic is implemented + tested. |
| `sa_in.py`                             | Implements the **Seasonal Adjustment** functionality where `sa_in.csv` data are produced                                                                                                                                 | The [NDM Documentation]({{fc_baseurl.doc}}/datasource/ndm/overview.md) has information about how the `sa_in.csv` tables are produced.                                                                          |
| `release.py`                           | Implements the **Sign Off** functionality on the webapp dashboard page.                                                                                                                                                  | A section on this page of the documentation details how this part of the system works.                                                                                                             |
| `generate_leading_indicator_report.py` | Creates the so-called **Leading Indicator** report that the Frontier Counts production team uses to validate the data for the "leading release" of the system.                                                                 | The [Leading Indicator Report docs]({{fc_baseurl.doc}}/datasource/ndm/leading_indicator_report.md) outline the use + purpose of this report.                                                              |
| `data_integrity.py`                    | Creates the so-called **Data Integrity** report that the Frontier Counts production team uses to ensure the data output from the system is internally consistent.                                                              | The [Data Integrity Report docs]({{fc_baseurl.doc}}/datasource/ndm/data_integrity.md) outline the use + purpose of this report.                                                                           |
| `ndm_integrity.py`                     | Creates the so-called **NDM Integrity** report that the Frontier Counts production team uses to ensure the NDM tables produced by the system do not contain any aggregations where the sum of the parts don't equal the total. | The [NDM Integrity Report docs]({{fc_baseurl.doc}}/reference/ndm_integrity.md) outline the use + purpose of this report.                                                                             |
| `ndm_prepare_outbox.py`                | Moves a certain number of months for each NDM table to the `/outbox` location, where a Frontier Counts production team member can download and place on Network A so that these files can be ingested into the NDM system.         | This page details A section on this page of the documentation details how this part of the system works.                                                                                           |

# Check Inbox Overview

Throughout each month, CBSA sends files from various data sources to the Frontier Counts production team. Upon reception of the files, a production team member will place the files into the `/inbox` location in MinIO and press the **Check Inbox** button on the dashboard page of the web application. When this button is pressed, a request is sent to the `/check_inbox` route of the web application, the definition of which can be found in `src/webapp/controllers/ctrl_dashboard.py`. The function `modules.argo.argo_entrypoint` - which is detailed further in the **Data Processing Pipeline** section of this page - is used to send a workflow spec to Argo Workflows API server, which in turn creates an argo workflow whose entrypoint is `python3 loader.py --check-inbox`. The [Loader docs]({{fc_baseurl.doc}}/loaders/overview) explain how exactly this is implemented, but in short, any files in the `/inbox` location are triaged to either (1) an `/unknown/*` location if the file name does not match any expected patterns (2) an `/error/*` location if there was an error processing the input data or (3) an appropriate `RAW`, `CLEAN`, `TRANSFORMED`, or `AGGREGATED` location, depending on the details of the particular data source's loader.

# Data Processing Pipeline Overview

All data processing pipelines in the Frontier Counts system can be invoked with the `src/run_pipeline.py` CLI program. The pipeline codebase can be found in `src/datasource`, where each datasource is its own python module that is named after the data source that the module code applies to. For example, the `datasource.ipil_hwy` module has code that implements business logic, validation logic, and the `datasource.ipil_hwy.pipeline` module that assembles the various business logic and validation logic functions together.

Any pipeline instance is run as an Argo Workflow pod on the SDLC kubernetes cluster that the Frontier Counts system is deployed to. At a high level, the steps that a production user takes to create an Argo Workflow are as follows.

-  A user uses the menu on the dashboard page of the web application to select workflow details. In particular, they typically either submit a **composite pipeline** or a regular **data pipeline**. They can choose several parameters such as the name of the data source they want to run the pipeline for, the pipeline class that they want to run, and the date they want to run the pipeline for. Note: a "pipeline class" simply identifies which stages of processing a pipeline sits between - e.g. a pipeline may sit between the RAW and CLEAN stages of processing. More high-level information about what the data processing pipelines are doing can be found in the [monthly production overview]({{fc_baseurl.doc}}/getting_started/monthly_production_overview) documentation.

![Frontier Counts dashboard page](../img/architecture/dashboard-pipeline-workflow.PNG)

- Once the user clicks the **Execute Composite Data Pipeline** or **Execute Data Pipeline** button on the web UI, a request is sent to either the `/run_pipeline` or `/run_sequential_pipeline` routes of the web application; the definition of these routes can be found in `src/webapp/controllers/ctrl_dashboard.py`. The functions `argo_entrypoint` and `argo_dag_entrypoint`, respectively, submit either a single workflow or a composite workflow - the definition of these two functions can be found in `src/modules/argo.py`. More detailed documentation on the web application can be found in the [Frontier Counts webapp documentation]({{fc_baseurl.doc}}/webapp/index) and more detailed information about Argo Workflows can be found in the [Frontier Counts Argo Workflows]({{fc_baseurl.doc}}/deployment/argo_workflows).

- Finally, the `argo_entrypoint` and `argo_dag_entrypoint` functions actually connect to the Argo Workflow API server using the [Python SDK for Argo Workflows](https://pypi.org/project/argo-workflows/) to create a client, then submit the appropriate workflow spec to the Argo Workflows API server. At this point, Argo creates an Argo Workflow pod, using the Frontier Counts container image that is pushed to [artifactory](https://artifactory.cloud.statcan.ca/) during our [Gitlab CI pipeline]({{fc_baseurl.doc}}/deployment/gitlab_ci). The entrypoint to our container image is simply `python3 <CLI script name> <CLI script args>` where the script name and args are passed dynamically in our workflow spec as parameters.

**Note**: there exist multiple other CLI programs other than `run_pipeline.py` that run workflows on behalf of users and what they submit in the webapp. That being said, the workflow described above applies to each of them. The table below details each CLI program that gets used in Argo Workflows that are submitted from the web app.

# Seasonal Adjustment Overview

At a certain point in the month, two data sources called `ndm_unadjusted` and `sa_in` are produced by the Frontier Counts system. These AGGREGATED tables are derrived from the  [travellers_main]({{fc_baseurl.doc}}/datasource/travellers/overview.md) and [vehicles_main]({{fc_baseurl.doc}}/datsource/vehicles/overview.md) tables. Additional detail about these data sources can be found in the [NDM documentation]({{fc_baseurl.doc}}/datasource/ndm/overview.md). The `sa_in` data source consists of a number of time series data points that need to be seasonally adjusted by a team at StatCan who perform time series workflows such as adjusting for seasonal trends. Since this workflow happens outside of the Frontier Counts system, the `sa_in` data needs to be moved to the `/outbox` location so that a Frontier Counts production team member can move it to an on-prem location for the time series team to access. In particular, since this is time-series data, all of the data since **2010-01-01** (a configurable date provided to us by the Frontier Counts production team) needs to be sent to the time series team along with the current month's data.

![Frontier Counts dashboard page](../img/architecture/dashboard-sa-in-workflow.PNG)

The above description is performed by a member of the Frontier Counts production team by entering data into the **Seasonal Adjustment** form of the Dashboard page of the web application. There are 3 parameters called `periods`, `force`, and `date` which are provided by the Frontier Counts production team member who submits the form (these are used in a second file that appears in `/outbox` called `SA_PARAMETERS.csv` which is also needed by the Time Series adjustment team). The interpretation of these parameters is out of scope for this project - they simply need to be provided to the Time Series team and the meaning of the parameters is negotiated between the Frontier Counts production team and the Time Series team. The IT maintainer(s) of this project may simply regard these as user-defined parameters that must be forwarded to the `/outbox` location.

Once the user presses **Execute Seasonal Adjustment**, a request is sent to the `/run_sa` route defined in `src/webapp/controllers/ctrl_dashboard.py`. The parameters are forwarded to `argo_entrypoint` - the details here are largely similar to what was described in the previous section of the documentation. The entrypoint that the Seasonal Adjustment Argo Workflow
runs with is `python3 sa_in.py --num-periods <user specified number of periods> --force <user specified value> --date <user specified date>` where, of course, the three user defined parameters are subtituted in the indicated locations.

When this workflow completes, two files will be present in the `/outbox` location in MinIO: `SA_IN.csv` and `SA_PARAMETERS.csv`.

# Sign Off Overview

There are four kinds of "releases" that happen with the system: **leading pre-release**, **leading release**, **main pre-release**, **main release**. These releases differ in the scope of data released, the timing at which it is released, and the audience who may view the released data. The details of these releases are largely handled by the Frontier Counts production team. This section of the documentation outlines the components that are relevant to the Frontier Counts system.

!!! note
    Although the workflows described in this section are called **releases**, no data is actually released in these workflows per se. There is a separate manual process (see TODO item below) that the Frontier Counts team members go through to actually disseminate this data to users outside of the Tourism team.

Each of the four release workflows are manually triggered by a Frontier Counts production team member on the appropriate dates using the dashboard page of the webapp. The Argo Workflows themselves only read/write to the MinIO instance deployed in the `production` SDLC kubernetes cluster, which is backed by the `frontiercountsblobprod` Azure storage account. In other words, the copying of data to the `/pre-release` and `/release` locations are only visible to the people who already have access to the `frontiercountsblobprod` storage account, which is just the Tourism production team.

--8<-- "docs/templates/azure_obj_replication_admonition.md"

![Sign Off (Release) Workflow](../img/architecture/dashboard-sign-off-workflow.PNG)

The `release.py` CLI program simply takes a year, a month, and one of four parameters indicating which release is happening. Each of the four releases is configured to copy certain S3 objects to either the `/pre-release` or `/release` locations on MinIO. The Argo workflow that runs one of these releases will have an entrypoint such as `python3 release.py --year 2022 --month 1 --leading-pre-release`. The user simply selects the date along with the kind of release they want to perform using the web app form on the dashboard page, and presses **Execute Sign Off**. The request from submitting this form goes to the `/run_sign_off` route of the webapp, which submits a workflow using `modules.argo.argo_entrypoint` in the same way described in previous sections of this page.

# Data Integrity Report Overview

Once the AGGREGATED [travellers]({{fc_baseurl.doc}}/travellers) and [vehicles]({{fc_baseurl.doc}}/vehicles) tables are created, the production team runs the so-called data integrity report to ensure that various properties and invariants of the travellers and vehicles tables hold true before moving onto the next stage of processing. In the event that something unexpected happens that is flagged by the data integrity report, the Frontier Counts production team will investigate the issue and re-run the necessary pipelines on the revised data.

The CLI program `data_integrity.py` contains all of the business logic to generate this report.  The [Data Integrity Report]({{fc_baseurl.doc}}/datasource/data_integrity) documentation goes into more detail with respect to the various business logic that this CLI program performs.

The outputs of this report are broken into two parts, and again broken into four additional parts. First, there is a distinction between `travellers` and `vehicles`. Second, for each of `travellers` and `vehicles`, there are `geographical_based_validations`, `misc_validations`, `time_based_validations`, and `type_based_validations`. In total, there are eight different paths under which data integrity validations may be written:

- `/validation/travellers/geographical_based_validations/<year>/<month>/<timestamp>.csv`
- `/validation/travellers/misc_validations/<year>/<month>/<timestamp>.csv`
- `/validation/travellers/time_based_validations/<year>/<month>/<timestamp>.csv`
- `/validation/travellers/type_based_validations/<year>/<month>/<timestamp>.csv`
- `/validation/vehicles/geographical_based_validations/<year>/<month>/<timestamp>.csv`
- `/validation/vehicles/misc_validations/<year>/<month>/<timestamp>.csv`
- `/validation/vehicles/time_based_validations/<year>/<month>/<timestamp>.csv`
- `/validation/vehicles/type_based_validations/<year>/<month>/<timestamp>.csv`

The Frontier Counts production team has a PowerBI dashboard that visualizes this validation data so that they can more easily interpret the results of these validations. This PowerBI dashboard is managed entirely by the Tourism team.

![validation widget dashboard](../img/architecture/dashboard-validation-workflow.PNG)

To create this validation data, a Frontier Counts production team member chooses the `data_integrity` validation from the `Validations` form and specifies the date which the validation applies. When the user presses **Execute Validation**, the request goes to the `/run_ndm_validation` route of the web application, which uses `modules.argo.argo_entrypoint` to submit the appropriate workflow in the same way described in previous sections of this page.

# Generate Leading Indicator Report Overview

Once the various **leading** tables are created, the Frontier Counts production team needs to perform a series of validations against them (i.e. `travellers_leading` and `vehicles_leading` (see [travellers]({{fc_baseurl.doc}}/travellers) and [vehicles]({{fc_baseurl.doc}}/vehicles)) documentation for more information about these tables).

The CLI program `generate_leading_indicator_report.py` contains all of the business logic required to check the various conditions that the Frontier Counts production team needs to verify about the leading tables before releasing them in the leading releases. The [Leading Indicator Report]({{fc_baseurl.doc}}/datasource/leading_indicator_report) documentation has more detail about the specs of everything that is generated with this report.

![Leading Indicator Workflow](../img/architecture/dashboard-leading-indicator-workflow.PNG)

The outputs of this report can be found in MinIO in the `/validation/leading_indicator/<year>/<month>` location. Users create this report by running the **Leading Indicator** form on the dashboard page of the web application. The request from submitting this form goes to the `/run_leading_indicator` route in the web app, which uses `modules.argo.argo_entrypoint` to submit the appropriate workflow in the same way described in previous sections of this page.

# NDM Integrity Report Overview

Once the [NDM tables]({{fc_baseurl.doc}}/datasource/ndm) have been produced by the system, the `ndm_integrity.py` CLI program ensures that the values of each NDM table are internally consistent with respect to a series of known checks. Additionally, a series of so-called **between tables** validations are performed to ensure that values that need to align between tables are correct. The [NDM Integrity Report]({{fc_baseurl.doc}}/datasource/ndm_integrity) documentation elaborates on the business requirements of this report in greater detail.

The output from the ndm integrity validations is written to a location of the form `/validation/ndm_<table number>/<year>/<mont>/<year>-<month>-ndm_integrity-<timestamp>.csv` where `<table number>` corresponds to the particular NDM table number that the system publishes and the other fields are self explanatory. The NDM tables documentation linked in the previous paragraph has more information about each NDM table number and what data it corresponds to.

The Frontier Counts production team runs the NDM Integrity report the same way they run the Data Integrity report described in an earlier section of this page. The only difference is that they select `ndm_integrity` rather than `data_integrity` in the webapp dashboard menu.

# NDM Prepare Outbox Overview

The very last stage before data are exported from the Frontier Counts system is to run the **NDM Prepare Outbox** CLI program, implemented in `ndm_prepare_outbox.py`.

This workflow is invoked by submitting the **NDM Prepare Outbox** form on the dashboard page of the web application. Note that this triggers a [Composite Workflow]({{fc_baseurl.doc}}//deployment/argo_workflows/#application-specific-configuration-for-composite-workflows) that moves the appropriate files for each NDM table into the `/outbox` location on MinIO. There is a user-specified parameter called **Periods** which indicates how many months **excluding the current month of the date specified** to include for **seasonally adjusted** NDM tables. The reason that this **Periods** parameter is required is that seasonally adjustment, by its nature, updates many periods of data at once. As such, the Frontier Counts production team has decided on a number of seasonal adjustment periods to *retroactively* update for historical data.

# Conflicts Viewer

Users of the system will sometimes use the web application to view conflicts that are created when processing the same data source multiple times. For example, CBSA may send a data source, realize that a number of rows are missing, and send a second copy of the data source with the ammended rows. The production team would place the ammended file in the `/inbox` S3 location and run the **Check Inbox** program, which will realize that the same stage, data source, year, and month are already stored in the system, and create a conflicting entry. The dashboard page of the web application will indicate that a conflict was created from the pipeline run in the **Status** column, which will prompt the user to take an action to resolve the conflict.

![conflicts dashboard](../img/architecture/conflicts-dashboard.PNG)

Users can view conflicts by clicking **Conflicts** --> **<Stage>** and searching for the year they want to view conflicts for. For example, the screenshot below shows the user searching for a conflict to the **IPIL_HWY** data source for December 1, 2020.

![conflicts explorer](../img/architecture/conflicts-explorer.PNG)

Once the user clicks the file they want to resolve conflicts for, they can use the interactive toggles to restrict the view to duplicates, missing values, new entries, or conflict entries. They can instruct the application to accept the conflict, reject the conflict, or perform a simple merge of the two files. If a more intricate edit is required, the user can download the new file, the original file, or both, then make any edits locally and upload the new resolved file to `/inbox` then run **Check Inbox**.

![conflicts viewer](../img/architecture/conflicts-viewer.PNG)

# Historical Viewer

By default, the system will maintain all historical versions of files on the system so they can be revisited at a later date. If a user ever needs to revert back to a previous version of the data, they can do so through the web app as follows.

![historical viewer](../img/architecture/historical-viewer.PNG)

If the user selects the date/time corresponding to the version they want to revert to, the user can simply click the appropriate entry, then click the **Rollback to Version** button. Note that the active version has an asterisk beside the time. This will replace the chosen historical version as the current version and archive the current version as a historical version.

# Manual Entry - Data Capture

A portion of the data in the Frontier Counts system requires a Frontier Counts production team member to manually specify some data received by CBSA. Additional detail about how the manual entry data source works can be found in the [Manual Entry Overview]({{fc_baseurl.doc}}/datasource/manual_entry/overview) documentation.

![manual entry data capture](../img/architecture/manual-entry-data-capture.PNG)

The user enters a variety of fields and presses **Submit**. The request is received on the `/capture` route defined in the `src/webapp/views.py` file. A series of validations are performed on the submitted data. If there is an error, the page is re-rendered with the appropriate error message(s) displaying. If there is no error, the data are written to a single CSV file in `/raw/manual_entry_<travellers/vehicles>/year/month/` that has the naming convention `<port>-<data source>-<passenger type>-<country>-<date>-<timestamp>.csv`. Note that each month there will be on the order of 10-30 such submissions; we opted to use a single CSV file per submission as the number of records ingested with this method is quite small.

All of the raw files written to the previously mentioned location are concatenated as part of the **RAW** --> **CLEAN** pipeline for each of the `manual_entry_travellers` and `manual_entry_vehicles` data sources.

# Manual Entry - Fixed Rules

One of the imputations performed on manual entry data are so-called [Fixed Rules imputations]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_020). These specify fixed rules that take priority over imputation that is based on drawing from reference distributions. To specify such rules, users can enter data in the Fixed Proportion Rules form, shown in the screenshot below.

![manual entry fixed proportions](../img/architecture/manual-entry-fixed-proportions.PNG)

Users select the **Datasource** and **Port** to which the rule applies, the date range that the rule is valid from/to, and the fixed proportion variable that will be imputed using this rule. Users may also set an additional set of conditions that further restrict the cases to which the rule applies. Finally, the users choose the fixed proportions that define the probability of assignment to any particular fixed proportion variable value.

# Check Unit/Integration Test Status

The **Tests** tab in the Frontier Counts menu allows users to view the results of the unit/integration test suite through the webapp. The tests will run on the version of the code that is currently deployed on the webapp instance.

![test suite page](../img/architecture/test-suite-page.PNG)

The test suite runs automatically as part of the CI pipeline, but the Frontier Counts production team may wish to see the status of the test suite at any given time without needing to view a CI/CD pipeline in Gitlab.