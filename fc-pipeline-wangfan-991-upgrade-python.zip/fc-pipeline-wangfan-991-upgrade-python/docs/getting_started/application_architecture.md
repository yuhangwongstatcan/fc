This page outlines the application architecture at a high level. Note that the content of this page will probably make more sense if the reader has first viewed the [Monthly Production Overview]({{fc_baseurl.doc}}/getting_started/monthly_production_overview) and [Use Cases]({{fc_baseurl.doc}}/getting_started/use_cases) documentation.

# Architecture Overview

The Frontier Counts system is comprised of a small web application and a series of command line interface (CLI) programs that leverage S3-compatible object storage (a MinIO instance deployed in gateway mode, backed by Azure blob storage) as a data back-end, and Argo Workflows (deployed on the SDLC clusters as a managed service) as a workflow orchestrator.

![Application Architecture](../img/architecture/fc-diagram-2021-11-05.drawio.png)


# Pipeline Architecture/Organization

Upstream CBSA data always enters the Frontier Counts system through the `/inbox` prefix of our `fc-bucket` bucket. At the time of writing this documentation, Frontier Counts production users of the system drag and drop relevant files from Network A directly to the `/inbox` location in MinIO. In the future, however, this transfer of data may be automated at the level of Azure storage accounts.

![pipeline-context diagram](../img/architecture/pipeline-context.png)

A [loader / triage program]({{fc_baseurl.doc}}/loaders/overview) attempts to process each file that arrives in the `/inbox` location. It figures out which `loader` callback function to invoke based on pattern matching the file names received. For example, [IPIL_HWY]({{fc_baseurl.doc}}/datasource/ipil_hwy/overview) data has a distinct naming convention that can be used to identify that the `ipil_hwy` loader function located in `src/datasource/ipil_hwy/loader.py` should be used to process the matched files. Matched files are triaged to either to their intended stage/datasource/year/month combination, or to given `/conflicts`, `/error`, or `/historical` locations. The file will be written to `/conflcits` if a file of the same stage/datasource/year/month/name already exists and the fallback behaviour for that stage/datasource is to write a conflict. The user can then use the conflict resolution tooling built into the webapp (see [Conflicts Viewer Use Case documentation]({{fc_baseurl.doc}}/getting_started/use_cases/#conflicts-viewer)). The file will be written to `/historical` if a file of the same stage/datasource/year/month/name already exists and the fallback behaviour for that stage/datasource is to save a historical version of the record. If there is an error processing the file in the `/inbox` then the file that caused the processing error will be written to the `/error` location.

The data sources then make their way through a series of stages called **RAW**, **CLEAN**, **TRANSFORMED**, and **AGGREGATED**. The meaning of these stages are documented further in the [Pipeline Steps]({{fc_baseurl.doc}}/getting_started/monthly_production_overview/#pipeline-steps) documentation.

Once data are in the **AGGREGATED** stage, there are certain files that need to move to an on-prem location (see [Seasonal Adjustment Overview]({{fc_baseurl.doc}}/getting_started/use_cases/#seasonal-adjustment-overview) and [NDM Prepare Outbox Overview]({{fc_baseurl.doc}}/getting_started/use_cases/#ndm-prepare-outbox-overview) for more information about these processes).

The diagram above is slightly out of date, but the core idea is the same. Each of the workflows shown with the Docker/Python icon is implemented as an [Argo Workflow]({{fc_baseurl.doc}}/deployment/argo_workflows), which is an abstraction of a Kubernetes pod that is designed to be short-lived. More information about Argo Workflows can be found in the linked documentation. Our application code has a thin MinIO client which extends the base Python MinIO SDK with some application-specific functionality. It is through this MinIO client that we read/write data from MinIO as needed.

![individual workflow diagram](../img/architecture/individual-workflow.png)

The base image for each workflow is produced in the Gitlab CI pipeline and pushed to [artifactory](https://artifactory.cloud.statcan.ca/) under **Artifacts** --> **docker** --> `tourism-tourisme/frontier-counts`. This image is specified as part of the Kubernetes deployment in our [Helm Chart]({{fc_baseurl.doc}}/deployment/helm_chart) `values.yaml` file. Every component of the system that is implemented as an Argo Workflow has a Python CLI program that provides and entrypoint for execution. Every argo workflow takes a `script_name` parameter and a `cli_args` parameter which, respectively, specify which CLI program to run in the workflow and what CLI arguments/options to pass to that program.

!!! note
    The above diagram is slightly out of date. The three steps "Clone Gitlab Repo", "Create Python Virtual Environment (venv)", and "Install dependencies into venv" were historically done "on the fly" using a base `conda` image because we didn't have access to an image registry. Now that we have access to an image registry, these steps are all part of our `Dockerfile` and handled at build time. As such, when the Frontier Counts image is used, it simply needs to activate the python virtual environment that is baked into the image and run whatever entrypoint was specified.

# Moving data out of the Frontier Counts system

There are a number of steps where data exits the Frontier Counts system. In addition to the [Seasonal Adjustment]({{fc_baseurl.doc}}/getting_started/use_cases/#seasonal-adjustment-overview) process, there are two kinds of "releases" that are intended for users of Frontier Counts data.

![release-process](../img/architecture/release-process.png)

The first kind of release relates to the monthly so-called [pre-release and release]({{fc_baseurl.doc}}/getting_started/use_cases/#sign-off-overview) dissemination to internal StatCan users.

The second kind of release relates to the [New Dissemination Model (NDM)]({{fc_baseurl.doc}}/datasource/ndm/overview). Once the NDM data for a given year/month are ready for dissemination, there is an Argo Workflow that runs a [composite workflow]({{fc_baseurl.doc}}deployment/argo_workflows/#application-specific-configuration-for-composite-workflows) that prepares the `/outbox` location with the necessary NDM data that needs to be ingested by the NDM system. See [NDM Prepare Outbox Overview]({{fc_baseurl.doc}}/getting_started/use_cases/#ndm-prepare-outbox-overview) for more information.
