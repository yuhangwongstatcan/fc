This page describes how Argo Workflows are used throughout the application.

# Workflow Template

Argo allows users to include definitions of workflows that live on the kubernetes cluster using [Workflow Templates](https://argoproj.github.io/argo-workflows/workflow-templates/). In Frontier Counts, all of our workflows follow the pattern `python3 <CLI program name>.py <CLI args>`, so we opted to create an Argo Workflow Template to create workflows of this format. Our workflow template can be found in the `stable/frontier-counts/templates/` folder, with templates indicated by the prefix `wf-template`, in the [cloudnative charts repo](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts/templates).

In the workflow templates mentioned above, we pass the script name and arguments as workflow parameters, activate the python virtual environment, and invoke the `python3` interpreter on the given script followed by the given CLI arguments. The container image from which workflows are created is generated dynamically when the Frontier Counts helm chart is installed. A number of environment variables are mounted either directly, or from [kubernetes secrets](https://kubernetes.io/docs/concepts/configuration/secret/).

# Creating Argo Workflows

The workflows in the Frontier Counts system will usually be generated from the webapp and submitted directly to the Argo Workflows API server. It is possible, however, to create and list workflows using the [Argo CLI](https://argoproj.github.io/argo-workflows/cli/), the [Argo Web UI](https://argo-workflows.prod.cloud.statcan.ca/), or directly from `kubectl` by applying a workflow manifest. This section of the documentaion focuses on the creation of workflows from the Frontier Counts web application, as the majority of workflows will be created this way.

## Custom Workflow Settings

As we are running workflows on a cluster-wide instance of Argo Workflows, we have been asked to include a number of settings in the workflows we submit. These are highlighted below.

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Workflow
metadata:
  generateName: frontier-counts-workflow-template
  namespace: frontiercounts  # Namespace that the workflows run under
spec:
  serviceAccountName: "argo-workflows"  # Service account that workflow pods run under
  podMetadata:
    annotations:
      proxy.istio.io/config: '{ "holdApplicationUntilProxyStarts": true }'  # Istio annotation requested by the cloudnative team
  imagePullSecrets:
    - name: artifactory-prod  # Secrets to use to pull images from artifactory
  ttlStrategy:
    secondsAfterCompletion: 86400  # Workflow time-to-live after completion (in seconds)
  podGC:
    strategy: OnPodCompletion  # How Argo should garbage collect workflow pods that are no longer needed
  templates:
    # user-defined workflow specification
```

## Generating Workflows with Pydantic Models

We installed the [argo-workflows-tools](https://github.com/DiagnosticRobotics/argo-workflow-tools) Python package that provides [Pydantic](https://pydantic-docs.helpmanual.io/) models for the entire set of Argo Workflows kubernetes resources. The `src/modules/argo.py` module contains a number of utilities to both create and list workflows, and `src/config/argo.py` contains a variety of configuration items related to Argo Workflows.

## Special application-specific exit codes

::: config.argo.ArgoStatusCodes

The `argo_list_workflows` function in `src/modules/argo.py` uses the `get_pipeline_status` function defined in the same module to display the appropriate status given the non-standard exit code that may be included with the Argo Workflow metadata.

## Submitting argo workflows from the webapp

In order for an application to submit workflows to Argo Workflows, it must be running under a Kubernetes service account which is bound with the necessary roles to submit Argo Workflows.

In Frontier Counts, we have a `webapp-service-account.yaml` defined in the [cloudnative charts repository](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts/templates). This service account is associated with a role defined in `argo-role.yaml` via a role-binding defined in `webapp-rolebinding.yaml`.

Each pod in Kubernetes is associated with exactly one service account, and the service account JWT is automatically mounted to the container filesystem of each container in the pod by Kubernetes. The default location that Kubernetes mounds the service account JWT is `/var/run/secrets/kubernetes.io/serviceaccount/token`. This path is automatically set in the `WEBAPP_SERVICE_ACCOUNT_JWT` environment variable (see [Development Environment Setup]({{fc_baseurl.doc}}/getting_started/development_environment/#set-up-env-file) for documentation on the various environment variables that are set in this application).

The application instance simply needs to get the value stored in the mounted service account JWT, and attach it as an `Authorization` header on the HTTP request to Argo Workflows. This essentially communicates that the web application in the Kubernetes pod is running under a service account that has permission to make such requests to the Argo Workflows server. See the code snippet below for how this is done in Python.

```python
from argo.workflows.client import (ApiClient, Configuration)
# Argo Workflow server host url
ARGO_HOST = environ().ARGO_HOST
# Kubernetes namespace that the workflow pod will run in
ARGO_NAMESPACE = environ().ARGO_NAMESPACE
# Need the service account JWT in order to submit requests on behalf
# of the current webapp service account.
WEBAPP_SA_JWT = environ().WEBAPP_SERVICE_ACCOUNT_JWT
# Create configuration/client instances for the argo client
config = Configuration(host=ARGO_HOST)
# Note that we need to pass the auth header with JWT token to the ApiClient in
# order for requests to get authenticated correctly.
client = ApiClient(
    configuration=config,
    header_name="Authorization",
    header_value=f"Bearer {WEBAPP_SA_JWT._secret_value}",
)
```

## Application-specific configuration for composite workflows

There are a number of workflows that the Frontier Counts team submits that are composites of existing workflows. More generally, there exist recursive composites of composites (e.g. there is a `nexus` composite that runs the `nexus_air` and `nexus_hwy` composites which, respectively, run `nexus_air RAW` and `nexus_air CLEAN`; and `nexus_hwy RAW` and `nexus_hwy CLEAN`).

Since there are only a small number of attributes that change between a large number of different Frontier Counts workflows that may be submitted, we have application-specific configuration in `src/config/composite_pipelines.json` where each key in the JSON file contains either a list of workflow configurations, or the names of existing workflow configurations in the case of composite workflows.

For example, the following three configurations define a series of workflows that produce the [Frontier Counts NDM Tables]({{fc_baseurl.doc}}/datasource/ndm/overview) and the composite workflow that runs both the unadjusted and seasonally adjusted composites.

```json
{
    // ...
    "ndm_unadjusted_outputs": [
        {
            "name": "ndm-24100050",
            "cli_script": "run_pipeline.py",
            "pipeline_class": "PipelineAggregated",
            "data_source": "ndm_24100050"
        },
        {
            "name": "ndm-24100052",
            "cli_script": "run_pipeline.py",
            "pipeline_class": "PipelineAggregated",
            "data_source": "ndm_24100052"
        },
        {
            "name": "ndm-24100053",
            "cli_script": "run_pipeline.py",
            "pipeline_class": "PipelineAggregated",
            "data_source": "ndm_24100053"
        }
    ],
    "ndm_adjusted_outputs": [
        {
            "name": "ndm-24100051",
            "cli_script": "run_pipeline.py",
            "pipeline_class": "PipelineAggregated",
            "data_source": "ndm_24100051"
        },
        {
            "name": "ndm-24100054",
            "cli_script": "run_pipeline.py",
            "pipeline_class": "PipelineAggregated",
            "data_source": "ndm_24100054"
        }
    ],
    "ndm_all_outputs": [
        "ndm_adjusted_outputs",
        "ndm_unadjusted_outputs"
    ]
    // ...
}
```

Argo Workflow DAG templates are created from the above-mentioned application-specific configuration, which are detailed below.

All Argo Workflow DAG pydantic models extend `config.argo.ArgoFCBaseModel`.

::: config.argo.ArgoFCBaseModel

The "base case" of the recursively defined configurations in `src/config/composite_pipelines.json` is an object with five attributes, three of which are optional.

::: config.argo.FCWorkflowOptions

::: config.argo.ArgoWorkflowDagTask

::: config.argo.ArgoWorkflowRecursiveDagTask

The `config.argo.fc_composite_pipelines` acts as a getter function for a given Frontier Counts Argo Workflow that is defined by the `src/config/composite_pipelines.json`.

::: config.argo.fc_composite_pipelines




# Creating "Ad Hoc" Workflows directly on Argo Web UI

There will occasionally be a use case that requires "ad hoc" or one-time workflows to be run directly outside of the system. For example, during the development of the Frontier Counts system, we occasionally had to recreate the entire history of NDM tables dating back to January 1, 1972.

There are a number of workflow `yaml` files in the `src/argo` folder of this repository. These are indended to serve as examples of workflows you can submit directly to Argo Workflows by either copy + pasting the `yaml` definition in the Argo Workflows UI, submitting via the Argo CLI program, or applying it directly with `kubectl`. One particular workflow setting that is noteworthy is the `withItems` keyword that allows the user to enumerate a number of workflow parameters that will be passed to a number of identical workflow instances. At the time of writing this documentation, the SDLC kubernetes clusters don't support autoscaling, so we were asked to keep the number of parallel workflows limited to a reasonable number (e.g. 12-24) to avoid putting too much burden on cluster resources; this limit can be achieved by setting the `parallelism` parameter. In the future, if the SLDC clusters support autoscaling, it may be possible to increase the parallelism to as high of a degree as required (within reason). The snippet below shows an example of such a workflow.

```yaml
# Example to recreate > 600 NDM tables with Argo Workflows in light of revised input data.
apiVersion: argoproj.io/v1alpha1
kind: Workflow
metadata:
  generateName: frontier-counts-workflow-template
  namespace: frontiercounts
spec:
  serviceAccountName: "argo-workflows"
  podMetadata:
    annotations:
      proxy.istio.io/config: '{ "holdApplicationUntilProxyStarts": true }'
  imagePullSecrets:
    - name: artifactory-prod
  podGC:
    strategy: OnPodCompletion
  ttlStrategy:
    secondsAfterCompletion: 86400
  entrypoint: on-workflow-template
  parallelism: 12 # This is the number of concurrent workflows
  templates:
    - name: on-workflow-template
      metadata:
        labels:
          pipelineName: changeme
      steps:
        - - name: call-frontier-counts-template
            templateRef:
              name: frontier-counts-workflow-template
              template: main
            arguments:
              parameters:
                - name: script_name
                  value: "\{\{ item.script_name \}\}"  # Note that the curly brackets aren't actually escaped - this is to prevent the documentation site from trying to render these values.
                - name: args
                  value: "\{\{ item.args \}\}"
            withItems:  # This is the list where you can enumerate the workflow parameters
              - args: --pipeline-class PipelineAggregated --data-source ndm_unadjusted --date 1972-01-01
                script_name: run_pipeline.py
              - args: --pipeline-class PipelineAggregated --data-source ndm_unadjusted --date 1972-02-01
                script_name: run_pipeline.py
              - args: --pipeline-class PipelineAggregated --data-source ndm_unadjusted --date 1972-03-01
                script_name: run_pipeline.py
            # ...
```