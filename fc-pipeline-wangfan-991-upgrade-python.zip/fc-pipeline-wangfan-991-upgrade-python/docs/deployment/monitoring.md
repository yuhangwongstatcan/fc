This page outlines how to monitor the various components of the Frontier Counts system.

# Azure Storage

The Azure web interface provides direct access to monitoring and metrics functionalities. We simply visit this editor directly to view various metrics of interest for our storage containers (e.g. used capacity, number of transactions, and so on).

# Webapp

There are a few ways to gain visibility into the webapp. First, you can directly inspect the resources used by the webapp pod using your preferred kubernetes environment (e.g. k9s, lens). We have configured the gunicorn server to write access and error logs by adding the ` --access-logfile access.txt --error-logfile error.txt --log-level info` options to our `gunicorn` command. You can access these logs by opening a shell into the `frontier-counts` container in the `webapp` pod and inspecting either the `error.txt` file or the `access.txt` file.

# Argo Workflows

Each argo workflow displays error messages to the console output (stdout) of the `main` container of the workflow being run. To view the error messages from a workflow, go to the [Argo Workflows Web UI](https://argo-workflows.prod.cloud.statcan.ca/), click the workflow you want to inspect. This will open up a window on the right-side of the screen, then click the "MAIN LOGS" button to view log messages from the workflow.

# Octopus

Octopus keeps a record of all of the tasks run on it. If you need to check which versions were deployed into a particular environment, go to the the Tasks tab in the sidebar of the Frontier Counts project and find the task that you'd like more info on. In here you can access the more verbose logs kept on Octopus and see which commit from the [Octopus repo](https://gitlab.k8s.cloud.statcan.ca/cctts-ccstt/frontiercounts/frontier-counts/fc-octopus-deploy) was associated with your task. 

