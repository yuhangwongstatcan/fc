This page details how to manually deploy the Frontier Counts system on Kubernetes.

# `Makefile`

To rapidly test/prototype, we use a combination of settings in the `values.yaml` file along with a `Makefile` to deploy our helm chart onto a given Kubernetes cluster. Once continuous deployment is set up, the purpose of manually deploying with the Makefile is for ad-hoc deployments/upgrades that need to happen outside of the CI/CD cycle.

The `Makefile` can be found in at `stable/frontier-counts/Makefile` in the [cloudnative charts repo](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts/templates).

# Rules for Deploying with Helm

There are several Makefile rules corresponding to various deployment environments that are indicated by commented block letters for visual clarify. E.g.

```bash
#            _       _ _          _
#  _ __ ___ (_)_ __ (_) | ___   _| |__   ___
# | '_ ` _ \| | '_ \| | |/ / | | | '_ \ / _ \
# | | | | | | | | | | |   <| |_| | |_) |  __/
# |_| |_| |_|_|_| |_|_|_|\_\\__,_|_.__/ \___|

#      _
#   __| | _____   __
#  / _` |/ _ \ \ / /
# | (_| |  __/\ V /
#  \__,_|\___| \_/

# and so on.
```

Each of these rules (except for `alpha`) accepts targets `install`, `upgrade`, or `template` and runs dependency rules `chart-cluster`, `helm-repos`, and `helm-deps` which perform any necessary setup in case it has not already been performed. In each case, the rule is a thin shim around `helm` followed by the target name. For example, `make install` runs `helm install`, `make upgrade` runs `helm upgrade`, and so on. The remaining lines of the rules set environment-specific configuration using the `--set` option in the `helm` client.

We simply comment the various rules that are not applicable to the current environment. For example, when using the `Makefile` on the `production` cluster, we would commend out the **minikube**, **dev**, and **test** rules with the same target names. The one exception to this is the `alpha` rules which instead are defined as two targets: `alpha-install` and `alpha-upgrade`. The reason for this is that the `prod-alpha` release of the helm chart is deployed into the same kubernetes cluster in the same namespace as the main production deployment. It ended up being slightly more convenient to avoid the extra step of commenting + uncommenting between `prod` and `prod-alpha` releases, and instead simply typing `make alpha-upgrade` after `make upgrade`. Note that in any of these cases, the appropriate block of configuration at the top of `values.yaml` needs to be uncommented as well due to the yaml anchor issue mentioned in the Frontier Counts [Helm Chart documentation]({{fc_baseurl.doc}}/deployment/helm_chart).

# MinIO

For more detail about MinIO, see the [Frontier Counts MinIO]({{fc_baseurl.doc}}/deployment/minio) documentation.

You can create all of the user roles in MinIO by running `make minio-policies`. `init/init_minio_users.sh` is a corresponding shell script that creates users in MinIO from a text file - the script binds users to roles created in `make minio-policies`.

We wrote a small number of unit tests to verify that the MinIO IAM policies we created for the various users behave as expected. You can run these by doing `make test` or `make tests`.

# Other `Makefile` Rules.

There are a variety of rules to port forward various services using `kubectl port-forward`. For example, you can port-forward the MinIO service by running `make pf-minio`.