# Create users in MinIO

Since there are so few MinIO users (i.e. the production team along with a small number of specific staff), we simply create the MinIO users from a shell script and a text file. In the `init` folder at the project root, there is a file called `example.minio_users.txt` which outlines the format of how MinIO users should be specified. The format of this file is the following.

```txt
production johndoe changeme
production janedoe changeme
uploader jimdoe changeme
```

The first value is the MinIO role that the user will be assigned to. The MinIO IAM policies are defined in the `stable/frontier-counts/minio-config` folder of the [cloudnative charts](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts) repository. The second value is the access key (user name), and the third value is the secret key (password). For simplicity and security, we made each user's password a randomly generated string that we then sent them by encrypted email. At the time of writing, these passwords are still being used, and will be securely transfered to the maintainers of the project.

Once the MinIO IAM policies are created (using `make minio-policies` - see [Makefile docs]({{fc_baseurl.doc}}/deployment/manual_deployment)), the users can be created from a text file like the one described above by running the `init_minio_users.sh` shell script. Of course, the file `minio_users.txt` is gitignored so that it is not accidentally committed to source control.

!!! note
    The two steps above `make minio-policies` and running `init_minio_users.sh` only need to be run on a fresh `make install`; if you are just upgrading the helm chart, there is no need to run these two steps.

# MinIO IAM Policies

A number of S3 IAM policies are created in the `stable/frontier-counts/minio-config` folder of the [cloudnative charts](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts) repository. The purpose of each role is outlined below. The name of each user role corresponds to the file name in the `minio-config` path stated above (e.g. `power-user` role is in the file `power-user.json`).

| User Type     | Scope of Access                                                                                                                                               | Purpose                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `power-user`  | full read access, no write access                                                                                                                             | There are a small number of (authorized) "power users" who need full access to the raw/clean data of the Frontier Counts system. This role allows them to read all of the system contents while not being able to modify any of the data.                                                                                                                                                                                     |
| `pre-release` | read access to `fc-bucket/pre_release/*` and `fc-bucket/release/*` only, no write access.                                                                     | For users who have permission to view pre-release data.                                                                                                                                                                                                                                                                                                                                                                       |
| `production`  | full read access, write access to `fc-bucket/inbox/*`, `fc-bucket/outbox/*`, `fc-bucket/raw/manual_entry/*`, `fc-bucket/staging/*`, `fc-bucket/dashboards/*`. | For the Frontier Counts production users of the system. This role is favoured over the admin role to prevent accidental deletion/modification of system contents.                                                                                                                                                                                                                                                                      |
| `release`     | read access to `fc-bucket/release/*` only, no write access                                                                                                    | For users who have permission to view release data in the system.                                                                                                                                                                                                                                                                                                                                                             |
| `report-hub`  | read access to `fc-bucket/aggregated/ndm_*` and `fc-bucket/reference/*`, no write access.                                                                     | The related **Report Hub** project may eventually read directly from Frontier Counts' object storage. In such a case, this role could be assigned to a machine identity for the report hub application.                                                                                                                                                                                                                       |
| `uploader`    | read access to `fc-bucket/outbox/*`, write access to `fc-bucket/inbox/*`.                                                                                     | An automated process may be used at some point to upload data to the `/inbox` or read data from the `/outbox` prefixes. In such a case, the `uploader` role can be assigned to a machine identity for an automated process. Note that this is primarily for reference/archive purposes, in practice, a corporate solution for such a transfer would likely happen directly between Azure storage accounts/storage containers. |

!!! note
    At the time of writing this documentation, only the `production` and `power-user` roles are used by the Frontier Counts system. The other IAM policies exist in case the other roles need to be used, however at the time of writing this is just for informational/archive purposes.

# Unit Testing MinIO IAM Policies

There are 4 MinIO IAM policies for this system: `pre-release`, `release`, `report-hub`, and `uploader` - the configurations for these policies can be found in `kubernetes/frontier-counts/minio-config`.

The IAM policy simultator by AWS requires an AWS account. Further, there are a relatively small number of IAM policies in this application. Therefore, we opted to write a simple test suite by hand in `kubernetes/Makefile`. To invoke the test suite, navigate to the `kubernetes` folder and run `make test`, you should see console printout similar to what is shown below.

![iam-test-screenshot](../img/minio-iam-unit-test.PNG)

# MinIO Gateway Mode

At the time of writing this documentation, we run MinIO in gateway mode to Azure blob storage. The relevant configuration can be found in our `values.yaml` file in the [cloudnative charts](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts) repository.

For convenience, the relevant snippet is shown below:

```yaml
# values.yaml
# ...
minio:
  enabled: true
  ## MinIO(R) Gateway configuration
  fullnameOverride: *minioName
  gateway:
    enabled: true
    replicaCount: 2
    type: azure
    auth:
      azure:
        storageAccountName: *storageAccountName
        storageAccountKey: *storageAccountKey
# ...
```

!!! warning
    MinIO is planning to [deprecate support for running in Gateway mode](https://blog.min.io/deprecation-of-the-minio-gateway/#:~:text=MinIO%20is%20deprecating%20the%20gateway,has%20only%20made%20bug%20fixes.) in August 2022. Alternative solutions are being investigated to allow users access to the S3 API while still leveraging Azure blob storage. This task has been flagged as an item for the maintenance team that will take over the Frontier Counts system.