# Argo Cron Workflow Template

In the [cloudnative charts repo](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts/templates) under `stable/frontier-counts/templates`, there is a template called `cron-workflow-template.yaml` that specifies a template from which [Argo Cron Workflows](https://argoproj.github.io/argo-workflows/cron-workflows/) can be created.

The template mentioned above was primarily created to get around the limit Azure imposes on [object replication policies]({{fc_baseurl.doc}}/deployment/terraform_azure/#object-replication-policies).

The workflow of this template essentially runs a recursive copy from one storage account/container/prefix to another storage account/container/prefix. The workflow expects four environment variables to be mounted: `AZURE_SOURCE_ACCOUNT_NAME`, `AZURE_SOURCE_ACCOUNT_KEY`, `AZURE_DESTINATION_ACCOUNT_NAME`, and `AZURE_DESTINATION_ACCOUNT_KEY`. Additionally, it takes four other environment variables indicating the source container/blob pattern and the destination container/blob pattern. The environment variables are expected to be found in the kubernetes secret defined in `cron-workflow-secrets.yaml`, while the latter four variables can just be mounted directly as they are not sensitive.

**Note**: in retrospect, it would have been fine to have only the storage account keys mounted from kubernetes secrets, however I added these environment variables at two separate times, so I simply put both the storage account keys and names in the same kubernetes secrets.

!!! todo
    At the time of writing this documentation, the cron workflow template referenced in this section of the documentation does a naive recursive copy of the entire contents of the pattern matching `<container name>/<blob pattern>` between source and destination.

    If this feature ends up getting used in the future, it is probably worthwhile to investigate the various options that can be passed to the [Azure CLI program](https://docs.microsoft.com/en-us/cli/azure/) to do a more intelligent copy based on timestamps/last modified dates.

    In linux, you can print out a relative date in the format expected by the Azure client (Y-m-d'T'H:M'Z') using something like https://stackoverflow.com/a/49189559.

The `--if-modified-since` option in the Azure client should let you specify the criteria above.

```bash
az storage blob upload-batch --help
# ...
Precondition Arguments
    --if-match                              : An ETag value, or the wildcard character (*). Specify
                                              this header to perform the operation only if the
                                              resource's ETag matches the value specified.
    --if-modified-since                     : Commence only if modified since supplied UTC datetime
                                              (Y-m-d'T'H:M'Z').
    --if-none-match                         : An ETag value, or the wildcard character (*).
        Specify this header to perform the operation only if the resource's ETag does not match the
        value specified. Specify the wildcard character (*) to perform the operation only if the
        resource does not exist, and fail the operation if it does exist.
    --if-unmodified-since                   : Commence only if unmodified since supplied UTC
                                              datetime (Y-m-d'T'H:M'Z').

```