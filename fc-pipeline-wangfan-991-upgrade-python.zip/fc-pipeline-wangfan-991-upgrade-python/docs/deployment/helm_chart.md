This page documents the Frontier Counts [helm chart](https://helm.sh/docs/topics/charts/) that can be found in the [cloudnative charts repo](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts/templates). Although this was previously managed manually, the Frontier Counts helm chart is now done through [Octopus Deploy]({{fc_baseurl.doc}}/deployment/octopus).

# Organization

The Frontier Counts helm chart has two dependencies as subcharts: `minio` and `etcd` - both of these are specified in the project's `Chart.yaml` file. Optionally, for local development, a subchart can be included for `argo-workflows`, see [Installing the chart locally](#localsetup) for more information about how to do this.

Deployment should be [managed through Octopus]({{fc_baseurl.doc}}/deployment/octopus).

!!! note
    Previously, [deployment was done manually]({{fc_baseurl.doc}}/deployment/deployment/manual_deployment) for Frontier Counts. However, this method is now deprecated.

The `values.yaml` file defines the API to the helm chart. Anything exposed in this file can be configured. The three main sections are the **Frontier Counts Application**, **MinIO**, and **etcd**. Argo Workflows can be configured optionally for local development, but by default it is not deployed as Argo Workflows is already provided as a managed service on the SDLC kubernetes environments.

Most fields in the `values.yaml` file have comments indicating what they do, but a few noteworthy items are mentioned in this page of the documentation.

**YAML Anchors**

At the very top of the `values.yaml` file, there are a number of value that are defined with [YAML anchors](https://support.atlassian.com/bitbucket-cloud/docs/yaml-anchors/) to prevent pasting duplicate configuration throughout the `values.yaml` file. At the time of writing, to the best of our knowledge, there is no way to override yaml anchors when setting configuration values through `helm` (i.e. using the `--set` option when running `helm upgrade` or `helm install`). Therefore, for local development, we opted to simply have 4 blocks of keys with YAML anchors that we comment/uncomment as needed. In octopus, these can be set per deployment environment, but for local development we found that this workflow was simple enough.

# Prod/Alpha Release in `production` Namespace

!!! todo
    This section of the documentation needs to be updated once the prod/alpha storage accounts are updated as per this [Gitlab Issue](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/442).

A the time of writing this documentation, the intended way to deploy a "QA" or "alpha" environment is to make an alpha release in the same kubernetes namespace as the production instance of the application. Since there is no namespace isolation between these two releases, certain Kubernetes resources are shared between them. This section explains how the `prod` and `prod-alpha` releases are configured.

## Environment variables that differ between Prod and Alpha releases

First, there are a number of environment variables that are set in the `frontier-counts` container of the `webapp` pod. The table below shows each environment variable, its value in the `prod` release, its value in the `prod-alpha` release, and a short explanation where appropriate.

| environment variable | `prod` value                                                                           | `prod-alpha` value                                                                     |
| -------------------- | -------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `FC_BASE_URL`        | https://fc-webapp.prod.cloud.statcan.ca                                                | https://fc-webapp-alpha.prod.cloud.statcan.ca                                          |
| `DOC_BASE_URL`       | https://tourism-tourisme.pages.cloud.statcan.ca/frontiercounts/frontier-counts/fc-pipeline/ | https://tourism-tourisme.pages.cloud.statcan.ca/frontiercounts/frontier-counts/fc-pipeline/ |
| `ARGO_HOST`          | https://argo-workflows.prod.cloud.statcan.ca                                           | https://argo-workflows.prod.cloud.statcan.ca                                           |
| `ARGO_NAMESPACE`     | `frontiercounts`                                                                       | `frontiercounts`                                                                       |
| `MINIO_INGRESS`      | fc-minio.prod.cloud.statcan.ca                                                         | fc-minio-alpha.prod.cloud.statcan.ca                                                   |
| `ARGO_INGRESS`       | argo-workflows.prod.cloud.statcan.ca                                                   | argo-workflows.prod.cloud.statcan.ca                                                   |
| `DEFAULT_BUCKET`     | `fc-bucket`                                                                            | `fc-bucket-alpha`                                                                      |
| `ALPHA_DEPLOYMENT`   | False                                                                                  | True                                                                                   |
| `ARGO_TEMPLATE_NAME` | `frontier-counts-workflow-template`                                                    | `frontier-counts-workflow-alpha-workflow-template`                                              |

Some resources are shared between the releases. For example, `DOC_BASE_URL` is the same because the documentation site does not distinguish between releases. Also `ARGO_HOST`, `ARGO_NAMESPACE`, and `ARGO_INGRESS` are identical because both releases use the same Argo Workflows managed service. Note that the original distinction between `ARGO_HOST` and `ARGO_INGRESS` is that the former is what the webapp sends requests to, while the latter is the external-facing ingress URL that is displayed on the dashboard page of the web app. In this case, they are the same URL, but this is not always the case (e.g. the `ARGO_HOST` might use the internal URL while `ARGO_INGRESS` will always be the external-facing URL). Note also that since both releases are deployed in the `frontiercounts` namespace, workflows for either release are run in the `frontiercounts` namespace.

The webapp/minio ingress URLs change depending on which instance is deployed. Specifically, the `prod-alpha` release has the `-alpha` suffix. There is a separate Azure storage container that is provisioned in the `frontiercountsblobprod` storage account called `fc-bucket-alpha` - see our [Frontier Counts Terraform Documentation]({{fc_baseurl.doc}}/deployment/terraform_azure) for more information about how storage containers are provisioned. A future refactor will likely provision a separate storage account for the `prod-alpha` release, and create a container called `fc-bucket` that is scoped to that storage account (see TODO item above).

Since certain environment variables need to change depending on which environment the application is running in, a separate Argo Workflow Template exists for each of the two environments (`prod` and `prod-alpha`). Depending on whether the user creates workflows from the `fc-webapp-alpha` URL or the `fc-webapp` URL, the appropriate template will be chosen in the workflow spec that is submitted to the Argo Workflows API server.

## Shared Resources

The major components for each of the `prod` and `prod-alpha` release are separate instances for each release. For example, the various pods, services, ingresses, etc. each have a separate instance for the `prod` and `prod-alpha` releases. However, there are a number of shared resources which are noted in this section of the documentation.

The `minio` subchart accepts a configuration value called `existingSecret` which indicates whether the deployment of the MinIO subchart should create a kubernetes secret containing the access key/secret key pair used to log into MinIO as the admin user. Since this secret is already created as part of the `prod` release, there is no need to create a second secret. Additionally, at the time of writing, the name of the secret that the MinIO subchart creates is not configurable, so attempting to create two secrets as part of this subchart deployment throws an error. The solution we chose is to simply have each MinIO instance (`prod` and `prod-alpha`) share the same access key/secret key pair. The `nginx` reverse proxy in front of the web application also accepts a kubernetes secret. Similar to MinIO, we also have the NGINX container share a kubernetes secret between the `prod` and `prod-alpha` releases. The primary reason for this was to minimize user burden of the number of distinct credentials they need to memorize.


# <a name="localsetup"></a>Installing the chart locally

If you are switching between development on a local kubernetes distribution like MiniKube or k3s, you can include a file called `stable/frontier-counts/tmp/Chart.argo.yaml` (gitignored) with the following contents, and run `make chart-minikube` to quickly swap the contents of the below file for the main `Chart.yaml` file.

```yaml
apiVersion: v2
name: frontier-counts
description: Frontier Counts Application

# A chart can be either an 'application' or a 'library' chart.
#
# Application charts are a collection of templates that can be packaged into versioned archives
# to be deployed.
#
# Library charts provide useful utilities or functions for the chart developer. They're included as
# a dependency of application charts to inject those utilities and functions into the rendering
# pipeline. Library charts do not define any templates and therefore cannot be deployed.
type: application

# This is the chart version. This version number should be incremented each time you make changes
# to the chart and its templates, including the app version.
version: 0.0.2

# This is the version number of the application being deployed. This version number should be
# incremented each time you make changes to the application.
appVersion: latest

dependencies:
- name: minio
  version: "7.2.0"
  repository: https://charts.bitnami.com/bitnami
  condition: minio.enabled
- name: etcd
  version: "6.2.9"
  repository: https://charts.bitnami.com/bitnami
  condition: etcd.enabled
  # Only in local k8s cluster
- name: argo-workflows
  version: "0.2.5"
  repository: https://argoproj.github.io/argo-helm/
  condition: argo-workflows.enabled
```