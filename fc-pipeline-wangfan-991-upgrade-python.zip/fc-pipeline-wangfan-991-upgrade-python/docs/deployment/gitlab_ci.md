This page details our Gitlab CI pipeline.

# Versioning, scanning, and pushing image to artifactory

Our `.gitlab-ci.yml` configuration extends a [`.gitlab-ci.yml` template](https://gitlab.k8s.cloud.statcan.ca/cloudnative/gitlab/gitlabci/kaniko-image-ci) that was created by the [cloudnative team](https://cloudnative.pages.cloud.statcan.ca/en/team-equipe/). We largely follow the strategy outlined in the linked template repository with respect to container scanning and pushing images, please refer to this documentation for more detail on how this part of the CI pipeline works.

**Note 1**: the image tag naming convention is the following: `frontier-counts:<major version>.<minor version>.<patch>-rc-<release candidate (optional)>-<commits ahead of the last Git tag>-<8 characters of the Git commit SHA>`. For example, `frontier-counts:0.6.3-rc1-17-g8d06c5a` can be read as "the `frontier-counts` image, version `0.6.3`, release candidate `1`, `17` commits ahead of the most recent Git tag (`0.6.3`), with the Git commit SHA starting with `g8d06c5a`.

**Note 2**: we set certain configuration settings that can be found at the top of the `.gitlab-ci.yml` file. In particular, we ignore one hadolint error and only flag critical CVEs. Future maintainers may wish to adjust these settings if requirements change.

# Unit and integration tests

Our [unit/integration testing suite]({{fc_baseurl.doc}}/tests/run_tests) is run as part of the Gitlab CI pipeline.

# Documentation site

Our documentation site is built with [mkdocs](https://www.mkdocs.org/) and moved in the `/public` folder of our project repository so that it can be hosted with [Gitlab pages](https://docs.gitlab.com/ee/user/project/pages/).