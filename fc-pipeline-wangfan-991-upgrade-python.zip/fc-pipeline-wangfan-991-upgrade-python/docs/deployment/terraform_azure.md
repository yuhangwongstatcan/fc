This page details how the Frontier Counts project uses [Terraform](https://www.terraform.io/) along with the [Terraform Azure Provider](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs) to automate the provisioning of Azure resources - primarily those related to storage accounts.

--8<-- "docs/templates/terraform_repos.md"

!!! info
    At the time of writing, only the `development` and `production` environments are actively being used by the Frontier Counts system. The `development` environment is used to make changes and test their efficacy, while the `production` environment is used to deploy the `prod-alpha` and `prod` releases of the system. The Terraform repository for the `test` environment still exists, although it is not being actively maintained.


# Azure Storage Accounts

The main Azure resources provisioned by Terraform are Azure storage accounts and storage containers in those storage accounts. Additionally, the system makes use of Azure's [object replication policies](https://docs.microsoft.com/en-us/azure/storage/blobs/object-replication-overview), which require terraform modules for provisioning along with modules to provision storage management policies to ensure cleanup of previous versions/snapshots in Azure. This documentation references artifacts in the [frontiercounts-production-rg](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/environment/production/frontiercounts-production-rg) repository, however the configurations are almost identical for the `test` and `development` environments.

The storage accounts for each environment are provisioned in `infrastructure/main.tf`. At the time of writing, there are three storage accounts provisioned in each environment:

- `frontiercountsblobprod` - the storage account where the main Frontier Counts data are stored.

- `frontiercountsvalprod` - the storage account where validation data and reference files are copied to. The purpose of this storage account is to enable the Frontier Counts production team to access an (unprotected) subset of the data by connecting PowerBI directly to the `frontiercountsvalprod` storage account. The relevant validation/reference data are copied between the storage accounts using an Azure object replication policy (detailed later in this page).

- `frontiercountsprerelprod` - the storage account where so-called "pre-release" data are stored. The purpose of this storage account is to move a subset of aggregated data that is intended to be shown to a number of internal StatCan users. By moving this data to a separate storage account, it is possible to use Azure Active Directory to specify which users have access to this pre-release data. Data are moved to a different storage account through an Azure object replication policy.

- `frontiercountsrelprod` - the storage account where so-called "release" data are stored. The purpose of this storage account is the same as `frontiercountsprerelprod`, however the scope of data and users who have access is different. This feature is not currently being used, however, if it is used in the future it will be necessary to use something like an [Argo Cron Workflow]({{fc_baseurl.doc}}/deployment/argo_workflows) to copy data between the two storage accounts. This is because Azure places a limit of 2 source/destination accounts that can be associated with object replication policies (see warning later in this page).

!!! note
    It is necessary that both `frontiercountsblobprod` and `frontiercountsrelprod` are associated with both the cloud workstations subnet and the production cluster subnet. This is because MinIO needs to access these storage accounts directly in gateway mode from the production cluster, and users will also want to be able to access the storage account directly from the cloud workstations (e.g. while developing/debuggin the Frontier Counts system).

# Azure Storage Containers

Each of the above-mentioned storage accounts has at least one storage container associated with it. For readers familiar with AWS S3 terminology, an azure storage container is roughly equivalent to an S3 bucket.

For consistency purposes, this storage container is always called `fc-bucket` as there is no reason to change the name between storage accounts.

The storage containers that are provisioned can be found in `infrastructure/blob.tf`.

# Object Replication Policies

Object replication policies are used to move specific subsets of data between two storage accounts. In Frontier Counts, there are two such object replication policies that are detailed below:

- **Move validation/reference data between storage accounts**
  - Moves the `fc-bucket/valdiation` and `fc-bucket/reference` prefixes from the `frontiercountsblobprod` storage account to the `frontiercountsvalprod` storage account.

- **Move pre-release data between storage accounts**
  - Moves the `fc-bucket/pre_release` prefix from the `frontiercountsblobprod` storage account to the `frontiercountsvalprod` storage account.

The object replication policies are defined in `infrastructure/object_replication.tf`.

!!! warning
    At the time of writing this documentation, there is a limit on the number of times a storage account can be the source or target of an object replication policy. In particular, an account can be the source/destination of an object replication policy no more than two times (see this [stackoverflow comment](https://stackoverflow.com/a/69223221) detailing this limitation). More generally, this link details the [object replication policies and rules](https://docs.microsoft.com/en-us/azure/storage/blobs/object-replication-overview?tabs=powershell#object-replication-policies-and-rules). There is a workaround to this limit by using [Argo Cron Workflows](https://argoproj.github.io/argo-workflows/cron-workflows/); the use of a cron workflow to perform a manual copy between two storage accounts is detailed in the [Frontier Counts Argo Workflows Docs]({{fc_baseurl.doc}}/deployment/argo_workflows).

# Storage Management Policies

In order to leverage Azure's object replication policies, we had to provision storage accounts that had the [blob versioning](https://docs.microsoft.com/en-us/azure/storage/blobs/versioning-overview) feature enabled (see `infrastructure/modules/terraform-azurerm-storagev2-blob/main.tf` for the configuration to enable blob versioning). By default, Azure keeps all pervious versions of objects in hot tier storage indefinitely. For the purposes of Frontier Counts, this is not necessary, so we set policies to automatically move to cool storage (and eventually delete) Azure snapshots and previous versions after a number of days. The precise configurations should be discussed between the maintainer team and the Tourism production team. The configuration of these storage management policies can be found in `infrastructure/storage_mgmt_policies.tf`.

!!! danger
    It is important to make sure these storage management policies are tuned in a way that deletes historical versions after a certain amount of inactivity. In the absence of such policies, by default Azure will keep historical versions of data indefinitely. This will cause storage size to increase considerably. If users are using the Frontier Counts system through the application rather than modifying files directly, the application will create historical versions. Therefore, the Azure previous versions are only useful if there is an error outside of the system that needs to be recovered (e.g. an accidental deletion of files).


**Note**: You can also use `infrastructure/storage_mgmt_policies.tf` to implement automated data retention policies (e.g. "delete all files of a certain kind after 2 years"). For example, a configuraiton like the following could implement a 2 year data retention policy.

```terraform
resource "azurerm_storage_management_policy" "example" {
storage_account_id = module.terraform_storage.id

rule {
    name    = "cleanup_old_versions"
    enabled = true
    filters {
    prefix_match = ["fc-bucket/*"]
    blob_types   = ["blockBlob"]
    }
    # TODO: Review these values with Tourism
    actions {
    base_blob {
        tier_to_cool_after_days_since_modification_greater_than    = 183
        tier_to_archive_after_days_since_modification_greater_than = 365
        delete_after_days_since_modification_greater_than          = 730
    }
    snapshot {
        change_tier_to_archive_after_days_since_creation = 1
        change_tier_to_cool_after_days_since_creation    = 2
        delete_after_days_since_creation_greater_than    = 31
    }
    version {
        change_tier_to_archive_after_days_since_creation = 1
        change_tier_to_cool_after_days_since_creation    = 2
        delete_after_days_since_creation                 = 31
    }
    }
}
```

