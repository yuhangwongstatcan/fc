[Octopus Deploy](https://octopus.com/use-case/kubernetes) is a tool that we use to simplify our deployments to Kubernetes. It centralizes the deployment of [our helm charts](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts?ref_type=heads) as well as the configuration of our variables. It also provides a GUI to make self-serving the deployment of our system easier. Octopus Deploy at Statcan is maintained by the Cloud Native team. 

## Useful Links

- [Octopus repo for Frontier Counts](https://gitlab.k8s.cloud.statcan.ca/cloudnative/terraform/octopus/octopus-frontiercounts)
- [k8s/charts repo for Frontier Counts](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts)
- [dev resource group terraform repo](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/environment/dev/frontiercounts-dev-rg)

- [Octopus Deploy URL](https://octopus.cloud.statcan.ca/)

- [Octopus configuration repo](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-octopus-deploy)

## Overview

- Our FC project is set up with dev, test, and prod lifecycle environments (see `lifecycles.tf`)

- You create variables in Octopus that override the variables in the `values.yaml` file of the helm chart that Octopus is deploying

- [Example of putting a values.yaml as configuration in Octopus](https://gitlab.k8s.cloud.statcan.ca/cloudnative/terraform/octopus/octopus-example/-/blob/master/project_vmmui.tf)


Gitlab CI in octopus repo: validate, plan, and (manually) apply terraform. This configures an Octopus environment, but does not actually do the deployment.

Octopus UI: you then go to the Octopus UI to actually deploy the helm chart into the desired environment.

## Concepts

Make sure to check out the Octopus documentation, starting with their [Getting Started](https://octopus.com/docs/getting-started).

### Releases

We use [releases](https://octopus.com/docs/releases) to deploy changes to any configuration other than changing variable values. Releases can be found under the Releases tab on the sidebar.

![octopus release](../img/octopus/base-deploy.png)

If you need to deploy a change, you'll need to create a new release. Note how only the Variable Snapshot can be updated on an existing release. 

### Process

The [deployment process](https://octopus.com/docs/projects/deployment-process) details what environments are deployed to, how, and with which variables. Deployment processes can be found under the Process tab in the sidebar.

Dev, test, and prod each have a slightly different process which allows us to deploy to each environment independently. However dev, test, and prod are each reliant on the previous one, meaning that you can't deploy a release to an environment without first deploying to the previous one (Dev -> Test -> Prod).

If you need to change the way that deployments are done, or add/remove/rename variables you will need to update the process. 

In the process, the project variables that are taken from the Variables tab are defined as well as the `values.yaml` override. The `values.yaml` takes precedence over all other variable definitions so look here if you can't figure out why a variable isn't being updated or can't find where a variable is being defined in the helm chart or Variables tab. 

### Project Variables

The [project variables](https://octopus.com/docs/projects/variables) allow for variables to be set based on which environment they're being deployed to. This allows us to deploy to each environment with the same helm chart while only changing these project variables. Project variables can be found under the Variables tab in the sidebar. 


### Version Control

Our Octopus configuration is version controlled on the [cloud gitlab]((https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-octopus-deploy)) which allows us to roll back deployments or inspect older configurations if necessary. 

Importantly, the git repo is the easiest way to inspect which Process and Variables are currently being used. If you're ever unsure about what specific variables or deployment processes are currently being used, or if you're unsure that your change has been deployed, refer to the commit hash referenced in the Release page. 

## Gotchas

### Updating Variables

When you update a variable in the sidebar even if you've committed the change it won't be updated in any of the existing releases. Make sure to go and click on "Update Variables" if you want an existing release to use your variables in an upcoming deployment.

### Deploying to Prod and Prod Alpha

Prod and Prod Alpha are both deployed to using the Prod process:

![top of release page](../img/octopus/top-of-release-page.png)

Once you click into the DEPLOY/REDEPLOY page for Prod, take not of the Excluded Steps tab: 

![deploy to prod](../img/octopus/deploy-to-prod-page.png)

EXCLUDE the environment that you're not deploying to (confusing, I know). Prod and Prod Alpha should never be deployed to at the same time so just make sure that you've excluded the correct one and continue the deployment process with the green DEPLOY button. 

*Note: If you deploy to both Prod and Prod Alpha at the same time your project variables will get mixed up and one of the environments will end up with the wrong variables*
