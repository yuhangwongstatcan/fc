This piece of documentation is included for convenience - it outlines how to do a few key items with the Azure CLI client.

# How to connect to azure blob storage and pass the account key

Set the following environment variables in your `.bashrc` file so you don't have to manually specify each value

```bash
export AZURE_STORAGE_ACCOUNT=your storage account name
export AZURE_STORAGE_KEY=your azure storage account key
```

These can also be passed explicitly as an argument in the following way:

```bash
az storage blob list --account-key <your account key> --account-name <your account name> <other args ...>
```

# List blobs in azure

- [az docs - list](https://docs.microsoft.com/en-us/cli/azure/storage/blob/directory?view=azure-cli-latest#az_storage_blob_directory_list)


List the blobs in a container - example

```bash
az storage blob list --container-name fc-bucket --prefix validation
```

Can also be shortened to

```bash
az storage blob list --c fc-bucket --prefix validation
```

# Download a blob recursively from a container/storage account

- [az docs on downloading blob/prefix pattern](https://docs.microsoft.com/en-us/cli/azure/storage/azcopy/blob?view=azure-cli-latest#az_storage_azcopy_blob_download)

```bash
az storage azcopy blob download --container fc-bucket -s "validation" -d "." --recursive
```

# Upload a blob recursively to a container/storage account

```bash
az storage azcopy blob upload --container frontier-counts -s "validation" -d "validation" --recursive
```

To just copy the folder to the top of the container, do

```bash
az storage azcopy blob upload --container frontier-counts -s "validation" --recursive
```

Recursively uploading a blob overwrites existing content that was previously present.

# Delete a blob recursively from a container/storage account

```bash
az storage azcopy blob delete --container frontier-counts -t "validation" --recursive
```

# az CLI tool in Docker

```bash
docker pull mcr.microsoft.com/azure-cli
docker run -it mcr.microsoft.com/azure-cli
```

# Back up a container with azure client

az storage blob download  --account-name $AZURE_SOURCE_ACCOUNT_NAME --account-key $AZURE_SOURCE_ACCOUNT_KEY \
                                            --container fc-bucket -s "." -d "." --recursive