# S3 Locations

We use a proxy class to generate S3 Locations in a systematic way. Specifically, there are certain dimensions that uniquely identify a file:

- Stage of processing
- Data source
- Date (Year, Month, and possibly Day)
- Basename

Between some (or all) of these dimensions, we can construct the correct S3 Location where a particular file should be located. The use of our proxy class is explained in more detail below.

# S3Location

We use a named tuple to represent S3Locations.

```python
S3Location  = namedtuple('S3Location', ['bucket', 'prefix', 'basename'], defaults=['','',''])
```

An S3Location is a named tuple with three relevant members: `bucket`, `prefix`, `basename`. 

We use an `S3Location` object to identify either a folder (prefix) or object location. 

**Examples**

```python
from config.api import S3Location

folder = S3Location(bucket='aaw-fc', prefix='inbox/')
objec  = S3Location(bucket='aww-fc', prefix='inbox/', basename='a.zip')
```

Inside the `config.api` module we have a few global variables defining some of our more relevant S3 locations. Although it's possible to specify multiple buckets, we are currently using only one (i.e., `aaw-fc`). 

**Locations:**

```python
INBOX       = S3Location('aaw-fc', 'inbox/')
ERROR       = S3Location('aaw-fc', 'error/')
ARCHIVE     = S3Location('aaw-fc', 'archive/')
STORAGE     = S3Location('aaw-fc', 'storage/')
PROCESSING  = S3Location('aaw-fc', 'processing/')
```

1. `INBOX` - Place where all the raw data is uploaded too. This is the main entry point to ingest data to our pipelines.


2. `ERROR` - Files that aren't from any of our data sources will be removed from INBOX and placed here.


3. `ARCHIVE` - Files that are from any of our valid data sources will be archived here. 


4. `STORAGE` - Persistent storage for multiple data sources


5. `PROCESSING` - Temporary working spaces created while processing our data pipelines. 

The data inside of these locations are stored by following a certain pattern or guideline for easy query and organization. 


1. `INBOX` : this location has no path guidelines, all objects here will be processed. 

2. `ERROR` : `error/<type>/<year>/<month>/<day>/<filename.ext>`

3. `ARCHIVE`: `archive/<data-source>/<year>/<month>/<day>/<filename.zip>`

4. `STORAGE`: `storage/<data-source>/<year>/<month>/<filename.dat>`

5. `PROCESSING`: `processing/`

*Note:*

The `year`, `month`, and `day` of `ERROR` refer to the date in which the error was recognized, while the `year`, `month`, and `day` of the other locations refers to the date of the data.

For example, the location `aaw-fc/error/unknown/2021/04/09/STATSCAN_2019-08-20-00.01.14.268 v2.dat` points to a file called `STATSCAN_2019-08-20-00.01.14.268 v2.dat` that was incorrectly named, the error was **"unknown file received"**, and this occurred on April 9, 2021.

In contrast, the location `aaw-fc/raw/ipil_hwy/2019/08/20190801.dat` refers to a file called `20190801.dat` that belongs to the `ipil_hwy` data source at the `raw` stage of processing, and the date of the data in this file is the month of August 2019 (i.e. records range from August 1, 2019 to August 31, 2019).

## Data Sources

Each piece of data that is used in the Frontier Counts system is considered to be a data source. We distinguish between **time-based** data sources, which are received on a recurring basis, and **file-based** data sources, which do not change on a recurring basis (although their contents can change over time). The following table highlights some key differences between these two kinds of data sources.

| **time-based** | **file-based** |
| -------------- | -------------- |
| New data are recieved on a periodic basis (e.g. every month) | New data are received on an ad hoc basis (e.g. a new port of entry is added in the future) |
| We explicitly track these files over time (e.g. every month gets its own dedicated S3 location) | We do not track these files over time; when a new file for an existing data source is recieved, we **overwrite** the contents of the previous one. For example, if there is an update to the `ports` table, we overwrite the existing `ports` table with the contents of hte new one. |
| Time-based files form the contents of the `vehicles` and `travellers` tables. | File-based files are auxiliary to the contents of the `vehicles` and `travellers` tables (i.e. they are used in the data processing, but they themselves do not contain any records that form counts/sums in the `vehicles` and `travellers` tables).
| Time-based S3Locations are uniquely identified by the combination of `Stage`, `DataSource`, and `Date`. | File-based S3Locations are uniquely identified by the combination of `Stage`, `DataSource`, and `Basename` (i.e. the name of the file itself).|
| Time-based Data sources contain the date as part of their path (i.e. year and month). The reason behind this is for easy time queries. If the time base datasource doesn’t have a day (Some data sources don’t have that level of granularity), we set `day = 01` by convention. For example: `ipil_hwy` data for Dec 1st 2020 is stored as: `/<stage>/ipil_hwy/2020/12/20201201.dat` | File-based Data sources don’t have time series data and are represented by their filename. For example: `/<stage>/<datasource>/<filename>.csv`. |

## Stages

We have identified at least 6 main Data Stages.
 
**Stages:**

- Raw

- Clean

- Transformed

- Aggregated

- Release1

- Release2

**Notes regarding the Stages**

Each Stage will be represented by a S3 Location namedtuple defining a top level bucket path. All references to a ‘Stage’ should be done using such tuple  (e.g., `RAW = S3Location('aaw-fc', '/raw/', '')`)

Each stage could store multiple Data sources by adding a subfolder to the Stage (e.g., `/raw/ipil_hwy`, `/raw/ports`, `/raw/nexus`, etc).

Each stage will contain ‘conflicts’ and ‘historical’ subfolders. The path proceeding the ‘conflicts’ and ‘historical’ subfolders should be the same of the original data. For the historical subfolder a new folder with the name of the original path is created, the file is renamed to the current datetimestamp with nanoseconds precision

**Examples:**

- `/raw/conflicts/<data_path>`

- `/raw/historical/<data_path>/<datetimestamp>.dat`

- `<data_path> should be the same of the original staged data`

- `/raw/ipil_hwy/2020/12/20201201.dat`

- `/raw/conflicts/ipil_hwy/2020/12/20201201.dat`

- `/raw/historical/ipil_hwy/2020/12/20201201.dat/<datetimestamp>`

Conflicts files are created if a particular staged file already exists for a path. The current path is not overwritten, a new `conflicts` entry is created at the corresponding stage containing the same path from the original under the subfolder `/<stage>/conflicts/<path_to_file>`. There can only be one conflict per original file. If a file generates a second conflict for the same file, this will override the previous conflict file with the most recent one.

Historical files are created each time a file is overwritten by resolving a conflict (i.e., automatically or manually). The file to be overwritten is copied to its `historical` path and replaced by the resolved conflict. The file is renamed to the current running datetimestamp with nanoseconds precision (this is to avoid naming conflicts). Note that the historical path defines the original path of the file.

Path generation should never be created manually. For this task, we’ll use a proxy class (i.e., `config.api.S3`).

The documentation for our `S3` proxy class is detailed in the next section.

# S3 Proxy Class API

## Public API

The static methods below comprise the intended public API for the `S3` proxy class. We include complete documentation below.

**`S3.get_error_location(datasource: DataSource, name: str) -> S3Location`**
> Gets the S3Location for a file that arrived in the inbox by error (e.g. incorrectly named file).


**`S3.get_s3_basename(stage: Stage, datasource: DataSource, year: str, month: str, day: str) -> str`**
> Given the stage, datasource, year, month, day of a time-based data source, generates the basename in the correct format. The purpose of this function is to remove the overhead of remembering how to format the basename for a given time-based data source.


**`S3.get_loc(stage: Stage, datasource: DataSource, basename: str) -> S3Location`**
> Gets the S3Location for a given stage, datasource, and basename.


**`S3.get_conflicts_loc(stage: Stage, datasource: DataSource, basename: str) -> S3Location`**
> Gets the S3Location for a given stage, datasource, and basename that was in conflict with an existing object.


**`S3.get_historical_loc(stage: Stage, datasource: DataSource, basename: str) -> S3Location`**
> Gets the S3Location for a given stage, datasource, and basename that are being archived to a historical location.

::: config.api.S3