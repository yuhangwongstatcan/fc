# S3 Minio

Documentation around the S3 MinIO client used in the Frontier Counts project.

### S3Location

There a few relevant S3 locations to our application.
Each folder contains relevant data for different stages of our pipeline.

```
S3Location  = namedtuple('S3Location', ['bucket', 'prefix', 'basename'], defaults=['','',''])
```

An S3Location is a named tuple with three relevant members: bucket, prefix, basename.
We use an S3Location object to identify either a folder or object location.

```
from config.api import S3Location

folder = S3Location(bucket='aaw-fc', prefix='inbox/')
objec  = S3Location(bucket='aww-fc', prefix='inbox/', basename='a.zip')
```

Inside the modules.s3minio.s3location module we have a few global variables defining some of our more relevant S3 locations. Although it's possible to specify multiple buckets, we are currently using only one (i.e., aaw-fc).

Locations:

```
INBOX       = S3Location('aaw-fc', 'inbox/')
ERROR       = S3Location('aaw-fc', 'error/')
ARCHIVE     = S3Location('aaw-fc', 'archive/')
STORAGE     = S3Location('aaw-fc', 'storage/')
PROCESSING  = S3Location('aaw-fc', 'processing/')
```

1. INBOX | Place where all the raw data is uploaded too. This is the main entry point to ingest data to our pipelines.
2. ERROR | Files that aren't from any of our data sources will be removed from INBOX and placed here.
3. ARCHIVE | Files that are from any of our valid data sources will be archived here.
4. STORAGE | Persistent storage for multiple data sources
5. PROCESSING | Temporary working spaces created while processing our data pipelines.

The data inside of these locations are stored by following a certain pattern or guideline for easy query and organization.

1. INBOX : this location has no path guidelines, all objects here will be processed.

2. ERROR : error/<year>/<month>/<day>/<filename.ext>

3. ARCHIVE: archive/<data-source>/<year>/<month>/<day>/<filename.zip>

4. STORAGE: storage/<data-source>/<year>/<month>/<filename.dat>

5. PROCESSING: processing/

### S3Client

Our S3Client is an extension built around the Minio Client API
(https://docs.min.io/docs/python-client-api-reference.html)
(https://github.com/minio/minio-py)

The current version uses minio=6.0.0 as a starting point, but there is also an S3Client for minio=5.0.10 in the repository for reference. Our implementation is in our git repository under src/modules/s3minio/s3client.py

```python
from modules.s3client  import S3Client
"""
for a JSON example look at /vault/secrets/minio-minimal-tenant1.json

{"S3PROXY_URL" : "<url>",
 "S3PROXY_ACCESS_KEY":"<key>",
 "S3PROXY_SECRET_KEY":"<secret_key>
}
"""
client = S3Client(json_file)
```

The S3Client is a child class from minio.Minio and extends its functionality by implementing the following object operations:

| @staticmethod        | members         |
| -------------------- | --------------- |
| get_client           | mkdir           |
| get_premium_client   | ls_objs         |
| get_pychyderm_client | rm              |
|                      | move_obj        |
|                      | cp_obj          |
|                      | pandas_from_csv |

For a complete list of methods available from the parent class minio.Minio look at:
(https://docs.min.io/docs/python-client-api-reference.html#select_object_content)

### Usage & Examples

#### get_client

#### get_premium_client

#### get_pychyderm_client

Usage:

```python
'''
it looks for the {minimal|premium|pychyderm} vault secret instead of manually specifying a json configuration
'''
client = S3Client.get_client()
client = S3Client.get_premium_client()
client = S3Client.get_pychyderm_client()
```

#### mkdir

Creates an empty "folder".
Creates an empty file "self.\_default_folder_file" in the specified folder path.

```python
def mkdir(self, bucket: str, folder:str) -> None:
```

Usage:

```python
from modules.s3client  import S3Client
from config.api import S3Location, ARCHIVE

client = S3Client.get_client()
client.mkdir(bucket='aaw-fc', folder='folder/path/')

#this will add the obj folder/path/.empty to the bucket aaw-fc
```

#### list_object_ex

Same API call than minio.list_objects with extra functionalities. It will not list the .empty files inside folders if default_folder_file is set to False

```python
def ls_objs(self, bucket: str, prefix: str, recursive:bool  = False,
                        only_files:bool = False, default_folder_file:bool=False):
```

Usage:

```python
from modules.s3client  import S3Client

client = S3Client.get_client()

for obj in client.ls_objs(bucket='aaw-fc', prefix='folder/path/', recursive=True,    default_folder_file=False):
    print(obj.object_name)


```

#### rm

Removes all the objects under the bucket and with the `folder` prefix.

```python
def rm(self, bucket:str, folder:str) -> None:
```

Usage:

```python
from modules.s3client  import S3Client

client = S3Client.get_client()

client.rm(bucket='aaw-fc', folder='inbox/')
```

#### mv_obj

Moves a object from a bucket/path to another bucket path on the server-side. If no dst_bucket is defined, the src_bucket is used. The source object will be deleted.

```python
def mv_obj(self,src_bucket: str, src_obj   : str,dst_obj   : str, dst_bucket: str = None):
```

Usage:

```python
from modules.s3client  import S3Client

client = S3Client.get_client()

client.mv_obj(bucket='aaw-fc', src_obj='inbox/a.dat', dst_bucket='error/a.dat')
```

#### cp_obj

Copies a object from a bucket/path to another bucket path in the server side. If
no dst_bucket is defined, the src_bucket is used.

```python
def cp_obj(self,src_bucket: str, src_obj   : str,dst_obj   : str, dst_bucket: str = None):
```

Usage:

```python
from modules.s3client  import S3Client

client = S3Client.get_client()

client.cp_obj(bucket='aaw-fc', src_obj='inbox/a.dat', dst_bucket='error/a.dat')
```

### SQL Query

#### pandas_from_csv

Allows to query structured data in CSV format from the S3 bucket.
This returns a pandas.Dataframe object. You can specify a prefix for multiple files querying and an obj for single file querying. The CSV files can be compressed (i.e., GZIP, BZIP2) or uncompressed.

```python
pandas_from_csv(self, bucket:str, prefix:str, query:str, compression="NONE",  file_header_info="USE"):
'''
@params:
bucket: str | bucket name
prefix: str | prefix or obj name
query: str  | SQL query to apply
compression: str |  NONE, GZIP, or BZIP2
file_header_info: str |  "USE", "IGNORE", "NONE"
'''
```

Usage: single file query

```python
from modules.s3client  import S3Client

client = S3Client.get_client()

data    = client.query_CSV(bucket='aaw-fc', prefix='inbox/input2.csv.gzip', "select s.numerical1 from s3object s  where s.numerical1  > '20' ",  "GZIP")
df.head()
```

Usage: multiple files query under prefix

```python
from modules.s3client  import S3Client

client = S3Client.get_client()

df    = client.query_CSV(bucket='aaw-fc', 'inbox/subfolder/', "select * from s3object ",  "GZIP")
df.head()
```

### Interface

<!-- ::: modules.s3client -->
