# Storage Organization

TODO: document the folder structuree of MinIO and its intended use.