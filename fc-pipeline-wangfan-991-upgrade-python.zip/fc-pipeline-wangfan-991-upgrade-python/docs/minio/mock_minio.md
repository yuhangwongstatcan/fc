There is a file-system version of some MinIO contents in this repository in the location `src/tests/mock_minio`. The purpose of `mock_minio` is threefold:

1. There are certain CSV files that serve as documentation artifacts (e.g. schema files with the naming convention `<stage>/<data source>__<stage>__index.csv`).
2. The unit/integration test suites need to be able to run independent of our live S3 object storage.
3. `mock_minio` allows reference files to be version controlled. By synchronizing the production reference files with `mock_minio` reference files, you can carefully track changes and use Git's diff tools to view changes between reference files.

# Synchronize/Reconcile Mock MinIO

!!! note
    The folder structure of Mock MinIO is shown later in this document.

Throughout the month, the production team will change reference files in the real production MinIO instance based on changes to business requirements. This workflow was chosen as they production team needs very fast turnaround time on reference file changes, and they do not have the expertise needed to update the Git repository and push new changes to the production instance of MinIO. Additionally, it is unreasonable to expect an IT maintainer to perform this updating and synchronizing tasks with a couple hours of turnaround time.

For the reasons mentioned above, the chosen workflow is the following:

- Once per month (after the monthly data that is needed from the system has been created), the maintainer needs to run `src/reconcile_mock_minio.py` - the purpose of this script is briefly outlined below.

::: reconcile_mock_minio

- Once `reconcile_mock_minio.py` is run, there will be a delta between the existing mock_minio files and the changes introduced in the production instance of MinIO. I recommend using VSCode's built-in Git integration to browse the differences and make sure that the differences introduced are expected. I recommend also planning a ~30 minute or 1 hour meeting with one or more members of the production team and the IT maintainer. There will be a number of changes where the IT maintainer will have no idea whether the change was expected or was introduced by error. Therefore, if both parties are in the same review meeting, a subject matter person will be able to advise on whether or not the change was expected.
- Before proceeding, run the unit/integration test suite to make sure that not test failures were introduced from changing the reference files. See the [Unit Test Docs]({{fc_baseurl.doc}}/tests/unit_tests.md)/[Integration Test Docs]({{fc_baseurl.doc}}/tests/unit_tests.md) for information about running the test suites. Alternatively, the continuous integration pipeline for this project will automatically run the unit/integration test suites on commits to any pull request, `dev` branch, or git tags, so it may be easier to push changes to Gitlab, go for a coffee break, and verify the results once the CI pipeline finishes.

!!! danger
    Make sure you check the unit/integration tests after running `reconcile_mock_minio.py`. The data processing logic is **tightly coupled** with reference file changes, so a change in a reference file could very possibly cause a unit/integration test to fail.

    The change might be the intended behaviour, but in this case, the unit/integration test is now out of date and needs to be updated to reflect the new outcome.

    If this activity isn't performed every month, the state of the reference files in the production instance of MinIO will quickly drift from the reference files in Mock MinIO, and the test suite will become unreliable, at which point the data processing logic is essentially untested.

- If any changes to the business logic or unit/integration tests are required, a meeting needs to be arranged between a subject matter expert and an IT maintainer to figure out why the tests are failing, and plan to do the work to make the appropriate changes.
- Once all reference files on Mock MinIO are updated, and any changes to the business/validation logic and/or unit/integration tests have been made, merge these changes into the main release branch. At this point, you can push the changes in reference files of Mock MinIO to the instances of MinIO in the `prod-alpha` release in the production cluster and the release in the development cluster using the `src/staging.py` script. Once you have pointed your configuration to the correct cluster, simply run `python staging.py --reference` to recursively upload all of the reference files in Mock MinIO to the MinIO instance you're connected to. Next, run `python loader.py --check-inbox`, or simply have a production team member press the "Check Inbox" button on the web app once they are ready to overwrite the old reference files on `prod-alpha`/`development` MinIO with the recently uploaded reference files.

# Mock MinIO Folder Structure

Below is the file structure of the `src/tests/mock_minio` folder.

```bash
.
├── aggregated  # Aggregated schema files
│   ├── ndm_24100050
│   ├── ndm_24100051
│   ├── ndm_24100052
│   ├── ndm_24100053
│   ├── ndm_24100054
│   ├── ndm_adjusted
│   ├── ndm_unadjusted
│   ├── sa_in
│   ├── sa_out
│   ├── travellers
│   ├── travellers_leading
│   ├── travellers_main
│   ├── vehicles
│   ├── vehicles_leading
│   └── vehicles_main
├── clean  # Clean schema files
│   ├── e311
│   ├── e63
│   ├── e63_1
│   ├── ipil_hwy
│   ├── manual_entry_travellers
│   ├── manual_entry_vehicles
│   ├── nexus_air
│   ├── nexus_hwy
│   ├── pik
│   └── trc
├── dataflow.diagram.yaml  # YAML diagram for data flow
├── raw  # Raw schema files
│   ├── e311
│   ├── e63
│   ├── e63_1
│   ├── ipil_hwy
│   ├── manual_entry_travellers
│   ├── manual_entry_vehicles
│   ├── ndm_adjusted
│   ├── ndm_unadjusted
│   ├── nexus_air
│   ├── nexus_hwy
│   ├── pik
│   └── trc
├── reference  # Reference schema files AND original reference files
│   ├── countries
│   ├── dimension
│   ├── e311_cutoff_dates
│   ├── fixed_proportion_rules
│   ├── fixed_proportions
│   ├── manual_entry_tracker_travellers
│   ├── manual_entry_tracker_vehicles
│   ├── mapping
│   ├── ndm_24100050_ref
│   ├── ndm_24100051_ref
│   ├── ndm_24100052_ref
│   ├── ndm_24100053_ref
│   ├── ndm_24100054_ref
│   ├── ndm_integrity_between_tables
│   ├── ndm_integrity_config
│   ├── ndm_sa
│   ├── ndm_vectors
│   ├── port_notes
│   ├── ports
│   ├── provinces_and_territories
│   ├── sa_in
│   ├── sa_out
│   ├── sa_parameters
│   ├── us_states
│   ├── work_locations
│   ├── work_locations_action
│   ├── work_locations_trans
│   └── work_locations_trans_action
├── table_relation.diagram.yaml  # YAML data for relational diagram
└── transformed  # Transformed schema files
    ├── travellers
    └── vehicles
```