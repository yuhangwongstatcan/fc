Welcome to the Frontier Counts System documentation. This documentation site is largely focused on developer/maintainer-focused tasks. The reader can go through the contents of this site in the order presented to the index menu on the left of the page, or (re)visit the documentation and search for specific topics that are relevant to the current task.

This home page attempts to indicate and link to all key resources that are related to the Frontier Counts system, as well as point to important (high-level) sections of the documentation.

# Project Artifacts and Organization

The various artifacts associated with the Frontier Counts project are scattered across several repositories. Links and descriptions of each repository are outlined below.

1. The application source code, unit tests, documentation, application-configuration data, and Dockerfile are contained in the Frontier Counts [fc-pipeline`](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline) repository.
2. The subject matter documentation for production users of the system is contained in the Frontier Counts [`fc-docs-site`](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-docs-site) repository. This repository publishes the [Documentation Site](https://tourism-tourisme.pages.cloud.statcan.ca/frontiercounts/frontier-counts/fc-docs-site/) for production users.
3. The helm chart that contains the kubernetes deployment for the Frontier Counts system redesign is contained in the [charts repository](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts/-/tree/master/stable/frontier-counts) of the cloudnative gitlab group. Documentation about the Frontier Counts helm chart as well as how to update it can be found in the [Helm Chart documentation]({{fc_baseurl.doc}}/deployment/release_mgmt).
4. There are three Terraform repositories that provision Azure resources in each of the `development`, `test`, and `production` cloud main environments. Please see the repositories linked below to get to the repositories that manage resources in each of these environments. See the [Frontier Counts Azure Terraform Docs]({{fc_baseurl.doc}}/deployment/terraform_azure) for more information about the resources provisioned by the Frontier Counts system.
5. Any issues that are not specific to Frontier Counts (e.g. questions about SDLC Kubernetes clusters) are managed through the [Net B JIRA](https://jirab.statcan.ca/). A (mostly) complete list of JIRA issues that relate to the Frontier Counts System Redesign can be found by searching for issues that have ["Frontier Counts App Support" as the Epic link](https://jirab.statcan.ca/issues/?jql=%22Epic%20Link%22%20%3D%20CLOUD-9077).

--8<-- "docs/templates/terraform_repos.md"

# Useful External Links

The following links could help with the maintenance of the Frontier Counts system.

Kubecost - Kubernetes costing for resources at Statcan:

<https://kubecost.prod.cloud.statcan.ca>

<https://kubecost.dev.cloud.statcan.ca/>

<https://kubecost.test.cloud.statcan.ca/>

Cloud Native Releases - information on releases from the cloud native team: 

<https://cloudnative.pages.cloud.statcan.ca/en/news-nouvelles/releases-versions/>

Data Engineering CoE - miscellaneous information on data engineering and data science at Statcan: 

<https://data-science-division.pages.cloud.statcan.ca/sades-sasid/data-engineering-coe/>

Webapps - the Frontier Counts webapps:

<https://frontier-counts-webapp.prod.cloud.statcan.ca/>

<https://frontier-counts-webapp.dev.cloud.statcan.ca/>

<https://frontier-counts-webapp.test.cloud.statcan.ca/>
