This page contains documentation about the Frontier Counts web application


!!! info
    **Context**: there are a total of 3-4 users of this web application, all of whom have identical permissions. In short, the web application is a thin user-facing client that sits between a variety of CLI tools and API calls. The primary purpose of this tool is to give the operators of the Frontier Counts system a non-programming interface to perform key system functionalities.

# Frontier Counts Webapp


# Hosting

Our web application is hosted with the [gunicorn WSGI server](https://gunicorn.org/). Full configuration settings can be found in our [helm chart](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts), however a few key items are outlined in this document for convenience.

## Number of worker processes and threads

By default, running a python web application with gunicorn will set `workers` to 1 (see [gunicorn `workers` documentatoin](https://docs.gunicorn.org/en/latest/settings.html#workers)) and `threads` to 1 (see [gunicorn `threads` documentation](https://docs.gunicorn.org/en/latest/settings.html#threads)). We override this configuration and set 4 worker processes and 8 threads to improve concurrency.

!!! warning
    A key feature of the Frontier Counts web application is that the dashboard page sends periodic AJAX requests to an endpoint on the web server that makes a **blocking** API call to argo workflows. The delay for this AJAX request is set in the JavaScript at the end of the `src/webapp/templates/index.html` page in the second parameter of the `setInterval` call. Between setting this number to a safe default (we currently set it to 180 seconds, but it may be shortened slightly if desired) and increasing the number of processes/threads that are available to handle requests, we are able to safely serve requests in light of this blocking I/O.

    Note, however, that even though there are a small number of production users, these users may accidentally have multiple webapp tabs open at the same time. In such a scenario, the webapp server is receiving potentially many requests per user, so the load on the web server could potentially be high.

    During development, this issue led to a very confusing bug. We ran the `gunicorn` process with the default of 1 worker and 1 thread, and set the page refresh mentioned above to every 3 seconds, which had not caused any issues for the overwhelming majority of our development. Then one day while testing, multiple users accidentally had multiple tabs open, and the pace at which page refresh requests were coming in was higher than the pace at which the web application could clear the blocking API calls to argo workflows sever to list workflows. This led to a very confusing issue with the webapp that took several days and many different people to resolve. The solution was to increase concurrency on the server side by increasing the number of worker processses/thread that the `gunicorn` server had to handle requests, and reduce the frequency with which AJAX requests were made to the web application server. Future maintainers should be aware of this setting and ensure that this scenario doesn't happen again. The current settings described above *should* ensure that this issue never occurs again in the lifetime of the system.

There are a few other settings worth mentioning. First, we set the request timeout to 7200 seconds because there can occasionally be some **very** long-lived http requests. This was accidental as a number of features that were originally designed for small amounts of data ended up being used with significantly larger data, which increased the running time by 2-3 orders of magnitude. Second, we set the following options to that access logs and error logs are written to text files that can be inspected by the developers to help debugging efforts: `--access-logfile access.txt --error-logfile error.txt --log-level info`.



# Model View Controller (MVC)


The Frontier Counts web app follows a Model-View-Controller design pattern. The folder structure allows for easy localization of each program logic (i.e., Model, View, and Controllers).

The web app entry point is defined inside the **__init__.py** with all its imports. The flask app configurations are defined inside **config.py**.

# Folder Structure

```bash
webapp
├── __init__.py  # App definition and module imports
├── config.py  # App configurations
├── controllers  # Controllers folder
│   ├── ctrl_conflicts.py
│   ├── ctrl_dashboard.py
│   ├── ctrl_diff.py
│   ├── ctrl_historical.py
│   └── ctrl_tests.py
├── models  # Models folder
│   ├── dashboard.py
│   ├── diff.py
│   ├── io.py
│   ├── session.py
│   └── webtests.py
├── static  # View static resources
│   ├── css
│   ├── imgs
│   ├── js
│   └── vendor
├── templates  # View Layouts
│   ├── conflict.html
│   ├── conflicts.html
│   ├── historical.html
│   ├── history.html
│   ├── index.html
│   ├── layout.html
│   └── tests.html
└── views.py  # App views
```

# Views Folder Structure and Life Cycle
Views are separated into three main locations.

1.	The **views.py** file publishes the view routes and connects them to their HTML layout.

2.	The **static** folder contains resources linked by the HTML layouts such as images, CSS, javascript components, and third-party libraries (i.e., vendors) such as jquery, bootstrap, etc.

3.	The **templates** folder contains the View layouts. All layouts extend from **layout.html**. The navigation menu is rendered in **layout.html**.

```bash
├── static  # View static resources
│   ├── css
│   ├── imgs
│   ├── js
│   └── vendor
├── templates  # View Layouts
│   ├── conflict.html
│   ├── conflicts.html
│   ├── historical.html
│   ├── history.html
│   ├── index.html
│   ├── layout.html
│   └── tests.html
└── views.py  # App views
```

A View’s life cycle starts at the **view.py** route. View routes will take only path parameters (i.e., that means no GET or POST parameters) and renders its correspondent HTML layout. All Views extend from “layout.html.” The layout.html file contains all of the web app HTML layout and menu.

Once a flask view is requested, it will contain all the dependencies and necessary parameters to request data from a controller and rendered in the client space (i.e., browser). All controller actions are performed using POST Ajax requests. The POST request will send a JSON object that will be un-serialized into a python class, a child of the `models.io.PostParms` base class. The controller will output a serialized @dataclass in JSON format.

The view JS interactive components are rendered using JQuery and Json2HTML. Json2Html is a JS library that allows you to convert JSON to DOM HTML while managing events and allowing template functionalities. All interactive components are defined under static/js/views.js, and their styles under static/css/views.css.

## View Lifecycle Example

Client requests route path

`conflicts/<stage>/<year>`

Flask returns a rendered template (i.e., conflicts.html) by passing all the necessary information:

```python
@app.route("/conflicts/<stage>/<year>", methods=['GET'])
def conflicts(stage:str, year:str = str(datetime.now().year)):
    init_session()
    return render_template('conflicts.html',
                            config   = app.config,
                            session  = session,
                            params   = StageParams(stage, year),
                            navigation_menu=navigation())
```

Then, inside the template (conflicts.html):

[[% raw %]]
```javascript
{ % extends "layout.html" % }
{ % set active_page = "conflicts_" + params.stage % }
{ % block local_dependencies % }{ % endblock % }

{ % block topbar % }{ % endblock topbar % }

{ % block content % }

<div id="content"></div>

<script>
  $(document).ready(function () {
    display_loader('#content');
    var reload = setTimeout(function () { location.reload(true); }, 90 * 1000);


    var StageParams = { { params | tojson | safe } };


    postJson('{ { url_for("get_conflicts") } }', StageParams, function (data) {
      clearTimeout(reload);
      var baseurl = "{ { url_for('conflicts', stage=params.stage, year='REPLACE') } }"
      display_timelines('#content', data, baseurl);
    });

  });
</script>

{ % endblock content % }
```
[[% endraw %]]

1.	First, the view extends from the layout.html template.

2.	We set the `active_page = <menu_id>` item to highlight a menu item  as active. See `views.py:navigation()` function for more details of the menu. The `active_page` variable should point to a menu item id.

3.	Define the view code inside the `\{\%block content \%\}`

    a.	In this case, the view only contains an empty div with a unique identifier (i.e., content).

    b.	The view displays the loader inside the `div.#content` and sets a timer to refresh the page after 90 secs if nothing was rendered.

    c.	Finally, the view makes a POST request to the controller by sending a JSON `StageParams` object obtained by the route. The `StageParams` object was created and passed to the template when rendering the view route.

    d.	If the request was successful, the controller's response will be used by the **display_timeline** function to render the interactive view components using jquery and json2html.


### Notes regarding view components:

View components are javascript functions; they are in charge of rendering components and manage client events such as clicks, change status, etc.… Inside a view component implementation, you'd find some parameter names that get repeated quite often. These follow these guidelines:

1.	controller: str -> URL to the controller to retrieve and send actions to

2.	container_id: str -> HTML DOM id tag where to insert the new rendered DOM tree

3.	Data: object -> if the component doesn't need to call a controller, it will receive data from a controller response called outside the component.

4.	Options object -> any other necessary configuration parameters…

# Controllers (Folder Structure)

Controllers are separated into different files following their business logic.

```bash
├── controllers  # Controllers folder
│   ├── ctrl_conflicts.py
│   ├── ctrl_dashboard.py
│   ├── ctrl_diff.py
│   ├── ctrl_historical.py
│   └── ctrl_tests.py
```

Controllers take user AJAX POST requests and return JSON objects to the client (i.e., browser), which renders interactive components and executes client actions. The controllers have only a single route name and receive all their parameters by a JSON object converted to a python class. This ensures that all the necessary data has been submitted to the controller to execute an action. The parsing process of taking the JSON object from the post request into un-serializing a child class of PostParams will fail if there are more or fewer fields than the specified in the child class. Keep in mind that Views only render data and communicate parameters to the JS view components.

## Controllers Life Cycle Example

```python
@app.route("/conflicts", methods=['POST'])
def get_conflicts():
    """
    List all the existing conflicts in a Stage

    StageParams -> StageOutput
    """
    init_session()

    params    = StageParams.load()

    … #More Code Logic

    output = StageOutput(header=f"{params.stage}",
                             desc  =f"descriptcion”,
                             bucket= stage.value.bucket,
                             stage = stage.name,
                             mode  = Mode.conflict,
                             year  = params.year,
                             count = total_datasource,
                             timelines = timelines)

    return jsonify(output)
```

1.	Controller routes don’t specify path parameters. They are all received in a JSON object. (e.g., StageParams.load())

2.	Models.io.StageParams extends from PostParams which the static method load() will create an instance of the child class (i.e. StageParams) containing all the parameters sent to the controller route from the client.

3.	The controller does its business logic or client action.

4.	Finally, it returns a jsonify @dataclass StageOutput object to the client. This object contains all the necessary data for the js view interactive component to render on the client-side.


# Models (Folder Structure)

Models are separated by their business logic too. Probably the most relevant module inside models is the **io** module. The IO model contains the Request Params and Output Objects used by Controllers.

```bash
├── models  # Models folder
│   ├── dashboard.py
│   ├── diff.py
│   ├── io.py
│   ├── session.py
│   └── webtests.py
```

# View Routes

![View Routes](../img/view-routes-1.png)

# Controllers Routes

![Controller Routes 1](../img/view-routes-1.png)
![Controller Routes 2](../img/view-routes-1.png)

# Working inside of a Container in a Kubernetes Cluster

As for flask route creation goes, we constantly use the function **url_for** to generate URLs and routes for our app. This function is used either in the server/python side by importing **from flask import url_for** or using it inside a template.

When working inside a container, we have no access to reverse proxy configurations, which creates the need to override the original behaviour of **url_for** by adding an URL prefix to all routes and paths.

We override the **url_for** original behaviour in **__init__.py** web app module where we check if the environment variable “FLASK_BASE_URL” exists and prepended its value to the result of calling **url_for** with the same arguments.

Make note that from now and on, while working on the server-side (i.e., Python), you should call **prefix_url_for** instead of **url_for**. For easy code integration, the following line should be used in your code trying to use the function **url_for**:

from webapp import prefix_url_for as url_for

The @app.context_processor defined in the file **__init__.py** overrides the url_for function with the prefix_url_for version. The context_processor decorator replaces url_for with function prefix_url_for on the template side.

```python
@app.context_processor
def override_url_for():
    return dict(url_for=prefix_url_for)
```