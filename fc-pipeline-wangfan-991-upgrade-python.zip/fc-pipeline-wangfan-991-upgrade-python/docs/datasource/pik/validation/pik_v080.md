# Documentation for Validation pik_v080

### ID
pik_v080

### Related Business Rule
None (pik_080 is an empty business rule)

### Name
Summary of Conflicts in Trip Purpose - PIK

### Type
Validation

### Purpose
Provide a summary of PIK records where there is a conflict between the crew and immigration indicators.

### Additional Details

##### Conflict in Trip Purpose
A PIK traveller can declare their purpose of trip as study, visit, work or immigration, or a combination of these. Frontier Counts also records
crew as a trip purpose, and there is an indicator for crew in the raw data. However, Frontier Counts only records one trip purpose (the "main"
trip purpose") for each arrival. As such, the current business process is to code trip purpose from PIK as follows:
> - First, Immigration, if the *purpimm* = 1
> - Second, Crew, if *crew* = "Y"
> - Then move to additional purposes

If both immigration AND crew are indicated for any records, then they will be counted as immigration instead of crew. The objective of this
validation is to confirm that there are not too many such cases. If there are, this could indicate an issue with the CBSA data, or a need to
revisit the business logic of coding trip purpose from PIK data.

Concretely, any records with *purpimm* = 1 and *crew* = "Y" should be flagged for this validation.

##### Dashboard Display
The dashboard displays a count of cases where immigration and crew indicators are in conflict (*count_conflicts*), as well as a count of 
records indicated as immigration (*count_imm*; count of *purpimm* = 1), a count of records indicated as crew (*count_crew*; count of *crew* = 
"Y") and the number of records in conflict as a percentage of immigration and crew records.

Additional filters are provided for year, month and airport (*wloc*).

### Validity
March 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
None
