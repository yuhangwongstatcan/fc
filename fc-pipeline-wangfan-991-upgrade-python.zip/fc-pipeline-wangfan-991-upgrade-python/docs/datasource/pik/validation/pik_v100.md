# Documentation for Validation pik_v100

### ID
pik_v100

### Related Business Rule
pik_100

### Name
Summary of Imputed PIK Durations

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of PIK records that had their duration imputed versus records that had a valid duration.

### Additional Details

##### Imputed Durations vs. Valid Durations
Missing *durationofstay* (for visitors) and *durofabsn* (for Canadian residents) are imputed by the rule pik_100 using appropriate donor records
which have completed durations. This validation provides the Production Team with a visualization to summarize the number of records with 
imputed durations versus the number with valid durations (the potential donors).

The count of "Imputed Durations" should include all records where imputation was done in pik_100. That is:
> - where *purpimm* = 0 and *rescntry* = "CAN" and (*durationofstay* < 365 or *durationofstay* = [blank]) and *durofabsn* = [blank] for **Canadian 
residents**
> - where *purpimm* = 0 and *rescntry* != "CAN" and *durationofstay* = [blank] for **visitors to Canada**

The count of "Valid Durations" should include all potential donor records from pik_100. That is:
> - where *purpimm* = 0 and *rescntry* = "CAN" and (*durationofstay* < 365 or *durationofstay* = [blank]) and *durofabsn* != [blank] for
**Canadian residents**
> - where *purpimm* = 0 and *rescntry* != "CAN" and *durationofstay* != [blank] for **visitors to Canada**

Any immigrating travellers or converted long-term visitors (in the case of Canadian residents) should not be included in the "Valid Durations".

##### Dashboard Display
The dashboard displays two pie charts, one for "Canadian Residents" and one for "Visitors to Canada" (*traveller_group* from the output), where 
each pie chart is divided into two wedges: "Imputed Durations" and "Valid Durations" (*imputation_status* from the output). The records which are 
excluded from this validation, as noted above, should not appear in the dashboard.

Additional high-level filters for year, month and airport (*wloc*) are provided.

### Validity
March 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation on pik_100]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_100)  
