# Documentation for Validation pik_v110

### ID
pik_v110

### Related Business Rule
pik_110

### Name
Summary of Trip Purpose as Work - PIK

### Type
Validation

### Purpose
Provide a summary of PIK records where the trip purpose has been coded as "work" (*purpose4* = 3).

### Additional Details

##### Trip Purpose as Work
A PIK traveller is considered to have trip purpose of work if *purpwork* = 1 (and *purpimm* = 0 and *crew* = "N"), however there is some ongoing
concern that travellers would misunderstand the trip purpose questions at the Kiosk, and would declare their trip purpose as "work" (technically,
requiring a work permit; to be employed by a resident entity of Canada) when in reality their purpose is "business" (which should be declared as
"visit" (*purpvisit* = 1)).

This is a concern because business travellers are part of the tourism population and workers are not. Therefore, if business travellers are
declaring their trip purpose as work, we will be under-counting the tourism population. The objective of this validation is to view the count of
workers compared to (and as a percentage of) the total travellers in order to evaluate if the proportion is becoming too high, which could indicate
that the trip purpose methodology needs to be revisited.

**Note: This validation should use the transformed file (travellers) as input.**

##### Dashboard Display
The dashboard displays a count of cases where trip purpose is work (*workers*; sum of *count_of_entries* where *purpose4* = 3), as well as a 
count of all arrivals (*travellers*; sum of *count_of_entries*) and the count of workers as a percentage of the total traveller arrivals.

Additional filters are provided for year, month, airport (*port*) and residency group (*residency_group*).  

Residency group (*residency_group*) is extracted from the **countries.csv** file by linking on *country_of_residence*.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The countries reference file is required.  
The dimension file for country residency group is required.

### Related Pages
[Documentation on pik_110]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_110)  
[Documentation on Countries]({{fc_baseurl.doc}}/reference/countries)
