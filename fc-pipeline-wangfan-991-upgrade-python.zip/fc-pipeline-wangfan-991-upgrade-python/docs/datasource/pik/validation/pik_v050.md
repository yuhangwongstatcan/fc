# Documentation for Validation pik_v050

### ID
pik_v050

### Related Business Rule
None (pik_050 is an empty business rule)

### Name
Summary of Unexpected Kiosk Flows

### Type
Validation

### Purpose
Provide a summary of travellers who went down unexpected kiosk flows.

### Additional Details

##### Kiosk Flows
The flow (questions asked of a traveller) at the PIK Kiosks is driven by the residency of the traveller and the country that issued the document.
However, in some cases, a traveller can be sent down the wrong flow because the Kiosk misreads the MRZ code from the document or due to other
technical issues.

Given that these Kiosk flows do not have a direct impact on Frontier Counts processing, typically no action is required as a result of this
validation. The main objective is to ensure that there is not a **significant** amount of unexpected flow patterns, as this could indicate a larger
issue with the Kiosk software that should be flagged to CBSA. A minimal number of failures is expected each month.

Note: The "document-issuing" country is not a raw variable provided by CBSA. It is derived as *doc_country* by the IT PIK Splitter program.

##### Identifying Unexpected Flows
The following cases should be identified and tabulated for the validation:

"Canadian Document with Duration of Stay"  
Any traveller using a Canadian passport or permanent resident card **should not** be asked for their duration of stay, whether or not they are
residents of Canada. Concretely, if *doc_country* = "CAN" and *durationofstay* is not missing, then flag under this category.

"Foreign Document without Duration of Stay"  
Any (non-immigrating) traveller using a foreign-issued passport **should** be asked for their duration of stay, regardless of their residency.
Concretely, if *doc_country* = "OTH" and *durationofstay* is missing and *purpimm* = 0, then flag under this category.

"Canadian Resident without Duration of Absence"  
A Canadian resident **should** be asked for a duration of absence if they are using a Canadian-issued document (all cases), and if they are using a 
foreign-issued document (as long as they are not immigrating). Concretely, if *rescntry* = "CAN" and (*doc_country* = "CAN" or (*doc_country* = OTH"
and *purpimm* = 0) and *durofabsn* is missing), then flag under this category.

"Foreign Resident with Duration of Absence"  
A resident of a country other than Canada **should not** be asked for a duration of absence, regardless of the type of document they're using.
Concretely, if *rescntry* != "CAN" and (*doc_country* = "CAN" or (*doc_country* = "OTH" and *purpimm* = 0) and *durofabsn* is not missing), then
flag under this category.

"Canadian Document with Purpose of Trip"  
Any traveller using a Canadian passport or permanent resident card **should not** be asked for their purpose of trip, whether or not they are 
residents of Canada. Concretely, if *doc_country* = "CAN" and (*purpimm* = 1 or *purpstudy* = 1 or *purpvisit* = 1 or *purpwork* = 1), then flag
under this category.

##### Dashboard Display
A summary of the count of occurrences of unexpected kiosk flows by type (*unexpected_flow*) is displayed in a grouped bar chart by airport (*wloc*).

Additional filters are provided for year and month.

### Validity
March 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
None
