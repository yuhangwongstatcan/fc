# Documentation for Validation pik_v040

### ID
pik_v040

### Related Business Rule
None (pik_040 is an empty business rule)

### Name
Summary of Large Traffic Gaps in PIK

### Type
Validation

### Purpose
Provide a summary of incidences of periods of more than one hour with no travellers at major airports.

### Additional Details

##### Determining Large Traffic Gaps
The objective of this validation is to identify potential PIK system outages by flagging any cases with "large gaps" between consecutive traveller
arrivals. This is only done at major airports since the arrival of international flights at smaller airports can be sporadic. A large gap is defined
as more than one hour between consecutive kiosk sessions between 7:00 AM and 11:59 PM, and the major airports are defined as Vancouver, 
Calgary, Toronto Pearson (Terminals 1 and 3) and Montreal.

Concretely, to identify cases of large gaps:
> - For each of *wloc* in (3961 [Montreal], 4971 [Toronto T1], 4974 [Toronto T3], 7011 [Calgary] and 8212 [Vancouver]), order the records (independently by airport) 
>   for the month ascending by *kioskdttm*
> - If the time between a preceding record and a following record is greater than 60 minutes, the preceding record is not the **last** record of a 
>    day and the following record is not the **first** record of a day, then flag the gap for output in this validation

##### Dashboard Display
The large traffic gaps are displayed as a table with the following columns:
> - Date
> - Start Time of Traffic Gap (extracted from *kioskdttm*)
> - End Time of Traffic Gap (should be more than hour after the preceding record) (extracted from *kioskdttm*)
> - Airport (*wloc*)

There is a high-level filter for year and month, so that the user can specify for the table to only display gaps for a particular month and year, as well as an auxiliary filter for airport.

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
None
