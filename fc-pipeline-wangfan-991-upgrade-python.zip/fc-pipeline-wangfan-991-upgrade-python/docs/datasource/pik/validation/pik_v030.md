# Documentation for Validation pik_v030

### ID
pik_v030

### Related Business Rule
None (pik_030 is an empty business rule)

### Name
PIK Daily Volume Summary

### Type
Validation

### Purpose
Provide a visualization for end users to view a count of travellers (records) by day after removal of invalid records.

### Additional Details

##### Dashboard Display
This visualization shows a bar graph to display the PIK volume by day. In PIK, since each record represents a traveller, it is equivalent to 
say that a daily count of travellers or a count of records is shown.

This graphic can be filtered dynamically by month (and year). Although these are components of the date, over time as the dashboard begins to 
include a significant amount of historical data, it will be useful to be able to have a high-level filter for month and year, and then to
see the daily graph.

Dynamic filters are also provided for airport (*wloc*) and crew status (*crew*).

### Validity
March 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
None
