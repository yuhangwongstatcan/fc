# Documentation for Validation pik_v090

### ID
pik_v090

### Related Business Rule
pik_090

### Name
Unmatched or Terminated PIK Countries

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of PIK country codes that could not be matched to the mapping file, or are from terminated
countries.

### Additional Details

##### Unmatched Countries
In order to add the Frontier Counts country code to the PIK data in edit pik_090, the PIK raw data is matched to the pik country of residence
mapping file, which maps the three-letter alpha country code from PIK to the five-digit Frontier Counts country code. In the case where there is no
match in the mapping file, the corresponding record is dropped.

This validation provides a visual summary of dropped records with their three-letter alpha code, so that the Production Team can investigate if
there is an error in the PIK raw data (and the record really should be dropped), or if an update to the country reference and mapping files is
required.

##### Terminated Countries
The **countries.csv** reference file provides a start and end date for the validity of each country in the Frontier Counts system. This validation 
also provides a summary of any cases from the raw PIK data which were matched to the pik country of residence mapping file, but whose corresponding
Frontier Counts country code has passed its end date (i.e. *country_end* < month being processed in the system).

To determine these cases, each PIK record must be matched to the pik country of residence mapping file on *rescntry* from PIK raw = *key* from the
mapping file, then the corresponding *value* (Frontier Counts country code) matched to the **countries.csv** reference file on *country_of_residence*
and the corresponding *country_end* examined as above.

##### Dashboard Display
The dashboard displays this validation in side-by-side bar charts, one for "Unmatched Countries" and one for "Terminated Countries" 
(*country_code_type* for the output). The individual values (the bars) are the country values (*rescntry*).

Additional filters are provided for year, month and airport (*wloc*).

### Validity
March 2017 - present

### Required Auxiliary Inputs
The country reference file and the PIK country of residence mapping file are both required.

### Related Pages
[Documentation on pik_090]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_090)  
[Documentation on Countries]({{fc_baseurl.doc}}/reference/countries)  
[Documentation on PIK Country Mapping]({{fc_baseurl.doc}}/datasource/countries/pik_country_mapping) 
