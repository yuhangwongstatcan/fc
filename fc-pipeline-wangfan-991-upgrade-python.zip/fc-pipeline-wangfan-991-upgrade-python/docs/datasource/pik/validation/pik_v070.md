# Documentation for Validation pik_v070

### ID
pik_v070

### Related Business Rule
pik_070

### Name
Summary of PIK Edits

### Type
Validation

### Purpose
Provide a summary of PIK records where edits were done in order to align with tourism concepts.

### Additional Details

##### Edits
This validation summarizes the edits done in business rule pik_070 in order to align with established UNWTO tourism concepts.

Currently, there are two edits done. Additional edits could be added to this rule in the future, and subsequently summarized in this validation.

"Remove Duration for Immigrants"  
Count of cases where, if *purpimm* was = 1, then *durationofstay* was set to missing and/or *durofabsn* is set to missing.

"Recode Long-Term Visitors"  
Count of cases where, if *durationofstay* was >= 365, then *rescntry* was set to "CAN".

##### Dashboard Display
A summary of the edits by type (*edit*) is displayed in a line chart by day.

Additional filters are provided for year, month and airport (*wloc*).

### Validity
March 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for pik_070]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_070)
