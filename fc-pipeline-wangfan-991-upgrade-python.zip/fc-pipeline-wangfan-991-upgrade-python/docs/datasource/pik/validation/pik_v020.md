# Documentation for Validation pik_v020

### ID
pik_v020

### Related Business Rule
pik_020

### Name
Summary of Removed Records - PIK

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of records that were removed from the PIK raw data for various reaons.

### Additional Details

##### Removal Reasons
The removed records from edit pik_020 can be grouped as follows for the summary validation:
> - Known test or health check records based on *kiosk_ssn_id*, *lname* or *fname* as "Test Records"
> - Missing *kioskdttm* records as "Missing KIOSKDTTM"
> - Missing *kiosk_ssn_id* records as "Missing KIOSK_SSN_ID"
> - Missing *arrivingfrom* records as "Missing ARRIVINGFROM"
> - Missing *rescntry* records as "Missing RESCNTRY"
> - Duplicate records as "Duplicates"

##### Dashboard Display
Any removed records are displayed in a pie chart graphic by *removal_reason* (described above with applicable labels).  

This graphic can be filtered dynamically by month and year, and by airport (*wloc*).

### Validity
March 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for pik_020]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_020)
