# Documentation for Validation trc_v000

### ID
trc_v000

### Related Business Rule
None (trc_000 is an empty business rule)

### Name
Summary of Unexpected Values - TRC

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected values for discrete variables in TRC.

### Additional Details

##### Variable Values
The system is only expecting to see certain values in each discrete variable, as specified in the dimension files **dim__trc__...**. The valid
values are based on the HTML files received historically from CBSA and columns coded by the TRC Loader function. The Production Team needs to be 
aware of unexpected values, because the system may not be able to handle them, or they could indicate invalid records from TRC raw data.

Specifically, the following variables should have their values validated:
> - *conveyance_type* in ("Airplane","Pleasure Craft","Automobile","Snowmobile","All-Terrain Vehicle")
> - *trav_char* in ("passenger_ovn","passenger_ovs","passenger_sdy","passenger_usa")

##### Dashboard Display
Any invalid values are displayed in a bar chart grouping invalid codes by variable name.  

This graphic can be filtered dynamically by month and year.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The dimension files for the trc data source are required.

### Related Pages
None
