# Documentation for Validation trc_v010

### ID
trc_v010

### Related Business Rule
trc_010

### Name
Summary of Unexpected TRC Data

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected data (work location and/or transportation type) received from the TRC system.

### Additional Details

##### Unexpected Work Locations or Transportation Types
This validation is produced for the Production Team to examine records that could not be matched to the TRC work location reference file
(**work_locations__trc.csv**) based on work location and transportation type (*work_location* and *conveyance_type* from the raw data), indicating 
that they are not accepted for TRC processing by default.

Since TRC data are only anticipated to be received from certain reporting sites and only for select transportation types, these unexpected cases 
could indicate work locations which are accepting new types of transportation, or data errors, both of which need to be investigated.

Since the TRC data is transmitted by *location*, which is a text string matched to a work location in edit trc_005, it is also quite possible
that *work_location* ends up blank if we cannot map a *location* due to a new site, an alternate spelling or a mistake. These unmatched cases
based on *location* will also be flagged here since *work_location* will be blank and therefore unmatched with the TRC work location 
reference file.

##### Dashboard Display
The count of travellers by unexpected work location and transportation type (unmatched *work_location* and *conveyance_type*) is displayed in a 
table showing the *work_location* and applicable *location*, as well as the *conveyance_type* that could not be matched.

For cases where there was no match because *work_location* was blank (likely not linked in the trc_005 mapping from *location*), the 
*work_location* column in the validation table is left blank, with the *location* and *conveyance_type* filled out. 

Filters are available by year and month.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The TRC work location reference file is required.

### Related Pages
[Documentation for trc_010]({{fc_baseurl.doc}}/datasource/trc/business_rule/trc_010)
