# Documentation for Validation trc_v020

### ID
trc_v020

### Related Business Rule
trc_020

### Name
Unmatched TRC Countries of Residence

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of reported TRC countries of residence that could not be matched to the **countries.csv**
reference file or to the TRC country of residence mapping file.

### Additional Details

##### Unmatched Countries
In order to add the Frontier Counts country code to the TRC data in edit trc_020, the TRC data is first matched to the **countries.csv** reference file
(by matching *country* from the raw data with *country_name_en* from the reference file), and, if this is unsuccessful, to the mapping file
**map__trc__raw__country__trc__clean__country_of_residence.csv** in order to catch alternate spellings or mistakes. In the case where there is no 
successful match to either reference file, the corresponding record is dropped.

This validation provides a visual summary of dropped records with their unmatched *country* name, so that the Production Team can investigate. Since
the TRC countries are free text, an unmatched *country* typically indicates either an alternate spelling or name (e.g. US VIRGIN ISLANDS instead of
Virgin Islands, U.S.) or a spelling mistake (e.g. BOSNIA HERCEGOVINA). These cases simply need to be added to the TRC country of residence mapping reference file
so that they can be matched to the correct Frontier Counts country code when the pipeline is rerun.

##### Dashboard Display
The count of travellers by unmatched country of residence are summarized in a table with a filter for month and year. 

The table shows the unmatched *country* and the corresponding *count* of travellers that could not be matched.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The countries reference file is required.  
The trc country of residence mapping file is required.

### Related Pages
[Documentation on trc_020]({{fc_baseurl.doc}}/datasource/trc/business_rule/trc_020)  
[Documentation on Countries Reference File]({{fc_baseurl.doc}}/reference/countries)  
