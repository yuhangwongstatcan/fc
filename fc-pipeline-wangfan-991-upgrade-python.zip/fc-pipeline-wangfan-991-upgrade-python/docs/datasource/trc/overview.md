# TRC Data Source

### TRC Program
The Telephone Reporting Centres (TRC) provide a means for travellers arriving in Canada to make their declaration to the CBSA without direct
contact with an agent. This can be required due to the remoteness of the arrival location, the procedures around certain types of arrivals or 
other reasons. All arrivals reported through a TRC are captured in the TRCS ("TRC System"), with data provided  to Statistics Canada on a monthly
basis.

The CANPASS trusted traveller program (an ancestor of the current NEXUS trusted traveller program) is also reported through the TRCS data, although
the program is almost completely phased out, so CANPASS arrivals would only represent a small portion (if any) of the travellers in TRCS data. 
Previously, the Frontier Counts program referred to this data source as "CANPASS" since it used to represent a higher proportion, so some legacy
documentation may use this name, however in the redesigned system, the data source is now called "TRC" to more accurately reflect the data that
CBSA is providing.

### Data Reception
TRC data is received in a single HTML file each month. The file provides an aggregate monthly total by TRC reporting site, mode of transportation
and various traveller characteristics (country of residence, trip duration and arriving from, in some cases).

The parameters of the received files are as follows:
> - File type: .html
> - Naming conventions:
>>  - File name of the form: TRC - E63 report MMM YYYY.html (Note: occasionally MMM reported as MMMM)
>>>   - Note: To identify TRC files, can use the pattern: TRC*.html
> - Timeliness: One file is received monthly near the middle of the following month
>>  - For example, file for February received in mid-March
> - Granularity: Monthly
> - Date Variable: N/A; year and month need to be extracted from one of the headers of the file:
>>  - "Monthly Summary E63 for Statistics Canada, Month of: YYYY/MM"
> - Format: 
>>  - YYYY/MM

### TRC Loader Function
To create the trc raw data with the loader function, the following steps needs to be done.  
**Note that some of the columns in the TRC HTML file do not have clear headers, some are staggered and in an HTML file it can be difficult to define
columns. As such, the column lettering below is based on file organization if the file is opened in Excel.**

##### Extract Date
Extract the date from the file header in Row 5, "Monthly Summary E63 for Statistics Canada, Month of: YYYY/MM", as YYYY-MM-DD, where YYYY and MM 
are extracted from the header label and DD = 01. Copy this *date* to every record in the raw data

##### Fill Down and Remove Unnecessary Rows and Columns
The columns A and B (which define the reporting district and the reporting site) are "staggered" in that they are only filled out for the first row 
among all the rows that they are applicable to, so they need to be filled down.
Concretely, for any blanks in column A or column B, fill down from the last non-blank value until reaching another non-blank value.

Then the following unnecessary rows can be removed:
> - If column E ("Psg Type" in the Excel) is blank
> - If column X ("Total" in the Excel) is blank
> - If column X = "Total"

Finally, the columns C, D, F, H, J, K, M, N, P, Q, S, U, W and X ("Total" in the Excel) can be removed as they do not contain any information that 
is required for TRC processing in Frontier Counts.

##### Convert Traveller Information from Wide to Long Format
Generate a record in the raw data for each of the following, coding the country of residence and the traveller characteristics as specified, and
copying the date (as specified above) and the summary values from columns A, B and E, for each generated record:
> - Any non-zero/non-missing values from Column G ("US Residents 1 Day" in the Excel) as *count*, setting *country* = "United States of America" 
> and *trav_char* = "passenger_sdy"
> - Any non-zero/non-missing values from Column I ("US Residents 2 Days or more" in the Excel) as *count*, setting *country* = "United States of 
> America" and *trav_char* = "passenger_ovn"
> - Any non-zero/non-missing values from Column L ("Returning Canadian Residents From US" in the Excel) as *count*, setting *country* = "Canada" and
> *trav_char* = "passenger_usa"
> - Any non-zero/non-missing values from Column O ("Returning Canadian Residents From Other Countries" in the Excel) as *count*, setting *country*
> = "Canada" and *trav_char* = "passenger_ovs"
> - Any non-zero/non-missing values from Column T ("Resident of other Countries 1 Day" in the Excel) as *count*, setting *country* equal to the 
> corresponding value of Column R ("Country") from the same row, and setting *trav_char* = "passenger_sdy"
> - Any non-zero/non-missing values from Column V ("Resident of other Countries 2 Days or more" in the Excel) as *count*, setting *country* equal 
> to the corresponding value of Column R ("Country") from the same row, and setting *trav_char* = "passenger_ovn"

### Variables in the Raw Data
To create the trc raw data, combine the extracted data as follows:

> - date: extracted from the HTML file header as described in the previous section
> - district: from Column A of the HTML
> - location: from Column B of the HTML
> - conveyance_type: from Column E of the HTML
> - country: coded as described in the previous section based on which column in the HTML file the count comes from
> - trav_char: coded as described in the previous section based on which column in the HTML file the count comes from
> - count: extracted as described in the previous section from Columns G, I, L, O, T or V
