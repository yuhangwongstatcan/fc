> This article is a stub, and could use further context

## Overview

The travellers data source exists as an intermediate data source between the CBSA data sources and the Frontier Counts releases. It has two stages: [Transformed and Aggregated]({{fc_baseurl.doc}}/getting_started/monthly_production_overview/#pipeline-steps). The transformed travellers data follows the individual data sources' clean to transformed pipelines and at this stage each data source's data is still stored in separate files. 

After individual data sources have been run through their pipelines up to the point of creating the transformed data, the next step is to aggregate all of the sources together in order to be able to generate totals for the Frontier Counts system. This task is accomplished by running the aggregation pipeline.

*UNMODIFIED AGGREGATED FILES (TRAVELLERS)*

These consist of all the transformed files for the individual data sources appended together, without editing to remove variables or protect confidentiality. They are the most comprehensive analytical files in the Frontier Counts system.

*MAIN RELEASE FILES (TRAVELLERS_MAIN)*

These are the aggregated files from which all additional steps for the main Frontier Counts release (containing all sources) are generated.

They are created from the unmodified aggregated files as follows:

- Drop variables considered to be for "analysis" which do not serve any purpose for dissemination (work_location and data_source)
- Roll up to published port instead of the original port of entry in order to protect confidentiality of any sensitive ports. This is described in the documentation on the ports file
- Re-aggregate the count_of_entries across all other dimensions after doing these two operations to make the file cleaner and smaller (no duplicates across key values)

---

The travellers tables are made up of data from all data sources. 
