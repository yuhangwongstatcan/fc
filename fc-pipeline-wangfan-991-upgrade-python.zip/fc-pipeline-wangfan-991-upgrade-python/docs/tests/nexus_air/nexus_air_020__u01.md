# Documentation of Unit Test nexus_air_020__u01

### ID
nexus_air_020__u01

### Related Business Rule
nexus_air_020

### Purpose of Test
This unit test will ensure the integrity of the business rule which redistributes the "Other" citizenships to Canadian or American citizenships.

The following cases are tested:
> - A work location with *citizenship* of 500 Canada, 400 United States and 77 Other results in **543** Canada and **434** United States
>>  - The total number to redistribute (impute) is 77 and among the known proportions there are 500/900 Canada and 400/900 United States,
>>  so there are 43 (round(77 x (500/900))) travellers added to "Canada" and 34 (77-round(77 x (500/900))) travellers added to "United States"
> - A work location with *citizenship* of 1000 Canada, 1200 United States and 100 Other results in **1045** Canada and **1255** United States
>>  - The total number to redistribute (impute) is 100 and among the known proportions there are 1000/2200 Canada and 1200/2200 United States,
>>  so there are 45 (round(100 x (1000/2200))) travellers added to "Canada" and 55 (100-round(100 x (1000/2200))) travellers added to "United States"
> - A work location with *citizenship* of 0 Canada, 0 United States and 123 Other results in **62** Canada and **61** United States
>>  - Since there is no "known" proportion (Canada and United States have zero *count*), we distribute evenly, with the extra traveller going to
>>  Canada

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_air_020]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_020)
