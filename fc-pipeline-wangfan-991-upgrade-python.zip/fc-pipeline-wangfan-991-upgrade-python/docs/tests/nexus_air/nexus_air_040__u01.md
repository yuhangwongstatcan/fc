# Documentation of Unit Test nexus_air_040__u01

### ID
nexus_air_040__u01

### Related Business Rule
nexus_air_040

### Purpose of Test
This unit test will ensure the integrity of the business rule which transforms the NEXUS Air clean data to create the contribution to the 
travellers table in the correct schema. Most of the columns can be coded or extracted directly from the clean data.

The following cases are tested:
> - Each of the columns *year*, *month*, *day*, *mode*, *vehicle_type*, *plate_country*, *plate_region*, *arriving_from*, *purpose9*, *purpose4*,
> *duration2*, *duration3*, *duration5*, *traveller_type*, *work_location* and *data_source* is coded correctly based directly on the clean data as 
> described in nexus_air_040
> - The *port* column is coded correctly by linking to the work location reference file as described in nexus_air_040
> - The *country_of_residence* column is coded correctly based conditionally on the *citizenship* variable

### Input
input.csv

### Output
travellers.csv

### Additional Notes
None

### Related pages
[Documentation for nexus_air_040]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_040)
