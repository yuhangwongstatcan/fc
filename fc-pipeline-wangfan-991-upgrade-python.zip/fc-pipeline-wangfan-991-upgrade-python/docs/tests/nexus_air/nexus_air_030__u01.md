# Documentation of Unit Test nexus_air_030__u01

### ID
nexus_air_030__u01

### Related Business Rule
nexus_air_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the trip duration (same day or overnight) of NEXUS Air travellers
based on PIK proportions from the same month, work location and residency, in the case where data from the same work location is available.

The following cases are tested:
> - Halifax Airport (7593) having 543 Canadian citizen travellers for January 2020 in NEXUS Air:
>>  - The transformed **travellers.csv.pik** file for January 2020 has a total of 405 Canadian resident excursionists (*traveller_type* = 1) and 1542 
>>  Canadian resident tourists (*traveller_type* = 2) at work location 7593, so the same-day proportion is 405/1947
>>  - Note: "Other travellers" (*traveller_type* = 3) are ignored in the calculation
>>  - As such, the 543 Canadian citizen travellers are redistributed as **113** (round(543 x (405/1947))) with *duration2* = 1 ("Same day") and 
>>  **430** (543-round(543 x (405/1947))) with *duration2* = 2 ("Overnight")
> - Halifax Airport (7593) having 434 American citizen travellers for January 2020 in NEXUS Air:
>>  - The transformed **travellers.csv.pik** file for January 2020 has a total of 441 American resident excursionists (*traveller_type* = 1) and 489 
>>  American resident tourists (*traveller_type* = 2) at work location 7593, so the same-day proportion is 441/930
>>  - As such, the 434 American citizen travellers are redistributed as **206** (round(434 x (441/930))) with *duration2* = 1 ("Same day") and 
>>   **228** (434-round(434 x (441/930))) with *duration2* = 2 ("Overnight")
> - Note: Other work locations present in the transformed PIK file (8212 - Vancouver in this example) are ignored in the calculations

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_air_030]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_030)
