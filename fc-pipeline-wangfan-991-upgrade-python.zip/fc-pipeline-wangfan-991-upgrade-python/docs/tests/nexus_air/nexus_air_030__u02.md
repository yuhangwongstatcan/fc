# Documentation of Unit Test nexus_air_030__u02

### ID
nexus_air_030__u02

### Related Business Rule
nexus_air_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the trip duration (same day or overnight) of NEXUS Air travellers
based on PIK proportions from the same month, work location and residency, in the case where data from the same work location is NOT available.

The following cases are tested:
> - Montreal Airport (3961) having 543 Canadian citizen travellers for January 2020 in NEXUS Air:
>>  - The transformed **travellers.csv.pik** file for January 2020 does not have any data for work location 3961, so the national proportion is used,
>>  with a total of 405 Canadian resident excursionists (*traveller_type* = 1) and 2017 Canadian resident tourists (*traveller_type* = 2), so the
>>  same-day proportion is 405/2422
>>  - Note: "Other travellers" (*traveller_type* = 3) are ignored in the calculation
>>  - As such, the 543 Canadian citizen travellers are redistributed as **91** (round(543 x (405/2422))) with *duration2* = 1 ("Same day") and 
>>  **452** (543-round(543 x (405/2422))) with *duration2* = 2 ("Overnight")
> - Montreal Airport (3961) having 434 American citizen travellers for January 2020 in NEXUS Air:
>>  - The transformed **travellers.csv.pik** file for January 2020 does not have any data for work location 3961, so the national proportion is used,
>>  with a of 4964 American resident excursionists (*traveller_type* = 1) and 1136 American resident tourists (*traveller_type* = 2), so the
>>  same-day proportion is 4964/6100
>>  - As such, the 434 American citizen travellers are redistributed as **353** (round(434 x (4964/6100))) with *duration2* = 1 ("Same day") and 
>   **81** (434-round(434 x (4964/6100))) with *duration2* = 2 ("Overnight")
>>  - Note: "Other travellers" (*traveller_type* = 3) are ignored in the calculation

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_air_030]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_030)
