# Documentation of Unit Test nexus_air_010__u01

### ID
nexus_air_010__u01

### Related Business Rule
nexus_air_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes records for unexpected NEXUS Air work locations until they can be 
verified.
This would apply for cases that cannot be matched to the nexus_air work location reference file (**work_locations__nexus_air.csv**), and those for 
which *transportation_type* does not indicate commercial aircraft (code "nexus_air__111").  
(Recall that all NEXUS Air data is considered commercial aircraft for vehicle type)

The following cases are tested:
> - A record with *work_location* = 4516 is removed. This is a real work location, but is not anticipated to accept NEXUS Air traffic, so 
> although it is present in the main work_locations.csv file, it does not have a corresponding "nexus_air__111" record in the 
> **work_locations__nexus_air.csv** reference file
> - A record with *work_location* = 9985 is removed. This is not a real work location, and not present in the work location reference file
> - A record with a blank *work_location* is removed
> - Records with valid NEXUS Air *work_location*s 3961, 4312 and 7593 are maintained

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_air_010]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_010)
