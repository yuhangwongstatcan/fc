# Documentation of Unit Test nexus_air_005__u01

### ID
nexus_air_005__u01

### Related Business Rule
nexus_air_005

### Purpose of Test
This unit test will ensure the integrity of the business rule which adds the NEXUS Air work location numeric code to the raw data based on the
string airport name provided by CBSA.

The following cases are tested:
> - A record that can be matched to the nexus_air work location mapping file has its numeric *work_location* coded based the string name provided
> by CBSA

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_air_005]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_005)
