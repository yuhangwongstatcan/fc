# Testing Instructions

## Design

The current test runner is based on the concept of comparing two datasets: actual output and expected output.

Specifically, it is assumed that each test provides the following information:

1. A single input dataset, which is intended to be the main input that a given function receives.
2. Zero or more metadata datasets that can be specified as a JSON in the ```meta``` field.
3. An expected output dataset. 
4. An ```fctest.config.json``` file that indicates (1) data type (2) file path, and (possibly) (3) a schema definition for input, output, and metadata data files.

__Example Configuration__

```json
{
    "input": {
        "type": "dat",
        "file": "input.dat",
        "schema": "ipil_hwy_16"
    },
    "output": {
        "type": "csv",
        "file": "travellers.csv",
        "schema": "ipilhwy016_output"
    },
    "meta": {
        "port_list": {
            "type": "csv",
            "file": "../../../../shared_resources/port_list/port_list.csv",
            "schema": "port_list"
        },
        "ipil_vehicle_mapping": {
            "type": "json",
            "file": "ipil_vehicle_mapping.csv"
        },
        "ipil_country_mapping": {
            "type": "json",
            "file": "ipil_country_mapping.csv"
        }
    },
    "doc": "doc.txt",
    "test_function": "IPILHWY016"
}
```

## Implementation

The runner crawls a given directory and extract a variety of test configurations that match given patterns.