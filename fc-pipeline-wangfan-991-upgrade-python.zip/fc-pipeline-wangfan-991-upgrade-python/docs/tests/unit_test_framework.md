# Unit Test Framework
## Design Principals
1. Citizen Development: Subject matter experts should be able to develop test cases without writing Python code. 
2. Ease of Integration: The testing framework should offer a simple API for integration into other applications (for example: Web UI)
3. DRY: Don't Repeat Yourself principal. Minimize code boilerplate throughout the test suite. Avoid specifying the same, or derivable information in multiple places. This eases development and refactoring.

## Implementation
The Frontier Counts Unit Testing framework uses `pytest` to run and discover tests. 

- The framework uses `src/datasource/test_datasource.py` to find and generate tests for each datasource based off of their configurations under `src/datasource/{datasource}/unit_test`.
- Business Rules are functions to be tested by the unit test suite. Business rules are defined in their respective `src/datasource/{datasource}/data_processing` files.

## Usage
### Creating a new unit test case
Each test case is associated with a folder. Each test case folder has the following structure:

```
[Test case name]
┣─ fctest.config.json
┃
┗─ ...
```
#### fctest.config.json

The schema for a valid `fctest.config.json` is as follows:

- `input`: The input data to be evaluated by the function being tested.

- `output`: The expected output data.

- `doc`: The documentation associated with the test, currently not implemented.

- `test_function`: The function to be tested.

- `stage`: The stage of the input data (RAW, CLEAN, TRANSFORMED).

A valid test case folder must contain a `fctest.config.json` file. This file defines the parameters of the test case, such as inputs, outputs, and the business rule that is associated with the test. Defining the business rule explicitly allows multiple test cases to be associated with an individual business rule.

Most test cases will also require inputs and expected outputs composed of synthetic data. 

### Creating a new business rule
In a datasource's `src/datasource/{datasource}/data_processing` directory, create a python file with a function defining the logic of the business rule. Each business rule should have an associated unit test developed for it in the `src/datasource/{datasource}/unit_test` directory. 
