# Documentation of Unit Test ipil_hwy_060__u01

### ID
ipil_hwy_060__u01

### Related Business Rule
ipil_hwy_060

### Purpose of Test
This unit test will ensure the integrity of the business rule which recodes *country* to "CD" (Canada) if the *province* variable indicates a valid 
province or territory code for the vehicle's licence plate.

The following cases are tested:
> - A record with each of the 13 valid province and territory licence plate codes is recoded to *country* = "CD"
> - Each test record has an input *country* of "US", "MX" or "XX"

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related Pages
[Documentation for ipil_hwy_060]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_060)
