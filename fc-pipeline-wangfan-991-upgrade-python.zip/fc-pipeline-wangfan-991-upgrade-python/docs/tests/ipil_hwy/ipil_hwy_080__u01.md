# Documentation of Unit Test ipil_hwy_080__u01

### ID
ipil_hwy_080__u01

### Related Business Rule
ipil_hwy_080

### Purpose of Test
This unit test will ensure the integrity of the business rule which recodes overfull automobiles (more than eight passengers) as buses.

The following cases are tested:
> - A record with *cdsd* = 9 is recoded from an automobile to a bus (from *vehi* = "A" to *vehi* = "B")
> - A record with each of *cdsd, cd1d, cd2d, ussd, us1d, us2d, osd, o1d, o2d* = 1 is recoded from an automobile to a bus
> - A record with a total of 31 passengers is recoded from an automobile to a bus
> - An automobile record with one passenger is kept as an automobile

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_080]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_080)
