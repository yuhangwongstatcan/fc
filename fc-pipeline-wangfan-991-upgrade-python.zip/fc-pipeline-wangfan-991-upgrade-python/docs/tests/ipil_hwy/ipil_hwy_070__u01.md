# Documentation of Unit Test ipil_hwy_070__u01

### ID
ipil_hwy_070__u01

### Related Business Rule
ipil_hwy_070

### Purpose of Test
This unit test will ensure the integrity of the business rule which recodes *province* to "MX" (Mexico) if the *country* licence plate variable
indicates "MX" and the *province* variable is missing, and recodes the *country* to "PR" (Puerto Rico) if the *province* licence plate variable
indicates "PR".

The following cases are tested:
> - A record where *country* = "MX" and the *province* variable is missing has its *province* set to "MX"
> - A record where *province* = "PR" has its *country* changed from "XX" to "PR"

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related Pages
[Documentation for ipil_hwy_070]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_070)
