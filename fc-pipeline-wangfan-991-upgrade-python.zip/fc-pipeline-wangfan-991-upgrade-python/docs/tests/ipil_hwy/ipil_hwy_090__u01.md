# Documentation of Unit Test ipil_hwy_090__u01

### ID
ipil_hwy_090__u01

### Related Business Rule
ipil_hwy_090

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes IPIL-Hwy records with a missing or invalid *province* value.

The following cases are tested:
> - A record with blank *province* and *country* = "US" should be removed
> - A record with blank *province* and *country* = "CD" should be removed
> - A record with *province* = "ZZ" (invalid code) should be removed
> - A record with blank *province* and blank *country* should be removed
> - A record with blank *province* and *country* = "MX" **should not** be removed. This is an exception (see documentation on ipil_hwy_090).

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_090]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_090)
