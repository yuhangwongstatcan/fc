# Documentation of Unit Test ipil_hwy_010__u03

### ID
ipil_hwy_010__u03

### Related Business Rule
ipil_hwy_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes known test port cases for IPIL-Hwy.

The following cases are tested:
> - All five known *cport* values which represent test ports (1001,1036,1050,1054,2060) are removed
>>  - Note: These are the cases identified as *action* = "T" in the ipil_hwy work location reference file
> - A regular (non-test) *cport* is not removed

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related Pages
[Documentation for ipil_hwy_010]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_010)
