# Documentation of Unit Test ipil_hwy_100__u01

### ID
ipil_hwy_100__u01

### Related Business Rule
ipil_hwy_100

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes empty vehicle records in IPIL-Hwy.

The following cases are tested:
> - A record with zeros in all nine passenger count variables should be removed
> - A record with a blank in all nine passenger count variables should be removed

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_100]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_100)
