# Documentation of Unit Test ipil_hwy_010__u02

### ID
ipil_hwy_010__u02

### Related Business Rule
ipil_hwy_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes records where *cport* cannot be matched to a record in the work location
reference file, or where the transportation type is not currently used from IPIL-Hwy at the work location (i.e. the combination of work location
and transportation type cannot be matched to the ipil_hwy work location reference file).

The following cases are tested:
> - A *cport* value that cannot be matched to the work location reference file is removed
> - A *cport* and *vehi* combination that cannot be matched to the work location reference file is removed
>>  - *vehi* = "A" at work location 1010
>>  - *vehi* = "B" at work location 8901

### Input
input.dat

### Output
output.dat

### Additional Notes
(Collin Feb 4, 2021)
The validation for ipil_hwy_001 requires the "orig_vehi" column that remained from ipil_hwy_000.

This extra column gets removed in the validation for ipil_hwy_001, but gets returned in the dataframe returned by the business rule.

Given the above, I've made the configuration for ipil_hwy_001 indicate "ipil-hwy-21-input" for both input and output so that the test will not fail due to the
number of columns being off by one. This is not a typo, both input/output schemas should read "ipil-hwy-21-input".

### Related Pages
[Documentation for ipil_hwy_010]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_010)
