# Documentation of Unit Test ipil_hwy_040__u01

### ID
ipil_hwy_040__u01

### Related Business Rule
ipil_hwy_040

### Purpose of Test
This unit test will ensure the integrity of the business rule which recodes *country* from "CA" to "CD" in IPIL-Hwy.

The following cases are tested:
> - A record with *country* = "CA" is recoded to *country* = "CD"

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related Pages
[Documentation for ipil_hwy_040]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_040)
