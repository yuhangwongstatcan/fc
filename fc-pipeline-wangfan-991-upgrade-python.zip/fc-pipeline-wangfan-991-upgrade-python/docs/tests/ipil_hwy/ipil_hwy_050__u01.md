# Documentation of Unit Test ipil_hwy_050__u01

### ID
ipil_hwy_050__u01

### Related Business Rule
ipil_hwy_050

### Purpose of Test
This unit test will ensure the integrity of the business rule which recodes *country* to "US" if the *province* variable indicates a valid state
code for the vehicle's licence plate.

The following cases are tested:
> - A record with each of the 51 valid state licence plate codes is recoded to *country* = "US"
> - Each test record has an input *country* of "CA", "CD", "MX" or "XX"

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related Pages
[Documentation for ipil_hwy_050]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_050)
