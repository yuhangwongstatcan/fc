# Documentation of Unit Test ipil_hwy_110__u01

### ID
ipil_hwy_110__u01

### Related Business Rule
ipil_hwy_110

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes duplicates in IPIL-Hwy.

The following cases are tested:
> - An input file with five records, including two sets of duplicates on *cport*, *lane*, *date* and *sin*, should output three records,
the first of each set of duplicates and the singleton record.

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_110]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_110)
