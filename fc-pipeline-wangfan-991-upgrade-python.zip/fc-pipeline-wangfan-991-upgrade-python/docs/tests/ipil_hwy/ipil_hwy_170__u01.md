# Documentation of Unit Test ipil_hwy_170__u01

### ID
ipil_hwy_170__u01

### Related Business Rule
ipil_hwy_170

### Purpose of Test
This unit test will ensure the integrity of the business rule which transforms the IPIL-Hwy clean data to create the contribution to the travellers
table in the correct schema.

The following cases are tested:
> - Each of the *vehi* values are coded correctly to the *mode* and *vehicle_type* columns, as per ipil_hwy_170
> - An automobile arrival at a ferry work location is correctly coded for *vehicle_type*, as per ipil_hwy_170
> - A pedestrian arrival at a ferry work location is correctly coded for *vehicle_type*, as per ipil_hwy_170
> - An "automobile" or "pedestrian" arrival at a marina location is correctly coded to *vehicle_type* = 321 ("Private boat"), as per ipil_hwy_170
> - Each of the *country* values are coded correctly to the *plate_country* column, as per ipil_hwy_170
> - *province* values are copied correctly to the *plate_region* column, as per ipil_hwy_170
> - A licence plate of "MX" or "PR" is coded as *arriving_from* = 3 ("Other country via the United States), and other records with Canadian or American
resident travellers are coded as *arriving_from* = 1 ("United States only")
> - Any overseas resident travellers are coded as *arriving_from* = 3 ("Other country via the United States")
> - *country_of_residence* is coded correctly for Canadian and American resident travellers, as per ipil_hwy_170
> - *country_of_residence* is coded correctly for any overseas travellers based on imputation from ipil_hwy_155
> - Any traveller arriving in a truck is coded as crew for *purpose9* and *purpose4*
> - A bus record with one traveller is coded as crew for *purpose9* and *purpose4*
> - A bus record with *ussd* = 15 and *us1d* = 21 has one *us1d* switched to crew for *purpose9* and *purpose4*
> - A licence plate of "XX" (non-pedestrian) is coded as *purpose9* = 43 ("Other purpose") and *purpose4* = 4 ("Other non-tourism")
> - *duration2* and *duration3* are coded correctly as same day, one night and two or more nights, as per ipil_hwy_170

### Input
input.dat

### Output
travellers.csv

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_155]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_155) 
[Documentation for ipil_hwy_170]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_170)
