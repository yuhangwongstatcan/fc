# Documentation of Unit Test ipil_hwy_010__u01

### ID
ipil_hwy_010__u01

### Related Business Rule
ipil_hwy_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which recodes transportation types if they are not permitted at certain work locations
in IPIL-Hwy.

The following cases are tested:
> - Several transportation types are maintained with code "A"  
> - An other land vehicle is recoded to a truck when applicable
> - A motorcycle is recoded to an automobile when applicable
> - A private watercraft is flagged when applicable
> - A ferry is flagged when applicable

### Input
input.dat

### Output
output.dat

### Additional Notes
Edit: Collin Brown, Feb 23, 2021

ipil_hwy_010 is always called from its corresponding validation, which converts ipil_portlist_vehicle_mapping to a dictionary before calling ipil_hwy_000.

Therefore, it is not a mistake that one of the auxiliary arguments in the test runner is a JSON while the other is a CSV.

### Related Pages
[Documentation for ipil_hwy_010]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_010)
