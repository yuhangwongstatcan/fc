# Documentation of Unit Test ipil_hwy_150__u01

### ID
ipil_hwy_150__u01

### Related Business Rule
ipil_hwy_150

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes overfull motorcycle records in IPIL-Hwy.

The following cases are tested:
> - A motorcycle record with four passengers should be imputed
> - The input file has potential donor records:
>>  - The nearest neighbour is ignored because *vehi* does not match
>>  - The next nearest neighbour is ignored because *country* does not match
>>  - The next nearest neighbour is ignored because *cport* does not match
>>  - The fourth-nearest neighbour is used as the donor

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_150]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_150)
