# Documentation of Unit Test ipil_hwy_160__u01

### ID
ipil_hwy_160__u01

### Related Business Rule
ipil_hwy_160

### Purpose of Test
This unit test will ensure the integrity of the business rule which transforms the IPIL-Hwy clean data to create the contribution to the vehicles
table in the correct schema.

The following cases are tested:
> - Each of the *vehi* values are coded correctly to the *mode* and *vehicle_type* columns, as per ipil_hwy_160
> - Each of the *country* values are coded correctly to the *plate_country* column, as per ipil_hwy_160
> - *province* values are copied correctly to the *plate_region* column, as per ipil_hwy_160
> - A pedestrian record (*vehi* = "P") is excluded from tabulation in the vehicles table

### Input
input.dat

### Output
vehicles.csv

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_160]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_160)
