# Documentation of Unit Test ipil_hwy_120__u01

### ID
ipil_hwy_120__u01

### Related Business Rule
ipil_hwy_120

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes records with missing date in IPIL-Hwy.

The following cases are tested:
> - A record with a blank *date* variable is removed
> - A record with a populated *date* variable is retained

### Input
input.dat

### Output
output.dat

### Additional Notes
None

### Related pages
[Documentation for ipil_hwy_120]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_120)
