# Test API

## Usage
To use the Test API, construct an instance of `tests.api.TestSuite`. Then call the `run` method on the `TestSuite` instance with optional parameters `datasource` and `name`. These 2 parameters narrow down the scope of tests to be run by datasource and name. If both are specified, then only the specific named test for that datasource is run. If datasource is specified, and name is not, then all tests for that datasource will be run. If neither is specified, then all tests of the type (unit, integration) are run.

The return value of the `run` method is a value of type `tests.api.TestResults`. This instance contains the following properties:
- run_count: the total number of tests that were run
- success_count: the number of successes
- failure_count: the number of failures
- error_count: the number of errors
- skipped_count: the number of skipped tests
- expected_failure_count: the number of tests that passed with failures that were expected
- unexpected_success_count: the number of tests that failed with successes that were not expected

In addition to these properties, `tests.api.TestResults` also contain the property `test_results` which return an Iterator of `tests.api.TestCaseResult`.

Below is a brief description of the fields available from `tests.api.TestCaseResult`
- name: The name of the test
- datasource: The datasource that this test belongs to
- results: The tabular diff between the expected and actual output of the test
- status: Test outcome such as success or failure
- message: A message specific to the test case

## Test CLI
In `src` directory, run `test_cli.py`. There are 3 parameters
- `--type` can be either `unit` or `integration`
- `--datasource`
- `--name` is the name of the test

<!-- ::: tests.api -->