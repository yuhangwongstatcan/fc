# Documentation of Unit Test manual_entry_travellers_030__u01

### ID
manual_entry_travellers_030__u01

### Related Business Rule
manual_entry_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes an unknown variable breakdown using data from the current month already in the system.

This data is used for the imputation because more than 50% of the data for the categories specified in the manual entry compared to the reference year have already been received (a "high proportion" of data are already in the system).

The following cases are tested:
> - A manual entry from April 2019 with 100 travellers from *port* = 35439, *vehicle_type* = 217 (PEDESTRIAN) and *country_of_residence* = 11124 (CANADA) has its *arriving_from*, *purpose4* and *duration2* imputed using data already in the April 2019 TRAVELLERS table.
> > - This data from the current month and year is used because the data in the system from April 2019 is more than 50% of the data from April 2018 for the categories specified in the manual entry
> - A manual entry from April 2019 with 100 travellers from *port* = 46504, *arriving_from* = 1 (U.S. ONLY), *country_of_residence* = 11124 (CANADA), *purpose4* = 1 (VISIT) and *duration2* = 1 (SAME DAY), and *vehicle_type* = 199 (AIR [NOT AVAILABLE]) has its *vehicle_type* imputed among air vehicle types using data already in the April 2019 TRAVELLERS table.
> > - Note that a water/private boat (*vehicle_type* = 321) record is not considered in the imputation because *vehicle_type* = #99 cases should only impute using breakdowns from the same mode (in this case, AIR)

### Input
input.csv

### Output
travellers.csv

### Related Pages
[Documentation for manual_entry_030]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_030)