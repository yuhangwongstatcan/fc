# Documentation of Unit Test manual_entry_travellers_030__u02

### ID
manual_entry_travellers_030__u02

### Related Business Rule
manual_entry_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes an unknown variable breakdown using data from the same month of a previous year.

This data is used for the imputation because 50% or less of the data for the categories specified in the manual entry compared to the specified reference year have already been received (a "low proportion" of data are already in the system for the current month), and the total for the categories specified in the reference year is at least 50% of the *count_of_entries* from the manual entry (a "sufficient" amount of data is available for the imputation from the reference year).

The following cases are tested:
> - A manual entry from April 2019 with 100 travellers from *port* = 47602, *vehicle_type* = 215 (BUS), *arriving_from* = 1 (U.S. ONLY), *purpose4* = 1 (VISIT) and *duration2* = 2 (OVERNIGHT), and *country_of_residence* = 99998 (OVERSEAS) has its *country_of_residence* imputed among overseas countries (not Canada or United States of America) using data from the April 2018 TRAVELLERS table.
> - This data from the same month of the specified reference year (April 2018) is used because:
> > - The data in the system from April 2019 is less than 50% of the data from April 2018 for the categories specified in the manual entry
> > - The data in the system from April 2018 for the categories specified in the manual entry is at least 50% of the *count_of_entries* to be imputed
> > - Note that Canadian and American records (*country_of_residence* in (11124,11840)) are excluded because 99998 (OVERSEAS) should be imputed using only overseas countries

### Input
input.csv

### Output
travellers.csv

### Related Pages
[Documentation for manual_entry_030]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_030)
