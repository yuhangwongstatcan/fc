# Documentation of Unit Test manual_entry_travellers_010__u01

### ID
manual_entry_travellers_010__u01

### Related Business Rule
manual_entry_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes a *count_of_entries* for the number of travellers when it is unknown and therefore left blank during manual entry capture.

The following cases are tested:
> - A manual entry from April 2019 with *port* = 13205, *vehicle_type* = 216 (TRAIN) and *arriving_from* = 1 (UNITED STATES ONLY), but a blank number of travellers has its *count_of_entries* imputed using the TRAVELLERS table from April 2018. The *reference_year* is passed as 2018 during runtime.

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for manual_entry_010]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_010)