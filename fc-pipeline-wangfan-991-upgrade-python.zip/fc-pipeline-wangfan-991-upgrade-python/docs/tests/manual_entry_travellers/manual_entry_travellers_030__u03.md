# Documentation of Unit Test manual_entry_travellers_030__u03

### ID
manual_entry_travellers_030__u03

### Related Business Rule
manual_entry_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes an unknown variable breakdown for a "correction".

A correction is required in the case where CBSA notifies Statistics Canada that too many travellers
were originally reported, so some need to be removed from the data already in the system. If the 
precise characteristics of the "extra" travellers are not known, then they are imputed using the
same methodology as what is used to do breakdowns for travellers being added to the system.

A correction is identified by a negative number entered in the manual entry component for the number
of travellers (or number of vehicles).

The following cases are tested:
> - A correction from April 2019 which requires 4 travellers to be removed from *port* = 35439, *vehicle_type* = 217 (PEDESTRIAN) and *country_of_residence* = 11124 (CANADA) has its *arriving_from*, *purpose4* and *duration2* imputed using data already in the April 2019 TRAVELLERS table.
> > - This data from the current month and year is used because the data in the system from April 2019 is more than 50% of the data from April 2018 for the categories specified in the manual entry

### Input
input.csv

### Output
travellers.csv

### Related Pages
[Documentation for manual_entry_030]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_030)