# Documentation of Unit Test manual_entry_travellers_020__u01

### ID
manual_entry_travellers_020__u01

### Related Business Rule
manual_entry_020

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes an unknown variable breakdown using a predefined distribution from the FIXED RULES module of the manual entry component.

The following cases are tested:
> - A manual entry from April 2021 with 100 travellers having *port* = 35421, *vehicle_type* = 217 (PEDESTRIAN) and *country_of_residence* = 11124 (CANADA) has its *duration2* breakdown imputed as 99 same-day pedestrians and 1 overnight pedestrian, based on the fixed rules of 99% same-day and 1% overnight for this port, vehicle type and country of residence.
> - A manual entry from April 2021 with 100 travellers from *port* = 35441, *vehicle_type* = 217 (PEDESTRIAN) and *country_of_residence* = 11124 (CANADA) has its *duration2* breakdown imputed as 50 same-day pedestrians and 50 overnight pedestrians, based on the 50/50 breakdown present in the April 2018 TRAVELLERS table (*reference_year* specified as 2018). This is used because there is no applicable fixed rule (none that applies to this port), and there is data in the April 2021 TRAVELLERS table for this combination of variable categories.

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for manual_entry_020]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_020)
