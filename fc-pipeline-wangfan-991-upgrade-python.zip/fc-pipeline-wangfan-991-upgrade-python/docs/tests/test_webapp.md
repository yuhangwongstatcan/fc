# Test Web app
## Startup Instructions
1. Activate virtual environment (```conda activate frontier-counts```)
2. From ```src```, run ```python -m tests.webapp.main```

TODO: set up docstrings for test webapp

<!-- ::: tests.webapp -->