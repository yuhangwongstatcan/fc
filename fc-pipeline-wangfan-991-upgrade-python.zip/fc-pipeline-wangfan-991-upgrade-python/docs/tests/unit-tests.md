# Unit Test Documentation


## Business Rules

__Test Coverage__: ```src/modules/test_functions```

### Overview
Business rules implement the logic involved in preprocessing an input (and (possibly) one or more auxiliary data sources) into an output. Business rules are implemented as __pure functions__ with no state or side effects. Hence, test cases correspond to the following workflow:

1. pass the input data (and possibly one or more auxiliary data sources) to the function implementing the business rule,
2. store the output produced by the business rule,
3. compare the output produced by the business rule against the expected output defined by subject matter experts: if they are the same, then the business rule worked correctly; if they differ, something went wrong.

Since all of these business rules involve the same testing workflow, it is possible to define the tests using a configuration file. There is a single test (defined in ```tests/unit/test_functions/test_test_functions.py```) that imports the configuration for each business rule and tests it as a sub-test. 

### Assumptions
1. Every test contains an __input__ data structure - this represents the main input that is being processed. This file should be specified in the "input" key of the configuration.
2. Every test contains an __output__ data structure - this represents the expected output that the business rule should produce. This file should be specified in the "output" key of the configuration.
3. Every test contains a __doc__ text file, which contains a human readable description of the business logic of the function being tested.
4. Tests may contain auxiliary data structures. If this is the case, the data structures need to be specified in a __meta__ (name still TBD) field of the configuration json.
5. Every configuration file is named ```fctest.config.json```.

### Running the Tests (on Net A)
>TODO: update this documentation if there is a more efficient way to go about this.
1. Open the Anaconda prompt and navigate to your local folder where this repository is cloned.
2. Run the tests in ```tests/unit/test_functions``` using the following command (note first part is optional to easily clear the output from the previous test run):

(windows)
```cmd
cls && python -m custom_test_runner [--path tests/unit/test_functions]  
```

(bash)
```bash
clear && python -m custom_test_runner [--path tests/unit/test_functions]
```

### Instructions to Add a New Test
> TODO: finish this. 

### Configuration Examples

__Configuration with no auxiliary data sources__

```json
{
    "input": {
        "type": "dat",
        "file": "input.dat"
    },
    "output": {
        "type": "dat",
        "file": "output.dat"
    },
    "doc": "doc.txt"
}
```

__Configuration with auxiliary data sources__

```json
{
    "input": {
        "type": "dat",
        "file": "input.dat"
    },
    "output": {
        "type": "dat",
        "file": "output.dat"
    },
    "meta": {
    	"auxiliary_data_1": {
    		"type": "csv",
    		"file": "auxiliary_data_1.csv"
    	},
    	"auxiliary_data_2": {
    		"type": "dat",
    		"file": "auxiliary_data_2.dat"
    	}
    },
    "doc": "doc.txt"
}
```