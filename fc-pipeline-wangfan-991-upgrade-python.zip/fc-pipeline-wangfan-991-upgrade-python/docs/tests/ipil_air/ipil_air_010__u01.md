# Documentation of Unit Test ipil_air_010__u01

### ID
ipil_air_010__u01

### Related Business Rule
ipil_air_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which recodes transportation types if they are not permitted at certain work 
locations in IPIL Air.

The following cases are tested:
> - Records which have a corresponding action of 'A' (accept) for each mode are maintained ('Air' at *wloc* 4974, 'Land' at *wloc* 4273, 'Rail' at
> *wloc* 4277 and 'Marine' at *wloc* 8115)
> - A record with a corresponding action of 'R111' (Recode to commercial aircraft) ('Rail' at *work_location* 4974) has its *mode* recoded from 
> 'Rail' to 'Air'
> - A record with a corresponding action of 'R215' (Recode to bus) ('Air' at *work_location* 4273) has its *mode* recoded from 'Air' to 'Land'
> - A record with a corresponding action of 'R216' (Recode to train) ('Marine' at *work_location* 4277) has its *mode* recoded from 'Marine' to 'Rail'
> - A record with a corresponding action of 'R315' (Recode to ferry) ('Land' at *work_location* 8115) has its *mode* recoded from 'Land' to 'Marine'

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_010]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_010)
