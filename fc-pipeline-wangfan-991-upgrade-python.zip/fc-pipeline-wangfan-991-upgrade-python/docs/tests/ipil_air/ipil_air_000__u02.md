# Documentation of Unit Test ipil_air_000__u02

### ID
ipil_air_000__u02

### Related Business Rule
ipil_air_000

### Purpose of Test
This unit test will ensure the integrity of the business rule which splits the *port_of_entry* and *citizenship* variables from RAW `ipil_air` 
data into *wloc* and *wloc_name*, and *citizenship_code* and *citizenship_country*, respectively in the case where there are
values of *citizenship* that should be set to missing (pd.NA).

The following cases are tested:
> - A *citizenship* value of "-2 - Other" is set as missing for *citizenship_code* and *citizenship_name*
> - A *citizenship* value of "-2 - Unknown" is set as missing for *citizenship_code* and *citizenship_name*
> - A *citizenship* value of "-2 - #Name?" is set as missing for *citizenship_code* and *citizenship_name*
> - A *citizenship* value of "#Name" is set as missing for *citizenship_code* and *citizenship_name*

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_000]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_000)
