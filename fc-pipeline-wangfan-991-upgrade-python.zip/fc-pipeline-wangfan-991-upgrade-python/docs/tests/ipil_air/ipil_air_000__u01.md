# Documentation of Unit Test ipil_air_000__u01

### ID
ipil_air_000__u01

### Related Business Rule
ipil_air_000

### Purpose of Test
This unit test will ensure the integrity of the business rule which splits the *port_of_entry* and *citizenship* variables from RAW `ipil_air` 
data into *wloc* and *wloc_name*, and *citizenship_code* and *citizenship_country*, respectively.

The following cases are tested:
> - The *port_of_entry* variable is split correctly for four-digit work location codes with and without leading zeros
> - The *citizenship* variable is split correctly for two-digit and three-digit citizenship codes, and in cases where the citizenship name has
> irregular characters such as commas
> - The original *port_of_entry* and *citizenship* variables are dropped, and the variables correctly reordered

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_000]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_000)
