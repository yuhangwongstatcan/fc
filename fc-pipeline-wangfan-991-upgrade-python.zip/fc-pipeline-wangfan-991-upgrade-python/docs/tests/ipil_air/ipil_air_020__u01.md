# Documentation of Unit Test ipil_air_020__u01

### ID
ipil_air_020__u01

### Related Business Rule
ipil_air_020

### Purpose of Test
This unit test will ensure the integrity of the business rule which adds the Frontier Counts country of residence and removes records where the
*citizenship_code* cannot be matched to the IPIL Air country mapping reference file (**map__ipil_air__raw__citizenship_code__ipil_air__clean__country_of_residence.csv**).

The following cases are tested:
> - A record with *citizenship_code* = "XXB" (Refugee, Article 1) is coded to the correct Frontier Counts country code, so that *country_of_residence* = 99999.
> - A record with *citizenship_code* = "FR" (France) is coded to the correct Frontier Counts country code, so that *country_of_residence* = 21250.
> - A record with a *citizenship_code* that cannot be matched to the IPIL Air country mapping reference file (*citizenship_code* = "WL") is removed.
> - A record with a blank *citizenship_code* is retained and the *country_of_residence* left blank as well.

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_020]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_020)
