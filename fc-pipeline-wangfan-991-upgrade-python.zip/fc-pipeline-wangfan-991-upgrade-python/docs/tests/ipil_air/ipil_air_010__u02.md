# Documentation of Unit Test ipil_air_010__u02

### ID
ipil_air_010__u02

### Related Business Rule
ipil_air_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes records with unexpected work locations or transportation types until 
they can be validated, and removes records that are identified as being rejected.

The following cases are tested:
> - A record with *wloc* = 4272 and *mode* = 'Rail' is removed. This work location is present in the `ipil_air` work location 
>   reference file, but trains are not expected from IPIL Air at this work location.
> - A record with *wloc* = 9190 and *mode* = 'Marine' is removed. This work location is identified in the `ipil_air` work location 
>   reference file to be rejected ('X').
> - A record with *wloc* = 0002, which is not found on the `ipil_air` work location reference file, is removed.
> - A record with a corresponding action of 'Accept' ('A') in the `ipil_air` work location file, based on the *wloc* and *mode* is maintained.

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_010]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_010)
