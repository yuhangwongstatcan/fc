# Documentation of Unit Test ipil_air_040__u03

### ID
ipil_air_040__u03

### Related Business Rule
ipil_air_040

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the trip duration (same day or overnight), purpose of 
trip (visit, crew, work or other) and arriving from (U.S. only, overseas direct or overseas via U.S.) of IPIL Air travellers, in 
cases where the variables are directly coded or are coded using the most common categories from a reference distribution due to small 
counts.

The following cases are tested:
> - St. John's Airport (*port* = 10914) having 1 Canadian resident (*region_of_residence* = "CAN") commercial air (*vehicle_type* = 111) 
> traveller for January 2025 in IPIL Air, so *duration2*, *purpose4* and *arriving_from* are coded based on the most common 
> categories due to the difficulty with splitting a small count based on auxiliary data.
> - St. John's Airport (*port* = 10914) having 2 American resident (*region_of_residence* = "USA") commercial air (*vehicle_type* = 111)
> travellers for January 2025 in IPIL Air, so *duration2*, *purpose4* and *arriving_from* are coded based on the most common 
> categories due to the difficulty with splitting a small count based on auxiliary data.
> - Calgary Airport (*port* = 48701) having 5 overseas resident (*region_of_residence* = "OVS") commercial air (*vehicle_type* = 111) 
> travellers for January 2025 in IPIL Air, so *duration2*, *purpose4* and *arriving_from* are coded based on the most common 
> categories due to the difficulty with splitting a small count based on auxiliary data.
> - Citizenship codes indicating stateless or refugees (*citizenship_code* in ("XA","XXB","XXC")) have *duration2*, *purpose4* and 
> *arriving_from* are coded directly


### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_040]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_040)
