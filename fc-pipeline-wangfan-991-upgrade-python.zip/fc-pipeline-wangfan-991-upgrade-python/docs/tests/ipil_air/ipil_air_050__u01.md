# Documentation of Unit Test ipil_air_050__u01

### ID
ipil_air_050__u01

### Related Business Rule
ipil_air_050

### Purpose of Test
This unit test will ensure the integrity of the business rule which transforms the IPIL Air clean data to create the contribution to the 
travellers table in the correct schema. Most of the columns can be coded or extracted directly from the clean data.

The following cases are tested:
> - Each of the columns *year*, *month*, *day*, *port*, *vehicle_type*, *plate_country*, *plate_region*, *arriving_from*, *country_of_residence*,
> *purpose4*, *duration2*, *duration3*, *duration5*, *traveller_type*, *work_location* and *data_source* is coded correctly, based directly on 
> the clean data as described in the `ipil_air_050` documentation
> - The *mode* column is coded correctly, based conditionally on the *vehicle_type* variable
> - The *purpose9* column is coded correctly, based conditionally on the *purpose4* and *citizenship_code* variables
> - The *traveller_type* column is coded correctly, based conditionally on the *purpose4*, *vehicle_type* and *duration2* variables

### Input
input.csv

### Output
travellers.csv

### Additional Notes
None

### Related pages
[Documentation for ipil_air_050]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_050)
