# Documentation of Unit Test ipil_air_040__u04

### ID
ipil_air_040__u04

### Related Business Rule
ipil_air_040

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the trip duration (same day or overnight), purpose of 
trip (visit, crew, work or other) and arriving from (U.S. only, overseas direct or overseas via U.S.) of IPIL Air travellers, in 
cases where non-standard vehicle types are used for IPIL Air due to particularities at certain work locations.

The following cases are tested:
> - Marine traffic at Quai Richelieu (*wloc* = 3514) is coded as *vehicle_type* = 321 (Private boat) and the proportions of 
> *duration2*, *purpose4* and *arriving_from* for its 100 travellers are determined from the proportions in the January 2024 
> `travellers` data for the port (24358), region of residence ("CAN") and vehicle type of private boat
> - Marine traffic at Sand Point Lake (*wloc* = 4115) is coded as *vehicle_type* = 321 (Private boat) and the proportions of its 
> 100 travellers are determined from the proportions in the January 2024 `travellers` data for the port (35434), region of residence 
> ("CAN") and vehicle type of private boat
> - Land traffic at Huntingdon (*wloc* = 8173) and Huntingdon Commercial (*wloc* = 8171) are coded as *vehicle_type* = 217 
> (Pedestrian), and the proportions of their 100 travellers each are determined from the proportions in the January 2024 
> `travellers` data for the port (59817), region of residence ("CAN") and vehicle type of pedestrian
> - Land traffic at Rainbow Bridge (*wloc* = 4272) is first split by *vehicle_type* = 215 (Bus) and *vehicle_type* = 217 
> (Pedestrian) according to the proportions in the January 2024 `travellers` data for the port (35421) and the region of residence 
> ("CAN"), then the proportions of *duration2*, *purpose4* and *arriving_from* are assigned based on the proportions for the port,
> region of residence, and the assigned vehicle type
> - Train travellers at the following work locations are assigned *purpose4* = 2 ("Crew") since all trains at these work locations
> are cargo trains. The *arriving_from* and*duration2* are assigned based on the national proportions because the ports do not have
> any reference data available from January 2024
>   - St. Croix (2310), Woburn (3090), Abercorn (3180), Hemmingford (3331), Stanhope (3540), Emerson (5021 and 5022) and North Portal (6021 and 6025)


### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_040]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_040)
