# Documentation of Unit Test ipil_air_030__u02

### ID
ipil_air_030__u02

### Related Business Rule
ipil_air_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes country of residence for travellers in IPIL Air that have an unknown 
or generic citizenship code (applicable 99999 or BLANK codes), for cases that should have *country_of_residence* left as 99999.

The following cases are tested to ensure that *country_of_residence* remains as 99999:
> - *citizenship_code* = "XA" (Stateless)
> - *citizenship_code* = "XXB" (Refugee, Article 1)
> - *citizenship_code* = "XXC" (Refugee, Other)

### Input
input.csv

### Output
output.csv

### Additional Notes
None

### Related pages
[Documentation for ipil_air_030]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_030)
