# Documentation of Unit Test ipil_air_005__u01

### ID
ipil_air_005__u01

### Related Business Rule
ipil_air_005

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes mode of transportation (*mode*) in cases where it is 
blank in the RAW `ipil_air` data.

The following cases are tested:
> - The *mode* variable is imputed in a case where all travellers from a *wloc* have the same mode (Toronto Pearson Airport - Air)
> - The *mode* variable is imputed as the most common mode of transportation in a case where there are multiple modes from a *wloc*
> within a month (Edmonton Airport - Air imputed instead of Edmonton Airport - Land)

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_005]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_005)
