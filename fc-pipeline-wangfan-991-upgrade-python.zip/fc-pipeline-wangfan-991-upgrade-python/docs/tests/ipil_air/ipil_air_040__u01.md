# Documentation of Unit Test ipil_air_040__u01

### ID
ipil_air_040__u01

### Related Business Rule
ipil_air_040

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the trip duration (same day or overnight), purpose of trip (visit, 
crew, work or other) and arriving from (U.S. only, overseas direct or overseas via U.S.) of IPIL Air travellers, in the case where the ports in
question are non-PIK ports, so data from the same port in the same month of 2024 Frontier Counts is used.

The following cases are tested:
> - Regina Airport (*port* = 47604) having 150 Canadian resident (*region_of_residence* = "CAN") commercial air (*vehicle_type* = 111) travellers 
> for January 2025 in IPIL Air, split across two records (one with 100 travellers and one with 50 travellers):
>>  - The aggregated **travellers.csv** file for January 2024 has a total of 5,424 Canadian resident commercial air travellers split across 22 
>>  non-zero combinations of *duration2*, *purpose4* and *arriving_from* at Regina Airport (47604)
>>  - When applied to the 100 IPIL Air travellers from the first Regina Airport record, five non-zero rounded values remain: **1** for the 1/2/1
>>  combination, **2** for the 1/2/2 combination, **17** for the 2/1/1 combination, **78** for the 2/1/2 combination and **1** for 2/2/2. Since 
>>  the original total must be respected, the 2/2/2 combination is set to **2** so the total is 100
>>  - The original record is split into five records with these characteristics applied and *count_of_travellers* adjusted
>>  - When applied to the 50 IPIL Air travellers from the second Regina Airport record, four non-zero rounded values remain: **1** for the 1/2/2
>>  combination, **8** for the 2/1/1 combination, **39** for the 2/1/2 combination and **1** for 2/2/2. Since the original total must be 
>>  respected, the 2/2/2 combination is set to **2** so the total is 50
>>  - Note: Records in **travellers.csv** from other ports, for other modes, and American and overseas resident records are ignored for this calculation
> - Niagara Falls - Queenston (*port* = 35427) having 100 American resident (*region_of_residence* = "USA") bus (*vehicle_type* = 215) travellers 
> for January 2025 in IPIL Air:
>>  - The aggregated **travellers.csv** file for January 2024 has a total of 209 American resident bus travellers split across 4 combinations of 
>>  *duration2* and *purpose4* at Queenston (35427)
>>  - When applied to the 100 IPIL Air travellers at Queenston, four non-zero rounded values remain: **23** for the 1/1 combination, **3** for 
>>  the 1/2 combination, **67** for the 2/1 combination and **7** for the 2/2 combination
>>  - The original record is split into four records with these characteristics applied and *count_of_travellers* adjusted
>>  - Since the travellers are non-air, *arriving_from* is set to 1 (U.S. only) in all cases
>>  - Note: Records in **travellers.csv** from other ports, for other modes, and Canadian and overseas resident records are ignored for this calculation
> - Regina Airport (*port* = 47604) having 10 Latvian resident (*region_of_residence* = "OVS") commercial air (*vehicle_type* = 111) travellers 
> for January 2025 in IPIL Air:
>>  - The aggregated **travellers.csv** file for January 2024 has a total of 22 overseas resident commercial air travellers split across 3 
>>  non-zero combinations of *duration2*, *purpose4* and *arriving_from* at Regina Airport (47604)
>>  - When applied to the 10 IPIL Air travellers from the first Regina Airport record, two non-zero values remain: **1** for the 2/1/1
>>  combination and **8** for the 2/1/2 combination. Since the original total must be respected, the 2/1/2 combination is set to **9** so the 
>>  total is 10
>>  - The original record is split into three records with these characteristics and counts applied
>>  - Note: Records in **travellers.csv** from other ports, for other modes, and Canadian and American resident records are ignored for this 
>>  calculation, as are records with *country_of_residence* = 99999

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_040]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_040)
