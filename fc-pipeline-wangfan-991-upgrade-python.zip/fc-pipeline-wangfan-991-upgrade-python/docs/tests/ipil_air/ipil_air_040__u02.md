# Documentation of Unit Test ipil_air_040__u02

### ID
ipil_air_040__u02

### Related Business Rule
ipil_air_040

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the trip duration (same day or overnight), purpose of trip (visit, 
crew, work or other) and arriving from (U.S. only, overseas direct or overseas via U.S.) of IPIL Air travellers, in the case where the ports in
question are PIK airports, so data from the same port in the same month of 2024 Frontier Counts is used in conjunction with PIK data from the
same month.

The following cases are tested:
> - Edmonton Airport (*port* = 47604) having 450 Canadian resident (*region_of_residence* = "CAN") commercial air (*vehicle_type* = 111) 
> travellers for January 2025 in IPIL Air:
>>  - Since Edmonton Airport is a PIK airport and the reference date is prior to January 2028, the breakdown of *duration2*, *purpose4* and
>> *arriving_from* is determined as a joint proportion of January 2024 **travellers.csv** data and January 2025 **travellers.pik.csv** data
>>  - The aggregated **travellers.csv** file for January 2024 has a joint proportion of 10% for 1/1/1 (*duration2*/*purpose4*/*arriving_from*), 
>>  10% for 1/1/3, 40% for 2/1/1 and 40% for 2/1/3 for Canadian resident commercial air travellers at Edmonton Airport
>>  - The transformed **travellers.pik.csv** for January 2025 has a joint proportion of 10% for 1/1/1, 50% for 1/1/3, 20% for 1/2/1 and 20% for 
>>  2/1/2 for Canadian resident commercial air travellers at Edmonton Airport
>>  - Combining these proprtions with a 50-50 weighting on each results in joint proportions of 10% for 1/1/1 (*duration2*/*purpose4*/*arriving_from*),
>>  30% for 1/1/3, 10% for 1/2/1, 10% for 2/1/2, 20% for 2/1/1 and 20% for 2/1/3
>>  - When applied to the 450 IPIL Air travellers, this results in totals of 45, 135, 45, 45, 90 and 90, respectively
>>  - The original record is split into six records with these characteristics applied and *count_of_travellers* adjusted
>>  - Note: Records in **travellers.csv** and **travellers.pik.csv** from other ports, for other modes, and American and overseas resident 
>>  records are ignored for this calculation

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for ipil_air_040]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_040)
