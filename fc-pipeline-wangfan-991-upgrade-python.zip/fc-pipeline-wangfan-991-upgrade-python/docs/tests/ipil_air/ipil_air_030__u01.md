# Documentation of Unit Test ipil_air_030__u01

### ID
ipil_air_030__u01

### Related Business Rule
ipil_air_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes country of residence for travellers in IPIL Air that have an unknown 
or generic citizenship code (applicable 99999 or BLANK codes).

The following cases are tested:
> - The record with *citizenship_code* BLANK has its two travellers imputed to *country_of_residence* = 44364 (Iran) and 14862 (Venezuela), respectively
> - The record with *citizenship_code* = "UNA" has its traveller imputed to *country_of_residence* = 44364 (Iran)
> - The record with *citizenship_code* = "UNO" has its traveller imputed to *country_of_residence* = 44364 (Iran)
> - The record with *citizenship_code* = "XX" has its traveller imputed to *country_of_residence* = 22428 (Latvia)
> - The record with *citizenship_code* = "EUE" has its traveller imputed to *country_of_residence* = 22428 (Latvia)

These imputed country of residence codes are based on the following process, as described in documentation for ipil_air_030:
> - The records in `ipil_air` (including explosions for records requiring imputation, as with the BLANK citizenship case in the test) 
> are each assigned a *random_number* based on the seed 202408 (to match the date in the data). In this case, the six records requiring imputation
> for *county_of_residence* receive the random numbers 0.6260.., 0.0542.., 0.9455.., 0.6546.., 0.1392.. and 0.2448..
> - The records are from *wloc* = 4974 and have *mode* = "Air"
> - Among travellers with a known country of residence in the same `ipil_air` file, there are 6 Iranian travellers, 1 Venezuelan traveller, 
> 1 Latvian traveller and 2 Danish travellers matching this criteria
>>   - Note: A record from a different `wloc` (7023 - Edmonton) is ignored
> - Based on the sequential order of their *country_of_residence* codes, the travellers are set on the (0,1) interval as:
>>   - Venezuela (14862) [0.0,0.1]; Latvia (22428) [0.1,0.2]; Denmark (23208) [0.2,0.4]; Iran (44364) [0.4,1.0]
> - Each each of the six traveller records requiring imputation are localized to an interval, and assigned that value.
>>   - For example, the random numbers for the two travellers of the BLANK record fall in the Iran and Venezuela intervals, respectively
> - The EUE (European Union) record is a special case that only considers European countries (first digit of *country_of_residence* = 2)
>>   - A new set of intervals is created as Latvia (22428) [0,0.33]; Denmark (23208) [0.334,1.0]
>>   - The random number (0.2448) of this record falls in the Latvia interval

### Input
input.csv

### Output
output.csv

### Additional Notes
None

### Related pages
[Documentation for ipil_air_030]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_030)
