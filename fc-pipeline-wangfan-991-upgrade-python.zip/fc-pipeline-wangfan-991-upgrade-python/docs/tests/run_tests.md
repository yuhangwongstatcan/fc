
# Running Tests

There are currently 4 ways that the Frontier Counts tests are meant to be run:

- Locally via command line

- Locally via command line with selectors

- Using an IDE's test runner/debugger tool

- In the CI pipeline

## Locally via command line

If you want to run all unit and integration tests, pytest will find and run all tests in the fc-pipeline project by default

1. Ensure that your have built the Frontier Counts conda environment and that it is active in your terminal session

    - E.g. if you named your conda environment "frontier-counts", activate it using `conda activate frontier-counts`

2. The `FC_USE_MOCK_MINIO` parameter in your .env file should be set to `1`

3. Change directory to the `src` or root directory

4. Run all tests using pytest: 

```
pytest .
``` 

## Locally via command line with selectors

You might not want to run all tests when in development, you can use [pytest's built-in keyword matching flag](https://docs.pytest.org/en/6.2.x/usage.html) `-k`

Steps 1-3 are the same as the previous section, but in step 4 you can use the `-k` flag to match keywords in the test names

For example, if you wanted to only run the unit tests you could select only the unit tests using: 

```
pytest -k unit .
```

Or for integration tests:

```
pytest -k integration .
```

If you were only interested in a particular datasource: 

```
pytest -k ipil_hwy .
```

Or even a particular function's tests:

```
pytest -k ipil_hwy_010 .
```

## Using an IDE's test runner/debugger tool

It is also possible to run the test suite suing VS Code's built-in tool.

The `test_datasource.py` and `test_integration_datasource.py` test runners have been configured to automatically run tests out of the correct working directory. 

In VS Code, simply navigate to the "Testing" tab (the flask icon). After configuring your testing tab, your IDE should discover the tests and allow you to debug or run them from this interface. 

## In the CI pipeline

The tests are also configured to be run in the gitlab CI pipeline on dev, tags, and merge requests. This test runner will run all tests using the `pytest .` command. When you're submitting a merge request, make sure that all your tests have passed in the CI pipeline. 
