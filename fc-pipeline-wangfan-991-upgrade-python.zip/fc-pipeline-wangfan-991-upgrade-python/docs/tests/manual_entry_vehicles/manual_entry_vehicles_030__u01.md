# Documentation of Unit Test manual_entry_vehicles_030__u01

### ID
manual_entry_vehicles_030__u01

### Related Business Rule
manual_entry_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes an unknown variable breakdown based on data from the current month already in the system, using data from all ports in the same province.

This data is used for the imputation because 50% or less of the data for the categories specified in the manual entry compared to the specified reference year have already been received at the port level (a "low proportion" of data are already in the system for the current month), and the total for the categories specified in the reference year is 50% or less of the *count_of_entries* from the manual entry at the port level (an "insufficient" amount of data is available for the imputation from the reference year). As such, the matching criteria is loosened to include all ports from the same province in the reference file.

The following cases are tested:
> - A manual entry from April 2019 with 100 vehicles from *port* = 59813 and *plate_country* = 2 (UNITED STATES OF AMERICA), and with  *vehicle_type* = 299 (LAND [NOT AVAILABLE]) has its *vehicle_type* imputed among land vehicle types using data from ALL British Columbia ports (first two digits of *port* = 59) from the April 2019 TRAVELLERS table.
> - This data from the current month (April 2019) with all B.C. ports is used because:
> > - The port-level data in the system from April 2019 is less than 50% of the data from April 2018 for the categories specified in the manual entry
> > - The port-level data in the system from April 2018 for the categories specified in the manual entry is less than 50% of the *count_of_entries* to be imputed

### Input
input.csv

### Output
vehicles.csv

### Related Pages
[Documentation for manual_entry_030]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_030)
