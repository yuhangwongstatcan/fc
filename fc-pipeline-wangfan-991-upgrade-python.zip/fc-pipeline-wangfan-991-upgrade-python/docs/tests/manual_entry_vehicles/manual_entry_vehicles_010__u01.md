# Documentation of Unit Test manual_entry_vehicles_010__u01

### ID
manual_entry_vehicles_010__u01

### Related Business Rule
manual_entry_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes a *count_of_entries* for the number of vehicles when it is unknown and therefore left blank during manual entry capture.

The following cases are tested:
> - A manual entry from April 2019 with *port* = 13231, *vehicle_type* = 212 (MOTORCYCLE) and *plate_country* = 1 (CANADA), but a blank number of vehicles has its *count_of_entries* imputed using the VEHICLES table from April 2018. The *reference_year* is passed as 2018 during runtime.

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for manual_entry_010]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_010)