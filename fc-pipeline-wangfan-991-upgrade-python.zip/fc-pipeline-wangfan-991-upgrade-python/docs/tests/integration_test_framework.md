# Integration Test Framework
## Implementation
The integration test framework is designed to be similar to the unit test framework. 

- The framework uses `src/datasource/test_integration_datasource.py` to find and generate tests for each datasource based off of their configuration under `src/datasource/{datasource}/integration_test`.
- Pipelines will be run by the integration test suite, they can be found in their respective `src/datasource/{datasource}/pipeline.py` files. 
- The intergation tests make use of Mock MinIO to pass inputs to the pipelines and fetch expected outputs. Mock MinIO data can be found at `src/tests/mock_minio`.

## Usage
The integration test framework uses configuration files similar to those of the unit test framework to specify test cases. Each integration test case is associated with a folder containing a configuration file named `integration.config.json`. These test cases are located in subfolders within `src/tests/integration`.

## Creating a new integration test
Each integration test is associated with a folder with the following structure:

```
[Test case name]
┣─ integration.config.json
┃
┗─ ...
```

A valid integration test case folder must contain a `integration.config.json` file. This file defines the parameters of the test case, such as date, outputs, datasource, and stage that is associated with the test.

## integration.config.json
The schema for a valid `integration.config.json` is as follows:

- `date`: The test will be run as if it is being run on this date. The format is `YYYY-MM-DD`.

- `outputs`: This is a list of objects as follows:

  - `datasource`: a valid data source such as `ipil_hwy`, `vehicles` or `travellers`

  - `stage`: a valid stage such as `raw`, `clean` or `transformed`

  - `basename`: a valid basename for the data to be loaded from mock MinIO/Azure

- `reference_year` (optional): For datasources that require a reference year, the reference year for imputation functions.

A valid test case folder must contain a `integration.config.json` file. This file defines the parameters of the test case, such as date, outputs, and the pieline that is associated with the test. 
