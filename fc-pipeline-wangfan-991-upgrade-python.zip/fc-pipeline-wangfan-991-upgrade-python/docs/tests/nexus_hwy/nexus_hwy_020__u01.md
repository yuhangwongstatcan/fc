# Documentation of Unit Test nexus_hwy_020__u01

### ID
nexus_hwy_020__u01

### Related Business Rule
nexus_hwy_020

### Purpose of Test
This unit test will ensure the integrity of the business rule which reduces the number of vehicles in NEXUS Highway if the count is higher than
the total number of NEXUS Highway travellers at the same work location.

The following cases are tested:
> - A work location which has a *count* of 2 vehicles, 1 American traveller and zero travellers of other citizenships has its vehicle count reduced
> to 1.
> - A work location which has a total traveller count of 80,388, and a vehicle count of 81,591 has its vehicle count reduced to 80,388.
> - Work locations which have less vehicles than total travellers, or an equal number are left unchanged

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_hwy_020]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_020)
