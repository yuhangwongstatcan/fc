# Documentation of Unit Test nexus_hwy_060__u01

### ID
nexus_hwy_060__u01

### Related Business Rule
nexus_hwy_060

### Purpose of Test
This unit test will ensure the integrity of the business rule which transforms the NEXUS Highway clean data to create the contribution to the 
vehicles table in the correct schema. Most of the columns can be coded or extracted directly from the clean data.

The following cases are tested:
> - Each of the columns *year*, *month*, *day*, *mode*, *vehicle_type*, *plate_country*, *plate_region*, *work_location* and *data_source* is coded 
> correctly based directly on the clean data as described in nexus_hwy_060
> - The *port* column is coded correctly by linking to the work location reference file as described in nexus_hwy_060

### Input
input.csv

### Output
vehicles.csv

### Additional Notes
None

### Related pages
[Documentation for nexus_hwy_060]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_060)
