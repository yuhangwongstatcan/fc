# Documentation of Unit Test nexus_hwy_010__u01

### ID
nexus_hwy_010__u01

### Related Business Rule
nexus_hwy_010

### Purpose of Test
This unit test will ensure the integrity of the business rule which removes records for unexpected NEXUS Highway work locations until they can be 
verified.
This would apply for cases that cannot be matched to the nexus_hwy work location reference file (**work_locations__nexus_hwy.csv**), and those for 
which *transportation_type* does not indicate automobile (code "nexus_hwy__211").  
(Recall that all NEXUS Highway data is considered automobile for vehicle type)

The following cases are tested:
> - A record with *work_location* = 3514 is removed. This is a real work location, but is not anticipated to accept NEXUS Highway traffic, so 
although it is present in the main work_locations.csv file, it does not have a corresponding "nexus_hwy__211" record in the 
**work_locations__nexus_hwy.csv** reference file
> - A record with *work_location* = 9984 is removed. This is not a real work location, and not present in the work location reference file
> - A record with a blank *work_location* is removed
> - Records with valid NEXUS Highway *work_location*s 2114, 4410, 4780 and 8133 are maintained

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_hwy_010]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_010)
