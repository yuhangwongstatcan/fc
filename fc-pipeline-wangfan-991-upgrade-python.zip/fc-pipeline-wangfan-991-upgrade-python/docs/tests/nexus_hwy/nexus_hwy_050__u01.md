# Documentation of Unit Test nexus_hwy_050__u01

### ID
nexus_hwy_050__u01

### Related Business Rule
nexus_hwy_050

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the trip duration (same day or overnight) of NEXUS Highway travellers
based on pre-defined fixed proportions by work location and citizenship.

The following cases are tested:
> - The work locations of Rte-55 Stanstead (3141), Aldergrove (8174), Boundary Bay (8150) and Abbotsford-Huntingdon (8173) are coded based on 95%
> same-day. Having *citizenship* of 58 Canada and 43 United States, the records are split as follows:
>>  - 55 (round(58 x 95%)) of Canadian citizens are coded as *duration2* = 1 ("Same day") and 3 (58 - round(58 x 95%)) are coded as *duration2* = 2
>>  ("Overnight")
>>  - 41 (round(43 x 95%)) of American citizens are coded as *duration2* = 1 and 2 (43 - round(43 x 95%)) are coded as *duration2* = 2
> - The work locations of Pacific Highway (8132) and Douglas (8133) are coded based on 60% same-day for American citizens:
>>  - 26 (round(43 x 60%)) of American citizens are coded as *duration2* = 1 and 17 (43 - round(43 x 60%)) are coded as *duration2* = 2
> - The work locations of Pacific Highway (8132) and Douglas (8133) are coded based on 70% same-day for Canadian citizens:
>>  - 41 (round(58 x 70%)) of Canadian citizens are code as *duration2* = 1 and 17 (58 - round(58 x 70%)) are coded as *duration2* = 2
> - The work location of Queenston Bridge (4273) (to represent it and all other non-specified work locations) is coded based on 80% same-day.
> Having *citizenship* of 58 Canada and 43 United States, the records are split as follows:
>>  - 46 (round(58 x 80%)) of Canadian citizens are coded as *duration2* = 1 and 12 (58 - round(58 x 80%)) are coded as *duration2* = 2
>>  - 34 (round(43 x 80%)) of American citizens are coded as *duration2* = 1 and 9 (43 - round(43 x 80%)) are coded as *duration2* = 2

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_hwy_050]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_050)
