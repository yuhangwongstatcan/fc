# Documentation of Unit Test nexus_hwy_030__u01

### ID
nexus_hwy_030__u01

### Related Business Rule
nexus_hwy_030

### Purpose of Test
This unit test will ensure the integrity of the business rule which redistributes the "Unknown" and "Other" citizenships to Canadian or American
citizenships.

The following cases are tested:
> - A work location with *citizenship* of 54 Canada, 40 United States, 0 Unknown and 7 Other results in **58** Canada and **43** United States
>>  - The total number to redistribute (impute) is 7 and among the known proportions there are 54/94 = 57% Canada and 40/94 = 43% United States,
>>  so there are 4 (round(7 x 57%)) travellers added to "Canada" and 3 (7-round(7 x 57%)) travellers added to "United States"
> - A work location with *citizenship* of 0 Canada, 0 United States, 1 Unknown and 2 Other results in **2** Canada and **1** United States
>>  - Since there is no "known" proportion (Canada and United States have zero *count*), we distribute evenly, with the extra traveller going to
>>  Canada

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_hwy_030]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_030)
