# Documentation of Unit Test nexus_hwy_040__u01

### ID
nexus_hwy_040__u01

### Related Business Rule
nexus_hwy_040

### Purpose of Test
This unit test will ensure the integrity of the business rule which imputes the plate country of NEXUS Highway vehicles based on the citizenship
distribution of the NEXUS Highway travellers.

The following cases are tested:
> - A work location with *citizenship* of 58 Canada and 43 United States, and 85 VEHICLEs:
>>  - 49 (round(85 x 58/101)) of the vehicles are coded as *plate_country* = 1 ("Canada")
>>  - 36 (85 - round(85 x 58/101)) of the vehicles are coded as *plate_country* = 2 ("United States of America")
>>  - The traveller rows are coded so that *plate_country* matches *citizenship* (1 if *citizenship* = "Canada" / 2 if *citizenship* = "United 
>>  States")
> - A work location with *citizenship* of 2 Canada and 1 United States, and 1 VEHICLE
>>  - 1 (round(1 x 2/3)) of the vehicles are coded as *plate_country* = 1 ("Canada")
>>  - 0 (1 - round(1 x 2/3)) of the vehicles are coded as *plate_country* = 2 ("United States of America")
>>  - The traveller rows are coded so that *plate_country* matches *citizenship* (1 if *citizenship* = "Canada" / 2 if *citizenship* = "United 
>>  States")

### Input
input.csv

### Output
output.csv

### Related Pages
[Documentation for nexus_hwy_040]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_040)
