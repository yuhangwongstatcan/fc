# Logging Validation Data to MinIO

The "Logging" in Frontier Counts refers to keeping track of certain properties of the data as well as certain properties of the data processing job so that an analyst(s) can review this information in some kind of dashboarding tool.

!!! note
    This is not the same thing as regular standard application logging to, e.g. stdout. Rather, this logger writes very specific user-defined validations to S3 locations in MinIO that are consumed by the clients through PowerBI visualizations.

To this end, we simply capture all of the data required for the validation in a CSV file that then gets written to a known MinIO location.

Please refer to the S3 documentation for more detail on how our [s3 client]({{fc_baseurl.doc}}/minio/s3_client)/[s3 storage]({{fc_baseurl.doc}}/minio/s3_storage) are set up.

# MinIOLogger Documentation

::: modules.logger