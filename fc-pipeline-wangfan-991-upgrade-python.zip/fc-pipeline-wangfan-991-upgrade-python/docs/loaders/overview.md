# Loader

*15/01/2024 - This section could use some additional context*

The loader's main use is in the `check inbox` stage. It matches an incoming file to the correct datasource and then uses that datasource's loading rules to correctly parse or reject the data files. Each implemented datasource has its own implemented loader (found at `src/datasource/{datsource}/loader.py`) which implements the rules for properly reading or rejecting an individual file. 

::: loader
