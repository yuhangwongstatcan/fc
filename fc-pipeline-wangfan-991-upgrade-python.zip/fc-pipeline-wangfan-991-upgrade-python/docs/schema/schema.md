Schemas for datasources are built using [Pandera schema models](https://pandera.readthedocs.io/en/stable/dataframe_models.html).

Common tooling such as common schemas, dimension values, and data types can be found in `src/datasource/common`

Some datasources use a thinly wrapped Pandera schema model for validation in order to provide more legible error messages for the production team. These wrappers can be found in `src/modules/utils/schema_wrappers.py`

:::modules.utils.schema_wrappers
