> This example was last updated on 06/03/2024

As of the writing of this article there are two places to find an image name: 

In a merge request CI pipeline: 

![MR page](../img/example_issues/deploying_to_octopus/MR-1.png)

![Image name from an MR](../img/example_issues/deploying_to_octopus/MR-2.png)

Or from a tag (in red): 

![Image name from a tag](../img/example_issues/deploying_to_octopus/tag-1.png)

In the Variables tab, scroll and update the image name for the environment that you want to deploy (in red) and then commit your changes (in green): 

![Where to update values](../img/example_issues/deploying_to_octopus/variables-2.png)

To deploy your new image, go to the Octopus release that you'll be deploying on. If you're creating a new release you can skip this step, but if you're deploying on an existing Octopus release you'll need to update its variables. Don't forget to update your variables (in red): 

![Update the variables in the release](../img/example_issues/deploying_to_octopus/release-1.png)

Now that Octopus has the updated image name(s), you can deploy to the environment you're trying to update (in red): 

![Deploy to your environment](../img/example_issues/deploying_to_octopus/deploy-1.png)

Your new image should be deployed to the environment in a minute or two. Don't forget that there are [special considerations]({{fc_baseurl.doc}}/deployment/octopus/#deploying-to-prod-and-prod-alpha) when deploying to prod and prod alpha. 
