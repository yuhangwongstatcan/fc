> The following article links to some issues that could provide a good starting point for future maintainers to see what kind of issues can arise in the FC system along with their solutions. 

## OAuth Secret Expiry

https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/838

This issue arose because the secret registered for OAuth expired. You can check to see if any of the relevant secrets are available under the "App Registrations" app in the Azure portal: 

![App registrations](../img/reference_issues/oauth-1.png)

You should be able to find each of the FC app registrations, clicking into them should tell you whether their secrets are expired: 

![The three FC apps](../img/reference_issues/oauth-2.png)


## Input Data Schema Failure

Sometimes, the input data fails a schema validation and the prod team is unable to pinpoint where the failure is. 

Here are a few examples of schema failures in the past being solved:

https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/799

https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/800

https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/835


## Infrastructure Issues

Sometimes, you have to refer to k9s to pinpoint exactly where the issue is. In the following issue, the cloud native team had to get involved to help us identify and deploy a fix to the S3proxy image we were using:

https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/830

## Argo Issues and Updates

Our Argo templates can sometimes interact with the FC system in an unexpected way. In the following issue, we had an issue with duplicates being caused by some overlapping names in our Argo templates. This ticket shows the steps taken to troubleshoot, update the argo templates, and deploy the fix: 

https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/825

## Loader Updates

In some cases, we want to update the data source loader to be a bit smarter. Here is an example of some work and fixes on an issue related to the E63 and E63-1 loaders: 

https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/817

