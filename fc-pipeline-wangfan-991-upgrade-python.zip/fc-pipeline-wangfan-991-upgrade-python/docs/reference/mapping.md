The `mapping` data source is used to store a correspondence between columns values that are each of an enumerator/categorical type.

The purpose of such files is twofold:

1. These files serve as a form of documentation for the mappings between column values within/between data sources.
2. These files can be used in the source code to dynamically the mapping information from a reference file to avoid hard-coding reference file values in the source code.

The naming convention used with `mapping` files can be found in the [naming convention]({{fc_baseurl.doc}}/config/naming) documentation.

# Load this Data Source
There are special methods in `src.modules.loaders.Loader` that load mapping files in either object or dataframe formats, depending on the task that is required. Both approaches are shown in code snippets on this page.

::: modules.utils.loaders.Loader.get_map_obj

::: modules.utils.loaders.Loader.get_map_df

# Schema

{{ read_csv('src/tests/mock_minio/reference/mapping/mapping__reference__index.csv') }}

# Preview

Unlike other reference files, there are many different mapping files. I include a few examples here for illustration purposes, but for the full list of mapping reference files, please see the `src/tests/mock_minio/reference/mapping` folder of the `fc-pipeline` repository.

## IPIL Hwy Country --> Plate Country

{{ read_csv('src/tests/mock_minio/reference/mapping/map__ipil_hwy__clean__country__travellers__transformed__plate_country.csv', nrows=5) }}

## TRC Country --> Plate Country

{{ read_csv('src/tests/mock_minio/reference/mapping/map__trc__raw__country__trc__clean__country_of_residence.csv', nrows=5) }}
