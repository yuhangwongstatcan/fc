Continents.
This file is similar to dim__countries__continent, however contains the column table_24100055 and table_24100056 which indicates the dim2 value for the continents in the CODR table 24100055 and 24100056.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

countries__rcontinent = Loader.get(Stage.REFERENCE, DataSource.countries__continent, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/countries_continent/countries__continent__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/countries_continent/countries__continent.csv', nrows=5) }}
