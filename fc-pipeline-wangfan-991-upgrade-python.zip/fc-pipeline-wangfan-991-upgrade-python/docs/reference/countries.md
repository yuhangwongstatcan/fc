The `countries` reference file is used in multiple data processing pipelines to get information about countries including the 5-digit country codes used throughout the Frontier Counts system. This reference file is often used in a series of left-joins with some data source for the purpose of augmenting each record with country information.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

countries = Loader.get(Stage.REFERENCE, DataSource.countries, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/countries/countries__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/countries/countries.csv', nrows=5) }}
