## DEPRECATION WARNING

> As of June 2023, this functionality has been deprecated. Dimensions have been simplified and replaced by dim.py files available either for common use in `src/datasource/common/dim.py` or for individual datasources in `src/datasource/{datasource}/dim.py

> The following documentation is only being kept around as a reference

---

The `dimension` data source is used to store columns values that are an enumerator/categorical type for each data source.

The purpose of such files is twofold:

1. These files serve as a form of documentation for the values that each table column can take on.
2. These files can be used in the source code to dynamically load Enumerator/category information from a reference file to avoid hard-coding reference file values in the source code.

The naming convention used with `dimension` files can be found in the [naming convention]({{fc_baseurl.doc}}/config/naming) documentation.

# Load this Data Source
There are special methods in `src.modules.loaders.Loader` that load dimension files in either object or dataframe formats, depending on the task that is required. Both approaches are shown in code snippets on this page.

# Schema

{{ read_csv('src/tests/mock_minio/reference/dimension/dimension__reference__index.csv') }}

# Preview

Unlike other reference files, there are many different dimension files. I include a few examples here for illustration purposes, but for the full list of dimension reference files, please see the `src/tests/mock_minio/reference/dimension` folder of the `fc-pipeline` repository.

## Countries Table - Continent Column

{{ read_csv('src/tests/mock_minio/reference/dimension/dim__countries__continent.csv', nrows=5) }}

## IPIL Hwy Table - Vehi Column

{{ read_csv('src/tests/mock_minio/reference/dimension/dim__ipil_hwy__vehi.csv', nrows=5) }}
