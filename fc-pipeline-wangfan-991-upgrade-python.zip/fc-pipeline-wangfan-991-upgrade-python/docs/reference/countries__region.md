The region of continents.
This file is similar to dim__countries__region, however contains the column table_24100055 which indicates the dim2 value for the sub-region of continents in the CODR table 24100055.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

countries__region = Loader.get(Stage.REFERENCE, DataSource.countries__region, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/countries_region/countries__region__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/countries_region/countries__region.csv', nrows=5) }}
