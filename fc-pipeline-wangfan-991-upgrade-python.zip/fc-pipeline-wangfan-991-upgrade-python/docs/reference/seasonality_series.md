# Purpose

These files are necessary to provide to the Dissemination team before you can load data into a table. Each of the NDM tables require a mapping and series files.

# File Structure

The mapping files have the following structure:  
![mapping file format](../img/CODR_mapping_1.png)

It is a file that enumerates each member in a dimension, each dimension requires a mapping file.

The series files have the following structure:

![series file format](../img/CODR_series_1.PNG)

It is a file that contains all the cells (combinations of the dimensions) that you will load data into and any cell you want to mark as impossible (...).

These are the values that can be taken by the first four columns:  
![dimensions of ScalarFactor](../img/CODR_series_2.png)

![dimensions of Decimals](../img/CODR_series_3.png)

![dimensions of VectorId and IsImpossible](docs/img/CODR_series_4.png)

# Circumstance to Update Files

The mappings and series files will need to be upadated if a new member is added to one of the dimensions.


