The `ports.csv` file contains information about each port of entry in Canada.

The `ports.csv` file is used many times throughout the code base.

A common use for the `ports.csv` file is to associate information such as the `sgc_code` (province code), `port_name`, and `published_port` with each record that has a given port number. Note that `published_port` is the value that is ultimately published as there exist certain ports that need to be "censored" or "collapsed" for privacy reasons.

**Note**: the first two digits of `port` are the `sgc_code` corresponding to that port.

--8<-- "docs/templates/wloc_port_sgc_aggregation_tip.md"

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

ports = Loader.get(
    Stage.REFERENCE,
    DataSource.ports,
    None
)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/ports/ports__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/ports/ports.csv', nrows=5) }}
