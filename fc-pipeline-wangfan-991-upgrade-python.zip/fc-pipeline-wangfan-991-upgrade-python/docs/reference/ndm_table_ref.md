This page describes multiple data sources that serve the same purpose, but each distinct file exists for a specific [NDM table]({{fc_baseurl.doc}}/datasource/ndm/overview) (see the linked docs for more information about NDM specifically along with NDM variable descriptions/definitions).

The purpose of the `ndm_<table number>_ref.csv` files is to establish a mapping between the `ndm_vector` of a record and its corresponding dimension values.

These files are used in the various ndm pipelines (e.g. `src/datasource/ndm_24100050/pipeline.py`) to map dimension/metadata values from the reference files to the `ndm_unadjusted`/`ndm_adjusted` tables.

There are also `Symbol`, `Status`, and `SecurityLevel` values included in the `ndm_<table number>_ref.csv` files. At the time of writing this documentation, these columns are not used (i.e. they are set to a default value of `0` always), however, their presence is necessary in order for NDM files produced by the Frontier Counts system to be ingested by the NDM system.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

ndm_24100051_ref = Loader.get(
    Stage.REFERENCE, DataSource.ndm_24100051_ref, None
)
```

# Schema
I include an example here for illustration purposes, but for the full list of `ndm_<table number>_ref.csv` reference files, please see the `src/tests/mock_minio/reference/` folder of the `fc-pipeline` repository.

{{ read_csv('src/tests/mock_minio/reference/ndm_24100053_ref/ndm_24100053_ref__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/ndm_24100053_ref/ndm_24100053_ref.csv', nrows=5) }}
