The `work_locations.csv` file contains information about each work location in Canada.

A common use for the `work_locations.csv` file is to map work locations to their corresponding port of entry (see [Ports documentation]({{fc_baseurl.doc}}/reference/ports) for description of the `ports.csv` file). Additionally, a number of data sources received by CBSA undergo a series of **work location validations** to determine how to apply certain recoding rules to combinations of vehicle types and work locations. The details of these reference files and corresponding validation logic is documented in the [Work Location Validations]({{fc_baseurl.doc}}/reference/work_locations_validation) reference file documentation.


--8<-- "docs/templates/wloc_port_sgc_aggregation_tip.md"


# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

work_locations = Loader.get(
    Stage.REFERENCE,
    DataSource.work_locations,
    None
)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/work_locations/work_locations__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/work_locations/work_locations.csv', nrows=5) }}
