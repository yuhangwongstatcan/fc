The Canadian provinces and territories, using the StatCan defined codes as the numeric representation of each state.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

provinces_and_territories = Loader.get(Stage.REFERENCE, DataSource.provinces_and_territories, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/provinces_and_territories/provinces_and_territories__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/provinces_and_territories/provinces_and_territories.csv', nrows=5) }}
