There are a series of validations performed on each data source ingested by CBSA that relate to how to treat certain combinations of **vehicle types** and **work locations**. In particular, the treatment may be to **Accept**, **Recode**, or **Reject** the value depending on the combination of vehicle type and work location.

Since these validations are repetative, there is a reusable component that applies these recodings based on multiple configuration files that are documented in this data source. In particular:

1. `work_locations_action__<data source>.csv`
2. `work_locations_trans__<data source>.csv`
3. `work_locations_trans_action__<data source>.csv`

Each of these data sources are detailed further below.

# Work Locations Action

## Schema
{{ read_csv('src/tests/mock_minio/reference/work_locations_action/work_locations_action__reference__index.csv') }}

## Preview (IPIL HWY Example)

{{ read_csv('src/tests/mock_minio/reference/work_locations_action/work_locations_action__ipil_hwy.csv', nrows=5) }}

# Work Locations Trans

## Schema
{{ read_csv('src/tests/mock_minio/reference/work_locations_trans/work_locations_trans__reference__index.csv') }}

## Preview (IPIL HWY Example)

{{ read_csv('src/tests/mock_minio/reference/work_locations_trans/work_locations_trans__ipil_hwy.csv', nrows=5) }}


# Work Locations Trans Action

## Schema
{{ read_csv('src/tests/mock_minio/reference/work_locations_trans_action/work_locations_trans_action__reference__index.csv') }}

## Preview (IPIL HWY Example)

{{ read_csv('src/tests/mock_minio/reference/work_locations_trans_action/work_locations__ipil_hwy.csv', nrows=5) }}

# Recode Codes Dimension

The `dim__work_locations__codes` dimension contains all of the recoding actions that may be taken by the `src.modules.utils.data_manipulation.work_locations_recode` program described later in this page.

## dim__work_locations__codes
{{ read_csv('src/tests/mock_minio/reference/dimension/dim__work_locations__codes.csv') }}

In addition to a few standard values (e.g. `A` = "accept", `C` = "confront", etc.), the general format of these codes is `R###*` where `R` stands for "recode", `###` refers to the vehicle type code used in the final `vehicles`/`travellers` tables of the Frontier Counts system. These codes are shown below for convenience/reference.

## dim__vt__vehicle_type
{{ read_csv('src/tests/mock_minio/reference/dimension/dim__vt__vehicle_type.csv') }}


# Work Locations Recode

The API documentation for `src.modules.utils.data_manipulation.work_locations_recode` is shown below.

::: modules.utils.data_manipulation.work_locations_recode

# Load These Data Sources

```python
from config.api import DataSource
from config.api import Stage
from config.api import WorkLocationsTransAction
from config.api import WorkLocationsAction
from config.api import WorkLocationsTransportation

from modules.utils.loaders import Loader

wl_trans = Loader.get(
    Stage.REFERENCE,
    DataSource.work_locations_trans,
    WorkLocationsTransportation.work_locations_trans__ipil_hwy,
)

wl_action = Loader.get(
    Stage.REFERENCE,
    DataSource.work_locations_action,
    WorkLocationsAction.work_locations_action__ipil_hwy,
)
wl_trans_action = Loader.get(
    Stage.REFERENCE,
    DataSource.work_locations_trans_action,
    WorkLocationsTransAction.work_locations__ipil_hwy,
)
```