There are two data sources used for the so-called **Fixed Proportion Imputation** of the manual entry pipelines. See [manual entry pipeline documentation]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_020) for more detail about how these fixed proportion imputations work.

Both of these reference files are generated programmatically by the web application. Their purpose is to specify imputation distributions when some fixed rule (e.g. "Always apply 60% Canada and 40% USA for country of residence in circumstance XYZ") is the best imputation possible.

These data sources should require little maintainer activity, but are documented below briefly for context.

--8<-- "docs/templates/manual_entry_deprecation_admonition.md"


# Fixed Proportion Rules

Each row of this table contains a series of conditions under which a fixed proportion rule applies. There is a primary key variable called `rule_id` that can be used to link to the `fixed_proportions.csv` table. This join is a **1:n** join, where one `rule_id` value corresponds to many records in the `fixed_proportions.csv` table. The Rule ID value is a universally unique identifier (UUID) for the record.

## Schema

{{ read_csv('src/tests/mock_minio/reference/fixed_proportion_rules/fixed_proportion_rules__reference__index.csv') }}

## Preview

{{ read_csv('src/tests/mock_minio/reference/fixed_proportion_rules/fixed_proportion_rules.csv', nrows=5) }}


# Fixed Proportions

This table enumerates the proportions associated with a given `rule_id` in the `fixed_proportion_rules.csv` table. The `fixed_proportions.csv` table enumerates the value-proportion pairs associated with a given rule.

Together, the `fixed_proportion_rules.csv` and `fixed_proportions.csv` tables specify the distribution for a fixed rule imputation.

## Schema

{{ read_csv('src/tests/mock_minio/reference/fixed_proportions/fixed_proportions__reference__index.csv') }}

## Preview

{{ read_csv('src/tests/mock_minio/reference/fixed_proportions/fixed_proportions.csv', nrows=5) }}



# Load these Data Sources

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

fixed_proportions = Loader.get(Stage.REFERENCE, DataSource.fixed_proportions, None)
fixed_proportion_rules = Loader.get(Stage.REFERENCE, DataSource.fixed_proportion_rules, None)
```
