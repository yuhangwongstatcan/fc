The Frontier Counts system uses a variety of configuration/auxiliary/reference data that is used to augment data processing logic. Such data is time invariant in the sense that it does not change on a regular basis. However, this data must be maintained throughout time and updated based on world events.

The various other pages in this section of the documentation outline each reference data source used, a quick explanation of what the data source is used for, the schema for the data source, and a preview of the reference file itself for quick reference.
