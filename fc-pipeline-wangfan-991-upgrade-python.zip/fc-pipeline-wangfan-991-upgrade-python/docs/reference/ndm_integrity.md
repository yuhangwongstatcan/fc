The use of this datasource is explained in the [NDM Integrity documentation]({{fc_baseurl.doc}}/datasource/ndm/ndm_integrity).

Note that there are two data sources related to NDM Integrity: (1) `ndm_integrity_config.csv` and (2) `ndm_integrity_between_tables.csv`. The use of both of these files are documented in the link above.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

ndm_integrity_config = Loader.get(
    Stage.REFERENCE, DataSource.ndm_integrity_config, None
)
```

# NDM Integrity Config Schema

{{ read_csv('src/tests/mock_minio/reference/ndm_integrity_config/ndm_integrity_config__reference__index.csv') }}

# NDM Integrity Config Preview

{{ read_csv('src/tests/mock_minio/reference/ndm_integrity_config/ndm_integrity_config.csv', nrows=5) }}


# NDM Integrity Between Tables Schema

{{ read_csv('src/tests/mock_minio/reference/ndm_integrity_between_tables/ndm_integrity_between_tables__reference__index.csv') }}

# NDM Integrity Between Tables Preview

{{ read_csv('src/tests/mock_minio/reference/ndm_integrity_between_tables/ndm_integrity_between_tables.csv', nrows=5) }}