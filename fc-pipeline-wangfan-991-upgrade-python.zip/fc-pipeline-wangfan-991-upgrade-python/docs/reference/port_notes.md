The `port_notes.csv` contains human-readable notes for production users of the system that contain certain relevant information for combinations of ports, years, and months.

Although this file is stored as a reference file in the Frontier Counts system, it is not used in any of the source code. Rather, this file is used by the PowerBI visualizations that are created and maintained by the Frontier Counts team.

This file will be updated and maintained exclusively by the Frontier Counts team, however, the file is documented here in case an IT maintainer needs to be involved with anything that involves the `port_notes.csv` reference file.

# Schema

{{ read_csv('src/tests/mock_minio/reference/port_notes/port_notes__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/port_notes/port_notes.csv', nrows=5) }}
