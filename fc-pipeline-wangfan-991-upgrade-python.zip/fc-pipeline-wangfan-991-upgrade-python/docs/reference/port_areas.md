The sub-region (area) of the provinces and territories.
This file is similar to dim__ports__port_area, however contains the column table_24100055 which indicates the dim1 value for the port areas in the CODR table 24100055.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

port_areas = Loader.get(Stage.REFERENCE, DataSource.port_areas, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/port_areas/port_areas__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/port_areas/port_areas.csv', nrows=5) }}
