A portion of the ndm time series records that are produced by the Frontier Counts system require adjustment for seasonal trends.

The team at StatCan who handles seasonal adjustment has their own input specification that differs from the NDM specification. Therefore, a reference file (`ndm_sa.csv`) is required to translate between NDM **queries** and so-called SA_IN (seasonal adjustment input) **series** (the UUID of the seasonal adjustment system). Additionally, this `ndm_sa.csv` reference file translates between so-called SA_OUT (seasonal adjustment output) **series** and NDM **vectors** (the UUID of the NDM system). Each translation process is explained in greater detail below.

## NDM Queries --> Seasonal Adjustment Input Series

The first step in this process is to translate NDM queries that run against the travellers_main table to records that can be given to the seasonal adjustment team. The clients of Frontier Counts requested that we specify the NDM --> series correspondence in this way for the following reasons:

1. There may be a **n:1** correspondence between NDM vectors and series, so applying an aggregation directly to a subset of the `travellers_main` table allows us to avoid enumerating which individual NDM vectors contribute to that sum.
2. If NDM vectors need to change, the entire set of vectors needs to be regenerated. In such a case, the `ndm_sa.csv` file would need to be regenerated with the new vectors. To avoid regenerating `ndm_sa.csv` if this scenario ever occurs, the queries are just specified directly in the `ndm_sa.csv` file to avoid hard-coding input vectors.

The business rule `src/datasource/ndm_unadjusted/business_rule/ndm_unadjusted_020.py` implements the logic to generate the `sa_in.csv` table from the `travellers_main` file.

## Seasonal Adjustment Output Series --> NDM Vectors

Seasonal adjustment output series are returned from the seasonal adjustment team. They arrive in the `/inbox` S3 location in a file called `SA_RK_OUT.csv`. The callback function in `src/datsource/ndm_adjusted/loader.py` defines how this `SA_RK_OUT.csv` file is joined back `ndm_sa.csv` to get the NDM vectors that make up the `ndm_adjusted.csv` file.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

ndm_sa = Loader.get(Stage.REFERENCE, DataSource.ndm_sa, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/ndm_sa/ndm_sa__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/ndm_sa/ndm_sa.csv', nrows=5) }}
