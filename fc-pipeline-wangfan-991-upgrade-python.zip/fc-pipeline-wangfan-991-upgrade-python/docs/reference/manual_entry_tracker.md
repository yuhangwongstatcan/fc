**Note**: this reference file relates to the manual entry pipeline validations - [manual_entry_v005]({{fc_baseurl.doc}}/datasource/manual_entry/validation/manual_entry_v005) and [manual_entry_v007]({{fc_baseurl.doc}}/datasource/manual_entry/validation/manual_entry_v007), more information can be found in the linked documentation.

The files `manual_entry_tracker_travellers.csv` and `manual_entry_tracker_vehicles.csv` are used to validate manual entry data in the following ways.

1. There are certain manual entries that are expected to not be received by CBSA. If a manual entry **should not be present but is**, then a validation in the manual entry pipeline reports the unexpected data. This is documented in  [manual_entry_v005]({{fc_baseurl.doc}}/datasource/manual_entry/validation/manual_entry_v005).
2. There are certain manual entries that are expected to be received by CBSA. If a manual entry **should be present but is not**, then a validation in the manual entry pipeline reports the unexpected data. This is documented in [manual_entry_v007]({{fc_baseurl.doc}}/datasource/manual_entry/validation/manual_entry_v007).

--8<-- "docs/templates/manual_entry_deprecation_admonition.md"

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

manual_entry_tracker = Loader.get(Stage.REFERENCE, DataSource.manual_entry_tracker_vehicles, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/manual_entry_tracker_travellers/manual_entry_tracker_travellers__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/manual_entry_tracker_travellers/manual_entry_tracker_travellers.csv', nrows=5) }}
