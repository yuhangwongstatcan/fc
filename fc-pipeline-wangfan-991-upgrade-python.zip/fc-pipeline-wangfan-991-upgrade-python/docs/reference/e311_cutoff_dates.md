
This datasource is explained in the [e311_003 business rule]({{fc_baseurl.doc}}/datasource/e311/business_rule/e311_003) documentation.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

e311_cutoff = Loader.get(Stage.REFERENCE, DataSource.e311_cutoff_dates, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/e311_cutoff_dates/e311_cutoff_dates__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/e311_cutoff_dates/e311_cutoff_dates.csv', nrows=5) }}
