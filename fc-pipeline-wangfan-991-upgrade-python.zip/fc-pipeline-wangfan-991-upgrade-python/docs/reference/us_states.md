The US states, using the StatCan defined `sgc_code` as the numeric representation of each Province/Territory.

# Load this Data Source

```python
from config.api import DataSource
from config.api import Stage

from modules.utils.loaders import Loader

us_states = Loader.get(Stage.REFERENCE, DataSource.us_states, None)
```

# Schema

{{ read_csv('src/tests/mock_minio/reference/us_states/us_states__reference__index.csv') }}

# Preview

{{ read_csv('src/tests/mock_minio/reference/us_states/us_states.csv', nrows=5) }}
