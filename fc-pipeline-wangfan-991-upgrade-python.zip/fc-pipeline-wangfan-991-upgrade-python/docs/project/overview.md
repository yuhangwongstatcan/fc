# Business Process and System Overview

# Production Workflow

## Loading Step

## Aggregation Step

## Seasonal Adjustment

# Downstream/Dissemination Workflow

## Dissemination Steps

## Reporting ("Report Hub")

# Summary of Different Data TAbles Required

