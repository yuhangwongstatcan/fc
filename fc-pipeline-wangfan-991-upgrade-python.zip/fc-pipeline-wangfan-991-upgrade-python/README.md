# Frontier Counts Redesign &middot; [![Python 3.6](https://img.shields.io/badge/python-3.9-blue.svg)](https://www.python.org/downloads/release/python-390/)

> A cloud native data processing system for the Frontier Counts program at StatCan.

## Related Repositories
- [fc-docs-site](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-docs-site) is the repository containing the [Subject Matter Documentation Site](https://tourism-tourisme.pages.cloud.statcan.ca/frontiercounts/frontier-counts/fc-docs-site/).
-

## Dependencies

- [MinIO](https://min.io/) for s3-compatible object storage
- [Power BI](https://powerbi.microsoft.com/en-au/) for dashboarding and visualization (connects to MinIO)
- [Argo Workflows](https://argoproj.github.io/workflows/) for Kubernetes-native workflow orchestration
- [Conda](https://docs.conda.io/en/latest/) for python environment and dependency management

## Installation (Current Process on AAW)

Clone this repository to your filesystem

Create/install/activate the conda virtual environment for this project:

```bash
cd src && conda env create -f environment.yml
```

```bash
conda activate frontier-counts
```

There are multiple environment variables in `example.env` that need to be set to perform the full functionality of the system. Create a `.env` file, copy + paste the contents of `example.env`, and set the various variables in `.env` as required. The application will automatically parse this file using [pydantic](https://pydantic-docs.helpmanual.io/) if the required variables are not found in the process environment variables.

## Deployment

There is a [Frontier Counts Helm Chart](https://gitlab.k8s.cloud.statcan.ca/cloudnative/k8s/charts) that is used to deploy the Frontier Counts system on Kubernetes. Further documentation will be provided at a later date (TODO), but the key points are as follows.

* An cluster-wide instance of Argo Workflows is managed by the SDLC platform teams. The Frontier Counts web application runs in the `frontiercounts` namespace on each Kubernetes cluster and runs under a custom `webapp-service-account` and a `RoleBinding` is used to bind a custom `argo-workflow-get-post` role to that service account. This is required to enable the webapp to make API calls to the Argo Workflow server on behalf of the user.

* We deploy an instance of MinIO in the `frontiercounts` namespace that runs in gateway mode, proxying an [Azure Storage Account](https://docs.microsoft.com/en-us/azure/storage/common/storage-account-create).

* The webapp is also deployed in the `frontiercounts` namespace, and runs under the above-mentioned `webapp-service-account`.

* An Argo Workflow template is provided in the above-linked Frontier Counts Helm Chart repository. Workflows are created based off of this template.

## Getting Started

All python code is executed from the `src` folder, and all functionality of the Frontier Counts system is exposed through several CLI programs. This section shows the main CLI programs along with examples of how to run each program.

### Web App
Run the webapp dev server

```bash
python main.py
```

Run the webapp prod server

```bash
# Note that there are some very long-lived http requests in Frontier Counts,
# so we set the timeout very high in case a request takes many minutes. Gunicorn
# will crash with a default timeout otherwise.
gunicorn main:app -b 0.0.0.0:8000 --timeout 3600
```
### Pipelines and Loader
Run data processing pipelines

```bash
# Get the list of available options
python run_pipeline.py --help
# Example pipeline run
python run_pipeline.py --pipeline-class PipelineRawClean --data-source ipil_hwy --date 2019-12-01
```

Triage incoming data into the appropriate S3 locations

```bash
python loader.py --check-inbox
```

### "Ad-Hoc" Validations

Generate the Data Integrity Report

```bash
python generate_data_integrity_report.py --year 2019 --month 12
```

Generate the Downstream Validation Report

```bash
python generate_downstream_validation.py -y1 2017 -y2 2018 -y3 2019 -m1 12 -m2 12 -m3 12
```

Generate the NDM Integrity Report

```bash
python ndm_integrity.py --year 2019 --month 12
```

### Other System Functionality

Bulk-prepare NDM outputs to the `/outbox` s3 location.

```bash
python ndm_prepare_outbox.py --date 2019-12-01 --periods 15
```

Reconcile the state of mock minio reference/configuration files maintained in Git and the corresponding reference/configuration files in S3. The purpose of this is to prevent "configuration drift" where the production team may update configuration files in MinIO but not in Git.

```bash
python reconcile_mock_minio.py
```

Move data to one of the release locations.

```bash
python release.py --leading-pre-release
```

Prepare time series data for the seasonal adjustment team

```bash
python sa_in.py --date 200-01-01 --num-periods 156 --force
```

Move data from one or more of the S3 `/staging` locations to the `/inbox` location.

```bash
python staging.py --s3 system_testing/ipil_hwy/test_cases --recursive
```

Update the schema definitions for system datasources

```bash
python -m schema.api
```

Run the unit/integration test suite

```bash
# Run a specific test
python test_cli.py --type unit --datasource ipil_hwy --name ipil_hwy_040__u01
# Run a datasource's test suite
python test_cli.py --type unit --datasource ipil_hwy
# Run the whole test suite for unit or integration tests
python test_cli.py --type integration
```

## Documentation

Our [documentation site](https://tourism-tourisme.pages.cloud.statcan.ca/frontiercounts/frontier-counts/fc-pipeline/) is hosted on Gitlab Pages.

## Contributing

This project follows the standard Git branching model. The `master` branch is reserved for releases, the `dev` branch contains active development work, and developers create feature branches off of `dev` following the convention `@<user>/<issue number>-<optional short description>`.

Releases are made through Git tags and follow the naming convention `<major version>.<minor version>.<patch>-rc-<release candidate number>`.

This project uses Gitlab CI to scan, build, and push our Frontier Counts container image. On tags, the CI pipeline also builds and deploys the documentation site.

## Project Management

Issues and Milestones can be found in the [Project](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts) group. Developer issues are scoped to the [project](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/project) repo and Subject Matter issues are scoped to the [tourism-frontier-counts-redesign-tasks](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/tourism-frontier-counts-redesign-tasks) repo.

## Getting Started

The `src` folder contains all of the project's source code.

* The `datasource` folder contains modules for the various data sources received by CBSA, as well as data sources that are derrived from upstream CBSA data. In general, a time-based data source contains a `pipeline` module that contains pipeline code, a `loader` module which contains a callback function that is invoked when `python loader.py --check-inbox` discovers an instance of that datasource in the `/inbox` S3 location, an optional `utils` module for datasource-specific utilities/helper functions, and `business_rule` / `validation` folders containing many business rules and validations that are called in the `pipeline` module.

* The `schema` folder contains a home-grown API for schema management from CSV files that are provided in `tests/mock_minio/<stage>/<datasource>/<datasource name>__<stage>__index.csv`. E.g. for IPIL HWY raw data, the schema definition is in `ipil_hwy__raw__index.csv`. The `Schema` class in the `schema.api` module parses the directory structure of `mock_minio` to discover these CSV files, and converts them to equivalent `yaml` files in the `schema/datasource` folder. Our schema api supports inheritence, so business rule/validation schemas can be "chained" together. **Note:** since creating this home-grown solution for schema management, our team has discovered [pandera](https://pandera.readthedocs.io/en/stable/) and [Frictionless Standards](https://specs.frictionlessdata.io/) which provide much of the same functionality out-of-the-box.

* The `webapp` folder contains code for the web app. This is a Flask web app that uses JavaScript and JQuery for the client-side. The webapp follows the standard MVC pattern. More information can be found on the documentation site.

* The `tests` folder contains the code for the unit/integration test runner. Every test for the business/validation logic follows the same format (i.e. `f(input) = expected output` where `input` and `expected_output` are pandas dataframes). **Note:** since creating this home-grown solution for our unit test runner, our team has discovered [pytest-cases](https://smarie.github.io/python-pytest-cases/) which allows you to parameterize a test by supplying a generator of test instances. If we had known about this pytest extension at the time of starting this project, we would have opted for the above-mentioned approach instead of creating a home-grown test runner.

* The `config` folder contains several important modules to manage system configuration. The `env` module contains a pytantic model for environment variables. The `api` module contains many enumerators, as well as an `S3` class that translates various S3 functionalities into a standard interface for application developers. The `rules.json` file contains a list of file matching rules that identifies the appropriate callback function to load each kind of file when it is encountered in the `/inbox` prefix. The `constants` module contains a variety of ad hoc constants that are used throughout the application.

* The `argo` folder contains a yaml file for posting workflows to the Argo Workflows API server using the Workflow Template that is installed to the namespace as part of the helm chart deployment.

* The `modules` folder contains various helpers and interfaces for components of the system. The `pipeline` module provides a `BasePipeline` class that contains boilerplate/reusable functionality - developers only need to extend this class when creating new pipelines. The `logger` module contains a standard interface for logging validations to MinIO (note that this has nothing to do with application logging (e.g. to stderr/stdout) - the purpose of this module is to write validation data to S3 in CSV format). The `s3client` module contains an S3Client class that provides a stnadard interface for reading/writing to S3. This `S3Client` class is used heavily in the module `modules.utils.loaders`, where a series of `Loader` interfaces are defined that allow developers to load data using enumerators rather than file paths. The final `Loader` class that is used throughout the application also detects whether S3 MinIO or "file system" MinIO ("mock minio") should be used based on the presence/absence of the `FC_USE_MOCK_MINIO` environment variable.

* The `diagram` module contains code to auto-generate documentation diagrams about the relationships between the various data sources in Frontier Counts.
