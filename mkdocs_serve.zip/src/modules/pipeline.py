"""
All data processing in Frontier Counts occurs within the context of pipelines. All pipelines extend
BasePipeline defined in this module.
"""
from __future__ import annotations

import importlib
import pandas as pd
import datetime
from typing import Optional
from typing import List
from typing import Callable
from typing import Tuple
from dataclasses import dataclass
from config.api import S3
from config.api import DataSource
from config.api import Stage
from config.api import RuleOutput
from config.api import S3Location


from modules.utils.loaders import Loader

from modules.s3client import S3Client
from modules.logger import MinIOLogger
from config.env import environ
from config.argo import ArgoStatusCodes
from modules.utils.schema import tuplify

from modules.utils.uid import PipelineUID


def get_pipeline(data_source: DataSource, pipeline_name: str) -> BasePipeline:
    """
    **Author(s)** Collin Brown - `collin.brown@canada.ca`

    **Created On:** February, 2021

    **Description:**

    Given command line arguments parsed, returns the appropriate handler function for
    a given data source.

    Examples:

    ```python
    Pipeline = get_pipeline(datasource, args.pipeline_class)
    ```

    Args:
        data_source:
            One of the data sources that is collected by the Frontier Counts program.
            Valid Values: Any values from the config.api.DataSource enumerator.
        pipeline_name:
            The name of the pipeline being run for a given data source.
            Valid Values:
                - PipelineRawClean
                - PipelineCleanTransformed
                - PipelineTransformedAggregated
                - PipelineAggregated

    Returns:
        modules.pipeline.BasePipeline:
            A pipeline class that extends modules.pipeline.BasePipeline
            Valid Values: Any of the pipeline classes defined in the datasource folder.
    """
    # Assume some kind of standard naming convention so that new handlers
    # can be imported dynamically.
    pipeline_module = importlib.import_module(
        f"datasource.{data_source.value}.pipeline"
    )
    return getattr(pipeline_module, pipeline_name)


def get_pipelines(datasource: DataSource) -> List:
    """
    **Author(s)** Collin Brown - `collin.brown@canada.ca`

    **Created On:** February, 2021

    **Description:**

    Gets all pipelines that are available for a given data source.

    Examples:

    ```
    pipelines = get_pipelines(DataSource.ipil_hwy)
    ```

    Args:
        datasource:
            The data source for which we want to get available pipelines.
            **Valid Values:** Any enum value of config.api.DataSource

    Returns:
        List[str]:
            List of strings containing pipeline names for the data source.

            **Valid Values:** Any of PipelineRawClean, PipelineCleanTransformed, etc.
    """
    try:
        pipeline_module = importlib.import_module(
            f"datasource.{datasource.value}.pipeline"
        )
        return [
            (name, cls)
            for name, cls in pipeline_module.__dict__.items()
            if isinstance(cls, type)
            and issubclass(cls, BasePipeline)
            and cls != BasePipeline
        ]
    except ModuleNotFoundError:
        pass
    return []


def validation_writer(
    validation_df: pd.DataFrame,
    func: Callable,
    datasource: DataSource,
    date: datetime.date,
) -> RuleOutput:
    """
    **Author(s)** Collin Brown - `collin.brown@canada.ca`

    **Created On:** February, 2021

    **Description:**

    The wrapper function that wraps a validation so that it can be called in a data processing
    pipeline.

    Examples:
        ```
         # ...
         df = (
            df.pipe(
                validation_wrapper,
                ipil_hwy_v200
                DataSource.ipil_hwy,
                self.date
            )
            .pipe(
            # ...
        ```

    Args:
        df:
            A pandas dataframe containing input data to a validation.
        func:
            The function that implements a given validation.
        datasource:
            The data source that this validation belongs to. Valid Values are any enum value in
            config.api.DataSource.
        date:
            The date of the data being processed. Valid Values are any date between January 1, 1970
            and the present.

    Returns:
        RuleOutput.output:
            The output of a validation. Valid Values are anything that is wrapped by
            `config.api.RuleOutput.output`
    """
    minio_logger = MinIOLogger.get_logger()
    # Add validation_name column to identify the validation
    if validation_df is not None:
        if len(validation_df):
            validation_df.loc[:, "validation_name"] = func.__name__
            validation_df.loc[:, "pipeline_uid"] = PipelineUID.get_uid()
            validation_df.loc[:, "datasource"] = datasource.value
            minio_logger.log_pandas(validation_df, datasource, func.__name__, date)
    return validation_df


@dataclass
class PipelineInput(object):
    """
    **Author(s):**

    - Collin Brown - `collin.brown@canada.ca`

    - Andrés Solis Montero - `andres.solismontero@canada.ca`

    **Created On:** February 2021

    **Description:**

    An abstraction over inputs to the data processing pipeline.
    As long as the required fields are present, `PipelineInput`
    handles the details of importing/loading the required input.

    There is a `load` factory method, or the constructor can be called
    directly with
    `PipelineInput(stage=stage, datasource=datasource, basename=basename)`.

    Attributes:
        data: a Pandas DataFrame that contains the input data itself.
        stage: a value of the Stage enumerator specifying to which stage
        the data belong.
        datasource: a value of the DataSource enumerator specifying which
        datasource the PipelineInput instance represents.
        basename: An optional string indicating the basename of the datasource
        being represented by the PipelineInput instance.
    """

    data: pd.DataFrame = None
    stage: Stage = None
    datasource: DataSource = None
    basename: Optional[str] = None

    def data_import(self):
        # Note that the PipelineInput.load method will set basename=None if it is a file-based
        # data source, so we can use Loader.get() as intended.
        self.data = Loader.get(self.stage, self.datasource, self.basename)

    @classmethod
    def load(cls, dep: "tuplify", year: int, month: int, day: int) -> "PipelineInput":
        """
        Given a input dependency (instance of Tuplify), loads the data from
        MinIO.
        """
        # Get the stage/datasource from the configuration
        stage = Stage[dep.stage.upper()]
        datasource = DataSource[dep.datasource]
        # Get the basename for the data source - if it is time-based, keep the name; if it is
        # file-based, set it to None (Loader.get() will infer the file-based name from the
        # DataSource automatically).
        basename = S3.get_s3_basename(
            stage, datasource, str(year), str(month), str(day)
        )
        return PipelineInput(stage=stage, datasource=datasource, basename=basename)


@dataclass
class PipelineOutput(object):
    """
    **Author(s)**

    - Collin Brown - `collin.brown@canada.ca`

    - Andrés Solis Montero - `andres.solismontero@canada.ca`

    **Created On:** February, 2021

    **Description:**

    A wrapper for output from a data processing pipeline. All outputs from a data processing
    pipeline are added as instances of PipelineOutput. The `export` method
    of PipelineOutput instances is used to export the given data to the
    appropriate location in MinIO.

    Attributes:
        data: a Pandas DataFrame that contains the output data itself.
        stage: a value of the Stage enumerator specifying to which stage
               the data belong.
        datasource: a value of the DataSource enumerator specifying which
                    datasource the PipelineOutput instance represents.
        basename: A string indicating the basename of the datasource
                  being represented by the PipelineOutput instance.
        fallback_on_conflicts: An optional flag indicating that the
            MinIO client should create a conflict if another file with the same
            stage, data source, year, and month already exists.
        fallback_on_historical: An optional flag indicating that the
            MinIO client should create an archived historical version of the
            existing file if a file with the same stage, data source, year, and
            month already exists.
    """

    data: pd.DataFrame = None
    stage: Stage = None
    datasource: DataSource = None
    basename: str = None
    fallback_on_conflicts: Optional[bool] = True
    fallback_on_historical: Optional[bool] = False

    def export(self):
        if environ().FC_USE_MOCK_MINIO:
            # donot need minio connection in testing mode
            return

        # Create instance of minio standard client
        minio_client = S3Client.get_client()
        # Write dataframe to specified s3 storage location
        return minio_client.upload_df_to_stage(
            df=self.data,
            stage=self.stage,
            datasource=self.datasource,
            basename=self.basename,
            fallback_on_conflicts=self.fallback_on_conflicts,
            fallback_on_historical=self.fallback_on_historical,
        )


class BasePipeline:
    """
    Base pipeline implementation. All Pipelines in the Frontier Counts system extend `BasePipeline`.

    Pipelines adhere to the naming convention `Pipeline<Before-stage><After-stage>` in Pascal case.
    For example, `PipelineRawClean` or `PipelineCleanTransformed` could respectively indicate that
    the pipeline sits between the **RAW** and **CLEAN** stages of processing. One exception to this
    naming convention is the case of the **AGGREGATED** stage where there are pipelines that process
    **AGGREGATED** data into more **AGGREGATED** data. In such cases, we adopt the convention
    `PipelineAggregated`, where it is implied that the before-stage **and** after-stage are both
    **AGGREGATED**.

    Pipelines are scoped to a data source based on their location in the `datasource` module. For
    example, in the module `datasource.ipil_hwy.pipeline`, the `PipelineRawClean` class is scoped
    to the `ipil_hwy` data source. When the `get_pipeline` function (defined earlier in this module)
    is called, the user must specify both a **datasource** and a **pipeline-name** which uniquely
    identify a given pipeline. For example, `get_pipeline(DataSource.ipil_hwy, "PipelineRawClean")`
    uniquely identifies the pipeline for the `ipil_hwy` data source that sits between the
    **RAW** and **CLEAN** stages of processing.

    Developers are expected to define the `pipeline` method in the child class that extends
    `BasePipeline`, and optionally the `dependency_check` method if they wish to use this
    feature. Most pipelines in the system at the time of writing only specify the `pipeline` method.

    The `pipeline` method should contain all of the necessary logic to load whatever data sources
    are needed, run any business rules and validations on the input(s), and create a dictionary of
    pipeline outputs that will be exported using the `export` instance method of `BasePipeline`.

    Attributes:
        datasource: a value of the DataSource enumerator specifying which
                    datasource the PipelineOutput instance represents.
        outputs: `Dict[DataSource, PipelineOutput]`, A dictionary where keys are values of the `DataSource` enumerator and values
            are instances of `PipelineOutput`. The `outputs` dictionary is declared at the end of
            the `pipeline` method in the child class that extends `BasePipeline`. Immediately after the
            `pipeline` instance method runs, the `export` instance method runs, which automatically
            writes the values specified in the `outputs` dictionary to MinIO.
        date: The date of the data that the pipeline is processing.
        year: The year of the data being processed (parsed from the `date` instance attribute)
        month: The month of the data being processed (parsed from the `date` instance attribute)
        day: The day of the data being processed (parsed from the `date` instance attribute)
        reference_year: An optional year indicating which year should be used for the reference distribution.
            Note that this argument is only required if the pipeline in question performs any imputation
            of missing values using historical data. By default this argument is `None`.
    """

    def __init__(
        self,
        datasource: DataSource,
        date: datetime.datetime.date,
        reference_year: int = None,
        force: bool = False,
    ):
        self.outputs = {}
        self.datasource: DataSource = datasource
        # Extract date information
        self.date: datetime.datetime = date
        self.year: int = date.year
        self.month: int = date.month
        self.day: int = date.day
        self.reference_year: int = reference_year
        self.force: bool = force

    @classmethod
    def get_available_pipelines(cls, datasource):
        importlib.import_module(f"datasource.{datasource}.pipeline")
        members = [cls.__name__ for cls in BasePipeline.__subclasses__()]
        return members

    def export(self):
        """
        Export every output value specified in outputs.
        """
        # We want to flag if any output file creates a conflict. If a conflict
        # is created, then trigger the appropriate exit code before terminating
        # the process.
        outputs = []
        for datasource in self.outputs.keys():
            outputs.append(self.outputs[datasource].export())
        for output in outputs:
            # This only applies if we are not in test mode (in test mode output is None)
            if output:
                if "conflicts" in output.prefix:
                    ArgoStatusCodes.exit_conflict()

    def run(self):
        """
        Runs the custom `pipeline` method that the user defined, and exports any outputs the user
        specified. Also performs automated dependency checks if any dependencies are specified.
        """
        self.get_dependencies()
        if not self.dependencies_exist():
            if environ().FC_VERBOSE:
                print(
                    f"At least one dependency for {self.date.strftime('%Y-%m-%d')} doesn't exist."
                )
            return
        if not self.force and self.outputs_exist() and not self.dependency_change():
            if environ().FC_VERBOSE:
                print(
                    f"No dependency change for {self.date.strftime('%Y-%m-%d')}, no need to run."
                )
            return
        self.pipeline()
        self.export()

    def pipeline(self):
        """
        Specific implementation for a given stage for a given data source.
        Should be overridden by child class.
        """

    def dependencies_exist(self) -> bool:
        """
        Returns True if all dependencies exist and False otherwise.
        """
        minio_client = S3Client.get_client()
        return minio_client.locs_exist(self.deps)

    def outputs_exist(self) -> bool:
        """
        Returns True if all dependencies exist and False otherwise.
        """
        minio_client = S3Client.get_client()
        return minio_client.locs_exist(self.output_locs)

    def dependency_change(self) -> bool:
        """
        Uses self.dependency_check to get the s3locations for dependencies and outputs of the
        computation (overridden by child class), then returns True if there is a dependency
        change and False otherwise.
        """
        minio_client = S3Client.get_client()
        return minio_client.dependency_change(self.deps, self.output_locs)

    def get_dependencies(self):
        deps, outputs = self.dependency_check()
        self.deps = deps
        self.output_locs = outputs

    def dependency_check(self) -> Tuple[List[S3Location], List[S3Location]]:
        """
        Child class extends this method and checks dependencies to see if any dependencies have
        been updated.

        If max(tuple[0]) > min(tuple[1]) then need to redo the computation, else not.
        """
        return [], []
