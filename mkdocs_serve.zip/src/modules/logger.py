"""
**Author(s)**

- Collin Brown - `collin.brown@canada.ca`
- Andrés Solis Montero - `andres.solismontero@canada.ca`
- Jeffery Zhang - `jeffery.zhang@canada.ca`

**Created On:** January, 2021

A module for the MinIO validation logger
"""
import os
import datetime
import io

from typing import Union
from config.api import DataSource
from config.env import environ

from pandas import DataFrame
from modules.s3client import S3Client

from modules.utils.uid import PipelineUID
from config.api import S3Location
from config.api import Stage

class TestMinIOLogger(object):
    """
    A test logger that can be used when running the test suite.
    """

    def log_pandas(self, df: DataFrame, datasource: DataSource, validation_name: str, date: datetime.date):
        pass


class MinIOLogger:
    """
    A logger that writes validation dataframes to minio locations
    """

    @classmethod
    def get_logger(cls, *args, **kwargs) -> Union["MinIOLogger", TestMinIOLogger]:
        """
        Returns either the real MinIO logger or the test MinIO logger depending
        on whether we are in the test or real environment.
        """
        if environ().FC_USE_MOCK_MINIO:
            return TestMinIOLogger(*args, **kwargs)
        return MinIOLogger(*args, **kwargs)

    def log_pandas(
        self, df: DataFrame, datasource: DataSource, validation_name: str, date: datetime.date
    ):
        """
        Logs a validation dataframe to a particular s3 location
        """
        # Get S3 Basename as pipeline UID timestamp
        basename = f"{PipelineUID.get_uid()}.csv"
        # Generate S3 prefix
        prefix = os.path.join(Stage.VALIDATION.name.lower(), datasource.value, validation_name, str(date.year), str(date.month))
        loc = S3Location(Stage.VALIDATION.value.bucket, prefix, basename)
        # Get s3 client
        client = S3Client.get_client()
        # Write dataframe to I/O buffer
        # Get CSV buffer for df
        CSV_bytes = df.to_csv(index=False).encode("utf-8")
        CSV_buffer = io.BytesIO(CSV_bytes)
        # Put file to S3 Location
        client.put_loc(
            loc,
            CSV_buffer,
            len(CSV_bytes),
            content_type="application/csv"
        )
