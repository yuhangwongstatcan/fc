"""
Some utilities to configure the CLI argument parser.
"""
import datetime
from typing import List
from argparse import ArgumentParser


def get_parser(data_sources: List) -> ArgumentParser:
    """
    Returns an instance of ArgumentParser that is configured to accept command
    line arguments for the Frontier Counts data source pipelines.

    Args:
        data_sources:
            A python list containing the data sources that should be picked up
            by the parser.
    Returns: A configured instance of ArgumentParser.
    """
    # Create instance of ArgumentParser
    pipeline_parser = ArgumentParser(
        prog="run_pipeline", description="Runs the pipeline for a specified data source"
    )
    # Configure pipeline_parser to accept data source argument.
    valid_sources = ", ".join([f"{source}" for source in data_sources])
    pipeline_parser.add_argument(
        "--data-source",
        required=True,
        help=f"Name of data source. One of the following: {valid_sources}",
    )
    # Add pipeline name - TODO: maybe implement a function to import all
    # classes that extend BaseClass and list their names.
    pipeline_parser.add_argument(
        "--pipeline-class", required=True, help="Name of pipeline class to use"
    )
    # Accepts date argument
    pipeline_parser.add_argument(
        "--date",
        type=datetime.date.fromisoformat,
        help="A date of the form YYYY-MM-DD (e.g. 2020-12-22)",
    )
    # Flag to force pipeline run
    pipeline_parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        default=False,
        help="Indicates whether the resulting pipeline run should be forced.",
    )
    # Flag to indicate whether the arg parser should go to persistent storage
    # or to "exclusion" storage - TODO: we might just delete this - leaving as
    # an option so that we can use the CLI in 'dev' or 'test' mode.
    pipeline_parser.add_argument(
        "--production",
        "-p",
        action="store_true",
        default=True,
        help="Indicates whether the resulting pipeline data are for production",
    )

    pipeline_parser.add_argument(
        "--reference_year",
        "-ry",
        type=int,
        help="Reference Year for Manual Entry",
    )

    return pipeline_parser
