"""
Utilities to help with validation/business rules for data sources.

Collin Brown (collin.brown@canada.ca)
Feb 22, 2021
"""
import pandas as pd
import pandera as pa
from config.api import DataSource, Stage
from modules.utils.loaders import Loader

from typing import List

from datasource.ports.schema import ReferenceSchema as PortsSchema


def sort_aggregated_tables(
    df: pd.DataFrame, schema: pa.SchemaModel, column_list: List
) -> pd.DataFrame:
    """Sorts an aggregated table along the schema columns.

    Args:
        df (pd.DataFrame): [description]
        schema (Schema): [description]
    """
    # Force every column to type Int64 for the sorting so they
    # sort in numeric rather than lexicographic order. If a column
    # cannot be converted to Int64, then skip it and let it sort in
    # lexicographic order.
    for col in list(schema.to_schema().columns.keys()):
        try:
            df[col] = pd.to_numeric(df[col]).astype("Int64")
        except ValueError as e:
            print(f"Cannot convert {col} to type Int64, skipping")

    # Sort in order along every column
    df = df.sort_values(column_list)

    # Ensure that the output file adheres to the correct schema
    df = schema(df)

    return df


def aggregate_statcan_tables(
    df: pd.DataFrame, schema: pa.SchemaModel, column_list: List
) -> pd.DataFrame:
    """
    Applies the aggregation logic for the vehicles/travellers tables. This
    logic is placed in a single function outside of both vehicles/travellers
    data sources to avoid duplication of similar code.

    Args:
        df:
        ports:
        datasource:
        business_rule_no:
        schema_kind:

    Returns:
        A pandas dataframe that has applied the appropriate aggregation logic.
    """
    # Read in the ports file
    ports = Loader.get(Stage.REFERENCE, DataSource.ports, None)
    ports = PortsSchema(ports)

    # Replace censored ports with their corresponding published ports.
    df = pd.merge(
        left=df,
        right=ports[[PortsSchema.port, PortsSchema.published_port]],
        on=[PortsSchema.port],
        how="left",
    )
    df = df.drop(columns=[PortsSchema.port])
    df = df.rename(columns={PortsSchema.published_port: PortsSchema.port})

    # Group by all remaining columns
    columns_to_remove = [schema.count_of_entries]
    # Define group by columns
    groupby_columns = [col for col in column_list if col not in columns_to_remove]

    # Perform the groupby and return dataframe
    return df.groupby(by=groupby_columns, dropna=False).sum().reset_index()
