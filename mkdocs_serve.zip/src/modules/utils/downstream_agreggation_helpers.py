from __future__ import print_function


import numpy as np

# from modules.utils.loaders import Loader
# from modules.utils.uid import PipelineUID

# from modules.utils.data_manipulation import explode

# from config.api import Stage
# from config.api import DataSource
# from config.api import S3
# from config.api import Dimension

from reportlab.pdfgen import canvas

point = 1
inch = 72

TEXT = """%s                                                      page %d of %d



Commercial Aircraft

1.1 Non-resident vistors by commmercial aircraft"""

def make_pdf_file(output_filename, np):
    title = "Specs for Validation - Leading Indicator"
    c = canvas.Canvas(output_filename, pagesize=(8.5 * inch, 11 * inch))
    c.setStrokeColorRGB(0,0,0)
    c.setFillColorRGB(0,0,0)
    c.setFont("Helvetica", 12 * point)
    for pn in range(1, np + 1):
        v = 10 * inch
        for subtline in (TEXT % (title, pn, np)).split( '\n' ):
            c.drawString( 1 * inch, v, subtline )
            v -= 12 * point
        c.showPage()
    c.save()

if __name__ == "__main__":
    nps = [None, 5, 11, 17]
    for i, np in enumerate(nps):
        if np:
            filename = "simple%d.pdf" % i
            make_pdf_file(filename, np)
            print ("Wrote", filename)