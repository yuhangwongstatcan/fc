import logging

import datetime
from typing import List
from typing import Tuple

import numpy as np
import pandas as pd
import pandera as pa

from modules.utils.loaders import Loader

from config.api import Stage, DataSource
from config.api import CURRENT_YEAR_THRESHOLD, PREV_YEAR_THRESHOLD


from datasource.common.dim import (
    DAY,
    MODE,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
    PLATE_REGION,
    DATA_SOURCE,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    COUNTRY_OF_RESIDENCE,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
)

from datasource.manual_entry_vehicles.schema import (
    RawSchema as ManualEntryVehiclesSchema,
)
from datasource.manual_entry_travellers.schema import (
    RawSchema as ManualEntryTravellersSchema,
    GREEN_COLUMNS,
)

from datasource.vehicles.schema import TransformedSchema as VehiclesSchema
from datasource.travellers.schema import TransformedSchema as TravellersSchema
from datasource.countries.schema import ReferenceSchema as CountriesSchema

logging.basicConfig(level=logging.INFO)

"""

def impute_number_travellers(
    df: pd.DataFrame, travellers_prev: pd.DataFrame
) -> pd.DataFrame:
    vehicles_schema = load_datasource_schema(
        DataSource.manual_entry_vehicles, Stage.RAW
    )
    if df.shape[1] > len(vehicles_schema.COLUMNS):
        schema = load_datasource_schema(
            DataSource.manual_entry_travellers, Stage.RAW
        )
    else:
        schema = vehicles_schema
    # For all rows where count of entries is null, we want to use year t-p of the same month and
    # take average grouped by all available properties.
    for idx, row in df.loc[df[schema.count_of_entries.name].isnull(), :].iterrows():
        # Get the condition to get the appropriate subset of travellers
        condition = get_impute_number_subset(
            row, exclude=[schema.year.name, schema.count_of_entries.name]
        )
        cond_mask = travellers_prev.eval(condition)
        if travellers_prev[cond_mask].empty:
            continue
        # Get the subset of vehicles and get the average value of this subset
        # travellers_prev[cond_mask]["count_of_entries"]
        # df.iloc[idx, ""] DO WE NEED THIS LINE?
        row[schema.count_of_entries.name] = math.floor(
            float(travellers_prev.loc[cond_mask, schema.count_of_entries.name].mean())
        )
        df.iloc[idx, df.columns.get_loc(schema.count_of_entries.name)] = row[
            schema.count_of_entries.name
        ]
    return df
"""


def get_impute_number_subset(row: pd.Series, exclude=[]) -> str:
    conditions = []
    for col in row.index:
        if pd.isna(row[col]):
            continue
        if col not in exclude:
            if isinstance(row[col], str):
                conditions.append(f"{col} == '{row[col]}'")
            else:
                conditions.append(f"{col} == {row[col]}")
    return " & ".join(conditions)


def fixed_proportion_imputation(
    df: pd.DataFrame,
    fixed_proportion_rules: pd.DataFrame,
    fixed_proportions: pd.DataFrame,
    schema: pa.SchemaModel,
    fixed_schema: pa.SchemaModel,
    rules_schema: pa.SchemaModel,
) -> pd.DataFrame:
    """
    **Description:**

    Checks for and applies the fixed proportion rules that apply to rows in the input manual entry dataframe

    Args:

    Returns:
        A dataframe with imputed rows via fixed proportions rules
    """

    # Apply fixed proportions imputations to the current data frame
    for _, row in fixed_proportion_rules.iterrows():
        # Keep track of the original count of entries in `row`, this will be used later in the
        # program to ensure rounding preserves the original total
        # Check if the rule is valid (i.e. the date of the current data falls inside the range
        # of dates in which this rule applies).

        # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM
        # idx = idx
        # if (idx <= 0):
        #    print(idx)
        # print(row[idx])
        # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM

        date = (
            df.iloc[0][schema.year]
            + "-"
            + f"{int(df.iloc[0][schema.month]):02d}"
            + "-01"
        )
        if not is_valid_rule(row, date, rules_schema):
            continue
        # Get the condition to generate a subset of the data frame
        if row[schema.data_source] == "all":
            condition, _ = get_subset_query(schema, row, counter=3)
        else:
            condition, _ = get_subset_query(schema, row, counter=0)

        # Note that datasource is not one of the green columns, so if a fixed rule applies
        # to a specific data source, then we need to add that condition specifically to
        # the condition.
        if row[schema.data_source] != "all":
            condition = (
                f"{condition} & {schema.data_source} == '{row[schema.data_source]}'"
            )
        # Add the condition that the current row's imputation column must be pd.NA,
        # otherwise there is no need to impute it.
        CURRENT_COLUMN = row[rules_schema.fixed_prop_variable]
        cond_mask = df.eval(condition) & df[CURRENT_COLUMN].isin(
            [
                np.nan,
                pd.NA,
                VEHICLE_TYPE.air_unknown.value,
                VEHICLE_TYPE.land_unknown.value,
                VEHICLE_TYPE.water_unknown.value,
                COUNTRY_OF_RESIDENCE.overseas.value,
            ]
        )
        # Skip if there are no rows that the fixed proportion rule applies to
        if df[cond_mask].empty:
            continue
        # If there are any rows that the fixed proportion rule applies to, apply it and split
        # the rows into multiple.
        prop_df = pd.merge(
            pd.DataFrame(data=[row.values], columns=row.index),
            fixed_proportions,
            left_on=rules_schema.rule_id,
            right_on=fixed_schema.rule_id,
        )
        # Drop proportions with value 0.00 since they are not allocated any count
        prop_df = prop_df[prop_df[fixed_schema.proportion] > 0]
        # For each row that satisfies the condition, we need to consider those rows in isolation
        # to avoid rounding errors.
        df_cond_rows = []
        for _, df_row in df[cond_mask].iterrows():
            # for df_row in df[cond_mask].iterrows():
            # Assign the values that each new row will take on for the fixed proportion column.
            df_row = pd.DataFrame(data=[df_row.values], columns=df_row.index)
            # Note #1: certain rows of prop_df will have the special value of `all`. If this
            # happens, then don't include that column as a merge condition.

            # Note #2: since we merge one row on fixed_proportions (1:N merge), every row
            # should have an identical value for any given column.

            # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM
            # ix = ix
            # if (ix <= 0):
            #    print(ix)
            # print(df_row[ix])
            # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM

            if df_row.shape[1] > len(
                list(ManualEntryVehiclesSchema.to_schema().columns.keys())
            ):
                MERGE_ON_COLUMNS = [
                    col
                    for col in [
                        schema.vehicle_type,
                        schema.country_of_residence,
                        schema.data_source,
                        schema.port,
                        schema.plate_country,
                        schema.arriving_from,
                        schema.purpose4,
                        schema.duration2,
                    ]
                    if not (prop_df[col] == "all").any()
                ]

                MERGE_ON_COLUMNS = [
                    col for col in MERGE_ON_COLUMNS if not prop_df[col].isna().any()
                ]

                df_row = pd.merge(
                    df_row,
                    prop_df[
                        [
                            schema.vehicle_type,
                            schema.country_of_residence,
                            schema.data_source,
                            schema.port,
                            schema.plate_country,
                            schema.arriving_from,
                            schema.purpose4,
                            schema.duration2,
                            fixed_schema.value,
                            fixed_schema.proportion,
                        ]
                    ],
                    on=MERGE_ON_COLUMNS,
                    how="left",
                    suffixes=(None, "_y"),
                )
            else:
                MERGE_ON_COLUMNS = [
                    col
                    for col in [
                        schema.vehicle_type,
                        schema.data_source,
                        schema.port,
                        schema.plate_country,
                    ]
                    if not (prop_df[col] == "all").any()
                ]

                MERGE_ON_COLUMNS = [
                    col for col in MERGE_ON_COLUMNS if not prop_df[col].isna().any()
                ]

                df_row = pd.merge(
                    df_row,
                    prop_df[
                        [
                            schema.vehicle_type,
                            schema.data_source,
                            schema.port,
                            schema.plate_country,
                            fixed_schema.value,
                            fixed_schema.proportion,
                        ]
                    ],
                    on=MERGE_ON_COLUMNS,
                    how="left",
                    suffixes=(None, "_y"),
                )
            # Since there was a left join, we need to REEVALUATE this condition as the number of
            # rows have changed.
            new_cond_mask = df_row.eval(condition) & df_row[CURRENT_COLUMN].isin(
                [
                    np.nan,
                    pd.NA,
                    VEHICLE_TYPE.air_unknown.value,
                    VEHICLE_TYPE.land_unknown.value,
                    VEHICLE_TYPE.water_unknown.value,
                    COUNTRY_OF_RESIDENCE.overseas.value,
                ]
            )
            # Get the fixed proportion column that we are applying the current fixed proportion rule to
            prop_df = prop_df.reset_index(drop=True)
            FIXED_PROP_COLUMN = prop_df.loc[0, rules_schema.fixed_prop_variable]
            df_row.loc[new_cond_mask, FIXED_PROP_COLUMN] = df_row.loc[
                new_cond_mask, fixed_schema.value
            ]
            # Get the first row of count of entries before we apply any rounding - this will be
            # used in the rounding calculation to ensure the sum of rounded totals equals the
            # original total.

            # Updated Feb.,2024: with the previous adjustment, the Nth entry could get negative value due to 
            # compounded rounding imperfections. To avoid negative numbers and forces the sum to match according 
            # to the imputation rules, we adjust the difference between the original total and 
            # the sum of rounded totals on the row with maximum entry number instead.
            BEFORE_ROUNDING_TOTAL = (
                df_row[new_cond_mask].head(1)[schema.count_of_entries].squeeze()
            )
            df_row.loc[new_cond_mask, schema.count_of_entries] = np.round(
                df_row[new_cond_mask][schema.count_of_entries]
                * df_row[new_cond_mask][fixed_schema.proportion]
            )
            # Ensure that rounding preserves original total
            if len(df_row[new_cond_mask]) > 1:
                diff = BEFORE_ROUNDING_TOTAL - df_row.loc[new_cond_mask,schema.count_of_entries].sum()
                if diff != 0:
                    idx_max = df_row.loc[new_cond_mask,schema.count_of_entries].idxmax()
                    df_row.loc[idx_max, schema.count_of_entries] = df_row.loc[idx_max, schema.count_of_entries] + diff

                # df_row.loc[
                #     df_row.index == df_row[new_cond_mask].index[-1],
                #     schema.count_of_entries,
                # ] = (
                #     BEFORE_ROUNDING_TOTAL
                #     - df_row.loc[
                #         df_row[new_cond_mask].index[:-1], schema.count_of_entries,
                #     ].sum()
                # )
            df_row = df_row[list(schema.to_schema().columns.keys())]
            df_cond_rows.append(df_row)
        # Once all of the imputation + rounding has completed, concatenate all of the
        # imputed rows together, and replace the unimputed rows with the imputed rows.
        df_cond_rows = pd.concat(df_cond_rows)
        df = df.loc[~cond_mask]
        df = pd.concat([df, df_cond_rows])
        df[schema.count_of_entries] = df[schema.count_of_entries].astype("Int64")

    return df


def is_valid_rule(
    row: pd.Series, date: datetime.date, rules_schema: pa.SchemaModel
) -> bool:
    """
    **Description:**

    Checks if the rule applies to the current data.

    Args:
        row: pd.Series
            [description]. Valid Values are [values]
        date: datetime.date
            [description]. Valid Values are [values]

    Returns:
        bool:
            [description]. Valid Values are [values]
    """
    valid_from = datetime.datetime.strptime(
        row[rules_schema.valid_from], "%Y-%m-%d"
    ).date()
    valid_to = datetime.datetime.strptime(row[rules_schema.valid_to], "%Y-%m-%d").date()
    date = pd.to_datetime(date)
    # The date should be within the range of [valid_from, valid_to]
    return True if date >= valid_from and date <= valid_to else False


def get_subset_query(schema, row: pd.Series, counter: int) -> Tuple[str, List]:
    """
    **Description:**

    Given a row with conditions, creates a query string that can be used with pd.DataFrame.query

    Args:
        row: pd.Series
            [description]. Valid Values are [values]

    Returns:
        str:
            [description]. Valid Values are [values]
    """
    green_columns = GREEN_COLUMNS
    # Since vehicles_schema has a subset of columns of travellers_schema, we
    # only want to keep the green columns that exist in the vehicles table.
    base_columns = [
        col for col in green_columns if col in list(schema.to_schema().columns.keys())
    ]
    if counter == 0:
        CONDITION_COLUMNS = base_columns + [schema.port]
    if counter == 1:
        CONDITION_COLUMNS = base_columns + ["province"]
    if counter == 2:
        # get rid of province/port altogether and take historical data from all of
        # Canada but with matching green column values (is this right?)
        CONDITION_COLUMNS = base_columns
    if counter == 3:
        if schema.data_source in base_columns:
            # This condition is just for fixed proportions where sometimes matching on
            # data source is not needed
            base_columns.remove(schema.data_source)
        CONDITION_COLUMNS = base_columns + [schema.port]
    return get_eval_string(row, CONDITION_COLUMNS)


def get_eval_string(row: pd.Series, condition_columns: List) -> Tuple[str, List]:
    conditions = []
    # For non-NaN columns, add the condition as a query string
    for col in condition_columns:
        # If the row is NA or the value is 'all', we need not include it in the
        # condition. This is because NA values need to be imputed (and should
        # not impose a restriction). Similarly, 'all' values apply to any value
        # that a particular column could take on, so there is no need to make
        # this a restriction.
        if pd.isna(row[col]) or row[col] == "all":
            continue
        # Assuming that anytime a string starts with a square bracket ([), the following string is meant to be a list
        if str(row[col])[0] == "[":
            cond = f"{col}.isin({row[col]})"
        elif isinstance(row[col], str):
            cond = f"{col} == '{row[col]}'"
        else:
            cond = f"{col} == {row[col]}"
        conditions.append(cond)
    return " & ".join(conditions), condition_columns


def apply_proportions(
    df: pd.DataFrame,
    columns_to_impute: list,
    row: pd.Series,
    proportions: pd.DataFrame,
    schema: pa.SchemaModel,
) -> pd.DataFrame:
    """
    def apply_proportions(
        df: pd.DataFrame,
        columns_to_impute: list,
        row: pd.Series,
        #ix: int,
        proportions: pd.DataFrame,
        #condition: str,
    ) -> pd.DataFrame:

    **Description:**

    Given a proprtions df, splits row into multiple, and returns imputed rows appended
    to original df. Called by impute_unfilled_columns helper function

    Args:

    Returns:
        A dataframe with imputed values for empty columns in row
    """

    # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM
    # condition = condition
    # ix = ix
    # condition = ix
    # ix = int(condition)
    # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM

    columns_to_impute.remove(schema.count_of_entries)
    columns = columns_to_impute
    proportions = proportions.groupby(by=columns, dropna=False, as_index=False)
    proportions = proportions[[schema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    proportions["probability"] = proportions[schema.count_of_entries] / int(
        proportions[schema.count_of_entries].sum()
    )
    
    # Drop proportions with 0.00 or negative values since they are not allocated true count
    proportions = proportions[proportions["probability"] > 0].reset_index(drop=True)
    
    df_new = pd.merge(row.to_frame().T, proportions, on=columns_to_impute, how="outer")
    df_new = df_new.ffill()
    df_new[schema.count_of_entries] = np.round(
        df_new["count_of_entries_x"] * df_new["probability"]
    )
    # Drop the row where count of entries is null (i.e. the original record whose
    # counts we are distributing according to `probability`) AND drop all rows
    # who receive a count of zero after rounding.
    df_new = df_new[
        (~df_new[schema.count_of_entries].isnull())
        & (df_new[schema.count_of_entries] != 0)
    ]
    # After we get rid of the rows who have zero entries, we need to reset the index because all
    # rows that get zero imputed records will be dropped. Additionally, we need to consider the
    # .loc indexer at position `N-1` rather than position `N` because when we reset index, the
    # default range_index is applied which starts indexing at zero. Failure to do this correction
    # will result in a record being inserted that has every columns except `count_of_entries`
    # set equal to `pd.NA`, which will cause confusing downstream errors.
    df_new = df_new.reset_index(drop=True)
    # Round in such a way that N-1 entries have the standard np.round() policy applied, then the
    # Nth entry is equal to df.iloc[0, "count_of_entries_x"] - sum(df.iloc[0:n-1, "count_of_entries"])
    # where the first term is the original count and the latter term is the sum of every rounded record
    # except for the last record, which will be assigned the difference.
    # Note that we only apply this policy after we've dropped the record that's been imputed
    # and there is only a need to consider this case if the df_new table contains more than one row.
    
    # Updated Feb.,2024: with the previous adjustment, the Nth entry could get negative value due to 
    # compounded rounding imperfections. To avoid negative numbers and forces the sum to match according 
    # to the imputation rules, we adjust the difference between df.iloc[0, "count_of_entries_x"] and 
    # sum(df.iloc[0:n-1, "count_of_entries"]) on the row with maximum entry number instead. 
    if len(df_new) > 1:
        N = len(df_new)
        diff = df_new.loc[1]["count_of_entries_x"] - df_new.loc[: N - 1][schema.count_of_entries].sum()
        if diff!=0:
            idx_max = df_new[[schema.count_of_entries]].idxmax()
            df_new.loc[idx_max, schema.count_of_entries] = df_new.loc[idx_max, schema.count_of_entries] + diff
        # df_new.loc[N - 1, schema.count_of_entries] = (
        #     df_new.loc[1]["count_of_entries_x"]
        #     - df_new.loc[: N - 2][schema.count_of_entries].sum()
        # )
    # Note that province is not in schema.COLUMNS so we have to add it explicitly
    df_new = df_new[list(schema.to_schema().columns.keys()) + ["province"]]
    # Figure out which row was imputed using the following assumption:
    # (1) If every column of the current row equals every column in df OR if
    #     row != row & df != df (i.e. there are pd.NA values), OR
    # (2) One of the *99 special cases is found (e.g. vehicle_type == 199)
    # Then we found the row that got imputed, so we can remove it from df and
    # replace it with the imputed rows.
    ROW_EQUALS_DF = (row == df) | ((row != row) & (df != df))
    SPECIAL_CASE_VEHICLE_TYPE = df.isin(
        [
            VEHICLE_TYPE.air_unknown.value,
            VEHICLE_TYPE.land_unknown.value,
            VEHICLE_TYPE.water_unknown.value,
        ]
    )
    SPECIAL_CASE_COUNTRY_OF_RESIDENCE = df == COUNTRY_OF_RESIDENCE.overseas.value
    CURRENT_ROW = (
        ROW_EQUALS_DF | SPECIAL_CASE_VEHICLE_TYPE | SPECIAL_CASE_COUNTRY_OF_RESIDENCE
    ).all(1)
    df = df.loc[~CURRENT_ROW, :]
    df = df.append(df_new)
    return df.reset_index(drop=True)


def format_condition_edge_cases(condition: str,countries:pd.DataFrame) -> str:
    """
    Note that there are two edge cases that require substituting the
    condition string produced above. (1) The codes '199', '299', and '399'
    are interpreted as "conditional wildcards" for a certain vehicle type,
    and (2) The country code '99998' is interpreted as "any country that
    is not Canada or USA".

    This function applies the appropriate substitutions for these two edge
    cases so that the returned condition makes the appropriate query to
    the table containing the reference distribution. If this function isn't
    applied, then the query will contain something nonsensical such as

    `vehicle_type == '199'`

    which does not correspond to a real vehicle type (and the result will
    always be that no results can be used as imputation donors).

    **Example**

    "vehicle_type == '199'"

    is substituted with

    "(vehicle_type == '111' | vehicle_type == '112' | vehicle_type == '121')"
    """
    # Get the values that match each of the 'conditional wildcards'. The reason
    # for getting the values in this way is so that if dimensions are added or
    # removed in the future, the change will be picked up automatically by the
    # updated reference file.
    VALUES_199 = [
        val
        for val in VEHICLE_TYPE.list()
        if val.startswith(VEHICLE_TYPE.air_unknown.value[0])
    ]
    VALUES_299 = [
        val
        for val in VEHICLE_TYPE.list()
        if val.startswith(VEHICLE_TYPE.land_unknown.value[0])
    ]
    VALUES_399 = [
        val
        for val in VEHICLE_TYPE.list()
        if val.startswith(VEHICLE_TYPE.water_unknown.value[0])
    ]
    # In each case, if we encounter `vehicle_type == {VEHICLE_TYPE_XXX}`, we
    # want to substitute this expression for the equivalent chain of OR
    # expressions.
    TO_REPLACE_199 = f"vehicle_type == '{VEHICLE_TYPE.air_unknown.value}'"
    if TO_REPLACE_199 in condition:
        OR_CHAIN = " | ".join(f"vehicle_type == '{val}'" for val in VALUES_199)
        REPLACE_WITH = f"({OR_CHAIN})"
        condition = condition.replace(TO_REPLACE_199, REPLACE_WITH)
    TO_REPLACE_299 = f"vehicle_type == '{VEHICLE_TYPE.land_unknown.value}'"
    if TO_REPLACE_299 in condition:
        OR_CHAIN = " | ".join(f"vehicle_type == '{val}'" for val in VALUES_299)
        REPLACE_WITH = f"({OR_CHAIN})"
        condition = condition.replace(TO_REPLACE_299, REPLACE_WITH)
    TO_REPLACE_399 = f"vehicle_type == '{VEHICLE_TYPE.water_unknown.value}'"
    if TO_REPLACE_399 in condition:
        OR_CHAIN = " | ".join(f"vehicle_type == '{val}'" for val in VALUES_399)
        REPLACE_WITH = f"({OR_CHAIN})"
        condition = condition.replace(TO_REPLACE_399, REPLACE_WITH)

    # Need to replace "overseas" cases with "not canada and not usa".
    OVERSEAS_CODE = countries.loc[
        countries[CountriesSchema.country_name_en] == "Overseas",
        CountriesSchema.country_of_residence,
    ].squeeze()
    CANADA_CODE = countries.loc[
        countries[CountriesSchema.country_name_en] == "Canada",
        CountriesSchema.country_of_residence,
    ].squeeze()
    USA_CODE = countries.loc[
        countries[CountriesSchema.country_name_en] == "United States of America",
        CountriesSchema.country_of_residence,
    ].squeeze()
    OVERSEAS_CONDITION = f"country_of_residence == '{OVERSEAS_CODE}'"
    if OVERSEAS_CONDITION in condition:
        OR_CHAIN = " & ".join(
            f"country_of_residence != '{val}'" for val in [CANADA_CODE, USA_CODE]
        )
        REPLACE_WITH = f"({OR_CHAIN})"
        condition = condition.replace(OVERSEAS_CONDITION, REPLACE_WITH)
    return condition


def impute_unfilled_columns(
    df: pd.DataFrame,
    reference_current: pd.DataFrame,
    reference_previous: pd.DataFrame,
    schema: pa.SchemaModel,
    counter: int,
) -> pd.DataFrame:
    """
    **Description:**

    Imputes unfilled columns for every row in the input manual_entry dataframe.
    Throws an exception if imputation cannot be carried out.

    Args:

    Returns:
        A dataframe with imputed values for once empty columns
    """
    green_columns = GREEN_COLUMNS


    countries = Loader.get(Stage.REFERENCE, DataSource.countries, None)
    countries = CountriesSchema(countries)

    for _, row in df.iterrows():
        # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM
        # ix = ix
        # if (ix <= 0):
        #    print(ix)
        # print(row[ix])
        # SETTING THESE TO RESOLVED UNUSED VARIABLE PROBLEM

        # testvar = ix

        columns_to_impute = row.isna()[lambda x: x].index
        # Depending on the edge cases below, there may be 0, 1, or 2 extra
        # imputation columns required (vehicle_type, country_of_residence
        # or both).
        EXTRA_COLUMNS_TO_IMPUTE = []

        condition, condition_columns = get_subset_query(schema, row, counter)
        # There are some extra edge cases that need to be taken into account
        # for certain vehicle_type and country_of_residence values. See the
        # docstring of the function below for explanation.
        condition = format_condition_edge_cases(condition,countries)
        # Only travellers has country_of_residence so we only need to do the
        # logic below if we are doing a travellers imputation
        if df.shape[1] > len(
            list(ManualEntryVehiclesSchema.to_schema().columns.keys()) + ["province"]
        ):
            OVERSEAS_CODE = countries.loc[
                countries[CountriesSchema.country_name_en] == "Overseas",
                CountriesSchema.country_of_residence,
            ].squeeze()
            if (
                not pd.isna(row[schema.country_of_residence])
                and row[schema.country_of_residence] == OVERSEAS_CODE
            ):
                row[schema.country_of_residence] = pd.NA
                EXTRA_COLUMNS_TO_IMPUTE.append(schema.country_of_residence)
        if (
            row[schema.vehicle_type] == VEHICLE_TYPE.air_unknown.value
            or row[schema.vehicle_type] == VEHICLE_TYPE.land_unknown.value
            or row[schema.vehicle_type] == VEHICLE_TYPE.water_unknown.value
        ):
            row[schema.vehicle_type] = pd.NA
            EXTRA_COLUMNS_TO_IMPUTE.append(schema.vehicle_type)
        # The line below ensures that "red" columns that we dont want to impute, that may be present
        # in columns_to_impute, are not carried through for imputation
        columns_to_impute = (
            columns_to_impute[columns_to_impute.isin(condition_columns)].tolist()
            + [schema.count_of_entries]
            + EXTRA_COLUMNS_TO_IMPUTE
        )
        # If columns_to_impute has length 1 (i.e. only count_of_entries which
        # is *always* added to the list of columns to impute), then we skip
        # because there are no columns to impute for this row.
        if len(columns_to_impute) <= 1:
            continue
        c_t = reference_current[reference_current.eval(condition)][
            schema.count_of_entries
        ].sum()
        # if c_t == 0:
        #     continue
        c_delta = reference_previous[reference_previous.eval(condition)][
            schema.count_of_entries
        ].sum()
        # Note: the code below is intended to address the case where c_delta = 0; if this
        # happens, we should go to the first branch of the if logic below.
        prop = int(c_t) / int(c_delta) if c_delta != 0 else CURRENT_YEAR_THRESHOLD + 1
        if c_t == 0 and c_delta == 0:
            continue
        if prop > CURRENT_YEAR_THRESHOLD:
            proportions = reference_current[reference_current.eval(condition)][
                columns_to_impute
            ]
            df = apply_proportions(
                df,
                columns_to_impute,
                row,
                # ix,
                proportions,
                # , condition
                schema,
            )
        else:
            # calculate new prop - Note that we need to take the absolute value
            # for this because we could have a correction where we have negative travellers.
            num_travellers = abs(int(row[schema.count_of_entries]))
            new_prop = int(c_delta) / num_travellers
            if new_prop > PREV_YEAR_THRESHOLD:
                proportions = reference_previous[reference_previous.eval(condition)][
                    columns_to_impute
                ]
                df = apply_proportions(
                    df,
                    columns_to_impute,
                    row,
                    # ix,
                    proportions,
                    # , condition
                    schema,
                )
    # If there are any columns which are intended to be filled, that still need imputing, call the
    # function again but with the expanded imputation condition set by counter. If counter == 2,
    # there are no more conditions to expand to, so raise an exception. Also need to only check
    # the green columns that exist in the current table schema - for travellers this is all of them
    # but for vehicles it is only a subset.
    GREEN_COLUMNS_TO_CHECK = [
        col for col in green_columns if col in list(schema.to_schema().columns.keys())
    ]
    # Additionally, if `vehicle_type` is one of 199, 299, or 399 we need to make another recursive
    # call OR if `country_of_residence` is 99998 (the latter only applies to travellers).
    VEHICLE_TYPE_EDGE_CASE_MASK = df[schema.vehicle_type].isin(
        [
            VEHICLE_TYPE.air_unknown.value,
            VEHICLE_TYPE.land_unknown.value,
            VEHICLE_TYPE.water_unknown.value,
        ]
    )
    VEHICLE_TYPE_EDGE_CASE = VEHICLE_TYPE_EDGE_CASE_MASK.any()
    if "country_of_residence" in list(schema.to_schema().columns.keys()):
        OVERSEAS_CODE = countries.loc[
            countries[CountriesSchema.country_name_en] == "Overseas",
            CountriesSchema.country_of_residence,
        ].squeeze()
        COUNTRY_OF_RESIDENCE_EDGE_CASE_MASK = (
            df[schema.country_of_residence] == OVERSEAS_CODE
        )
        COUNTRY_OF_RESIDENCE_EDGE_CASE = (
            True if COUNTRY_OF_RESIDENCE_EDGE_CASE_MASK.any() else False
        )
    else:
        COUNTRY_OF_RESIDENCE_EDGE_CASE = False
    if (
        df[GREEN_COLUMNS_TO_CHECK].isna().any().any()
        or VEHICLE_TYPE_EDGE_CASE
        or COUNTRY_OF_RESIDENCE_EDGE_CASE
    ):
        if counter == 2:
            logging.info(
                """
                Information about the record(s) that caused the "bottom out" recursion case.
                """
            )
            if VEHICLE_TYPE_EDGE_CASE:
                logging.info(
                    f"""
VEHICLE TYPE EDGE CASE
=========================================
The vehicle_type edge case where `vehicle_type` is in
{[VEHICLE_TYPE.air_unknown.value, VEHICLE_TYPE.land_unknown.value, VEHICLE_TYPE.water_unknown.value]} occurred.

The unimputed rows table looks as follows:
{
    df[VEHICLE_TYPE_EDGE_CASE_MASK][
        [
            schema.port,
            schema.country_of_residence,
            schema.vehicle_type,
            schema.arriving_from,
            schema.purpose4,
            schema.duration2,
            schema.count_of_entries

        ]
    ]
}
                    """
                )
            if (
                "country_of_residence" in list(schema.to_schema().columns.keys())
                and COUNTRY_OF_RESIDENCE_EDGE_CASE
            ):
                logging.info(
                    f"""
COUNTRY OF RESIDENCE EDGE CASE
=========================================
The country of residence edge case where `country_of_residence`
is in {[OVERSEAS_CODE]} occurred.

The unimputed rows table looks as follows:
{
    df[COUNTRY_OF_RESIDENCE_EDGE_CASE_MASK][
        [
            schema.port,
            schema.country_of_residence,
            schema.vehicle_type,
            schema.arriving_from,
            schema.purpose4,
            schema.duration2,
            schema.count_of_entries
        ]
    ]
}
                    """
                )
            if df[GREEN_COLUMNS_TO_CHECK].isna().any().any():
                logging.info(
                    f"""
VALUE COULD NOT BE IMPUTED
=========================================
The unimputed rows table looks as follows:
{
    df[df[GREEN_COLUMNS_TO_CHECK].isna().any(1)][
        [
            schema.port,
            schema.country_of_residence,
            schema.vehicle_type,
            schema.arriving_from,
            schema.purpose4,
            schema.duration2,
            schema.count_of_entries
        ]
    ]
}
                    """
                )
            raise Exception(
                "A column value was unable to be imputed using port, province, or all of Canada as imputation conditions.\
                This should occur extremely rarely."
            )
        df = impute_unfilled_columns(
            df, reference_current, reference_previous, schema, counter + 1
        )

    return df


def convert_to_vehicles_schema(df: pd.DataFrame) -> pd.DataFrame:
    """
    Converts the dataframe at the end of manual_entry_vehicles_030 to the
    schema of the vehicles table
    """
    # Plate region is always NA
    df[VehiclesSchema.plate_region] = pd.NA
    # Derive `mode` as the first digit of the `vehicle_type` column
    df[VehiclesSchema.mode] = df[VehiclesSchema.vehicle_type].str[0]
    # If a detailed work location is not known, it is just the general port value
    df[VehiclesSchema.work_location] = df[VehiclesSchema.port]

    return df


def convert_to_travellers_schema(df: pd.DataFrame) -> pd.DataFrame:
    """
    Converts the dataframe at the end of manual_entry_travellers_030 to the
    schema of the travellers table.
    """
    # Derive `mode` as the first digit of the `vehicle_type` column
    df[TravellersSchema.mode] = df[TravellersSchema.vehicle_type].str[0]
    # plate_region is always null
    df[TravellersSchema.plate_region] = pd.NA
    # duration5 is always null
    df[TravellersSchema.duration5] = pd.NA
    # duration3 is always null
    df[TravellersSchema.duration3] = pd.NA
    # If a detailed work location is not known, it is just the general port value
    df[TravellersSchema.work_location] = df[TravellersSchema.port]

    # The following logic determines traveller type
    df[TravellersSchema.traveller_type] = pd.NA
    PURPOSE4_3_4_MASK = df[TravellersSchema.purpose4].isin(
        [PURPOSE4.work.value, PURPOSE4.other_purpose.value]
    )
    PURPOSE4_2_MASK = df[TravellersSchema.purpose4].isin([PURPOSE4.crew.value])
    VEHICLE_TYPE_MASK = df[TravellersSchema.vehicle_type].isin(
        [
            VEHICLE_TYPE.commercial_aircraft.value,
            VEHICLE_TYPE.cargo_aircraft.value,
            VEHICLE_TYPE.truck.value,
            VEHICLE_TYPE.bus.value,
            VEHICLE_TYPE.train.value,
            VEHICLE_TYPE.cruise_ship.value,
            VEHICLE_TYPE.cargo_ship.value,
            VEHICLE_TYPE.ferry_private_vehicle.value,
            VEHICLE_TYPE.ferry_pedestrian.value,
            VEHICLE_TYPE.ferry_unknown.value,
        ]
    )
    DURATION2_IS_1 = df[TravellersSchema.duration2] == DURATION2.same_day.value
    DURATION2_IS_2 = df[TravellersSchema.duration2] == DURATION2.overnight.value
    # The series of logic to follow is an if-else if-else block (i.e. cases are mutually
    # exclusive), so we need to make sure that for each row an assignment happens for
    # only one of the three cases.
    JOINT_CONDITION = PURPOSE4_3_4_MASK | (PURPOSE4_2_MASK & VEHICLE_TYPE_MASK)
    df.loc[
        JOINT_CONDITION, TravellersSchema.traveller_type
    ] = TRAVELLER_TYPE.other_traveller.value
    df.loc[
        ~JOINT_CONDITION & DURATION2_IS_1, TravellersSchema.traveller_type
    ] = TRAVELLER_TYPE.excursionist.value
    df.loc[
        ~JOINT_CONDITION & DURATION2_IS_2, TravellersSchema.traveller_type
    ] = TRAVELLER_TYPE.tourist.value

    return df


def convert_pd_na_to_code_vehicles(df: pd.DataFrame) -> pd.DataFrame:
    """
    Whenever pd.NA is encountered in a column with enumerable values, replaces
    the pd.NA value with the appropriate missing value code for that dimension
    column.

    This function applies to the vehicles table.
    """
    df = df.replace(
        {VehiclesSchema.day: [pd.NA, np.nan]},
        {VehiclesSchema.day: DAY.not_available.value},
    )
    df = df.replace(
        {VehiclesSchema.mode: [pd.NA, np.nan]},
        {VehiclesSchema.mode: MODE.not_available.value},
    )
    df = df.replace(
        {VehiclesSchema.plate_region: [pd.NA, np.nan]},
        {VehiclesSchema.plate_region: PLATE_REGION.NA.value},
    )
    df = df.replace(
        {VehiclesSchema.data_source: [pd.NA, np.nan]},
        {VehiclesSchema.data_source: DATA_SOURCE.Not_Available.value},
    )
    df = df.replace(
        {VehiclesSchema.vehicle_type: [pd.NA, np.nan]},
        {VehiclesSchema.vehicle_type: VEHICLE_TYPE.not_available.value},
    )
    df = df.replace(
        {VehiclesSchema.plate_country: [pd.NA, np.nan]},
        {VehiclesSchema.plate_country: PLATE_COUNTRY.not_available.value},
    )
    return df


def convert_pd_na_to_code_travellers(df: pd.DataFrame) -> pd.DataFrame:
    """
    Whenever pd.NA is encountered in a column with enumerable values, replaces
    the pd.NA value with the appropriate missing value code for that dimension
    column.

    Since the vehicles table is a subset of the travellers table, we can simply
    call convert_pd_na_to_code_vehicles on the dataframe, then apply the remaining
    conversions as required.
    """
    df = convert_pd_na_to_code_vehicles(df)
    df = df.replace(
        {TravellersSchema.day: [pd.NA, np.nan]},
        {TravellersSchema.day: DAY.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.duration3: [pd.NA, np.nan]},
        {TravellersSchema.duration3: DURATION3.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.duration5: [pd.NA, np.nan]},
        {TravellersSchema.duration5: DURATION5.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.traveller_type: [pd.NA, np.nan]},
        {TravellersSchema.traveller_type: TRAVELLER_TYPE.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.arriving_from: [pd.NA, np.nan]},
        {TravellersSchema.arriving_from: ARRIVING_FROM.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.purpose9: [pd.NA, np.nan]},
        {TravellersSchema.purpose9: PURPOSE9.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.purpose4: [pd.NA, np.nan]},
        {TravellersSchema.purpose4: PURPOSE4.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.duration2: [pd.NA, np.nan]},
        {TravellersSchema.duration2: DURATION2.not_available.value},
    )
    df = df.replace(
        {TravellersSchema.country_of_residence: [pd.NA, np.nan]},
        {TravellersSchema.country_of_residence: COUNTRY_OF_RESIDENCE.not_applicable.value},
    )
    return df
