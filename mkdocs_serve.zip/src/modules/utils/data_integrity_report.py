import pandas as pd

from config.api import Stage, Countries, DataSource, Ports
from modules.utils.loaders import Loader

from datasource.travellers.schema import TransformedSchema as TravellersSchema
from datasource.ports.schema import ReferenceSchema as PortsSchema
from datasource.countries.schema import ReferenceSchema as CountriesSchema

from datasource.common.dim import (
    MODE,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
    PLATE_REGION,
    DATA_SOURCE,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    COUNTRY_OF_RESIDENCE,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
)


def time_based_validations(travellers: pd.DataFrame) -> pd.DataFrame:
    year = travellers[
        (travellers[TravellersSchema.year].isnull())
        | (~travellers[TravellersSchema.year].astype(int).between(1972, 2050))
    ]
    year["invalid_reason"] = "Invalid year"

    month = travellers[
        travellers[TravellersSchema.month].isnull()
        | (~travellers[TravellersSchema.month].astype(int).between(1, 12))
    ]
    month["invalid_reason"] = "Invalid month"

    day = travellers[
        (travellers[TravellersSchema.day].isnull())
        | ~(
            (travellers[TravellersSchema.day].astype(int).between(1, 31))
            | (travellers[TravellersSchema.day] == "99")
        )
        | (
            (travellers[TravellersSchema.month] == "2")
            & (travellers[TravellersSchema.day] == "30")
        )
        | (
            (travellers[TravellersSchema.month] == "2")
            & (travellers[TravellersSchema.day] == "31")
        )
        | (
            (travellers[TravellersSchema.month] == "4")
            & (travellers[TravellersSchema.day] == "31")
        )
        | (
            (travellers[TravellersSchema.month] == "6")
            & (travellers[TravellersSchema.day] == "31")
        )
        | (
            (travellers[TravellersSchema.month] == "9")
            & (travellers[TravellersSchema.day] == "31")
        )
        | (
            (travellers[TravellersSchema.month] == "11")
            & (travellers[TravellersSchema.day] == "31")
        )
    ]
    day["invalid_reason"] = "Invalid day"

    time_based = year.append([month, day])

    return time_based


def geographical_based_validations(travellers: pd.DataFrame) -> pd.DataFrame:

    ports_csv = Loader.get(Stage.REFERENCE, DataSource.ports, Ports.ports)
    ports_csv = PortsSchema(ports_csv)
    ports_csv = ports_csv[[PortsSchema.port, PortsSchema.port_end]]

    temp = travellers.copy()
    temp = pd.merge(temp, ports_csv, on=PortsSchema.port, how="left")
    port = travellers[
        (travellers[TravellersSchema.port].isnull())
        | (~temp[PortsSchema.port_end].isnull())
    ]
    port["invalid_reason"] = "Invalid port"

    plate_country_df = travellers[
        (travellers[TravellersSchema.plate_country].isnull())
        | (
            (
                travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.automobile.value,
                        VEHICLE_TYPE.motorcycle.value,
                        VEHICLE_TYPE.other_land_vehicle.value,
                        VEHICLE_TYPE.truck.value,
                    ]
                )
            )
            & (
                travellers[TravellersSchema.data_source]
                == DATA_SOURCE.IPIL_Highway.value
            )
            & (
                ~travellers[TravellersSchema.plate_country].isin(
                    [
                        PLATE_COUNTRY.canada.value,
                        PLATE_COUNTRY.united_states.value,
                        PLATE_COUNTRY.mexico.value,
                        PLATE_COUNTRY.puerto_rico.value,
                        PLATE_COUNTRY.other.value,
                    ]
                )
            )
        )
        | (
            (
                travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.automobile.value,
                        VEHICLE_TYPE.motorcycle.value,
                        VEHICLE_TYPE.other_land_vehicle.value,
                        VEHICLE_TYPE.truck.value,
                    ]
                )
            )
            & (
                travellers[TravellersSchema.data_source]
                != DATA_SOURCE.IPIL_Highway.value
            )
            & (
                ~travellers[TravellersSchema.plate_country].isin(
                    [
                        PLATE_COUNTRY.canada.value,
                        PLATE_COUNTRY.united_states.value,
                        PLATE_COUNTRY.not_available.value,
                    ]
                )
            )
        )
        | (
            (
                travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.bus.value,
                        VEHICLE_TYPE.ferry_private_vehicle.value,
                        VEHICLE_TYPE.ferry_unknown.value,
                    ]
                )
            )
            & (
                ~travellers[TravellersSchema.plate_country].isin(
                    [
                        PLATE_COUNTRY.canada.value,
                        PLATE_COUNTRY.united_states.value,
                        PLATE_COUNTRY.mexico.value,
                        PLATE_COUNTRY.puerto_rico.value,
                        PLATE_COUNTRY.other.value,
                        PLATE_COUNTRY.not_available.value,
                    ]
                )
            )
        )
        | (
            (
                travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.commercial_aircraft.value,
                        VEHICLE_TYPE.cargo_aircraft.value,
                        VEHICLE_TYPE.private_aircraft.value,
                        VEHICLE_TYPE.train.value,
                        VEHICLE_TYPE.pedestrian.value,
                        VEHICLE_TYPE.cruise_ship.value,
                        VEHICLE_TYPE.cargo_ship.value,
                        VEHICLE_TYPE.ferry_pedestrian.value,
                        VEHICLE_TYPE.private_boat.value,
                    ]
                )
            )
            & ~(
                travellers[TravellersSchema.plate_country]
                == PLATE_COUNTRY.not_available.value
            )
        )
    ]
    plate_country_df["invalid_reason"] = "Invalid plate country"

    plate_region_df = travellers[
        (travellers[TravellersSchema.plate_region].isnull())
        | (
            (travellers[TravellersSchema.plate_country] == PLATE_COUNTRY.canada.value)
            & (
                ~travellers[TravellersSchema.plate_region].isin(
                    [
                        PLATE_REGION.NL.value,
                        PLATE_REGION.PE.value,
                        PLATE_REGION.NS.value,
                        PLATE_REGION.NB.value,
                        PLATE_REGION.QC.value,
                        PLATE_REGION.ON.value,
                        PLATE_REGION.MB.value,
                        PLATE_REGION.SK.value,
                        PLATE_REGION.AB.value,
                        PLATE_REGION.BC.value,
                        PLATE_REGION.YT.value,
                        PLATE_REGION.NT.value,
                        PLATE_REGION.NU.value,
                        PLATE_REGION.NA.value,
                    ]
                )
            )
        )
        | (
            (
                travellers[TravellersSchema.plate_country]
                == PLATE_COUNTRY.united_states.value
            )
            & (
                ~travellers[TravellersSchema.plate_region].isin(
                    [
                        PLATE_REGION.AL.value,
                        PLATE_REGION.AK.value,
                        PLATE_REGION.AZ.value,
                        PLATE_REGION.AR.value,
                        PLATE_REGION.CA.value,
                        PLATE_REGION.CO.value,
                        PLATE_REGION.CT.value,
                        PLATE_REGION.DE.value,
                        PLATE_REGION.DC.value,
                        PLATE_REGION.FL.value,
                        PLATE_REGION.GA.value,
                        PLATE_REGION.HI.value,
                        PLATE_REGION.ID.value,
                        PLATE_REGION.IL.value,
                        PLATE_REGION.IN.value,
                        PLATE_REGION.IA.value,
                        PLATE_REGION.KS.value,
                        PLATE_REGION.KY.value,
                        PLATE_REGION.LA.value,
                        PLATE_REGION.ME.value,
                        PLATE_REGION.MD.value,
                        PLATE_REGION.MA.value,
                        PLATE_REGION.MI.value,
                        PLATE_REGION.MN.value,
                        PLATE_REGION.MS.value,
                        PLATE_REGION.MO.value,
                        PLATE_REGION.MT.value,
                        PLATE_REGION.NE.value,
                        PLATE_REGION.NV.value,
                        PLATE_REGION.NH.value,
                        PLATE_REGION.NJ.value,
                        PLATE_REGION.NM.value,
                        PLATE_REGION.NY.value,
                        PLATE_REGION.NC.value,
                        PLATE_REGION.ND.value,
                        PLATE_REGION.OH.value,
                        PLATE_REGION.OK.value,
                        PLATE_REGION.OR.value,
                        PLATE_REGION.PA.value,
                        PLATE_REGION.RI.value,
                        PLATE_REGION.SC.value,
                        PLATE_REGION.SD.value,
                        PLATE_REGION.TN.value,
                        PLATE_REGION.TX.value,
                        PLATE_REGION.UT.value,
                        PLATE_REGION.VT.value,
                        PLATE_REGION.VA.value,
                        PLATE_REGION.WA.value,
                        PLATE_REGION.WV.value,
                        PLATE_REGION.WI.value,
                        PLATE_REGION.WY.value,
                        PLATE_REGION.NA.value,
                    ]
                )
            )
        )
        | (
            (travellers[TravellersSchema.plate_country] == PLATE_COUNTRY.mexico.value)
            & ~(travellers[TravellersSchema.plate_region] == PLATE_REGION.MX.value)
        )
        | (
            (
                travellers[TravellersSchema.plate_country]
                == PLATE_COUNTRY.puerto_rico.value
            )
            & ~(travellers[TravellersSchema.plate_region] == PLATE_REGION.PR.value)
        )
        | (
            (travellers[TravellersSchema.plate_country] == PLATE_COUNTRY.other.value)
            & ~(travellers[TravellersSchema.plate_region] == PLATE_REGION.XX.value)
        )
        | (
            (
                travellers[TravellersSchema.plate_country]
                == PLATE_COUNTRY.not_available.value
            )
            & ~(travellers[TravellersSchema.plate_region] == PLATE_REGION.NA.value)
        )
    ]
    plate_region_df["invalid_reason"] = "Invalid plate region"

    arriving_from_df = travellers[
        (travellers[TravellersSchema.arriving_from].isnull())
        | (
            ~travellers[TravellersSchema.arriving_from].isin(
                [
                    ARRIVING_FROM.us_only.value,
                    ARRIVING_FROM.ovs_direct.value,
                    ARRIVING_FROM.ovs_via_us.value,
                ]
            )
        )
        | (
            (
                travellers[TravellersSchema.country_of_residence].isin(
                    [
                        COUNTRY_OF_RESIDENCE.canada.value,
                        COUNTRY_OF_RESIDENCE.united_states.value,
                    ]
                )
            )
            & (travellers[TravellersSchema.mode] == MODE.land.value)
            & (
                ~travellers[TravellersSchema.arriving_from].isin(
                    [ARRIVING_FROM.us_only.value, ARRIVING_FROM.ovs_via_us.value]
                )
            )
        )
        | (
            (
                ~travellers[TravellersSchema.country_of_residence].isin(
                    [
                        COUNTRY_OF_RESIDENCE.canada.value,
                        COUNTRY_OF_RESIDENCE.united_states.value,
                    ]
                )
            )
            & (travellers[TravellersSchema.mode] == MODE.land.value)
            & ~(
                travellers[TravellersSchema.arriving_from]
                == ARRIVING_FROM.ovs_via_us.value
            )
        )
    ]
    arriving_from_df["invalid_reason"] = "Invalid arriving from"

    countries_csv = Loader.get(
        Stage.REFERENCE, DataSource.countries, Countries.countries
    )
    countries_csv = CountriesSchema(countries_csv)
    countries_csv = countries_csv[
        [
            CountriesSchema.country_of_residence,
            CountriesSchema.country_name_en,
            CountriesSchema.country_end,
        ]
    ]

    temp = travellers.copy()
    temp = pd.merge(
        temp, countries_csv, on=CountriesSchema.country_of_residence, how="left"
    )

    country_df = travellers[
        (temp[CountriesSchema.country_name_en].isnull())
        | (
            travellers[TravellersSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.overseas.value
        )
        | (~temp[CountriesSchema.country_end].isnull())
        | (
            (travellers[TravellersSchema.purpose9] == PURPOSE9.immigration.value)
            & ~(
                travellers[TravellersSchema.country_of_residence]
                == COUNTRY_OF_RESIDENCE.not_applicable.value
            )
        )
        | (
            ~(travellers[TravellersSchema.purpose9] == PURPOSE9.immigration.value)
            & (
                travellers[TravellersSchema.country_of_residence].isin(
                    [
                        COUNTRY_OF_RESIDENCE.not_applicable.value,
                        COUNTRY_OF_RESIDENCE.overseas.value,
                    ]
                )
            )
        )
    ]
    country_df["invalid_reason"] = "Invalid country of residence"

    geographical_based = port.append(
        [plate_country_df, plate_region_df, arriving_from_df, country_df]
    )

    return geographical_based


def type_based_validations(travellers: pd.DataFrame) -> pd.DataFrame:

    mode_df = travellers[
        (travellers[TravellersSchema.mode].isnull())
        | (
            ~travellers[TravellersSchema.mode].isin(
                [MODE.air.value, MODE.land.value, MODE.water.value]
            )
        )
    ]
    mode_df["invalid_reason"] = "Invalid mode"

    vehicle_type_df = travellers[
        (travellers[TravellersSchema.vehicle_type].isnull())
        | (
            travellers[TravellersSchema.vehicle_type].isin(
                [
                    VEHICLE_TYPE.air_unknown.value,
                    VEHICLE_TYPE.land_unknown.value,
                    VEHICLE_TYPE.water_unknown.value,
                    VEHICLE_TYPE.not_available.value,
                ]
            )
        )
        | (
            (travellers[TravellersSchema.mode] == MODE.air.value)
            & (
                ~travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.commercial_aircraft.value,
                        VEHICLE_TYPE.cargo_aircraft.value,
                        VEHICLE_TYPE.private_aircraft.value,
                    ]
                )
            )
        )
        | (
            (travellers[TravellersSchema.mode] == MODE.land.value)
            & (
                ~travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.automobile.value,
                        VEHICLE_TYPE.motorcycle.value,
                        VEHICLE_TYPE.other_land_vehicle.value,
                        VEHICLE_TYPE.truck.value,
                        VEHICLE_TYPE.bus.value,
                        VEHICLE_TYPE.train.value,
                        VEHICLE_TYPE.pedestrian.value,
                    ]
                )
            )
        )
        | (
            (travellers[TravellersSchema.mode] == MODE.water.value)
            & (
                ~travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.cruise_ship.value,
                        VEHICLE_TYPE.cargo_ship.value,
                        VEHICLE_TYPE.ferry_private_vehicle.value,
                        VEHICLE_TYPE.ferry_pedestrian.value,
                        VEHICLE_TYPE.ferry_unknown.value,
                        VEHICLE_TYPE.private_boat.value,
                    ]
                )
            )
        )
    ]
    vehicle_type_df["invalid_reason"] = "Invalid vehicle type"

    traveller_type_df = travellers[
        (travellers[TravellersSchema.traveller_type].isnull())
        | (
            travellers[TravellersSchema.traveller_type]
            == TRAVELLER_TYPE.not_available.value
        )
        | (
            (
                travellers[TravellersSchema.purpose9].isin(
                    [
                        PURPOSE9.personal.value,
                        PURPOSE9.business.value,
                        PURPOSE9.study.value,
                        PURPOSE9.visit.value,
                    ]
                )
            )
            & (travellers[TravellersSchema.duration2] == DURATION2.same_day.value)
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.excursionist.value
            )
        )
        | (
            (travellers[TravellersSchema.purpose9] == PURPOSE9.crew.value)
            & (
                travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.private_aircraft.value,
                        VEHICLE_TYPE.private_boat.value,
                    ]
                )
            )
            & (travellers[TravellersSchema.duration2] == DURATION2.same_day.value)
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.excursionist.value
            )
        )
        | (
            (travellers[TravellersSchema.duration5] == DURATION5.over_one_year.value)
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.other_traveller.value
            )
        )
        | (
            (
                travellers[TravellersSchema.purpose9].isin(
                    [
                        PURPOSE9.personal.value,
                        PURPOSE9.business.value,
                        PURPOSE9.study.value,
                        PURPOSE9.visit.value,
                    ]
                )
            )
            & (travellers[TravellersSchema.duration2] == DURATION2.overnight.value)
            & ~(travellers[TravellersSchema.duration5] == DURATION5.over_one_year.value)
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.tourist.value
            )
        )
        | (
            (travellers[TravellersSchema.purpose9] == PURPOSE9.crew.value)
            & (
                travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.private_aircraft.value,
                        VEHICLE_TYPE.private_boat.value,
                    ]
                )
            )
            & (travellers[TravellersSchema.duration2] == DURATION2.overnight.value)
            & ~(travellers[TravellersSchema.duration5] == DURATION5.over_one_year.value)
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.tourist.value
            )
        )
        | (
            (travellers[TravellersSchema.purpose9] == PURPOSE9.crew.value)
            & (
                ~travellers[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.private_aircraft.value,
                        VEHICLE_TYPE.private_boat.value,
                    ]
                )
            )
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.other_traveller.value
            )
        )
        | (
            (
                travellers[TravellersSchema.purpose9].isin(
                    [
                        PURPOSE9.work.value,
                        PURPOSE9.immigration.value,
                        PURPOSE9.military.value,
                        PURPOSE9.other_purpose.value,
                    ]
                )
            )
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.other_traveller.value
            )
        )
        | (
            (travellers[TravellersSchema.vehicle_type].isin([VEHICLE_TYPE.truck.value]))
            & ~(
                travellers[TravellersSchema.traveller_type]
                == TRAVELLER_TYPE.other_traveller.value
            )
        )
    ]
    traveller_type_df["invalid_reason"] = "Invalid traveller type"

    type_based = mode_df.append([vehicle_type_df, traveller_type_df])

    return type_based


def misc_validations(travellers: pd.DataFrame) -> pd.DataFrame:
    purpose9_df = travellers[
        (travellers[TravellersSchema.purpose9].isnull())
        | (
            ~travellers[TravellersSchema.purpose9].isin(
                [
                    PURPOSE9.personal.value,
                    PURPOSE9.business.value,
                    PURPOSE9.study.value,
                    PURPOSE9.visit.value,
                    PURPOSE9.crew.value,
                    PURPOSE9.work.value,
                    PURPOSE9.immigration.value,
                    PURPOSE9.military.value,
                    PURPOSE9.other_purpose.value,
                ]
            )
        )
    ]
    # exclude the port 10913 from the invalid purpose9. issue #989
    purpose9_df = purpose9_df[~(
        (purpose9_df[TravellersSchema.port] == '10913') &
        (purpose9_df[TravellersSchema.data_source] == DATA_SOURCE.ORA.value) &
        (purpose9_df[TravellersSchema.mode] == MODE.air.value)
    )]
    purpose9_df["invalid_reason"] = "Invalid purpose9"

    purpose4_df = travellers[
        (travellers[TravellersSchema.purpose4].isnull())
        | (
            ~travellers[TravellersSchema.purpose4].isin(
                [
                    PURPOSE4.visit.value,
                    PURPOSE4.crew.value,
                    PURPOSE4.work.value,
                    PURPOSE4.other_purpose.value,
                ]
            )
        )
        | (
            (
                travellers[TravellersSchema.purpose9].isin(
                    [
                        PURPOSE9.personal.value,
                        PURPOSE9.business,
                        PURPOSE9.study.value,
                        PURPOSE9.visit.value,
                    ]
                )
            )
            & ~(travellers[TravellersSchema.purpose4] == PURPOSE4.visit.value)
        )
        | (
            (travellers[TravellersSchema.purpose9] == PURPOSE9.crew.value)
            & ~(travellers[TravellersSchema.purpose4] == PURPOSE4.crew.value)
        )
        | (
            (travellers[TravellersSchema.purpose9] == PURPOSE9.work.value)
            & ~(travellers[TravellersSchema.purpose4] == PURPOSE4.work.value)
        )
        | (
            (
                travellers[TravellersSchema.purpose9].isin(
                    [
                        PURPOSE9.immigration.value,
                        PURPOSE9.military.value,
                        PURPOSE9.other_purpose.value,
                    ]
                )
            )
            & ~(travellers[TravellersSchema.purpose4] == PURPOSE4.other_purpose.value)
        )
    ]
    purpose4_df["invalid_reason"] = "Invalid purpose4"

    duration5_df = travellers[
        (travellers[TravellersSchema.duration5].isnull())
        | (
            ~travellers[TravellersSchema.duration5].isin(
                [
                    DURATION5.same_day.value,
                    DURATION5.one_two_nights.value,
                    DURATION5.three_seven_nights.value,
                    DURATION5.eight_plus_nights.value,
                    DURATION5.over_one_year.value,
                    DURATION5.not_available.value,
                ]
            )
        )
    ]
    duration5_df["invalid_reason"] = "Invalid duration5"

    duration3_df = travellers[
        (travellers[TravellersSchema.duration3].isnull())
        | (
            ~travellers[TravellersSchema.duration3].isin(
                [
                    DURATION3.same_day.value,
                    DURATION3.one_night.value,
                    DURATION3.two_or_more_nights.value,
                    DURATION3.not_available.value,
                ]
            )
        )
    ]
    duration3_df["invalid_reason"] = "Invalid duration3"

    duration2_df = travellers[
        (travellers[TravellersSchema.duration2].isnull())
        | (
            ~travellers[TravellersSchema.duration2].isin(
                [
                    DURATION2.same_day.value,
                    DURATION2.overnight.value,
                    DURATION2.not_available.value,
                ]
            )
        )
        | (
            (travellers[TravellersSchema.purpose9] == PURPOSE9.immigration.value)
            & ~(travellers[TravellersSchema.duration2] == DURATION2.not_available.value)
        )
        | (
            (travellers[TravellersSchema.duration5] == DURATION5.same_day.value)
            & ~(travellers[TravellersSchema.duration2] == DURATION2.same_day.value)
        )
        | (
            (travellers[TravellersSchema.duration3] == DURATION3.same_day.value)
            & ~(travellers[TravellersSchema.duration2] == DURATION2.same_day.value)
        )
        | (
            (
                travellers[TravellersSchema.duration5].isin(
                    [
                        DURATION5.one_two_nights.value,
                        DURATION5.three_seven_nights.value,
                        DURATION5.eight_plus_nights.value,
                        DURATION5.over_one_year.value,
                    ]
                )
            )
            & ~(travellers[TravellersSchema.duration2] == DURATION2.overnight.value)
        )
        | (
            (
                travellers[TravellersSchema.duration3].isin(
                    [DURATION3.one_night.value, DURATION3.two_or_more_nights.value]
                )
            )
            & ~(travellers[TravellersSchema.duration2] == DURATION2.overnight.value)
        )
    ]
    duration2_df["invalid_reason"] = "Invalid duration2"

    # If the below = 0 check throws an error, it means that one or more count entries are not integers which should also be corrected
    counts_df = travellers[travellers[TravellersSchema.count_of_entries] <= 0]
    # Exclude the invalid counts for ports 59840 and 24314 related to issue #989
    counts_df = counts_df[~(
        (counts_df[TravellersSchema.port].isin(['59840', '24314'])) &
        (~counts_df[TravellersSchema.country_of_residence].isin([
            COUNTRY_OF_RESIDENCE.canada.value, COUNTRY_OF_RESIDENCE.united_states.value])) &
        (counts_df[TravellersSchema.mode] == MODE.land.value) &
        (counts_df[TravellersSchema.data_source] == DATA_SOURCE.IPIL_Highway.value) &
        (counts_df[TravellersSchema.vehicle_type].isin([
            VEHICLE_TYPE.automobile.value, 
            VEHICLE_TYPE.motorcycle.value, 
            VEHICLE_TYPE.other_land_vehicle.value, 
            VEHICLE_TYPE.truck.value, 
            VEHICLE_TYPE.bus.value, 
            VEHICLE_TYPE.pedestrian.value]))
    )]
    counts_df["invalid_reason"] = "Invalid count"

    miscellaneous = purpose9_df.append(
        [purpose4_df, duration5_df, duration3_df, duration2_df, counts_df]
    )

    return miscellaneous


def vehicles_geographical_based_validations(vehicles: pd.DataFrame) -> pd.DataFrame:

    ports_csv = Loader.get(Stage.REFERENCE, DataSource.ports, Ports.ports)
    ports_csv = PortsSchema(ports_csv)
    ports_csv = ports_csv[[PortsSchema.port, PortsSchema.port_end]]

    temp = vehicles.copy()
    temp = pd.merge(temp, ports_csv, on=PortsSchema.port, how="left")
    port = vehicles[
        (vehicles[TravellersSchema.port].isnull())
        | (~temp[PortsSchema.port_end].isnull())
    ]
    port["invalid_reason"] = "Invalid port"

    plate_country_df = vehicles[
        (vehicles[TravellersSchema.plate_country].isnull())
        | (
            (
                vehicles[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.automobile.value,
                        VEHICLE_TYPE.motorcycle.value,
                        VEHICLE_TYPE.other_land_vehicle.value,
                        VEHICLE_TYPE.truck.value,
                    ]
                )
            )
            & (vehicles[TravellersSchema.data_source] == DATA_SOURCE.IPIL_Highway.value)
            & (
                ~vehicles[TravellersSchema.plate_country].isin(
                    [
                        PLATE_COUNTRY.canada.value,
                        PLATE_COUNTRY.united_states.value,
                        PLATE_COUNTRY.mexico.value,
                        PLATE_COUNTRY.puerto_rico.value,
                        PLATE_COUNTRY.other.value,
                    ]
                )
            )
        )
        | (
            (
                vehicles[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.automobile.value,
                        VEHICLE_TYPE.motorcycle.value,
                        VEHICLE_TYPE.other_land_vehicle.value,
                        VEHICLE_TYPE.truck.value,
                    ]
                )
            )
            & (vehicles[TravellersSchema.data_source] != DATA_SOURCE.IPIL_Highway.value)
            & (
                ~vehicles[TravellersSchema.plate_country].isin(
                    [PLATE_COUNTRY.canada.value, PLATE_COUNTRY.united_states.value]
                )
            )
        )
        | (
            (
                vehicles[TravellersSchema.vehicle_type].isin(
                    [VEHICLE_TYPE.bus.value, VEHICLE_TYPE.ferry_private_vehicle.value]
                )
            )
            & (
                ~vehicles[TravellersSchema.plate_country].isin(
                    [
                        PLATE_COUNTRY.canada.value,
                        PLATE_COUNTRY.united_states.value,
                        PLATE_COUNTRY.mexico.value,
                        PLATE_COUNTRY.puerto_rico.value,
                        PLATE_COUNTRY.other.value,
                        PLATE_COUNTRY.not_available.value,
                    ]
                )
            )
        )
    ]
    plate_country_df["invalid_reason"] = "Invalid plate country"

    plate_region_df = vehicles[
        (vehicles[TravellersSchema.plate_region].isnull())
        | (
            (vehicles[TravellersSchema.plate_country] == PLATE_COUNTRY.canada.value)
            & (
                ~vehicles[TravellersSchema.plate_region].isin(
                    [
                        PLATE_REGION.NL.value,
                        PLATE_REGION.PE.value,
                        PLATE_REGION.NS.value,
                        PLATE_REGION.NB.value,
                        PLATE_REGION.QC.value,
                        PLATE_REGION.ON.value,
                        PLATE_REGION.MB.value,
                        PLATE_REGION.SK.value,
                        PLATE_REGION.AB.value,
                        PLATE_REGION.BC.value,
                        PLATE_REGION.YT.value,
                        PLATE_REGION.NT.value,
                        PLATE_REGION.NU.value,
                        PLATE_REGION.NA.value,
                    ]
                )
            )
        )
        | (
            (
                vehicles[TravellersSchema.plate_country]
                == PLATE_COUNTRY.united_states.value
            )
            & (
                ~vehicles[TravellersSchema.plate_region].isin(
                    [
                        PLATE_REGION.AL.value,
                        PLATE_REGION.AK.value,
                        PLATE_REGION.AZ.value,
                        PLATE_REGION.AR.value,
                        PLATE_REGION.CA.value,
                        PLATE_REGION.CO.value,
                        PLATE_REGION.CT.value,
                        PLATE_REGION.DE.value,
                        PLATE_REGION.DC.value,
                        PLATE_REGION.FL.value,
                        PLATE_REGION.GA.value,
                        PLATE_REGION.HI.value,
                        PLATE_REGION.ID.value,
                        PLATE_REGION.IL.value,
                        PLATE_REGION.IN.value,
                        PLATE_REGION.IA.value,
                        PLATE_REGION.KS.value,
                        PLATE_REGION.KY.value,
                        PLATE_REGION.LA.value,
                        PLATE_REGION.ME.value,
                        PLATE_REGION.MD.value,
                        PLATE_REGION.MA.value,
                        PLATE_REGION.MI.value,
                        PLATE_REGION.MN.value,
                        PLATE_REGION.MS.value,
                        PLATE_REGION.MO.value,
                        PLATE_REGION.MT.value,
                        PLATE_REGION.NE.value,
                        PLATE_REGION.NV.value,
                        PLATE_REGION.NH.value,
                        PLATE_REGION.NJ.value,
                        PLATE_REGION.NM.value,
                        PLATE_REGION.NY.value,
                        PLATE_REGION.NC.value,
                        PLATE_REGION.ND.value,
                        PLATE_REGION.OH.value,
                        PLATE_REGION.OK.value,
                        PLATE_REGION.OR.value,
                        PLATE_REGION.PA.value,
                        PLATE_REGION.RI.value,
                        PLATE_REGION.SC.value,
                        PLATE_REGION.SD.value,
                        PLATE_REGION.TN.value,
                        PLATE_REGION.TX.value,
                        PLATE_REGION.UT.value,
                        PLATE_REGION.VT.value,
                        PLATE_REGION.VA.value,
                        PLATE_REGION.WA.value,
                        PLATE_REGION.WV.value,
                        PLATE_REGION.WI.value,
                        PLATE_REGION.WY.value,
                        PLATE_REGION.NA.value,
                    ]
                )
            )
        )
        | (
            (vehicles[TravellersSchema.plate_country] == PLATE_COUNTRY.mexico.value)
            & ~(vehicles[TravellersSchema.plate_region] == PLATE_REGION.MX.value)
        )
        | (
            (
                vehicles[TravellersSchema.plate_country]
                == PLATE_COUNTRY.puerto_rico.value
            )
            & ~(vehicles[TravellersSchema.plate_region] == PLATE_REGION.PR.value)
        )
        | (
            (vehicles[TravellersSchema.plate_country] == PLATE_COUNTRY.other.value)
            & ~(vehicles[TravellersSchema.plate_region] == PLATE_REGION.XX.value)
        )
        | (
            (
                vehicles[TravellersSchema.plate_country]
                == PLATE_COUNTRY.not_available.value
            )
            & ~(vehicles[TravellersSchema.plate_region] == PLATE_REGION.NA.value)
        )
    ]
    plate_region_df["invalid_reason"] = "Invalid plate region"

    geographical_based_vehicles = port.append([plate_country_df, plate_region_df])

    return geographical_based_vehicles


def vehicles_type_misc_based_validations(vehicles: pd.DataFrame) -> pd.DataFrame:

    mode_df = vehicles[
        (vehicles[TravellersSchema.mode].isnull())
        | (~vehicles[TravellersSchema.mode].isin([MODE.land.value, MODE.water.value]))
    ]
    mode_df["invalid_reason"] = "Invalid mode"

    vehicle_type_df = vehicles[
        (vehicles[TravellersSchema.vehicle_type].isnull())
        | (
            (vehicles[TravellersSchema.mode] == MODE.land.value)
            & (
                ~vehicles[TravellersSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.automobile.value,
                        VEHICLE_TYPE.motorcycle.value,
                        VEHICLE_TYPE.other_land_vehicle.value,
                        VEHICLE_TYPE.truck.value,
                        VEHICLE_TYPE.bus.value,
                    ]
                )
            )
        )
        | (
            (vehicles[TravellersSchema.mode] == MODE.water.value)
            & ~(
                vehicles[TravellersSchema.vehicle_type]
                == VEHICLE_TYPE.ferry_private_vehicle.value
            )
        )
    ]
    vehicle_type_df["invalid_reason"] = "Invalid vehicle type"

    counts_df = vehicles[~vehicles[TravellersSchema.count_of_entries] >= 0]
    counts_df["invalid_reason"] = "Invalid count"

    miscellaneous_vehicles = mode_df.append([vehicle_type_df, counts_df])

    return miscellaneous_vehicles
