from datetime import timedelta
import datetime
from dateutil.relativedelta import relativedelta

from typing import Callable, Dict, Generator


def generate_month_range(start_date, end_date):
    """
    Generates the first day of every month for a given range of dates.
    Note that the lower bound is inclusive and the upper bound is exclusive.
    """
    for n in range(int((end_date - start_date).days)):
        if (start_date + timedelta(n)).day == 1:
            yield start_date + timedelta(n)


def pipeline_template_instances(
    script_name: str,
    arg_string_func: Callable[[str], str],
    num_periods: int,
    date: str,
) -> Generator[Dict[str, str], None, None]:
    # Note that the interpretation of periods is *excluding* the current production
    # month, so 19 months e.g. total for current month + 18 months of revision.
    date = datetime.datetime.strptime(date, "%Y-%m-%d")
    start_date = date - relativedelta(months=int(num_periods) - 1)
    for single_date in generate_month_range(start_date, date + relativedelta(months=1)):
        yield {
            "script_name": script_name,
            "args": arg_string_func(single_date.strftime("%Y-%m-%d")),
        }
