import datetime


class PipelineUID:
    __uid = str(datetime.datetime.utcnow().isoformat())

    @staticmethod
    def get_uid():
        return PipelineUID.__uid
