from argparse import ArgumentParser
import datetime

def get_parser():
    """
    CLI parser for NDM Validations
    """
    parser = ArgumentParser(
        prog="ndm_validations",
        description="CLI parser for NDM Validations",
    )
    # Start date (set by default to January 1 2000 but can change in the future)
    parser.add_argument(
        "-sd",
        "--start-date",
        default="2000-01-01",
        type=datetime.date.fromisoformat,
        help="""
        The start date (inclusive) to start generating the historical validation reports.
        Date is of the form YYYY-MM-DD (e.g. 2020-12-22)
        """,
    )
    # Current date (i.e. date for the data being run)
    parser.add_argument(
        "-ed",
        "--end-date",
        default="2020-01-01",
        type=datetime.date.fromisoformat,
        help="""
        The end date (inclusive) to start generating the historical validation reports.
        Date is of the form YYYY-MM-DD (e.g. 2020-12-22)
        """,
    )
    # Table number
    parser.add_argument(
        "-t",
        "--table",
        type=str,
        help="""
        The table for which we are generating comparison reports.
        """,
    )
    return parser