"""
A set of helper utilities used for various purpposes.
"""
import importlib
from os.path import join, dirname

import numpy as np
import pandas as pd


# I moved this here to avoid circular import error when config.py tries to
# import get_module_path in schema.py which imports DataSource from config.api
# - Collin
def get_module_path(module: str) -> str:
    """
    Returns the path of the scpecified module.
    There's no need for relative references (i.e., ".", "..")
    Args:
        module: name of the module to get the dir path
    Returns:
        dirname path of the module
    """
    return join(dirname(importlib.import_module(module).__file__))


def largest_remainder_rounding_pandas(
    df: pd.DataFrame, group_mask: pd.Series, total_mask: pd.Series, value_column: str
) -> pd.DataFrame:
    """Implements the largest remainder method of rounding a group of numbers.
       The purpose of this approach is to ensure that totals within a group
       sum to the correct total after rounding is applied.

    Args:
        df (pd.DataFrame): The dataframe containing a subset of rows that need
                           to be rounded correctly.
        group_mask (pd.Series): A boolean mask for members of the group.
        total_mask (pd.Series): A boolean mask for the total (note that this
                                should select a single row).
        value_column (str): The name of the column where the floating point
                            number to be rounded is stored.

    Returns:
        pd.DataFrame: The original dataframe with the selected columns rounded
                      correctly.
    """
    # Split floating point numbers into integer and fractional parts
    df.loc[group_mask, "fraction"], df.loc[group_mask, "integer"] = np.modf(
        df.loc[group_mask, value_column]
    )
    # Round the total column
    df.loc[total_mask, value_column] = np.floor(df.loc[total_mask, value_column])
    # Get the difference between the total and the sum of integers in the group.
    TOTAL = df.loc[total_mask, value_column].squeeze()
    if isinstance(TOTAL, pd.Series):
        raise ValueError(
            """
            `total_mask` returned more than one row; this mask
            should only return a single row.
            """
        )
    SUM_GROUP_INTEGERS = df.loc[group_mask, "integer"].sum()
    DELTA = int(TOTAL - SUM_GROUP_INTEGERS)
    # In decreasing order of the fractional component, allocate the delta between
    # total and sum of group integers.
    ones = np.full(shape=DELTA, fill_value=1, dtype=np.int64)
    zeros = np.full(shape=len(df[group_mask]) - DELTA, fill_value=0, dtype=np.int64)
    remainder_alloc = np.concatenate([ones, zeros])
    df.loc[group_mask, :] = df.loc[group_mask, :].sort_values(
        "fraction", ascending=False
    )
    df.loc[group_mask, value_column] = df.loc[group_mask, "integer"] + remainder_alloc
    return df.drop(columns=["integer", "fraction"])

