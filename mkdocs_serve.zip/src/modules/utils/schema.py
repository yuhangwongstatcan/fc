#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import keyword
import re
import keyword
import argparse
import importlib

from collections import namedtuple
from collections.abc import Mapping

from config.api import DataSource
from config.api import Stage


def load_datasource_schema(datasource: DataSource, stage: Stage = None):
    """
    Loads a datasource schema given a stage and datasource.
    """
    schema_module_str = ".".join(["datasource", datasource.value, "schema"])
    schema_module = importlib.import_module(schema_module_str)
    schema_name = f"{stage.name.capitalize()}Schema"
    return getattr(schema_module, schema_name)


def namedtupe_from_mappping(mapping: Mapping, name: str = "Tuplify"):
    tuple_maker = namedtuple(name, mapping.keys())
    return tuple_maker(**mapping)


def tuplify(_obj: object) -> object:
    """
    Nested mapping objects are converted to a namedtuple (i.e., tuplify)
    """
    if isinstance(_obj, Mapping):
        for k, v in _obj.items():
            _obj[k] = tuplify(v)
        return namedtupe_from_mappping(_obj)
    elif isinstance(_obj, list):
        for idx, v in enumerate(_obj):
            _obj[idx] = tuplify(v)
    return _obj


def naming(name: str):
    """
    Helper function to make sure that the tuple key names are valid.
    They are all converted to lowercase.
    """
    # If name is not a string (e.g. int), cast it to string
    if not isinstance(name, str):
        name = str(name)

    CAMEL_CASE = re.compile("^([A-Z][^A-Z]+){2,}$")
    VALID_COLUMN_NAME = re.compile("^[a-z][a-z0-9_]*$")

    if CAMEL_CASE.match(name):
        name = name[0] + re.sub(r"([A-Z])", r"_\1", name[1:])
    if not VALID_COLUMN_NAME.match(name):
        name = re.sub("([^\w]|[\s_])+", "_", name)
    name = name.lower()
    name = f"{name}_" if name in keyword.kwlist else name
    return name


def isnamedtupleinstance(x: object) -> object:
    """
    Helper function used buy unpack.
    """
    _type = type(x)
    bases = _type.__bases__
    if len(bases) != 1 or bases[0] != tuple:
        return False
    fields = getattr(_type, "_fields", None)
    if not isinstance(fields, tuple):
        return False
    return all(type(i) == str for i in fields)


def unpack(obj: object) -> object:
    """
    Unpack nested named tuple to a dictionary.
    Usefull to convert NamedTuple to json dumps.
    """
    if isinstance(obj, dict):
        return {key: unpack(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [unpack(value) for value in obj]
    elif isnamedtupleinstance(obj):
        return {key: unpack(value) for key, value in obj._asdict().items()}
    elif isinstance(obj, tuple):
        return tuple(unpack(value) for value in obj)
    else:
        return obj


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Loading")
    parser.add_argument("datasource", help="DataSource")
    args = parser.parse_args()
