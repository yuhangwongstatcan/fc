"""
Utilities to help with various data loading tasks.
"""
import os
import glob
from modules.io_helpers import safe_read_pandas
import pandas as pd
from pandas import DataFrame
from typing import Optional
from typing import List
from os.path import join
from os.path import dirname
from config.env import environ
from modules.s3client import S3Client
from config.api import S3Location
from config.api import S3
from config.api import Mode
from config.api import Stage
from config.api import DataSource
from config.api import Mapping
from modules.utils.schema import naming
from modules.utils.schema import tuplify

from modules.utils.schema import namedtupe_from_mappping
from dataclasses import field
from dataclasses import dataclass
from dataclasses import asdict
from enum import Enum
from typing import Union
from cachetools import cached
from cachetools.keys import hashkey
from typing import Callable

from modules.utils.schema import load_datasource_schema


class MockMinIO:
    @staticmethod
    def root():
        return join(dirname(__file__), "..", "..", "tests", "mock_minio")


class Transform(object):
    @staticmethod
    def dim2keys(df: DataFrame, idx: int = 0) -> "Tuplify":
        values = df.iloc[:, idx].tolist()
        obj = {f"v_{naming(val).upper()}": val for val in values}
        obj.update({"VALUES": values})
        return tuplify(obj)

    @staticmethod
    def map2obj(df: DataFrame, key_idx: int = 0, val_idx: int = 1) -> "Tuplify":
        keys, values = df.iloc[:, key_idx].tolist(), df.iloc[:, val_idx].tolist()
        obj = {
            f"k_{naming(k).upper()}": {"key": k, "value": v}
            for k, v in zip(keys, values)
        }
        # obj.update({
        #     "MAPS": {k:v for k,v in zip(keys,values)}
        # })
        tmp = namedtupe_from_mappping({"value": {k: v for k, v in zip(keys, values)}})
        # tmp.MAPS -> dict
        # tuplify(obj) -> obj.tmp -> Tuplify, obj.tmp.MAPS -> dict
        obj.update({"MAPS": tmp})
        # obj.maps.MAPS
        return tuplify(obj)


@dataclass
class DataLoader(object):
    datasource: DataSource
    stage: Stage
    client: S3Client = field(init=False)

    def __post_init__(self):
        self.client = S3Client.get_client()

    def load(self, basename: str) -> DataFrame:
        loc = S3.get_loc(self.stage, self.datasource, basename)
        df = self.client.get_CSV(loc, keep_default_na=False, na_values="",)
        return df  # .fillna(pd.NA)

    def copy(
        self,
        loc: S3Location,
        basename: str,
        fallback_on_conflicts=False,
        fallback_on_historical=False,
    ):
        return self.client.cp_loc_to_stage(
            loc,
            self.stage,
            self.datasource,
            basename,
            fallback_on_historical=fallback_on_historical,
            fallback_on_conflicts=fallback_on_conflicts,
        )

    def copy_dir(
        self, loc: S3Location, fallback_on_conflicts=False, fallback_on_historical=False
    ):
        return self.client.cp_loc_prefix_to_stage(
            loc,
            self.stage,
            self.datasource,
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )

    def upload(
        self,
        localpath: str,
        basename: str,
        fallback_on_conflicts=False,
        fallback_on_historical=False,
    ):
        return self.client.upload_file_to_stage(
            localpath,
            self.stage,
            self.datasource,
            basename=basename,
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )


@dataclass
class TestIndexLoader(object):
    datasource: DataSource
    stage: Stage

    @cached(
        cache={},
        key=lambda self, basename: hashkey(
            self.datasource.value, self.stage.value, basename
        ),
    )
    def load(self, basename: str) -> DataFrame:
        loc = S3.get_loc(self.stage, self.datasource, basename)
        df = pd.read_csv(
            join(MockMinIO.root(), loc.prefix, loc.basename), keep_default_na=False
        )
        return df


@dataclass
class TestDataLoader(object):
    datasource: DataSource
    stage: Stage

    def load(self, basename: str) -> DataFrame:
        loc = S3.get_loc(self.stage, self.datasource, basename)
        schema = load_datasource_schema(self.datasource, self.stage)
        df = pd.read_csv(
            join(MockMinIO.root(), loc.prefix, loc.basename),
            keep_default_na=False,
            na_values="",
        ).fillna(pd.NA)
        return schema.validate(df)


@dataclass
class QueryLoader(object):
    datasource: DataSource
    stage: Stage

    def load(
        self,
        year: Optional[int] = None,
        month: Optional[int] = None,
        day: Optional[int] = None,
    ) -> Optional[DataFrame]:
        client = S3Client.get_client()
        basename = (
            S3.get_s3_basename(self.stage, self.datasource, year, month, day)
            if year and month and day
            else ""
        )
        loc = S3.prefix(
            self.stage,
            Mode.file,
            self.datasource,
            year=year,
            month=month,
            basename=basename,
        )
        params = {
            "loc": loc,
            "keep_default_na": False,
            "na_values": "",
        }
        condition = year and month and day
        df = client.get_CSV(**params) if condition else client.get_CSVs(**params)
        return df  # .fillna(pd.NA)


@dataclass
class TestQueryLoader(object):
    datasource: DataSource
    stage: Stage

    def load(
        self,
        year: Optional[int] = None,
        month: Optional[int] = None,
        day: Optional[int] = None,
    ) -> Optional[DataFrame]:
        if year and month and day:
            basename = S3.get_s3_basename(self.stage, self.datasource, year, month, day)
            loc = S3.prefix(
                self.stage,
                Mode.file,
                self.datasource,
                year=year,
                month=month,
                basename=basename,
            )
            PATH = join(MockMinIO.root(), loc.prefix, loc.basename)
            filenames = [PATH]
        else:
            loc = S3.prefix(
                self.stage, Mode.file, self.datasource, year=year, month=month
            )
            PATH = join(MockMinIO.root(), loc.prefix)
            filenames = [
                file
                for path, subdir, files in os.walk(PATH)
                for file in sorted(glob.glob(os.path.join(path, "*.csv")))
            ]

        schema = load_datasource_schema(self.datasource, self.stage)
        dfs = [
            pd.read_csv(f, skip_blank_lines=True, keep_default_na=False,na_values="")
            #safe_read_pandas(f, schema)
            for f in filenames
            if os.path.exists(f)
        ]
        if not dfs:
            return None
        concat = pd.concat(dfs, ignore_index=True)
        return schema.validate(concat)


@dataclass
class FileBasedDataLoader(DataLoader):
    datasource: DataSource
    stage: Stage = Stage.REFERENCE

    def load(self, basename: Enum) -> DataFrame:
        return super().load(f"{basename.value}.csv")

    def copy(
        self,
        loc: S3Location,
        basename: Enum,
        fallback_on_conflicts=False,
        fallback_on_historical=False,
    ):
        return super().copy(
            loc,
            f"{basename.value}.csv",
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )

    def copy_dir(
        self, loc: S3Location, fallback_on_conflicts=False, fallback_on_historical=False
    ):
        return super().copy_dir(
            loc,
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )

    def upload(
        self,
        localpath: str,
        basename: Enum,
        fallback_on_conflicts=False,
        fallback_on_historical=False,
    ):
        return super().upload(
            localpath,
            f"{basename.value}.csv",
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )

@dataclass
class MappingLoader(FileBasedDataLoader):
    datasource: DataSource = DataSource.mapping
    stage: Stage = Stage.REFERENCE

    def obj(self, mapping: Mapping) -> "Tuplify":
        return Transform.map2obj(self.load(mapping))

    def load(self, mapping: Mapping) -> DataFrame:
        return super().load(mapping)


@dataclass
class TestFileBasedDataLoader(TestDataLoader):
    datasource: DataSource
    stage: Stage = Stage.REFERENCE

    @cached(
        cache={},
        key=lambda self, basename: hashkey(self.datasource.value, basename.value),
    )
    def load(self, basename: Enum) -> DataFrame:
        return super().load(f"{basename.value}.csv")


@dataclass
class TestMappingLoader(TestFileBasedDataLoader):
    datasource: DataSource = DataSource.mapping
    stage: Stage = Stage.REFERENCE

    def obj(self, mapping: Mapping) -> "Tuplify":
        return Transform.map2obj(self.load(mapping))

    def load(self, mapping: Mapping) -> DataFrame:
        return super().load(mapping)


@dataclass
class MergeDataSource:
    stage: Stage
    datasource: DataSource
    basename: Union[None, str, Mapping] = None


class Loader(object):
    """
    **Description:**

    Loader  containg static methods for
    file-base data sources, dimensions, and mappings.



    **Examples:**

    ```python
    map_obj = Loader.get_map_obj(Mapping.dim_<name>)
    map_obj.k_XX.key
    map_obj.k_XX.value
    map_obj.MAPS = {k:v}

    map_df  = Loader.get_map_df(Mapping.map_<name>)



    ```
    """

    @staticmethod
    def __instance__(prod: Callable, test: Callable):
        return test() if environ().FC_USE_MOCK_MINIO else prod()

    @staticmethod
    def get(
        stage: Stage,
        datasource: DataSource,
        basename: Union[None, str, Mapping],
    ) -> DataFrame:
        if datasource in DataSource.timebased():
            return Loader.__get_df__(stage, datasource, basename)
        else:
            return Loader.__get_fb_df__(stage, datasource, basename)

    @staticmethod
    def merge(
        left_table: Union[MergeDataSource, pd.DataFrame],
        right_table: MergeDataSource,
        left_on: List,
        right_on: List,
        left_subset: List = [],
        right_subset: List = [],
        **kwargs,
    ) -> pd.DataFrame:
        """
        **Description:**

        A thin wrapper over Pandas merge to avoid the need of loading dataframes just to merge
        them to existing dataframes. Semantics are one of the following:

        1. Either pass two instances of MergeDataSource, and Loader.merge returns a pandas
           dataframe.
        2. Pass an existing pandas dataframe (left) and specify an instance of MergeDataSource
           as the right table in the merge.

        In either case, the user can specify a subset of columns they want joined (e.g. if they
        only want a small subset of either table to actually be merged). The user can also pass
        any keyword args they would pass to `pd.merge`.

        Examples:
            ```
            [description]
            ```

        Args:
            left_table: Union[MergeDataSource, pd.DataFrame]
                [description]. Valid Values are [values]
            right_table: MergeDataSource
                [description]. Valid Values are [values]
            left_on: List
                [description]. Valid Values are [values]
            right_on: List
                [description]. Valid Values are [values]

        Kwargs:
            left_subset: List=[]
                [description]. Valid Values are [values]
            right_subset: List=[]
                [description]. Valid Values are [values]

        Returns:
            pd.DataFrame:
                [description]. Valid Values are [values]
        """
        # Load left table if left_table is an instance of MergeDataSource, otherwise just keep
        # the pd.DataFrame that was passed.
        left_table = (
            Loader.get(**asdict(left_table))
            if isinstance(left_table, MergeDataSource)
            else left_table
        )
        if left_subset:
            left_table = left_table[left_subset]
        # Load right table
        right_table = Loader.get(**asdict(right_table))
        if right_subset:
            right_table = right_table[right_subset]
        # Do merge
        return pd.merge(
            left_table, right_table, left_on=left_on, right_on=right_on, **kwargs
        )

    @staticmethod
    def query(
        stage: Stage,
        datasource: DataSource,
        year: Optional[int] = None,
        month: Optional[int] = None,
        day: Optional[int] = None,
    ):
        loader = Loader.__instance__(
            lambda: QueryLoader(datasource, stage),
            lambda: TestQueryLoader(datasource, stage),
        )
        return loader.load(year, month, day)

    @staticmethod
    def __get_df__(stage: Stage, datasource: DataSource, basename: str) -> DataFrame:
        loader = Loader.__instance__(
            lambda: DataLoader(datasource, stage),
            lambda: TestDataLoader(datasource, stage),
        )
        return loader.load(basename)

    @staticmethod
    def __get_fb_df__(stage: Stage, datasource: DataSource, obj: Enum) -> DataFrame:
        loader = Loader.__instance__(
            lambda: FileBasedDataLoader(datasource, stage),
            lambda: TestFileBasedDataLoader(datasource, stage),
        )
        return loader.load(datasource) if obj is None else loader.load(obj)

    @staticmethod
    def get_datasource_index(stage: Stage, datasource: DataSource) -> DataFrame:
        """
        Gets the index file for a data source. Note: you must run this with the environment variable
        FC_USE_MOCK_MINIO=1 set.
        """
        loader = TestIndexLoader(datasource, stage)
        tmp = loader.load(f"{datasource.value}__{stage.name.lower()}__index.csv")
        return tmp

    @staticmethod
    def get_map_obj(mapping: Mapping) -> "Tuplify":
        """
        Gets a mapping from a reference file for given
        tables/columns in "Tuplicy" object form.

        Args:
            mapping (Mapping): A value of the Mapping enumerator
            found in config.api.

        Returns:
            Tuplify: An instance of the "Tuplify" object containing
            the requested Mapping.

        ## Example:

            ```python
            from config.api import Mapping
            from modules.utils.loaders import Loader
            # Load the mapping between the `rescntry` column of `pik` (RAW)
            # and the `country_of_residence` column of `pik` (CLEAN).
            Loader.get_map_obj(Mapping.map__pik__raw__rescntry__pik__clean__country_of_residence)
            ```
        """
        loader = Loader.__instance__(
            lambda: MappingLoader(), lambda: TestMappingLoader()
        )
        return loader.obj(mapping)

    @staticmethod
    def get_map_df(mapping: Mapping) -> pd.DataFrame:
        """
        Gets a mapping from a reference file for given
        tables/columns in pandas dataframe form.

        Args:
            mapping (Mapping): A value of the Mapping enumerator
            found in config.api.

        Returns:
            pd.DataFrame: A pandas dataframe containing the
            requested mapping.

        ## Example:

            ```python
            from config.api import Mapping
            from modules.utils.loaders import Loader
            # Load the mapping between the `reporting_location` column of
            # `trc` (RAW) and the `work_location` column of `trc` (CLEAN).
            work_locations = Loader.get_map_df(
                Mapping.map__trc__raw__reporting_location__trc__clean__work_location
            )
            ```
        """
        loader = Loader.__instance__(
            lambda: MappingLoader(), lambda: TestMappingLoader()
        )
        return loader.load(mapping)


class Uploader(object):
    @staticmethod
    def copy(
        loc: S3Location,
        datasource: DataSource,
        fallback_on_conflicts=False,
        fallback_on_historical=False,
    ):
        return FileBasedDataLoader(datasource).copy(
            loc,
            datasource,
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )

    @staticmethod
    def copy_dir(
        loc: S3Location,
        stage: Stage,
        datasource: DataSource,
        fallback_on_conflicts=False,
        fallback_on_historical=False,
    ):
        return FileBasedDataLoader(datasource, stage).copy_dir(
            loc,
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )
