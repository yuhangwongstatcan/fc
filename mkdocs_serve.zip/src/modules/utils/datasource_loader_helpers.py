class InvalidDateError(Exception):
    """
    An exception for when the date cannot be properly parsed
    """

    def __init__(self, invalid_string):
        self.invalid_string = invalid_string
        self.message = f"The provided date is invalid: {invalid_string}"
        super().__init__(self.message)


class InvalidPortError(Exception):
    """
    An exception for when the date cannot be properly parsed
    """

    def __init__(self, invalid_string):
        self.invalid_string = invalid_string
        self.message = f"A port number could not be found: {invalid_string}"
        super().__init__(self.message)
