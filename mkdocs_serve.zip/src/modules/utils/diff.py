#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# Author: Andres Solis Montero
# -----------------------------------------------------------

import numpy as np
import pandas as pd
from enum import Enum
from pandas import DataFrame
from dataclasses import dataclass, field
from typing import List


class Column(str, Enum):
    """
    Column names used for TabularDiff
    """

    lnumber = "#line"
    action  = "#status"


class Action(str, Enum):
    """
    Possible Actions for in a TabularDiff
    """

    missing = "-"
    new = "+"
    duplicated = "="
    mconflict = "-@"
    nconflict = "+@"

    @classmethod
    def get_action(cls, value):
        for a in Action:
            if a.value == value:
                return a
        raise ValueError(f"No action with value:{value}")


@dataclass
class DiffStats:
    """
    Class Holding Stats regarding to the TabularDiff
    """

    total: int = 0
    duplicated: int = 0
    conflicts: int = 0
    missing: int = 0
    new: int = 0
    filtered: int = 0


@dataclass
class TabularDiff:
    """
    Class to compute TabularDiff of two DataFrames given a list of key columns.
    """

    A: DataFrame
    B: DataFrame
    indices: List
    columns: List = field(default_factory=list)
    _diff_: DataFrame = None
    _filter_: List = field(default_factory=list)
    _computed_: bool = False
    _stats_: DiffStats = None

    @property
    def stats(self) -> DiffStats:
        """
        Returns a DiffStats object containing stats related to the TabularDiff
        """
        if not self._computed_:
            self.compute()
        return self._stats_

    def __filtered_diff__(self) -> np.ndarray:
        """
        Internal function that applies filters to the diff result
        """
        if not self._computed_:
            self.compute()
        filter = self.__get_filter__()
        filtered = self._diff_[filter] if filter is not None else self._diff_
        self._stats_.filtered = filtered.shape[0]
        return filtered

    def __get_filter__(self) -> np.array:
        """
        Internal function that generates a boolean filter given the list of Actions
        """
        if self._filter_:
            filter = self._diff_[Column.action.value] == "X"
            for action in self._filter_:
                if action == Action.mconflict or action == Action.nconflict:
                    filter |= self._diff_[Column.action.value].str.startswith(
                        Action.mconflict.value
                    )
                    filter |= self._diff_[Column.action.value].str.startswith(
                        Action.nconflict.value
                    )
                else:
                    filter |= self._diff_[Column.action.value] == action.value
            return filter
        return None

    def filter(self, filters: List[Action]) -> None:
        """
        Sets a list of Action filters. An empty list will not apply any filter.
        """
        self._filter_ = filters

    @property
    def diff(self) -> DataFrame:
        """
        Returns the diff between A and B DataFrames
        """
        if not self._computed_:
            self.compute()
        return self._diff_

    @property
    def merge(self) -> DataFrame:
        """
        Automatic Merge combining duplicates + missing + new records(rows).
        Conflicts are automatically resolved by selecting the newer record.
        """
        if not self._computed_:
            self.compute()
        return self._diff_[
            ~self._diff_[Column.action.value].str.startswith(Action.mconflict.value)
        ].iloc[:, 2:]

    def page(self, page=1, limit=1000) -> DataFrame:
        filtered = self.__filtered_diff__()
        page = max(page, 1)
        page = min(page, filtered.shape[0] // limit + 1)
        offset = (page - 1) * limit
        return filtered.iloc[offset: offset + limit, :]

    def compute(self) -> None:
        self.A = self.A.applymap(str)
        self.B = self.B.applymap(str)
        self.A.fillna("", inplace=True)
        self.B.fillna("", inplace=True)

        # Columns that are not indices
        self.A.insert(loc=0, column=Column.action.value, value=Action.missing.value)
        self.B.insert(loc=0, column=Column.action.value, value=Action.new.value)

        self.A.insert(loc=0, column=Column.lnumber.value, value=0)
        self.B.insert(loc=0, column=Column.lnumber.value, value=0)

        self.columns = self.A.columns.values.tolist()
        actions = [Column.lnumber.value, Column.action.value]
        non_idxs_columns = [
            c for c in self.columns if c not in self.indices and c not in actions
        ]

        M = pd.concat([self.A, self.B], ignore_index=True)
        M = M.sort_values(
            by=self.indices + non_idxs_columns + [Column.action.value],
            ignore_index=True,
        )

        col_idx_map = {n: i for i, n in enumerate(self.columns)}
        col_idxs = [col_idx_map[n] for n in self.columns if n not in actions]
        ind_idxs = [col_idx_map[n] for n in self.indices]

        ln_col_idx = col_idx_map[Column.lnumber.value]
        act_col_idx = col_idx_map[Column.action.value]

        M1 = M.to_numpy()
        cursor, count = 0, 0
        self._diff_ = []
        self._stats_ = DiffStats()

        while cursor < M1.shape[0]:
            M1[cursor, ln_col_idx] = count
            self._stats_.total += 1
            if cursor == M1.shape[0] - 1:
                # Last row in the dataframe, nothing to compare to
                self._diff_.append(M1[cursor])
            # Two consecutive rows from different data source
            elif M1[cursor, act_col_idx] == M1[cursor + 1, act_col_idx]:
                # Two continuos rows from the same source
                self._diff_.append(M1[cursor])
            elif (M1[cursor, col_idxs] == M1[cursor + 1, col_idxs]).all():
                # Found a duplicated entry
                M1[cursor, act_col_idx] = Action.duplicated.value
                M1[cursor + 1, act_col_idx] = Action.duplicated.value
                self._diff_.append(M1[cursor])
                cursor += 1

            elif (
                self.indices
                and (M1[cursor, ind_idxs] == M1[cursor + 1, ind_idxs]).all()
            ):
                # conflict if all the ind_idxs have the same value
                pos = [str(i) for i in col_idxs if M1[cursor, i] != M1[cursor + 1, i]]
                M1[cursor, act_col_idx] = Action.mconflict.value + ",".join(pos)
                M1[cursor + 1, act_col_idx] = Action.nconflict.value + ",".join(pos)
                M1[cursor + 1, ln_col_idx] = ""
                self._diff_.append(M1[cursor])
                self._diff_.append(M1[cursor + 1])
                cursor += 1

                # count = count + 1
            else:
                # indices are not the same, different rows
                self._diff_.append(M1[cursor])

            action = self._diff_[-1][act_col_idx][:2]
            if action == Action.duplicated.value:
                self._stats_.duplicated += 1
            elif action == Action.nconflict.value or action == Action.mconflict.value:
                self._stats_.conflicts += 1
            elif action == Action.missing.value:
                self._stats_.missing += 1
            elif action == Action.new.value:
                self._stats_.new += 1
            cursor += 1
            count += 1
        self._diff_ = DataFrame(np.stack(self._diff_, axis=0), columns=self.columns) \
                            if len(self._diff_) > 0 else DataFrame(columns=self.columns)
        self._computed_ = True


if __name__ == "__main__":
    pass
