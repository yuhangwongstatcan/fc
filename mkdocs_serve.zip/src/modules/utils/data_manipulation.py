"""
Some helper functions to make data manipulation in Pandas easier for specialized
operations.
"""
import os

import importlib

from datetime import datetime
import pathlib
import re
import shutil
import tempfile
from typing import Any, List
from os.path import basename
from os.path import join
import zipfile
from modules.s3client import S3Client
import numpy as np
import pandas as pd
import pandera as pa
from pandera import DataFrameModel, Column 
from config.api import S3
from config.api import S3Location
from config.api import DataSource

from config.api import Stage


def explode(
    df: pd.DataFrame, lst_cols: List, fill_value: Any = "", preserve_index: bool = False
):
    """
    Borrowed from this SO answer: https://stackoverflow.com/a/40449726

    Uses list syntax to split a row of a dataframe into multiple rows.
    See link for more detailed explanation.

    Args:
        df: a pandas dataframe that is ready to have explode() applied to it.
        lst_cols: a python list containing the columns to explode on.
        fill_value: the value to fill missing values with by default.
        preserve_index:
            a bool indicating whether the original index values should be
            preserved.
    Returns:
        a pandas dataframe that has has rows split into multiple rows.
    """
    # make sure `lst_cols` is list-alike
    if (
        lst_cols is not None
        and len(lst_cols) > 0
        and not isinstance(lst_cols, (list, tuple, np.ndarray, pd.Series))
    ):
        lst_cols = [lst_cols]
    # all columns except `lst_cols`
    idx_cols = df.columns.difference(lst_cols)
    # calculate lengths of lists
    lens = df[lst_cols[0]].str.len()
    # preserve original index values
    idx = np.repeat(df.index.values, lens)
    # create "exploded" DF
    res = pd.DataFrame(
        {col: np.repeat(df[col].values, lens) for col in idx_cols}, index=idx
    ).assign(**{col: np.concatenate(df.loc[lens > 0, col].values) for col in lst_cols})
    # append those rows that have empty lists
    if (lens == 0).any():
        # at least one list in cells is empty
        res = res.append(df.loc[lens == 0, idx_cols], sort=False).fillna(fill_value)
    # revert the original index order
    res = res.sort_index()
    # reset index if requested
    if not preserve_index:
        res = res.reset_index(drop=True)
    return res


def is_col_a_dim(col: pa.Column) -> bool:
    """Checks if a Pandera schema column is a DIM.
    This check assumes that all schema columns using an "isin" check are DIMs.

    Args:
        col (pa.schema_components.Column): A Pandera schema columns, accessible from a Pandera SchemaModel using
                                           schema.to_schema().columns['col_name']

    Returns:
        bool: True if the column contains an "isin" check, False if not
    """
    checks = col.checks
    # If there are no checks, it's not a dim
    if len(checks) < 0:
        return False
    for check in checks:
        # It is a dim if one of the checks is isin
        if check.name == "isin":
            return True
    # Otherwise it is not a dim
    return False


def import_dim_values(modulename, name):
    try:
        module = __import__(modulename, globals(), locals(), [name])
    except ImportError:
        return None
    return vars(module)[name].list()


def validate_dimensions(
    df: pd.DataFrame,
    raw_schema: pa.DataFrameModel, # Change from pa.SchemaModel
    val_schema: pa.DataFrameModel, # Change from pa.SchemaModel
    cname_loc: str,
    cname_date: str,
    datasource: DataSource,
) -> pd.DataFrame:
    schema_cols = raw_schema.to_schema().columns
    # From the schema columns, select only the dimensions (as defined by is_col_a_dim) that are flagged as required
    dim_list = [
        col.upper()
        for col in schema_cols
        if is_col_a_dim(schema_cols[col]) and schema_cols[col].required
    ]

    dims = {}
    for dimension in dim_list:
        cname = dimension.lower()
        dims[cname] = import_dim_values(f"datasource.{datasource.name}.dim", dimension)
        # Casting dimension values to string if not string, otherwise the code below incorrectly
        # identifies unexpected values. E.g: purpimm has valid values of 0 and 1 but the comparison
        # 1=="1" will return False because types don't match.
        if all(isinstance(n, int) or isinstance(n, float) for n in dims[cname]):
            dims[cname] = list(map(str, dims[cname]))

    # helper function to compute frequency of not possible values of a dimension column
    def freq_counter(
        df: pd.DataFrame, cname: str, possible_values: list, loc: str, date: str
    ) -> pd.DataFrame:
        """ """

        cols = [cname, date, loc]
        _df = df[~df[cname].isin(possible_values)][cols]
        # Note: we need to fill NA values here with some placeholder (e.g. "NaN"),
        # otherwise groupby will drop the rows that have pd.NA values.
        _df = _df.groupby(cols, dropna=False).size().to_frame()
        _df.reset_index(inplace=True)
        _df.rename(
            columns={
                cname: val_schema.unexpected_value,
                date: cname_date,
                loc: val_schema.location,
                0: val_schema.count,
            },
            inplace=True,
        )
        _df.insert(0, val_schema.variable, cname)

        return _df

    # concatenate all frequency counter by column dimensions
    return pd.concat(
        (
            freq_counter(df, column, values, cname_loc, cname_date)
            for column, values in dims.items()
        ),
        ignore_index=True,
    )


def work_locations_recode(
    df: pd.DataFrame,
    wl_trans: pd.DataFrame,
    wl_action: pd.DataFrame,
    wl_trans_action: pd.DataFrame,
    work_location_column: "Tuplify",
    TransSchema: pa.DataFrameModel,      # Change
    ActionSchema: pa.DataFrameModel,     # Change
    TransActionSchema: pa.DataFrameModel, # Change
    ACTION,
    **kwargs,
) -> pd.DataFrame:
    """
    Implements the logic to apply vehicle type recodings to input data based on
    work location tables. The procedure to apply these recodings work as follows:

    First, we create a temporary `__trans__` column to hold the transportation type
    (vehicle type) using the work location trans table. For each row in this table, we
    evaluate which rows match a certain condition and assign the corresponding transportation
    type value to these rows.

    Next, now that each row has an associated `__trans__` column, we can use this
    new column to do a left join with the work location trans action table on columns
    __trans__ and work location.

    Next, we get the recode codes dimension.

    Finally, for any rows that require a recoding action (i.e. the default behaviour is not
    to accept/reject/etc.), we go through row-by-row and apply the appropriate recoding
    using the `apply_action` inner function.

    Any recode_codes that are not "accept" by default (i.e. the code `A`) are stored in an
    auxiliary dataframe that is returned along with the processed output. The purpose of
    `auxiliary_df` is to pass data to the validation function that will write validation
    data about which rows were recoded. This validation data is consumed by PowerBI
    visualizations created by the Frontier Counts production team.

    Args:
        df (pd.DataFrame): The input for the data source we are about to apply
        work location recoding to.
        datasource (DataSource): The enum value in config.api.DataSource
        indicating what data source the function is called on.
        wl_trans (pd.DataFrame): The [work location trans]() reference table.
        wl_action (pd.DataFrame): The [work location action]() reference table.
        wl_trans_action (pd.DataFrame): The [work location trans action]() reference table.
        work_location_column (Tuplify): The name of the column that contains the work
        location in the given data source. Note that this is necessary because not
        every data source from CBSA refers to the work location column using a
        standard name (e.g. sometimes it is `wloc`, `work_location`, etc).

    Returns:
        RuleOutput: An instance of `config.api.RuleOutput` which contains the dataframe
        produced by this function, any auxiliary data that needs to be used by the
        corresponding work locations recode validation, and the data source currently
        being processed.
    """

    # Create a temporary column named __trans__
    trans_col = "__trans__"
    df.loc[:, trans_col] = pd.NA
    # Iterate over all the work_location_transs.
    for _, row in wl_trans.iterrows():
        trans = row[TransSchema.transportation_type]
        query = row[TransSchema.query]
        df.loc[df.eval(query), trans_col] = trans

    # df.cols, wl_trans_action.action {D1,D2,D3, ..., Dn}
    df = pd.merge(
        df,
        wl_trans_action[
            [
                TransActionSchema.action,
                TransActionSchema.work_location,
                TransActionSchema.transportation_type,
            ]
        ],
        how="left",
        left_on=[work_location_column, trans_col],
        right_on=[
            TransActionSchema.work_location,
            TransActionSchema.transportation_type,
        ],
    )
    df.loc[
        df[TransActionSchema.action].isna(), TransActionSchema.action
    ] = ACTION.X.value
    actions = {}
    # Generate a dictionary structure containing all data source actions
    # as a list of object {column:"column_name", value:"value to be set"}
    # The action key, is a valid dimension D1, D2, ... , Dn
    for _, row in wl_action.iterrows():
        action = row[ActionSchema.action]
        column = row[ActionSchema.column]
        value = row[ActionSchema.value]

        actions.setdefault(action, []).append(
            {ActionSchema.column: column, ActionSchema.value: value}
        )
    # This is faster
    # wl_action.apply(lambda row: actions.setdefaults(row[wl_action_sch.row.name], []).append({
    #     wl_action_sch.column.name : column,
    #     wl_action_sch.value.name  : value
    # }) or row , axis=1)

    def apply_action(row: pd.Series) -> pd.Series:
        """
        Given a row's action column value, apply the list of actions
        associated to it.
        """
        try:
            for action in actions[row[TransActionSchema.action]]:
                row[action[ActionSchema.column]] = action[ActionSchema.value]
        except KeyError:
            pass
        return row

    # only apply changes in rows that are not D1
    mask = (
        (df[TransActionSchema.action] != ACTION.accept.value)
        & (df[TransActionSchema.action] != ACTION.X.value)
        & (df[TransActionSchema.action] != ACTION.confront.value)
        & (df[TransActionSchema.action] != ACTION.supplementary.value)
        & (df[TransActionSchema.action] != ACTION.test.value)
    )
    if any(mask):
        df.loc[mask, :] = df.loc[mask, :].apply(apply_action, axis=1)
    # For the heatmap/unexpected values validation, we want to keep all rows that were not (1)
    # accepted by default ('A') (2) Confronted by default ('C') or (3) Flagged as test ports ('T').
    # I.e. we want to log rows where a particular recoding rule was applied ('RXXX') or there was
    # no match (df["action"] is null).
    # Drop any rows that are invalid or belong to known test ports

    # confront actions are dropped for e311, but not for other datasources
    # if (datasource == DataSource.e311):
    #         selection_mask = ~df[wl_trans_action_sch.action.name].isin([recode_codes.v_T, recode_codes.v_X, recode_codes.v_C])
    #         aux_mask = ~df[wl_trans_action_sch.action.name].isin(       # anything not "accepted by default"
    #             [recode_codes.v_A]
    #         )
    # else:
    selection_mask = ~df[TransActionSchema.action].isin(
        [ACTION.test.value, ACTION.X.value, ACTION.confront.value, ACTION.supplementary.value]
    )
    aux_mask = ~df[TransActionSchema.action].isin([ACTION.accept.value])

    auxiliary_df = df[aux_mask]
    df = df[selection_mask]

    return df, auxiliary_df


def unzip(localname, dirpath):
    if zipfile.is_zipfile(localname):
        print(f"extracting: {localname}")
        with zipfile.ZipFile(localname, "r") as zip_ref:
            zip_ref.extractall(dirpath)


def process_vt_historical_data(
    client: S3Client,
    location: S3Location,
    stage: Stage,
    datasource: DataSource,
    schema: pa.DataFrameModel,
) -> bool:
    zippath = tempfile.mkdtemp()

    print(f"Inspecting s3 location: {location.bucket} {location.prefix}")

    # List all the files inside the S3Location looking for zip or sigular .dat files.
    # All files are download and extracted in a temporary local folder.

    print(f"\tDownloaded:")
    for obj in client.ls_objs(
        location.bucket,
        recursive=True,
        prefix=location.prefix,
        only_files=True,
        default_folder_file=False,
    ):
        localname = join(zippath, basename(obj.object_name))
        client.fget_object(location.bucket, obj.object_name, localname)
        print(f"\t\t{localname}")
        unzip(localname, zippath)

    files = sorted([f.as_posix() for f in pathlib.Path(zippath).rglob("*.csv")])

    localnames = set([])
    tmpdir = tempfile.mkdtemp()
    for f in files:
        try:
            # Some files appear to be tab delimited while others appear to be comma delimited.
            # Adding some logic to detect and apply the appropriate call to pd.read_csv - Collin
            tab = pd.read_csv(f, nrows=1, sep="\t").shape[1]
            com = pd.read_csv(f, nrows=1, sep=",").shape[1]
            if tab > com:
                df = pd.read_csv(f, dtype=str, sep="\t")
            else:
                df = pd.read_csv(f, dtype=str, sep=",")
            # The column called `plate_region` has a special value of "NA", which should
            # be used in place of the default np.NaN or pd.NA values.
            df[schema.plate_region] = df[schema.plate_region].fillna("NA")
            gdf = df.groupby([schema.year, schema.month])

            for year, month in gdf.groups:
                _df = gdf.get_group((year, month))
                filename = S3.get_s3_basename(
                    stage, datasource, int(year), int(month), 1
                )
                localname = join(tmpdir, filename)
                localnames.add(localname)
                _df.to_csv(localname, index=False, header=True)

            print(f"File Processed: {basename(f)}")
        except Exception as e:
            print(e)
            print(f"Error File: {basename(f)}")
            continue
    print(f"\tFile Uploaded:")
    for f in localnames:
        dst = client.upload_file_to_stage(f, stage, datasource, basename=basename(f))
        print(f"\t\t{dst} ")

    shutil.rmtree(zippath)
    shutil.rmtree(tmpdir)
    return True


def process_files(
    files: list,
    tmpdir: str,
    stage: Stage,
    datasource: DataSource,
    schema_date_column: str,
    input_date_format: str = "(\d{4})\/(\d{2})\/(\d{2})",
    input_separator: str = ",",
    input_header: str = None,
    fb_y=2021,
    fb_m=1,
):
    localnames = set([])
    date_pattern = re.compile(input_date_format)

    print("Processing Files")
    for f in files:
        try:
            # read file using serparator and header flags
            df = pd.read_csv(f, sep=input_separator, header=input_header)

            # If date is not filled out, then this is not a valid record (i.e. we do not know when
            # the crossing happened).
            df[schema_date_column] = df[
                schema_date_column
            ].str.strip()  # Strip white space from missing values
            # group by data by column name
            gdf = df.groupby(schema_date_column)
            # separate df into groups
            dfs = {_date: gdf.get_group(_date) for _date in gdf.groups}

            # Most repeated year,month that matches the pattern
            count = -1
            for _date, _df in dfs.items():
                match = date_pattern.match(_date)
                if match and _df.shape[0] > count:
                    fb_y, fb_m, _ = match.groups()
                    count = _df.shape[0]

            for _date, _df in dfs.items():
                match = date_pattern.match(_date)
                year, month, day = match.groups() if match else (fb_y, fb_m, _)
                filename = S3.get_s3_basename(
                    stage, datasource, int(year), int(month), int(day)
                )
                localname = join(tmpdir, filename)
                localnames.add(localname)
                _df.to_csv(localname, mode="a", index=False, header=None)

            print(f"File Processed: {basename(f)}")
        except Exception as e:
            print(f"Error File: {basename(f)}")
            return False
    return localnames


def upload_files(
    client: S3Client,
    files: list,
    stage: Stage,
    datasource: DataSource,
    schema: pa.DataFrameModel,
    sort_keys: List,
    fallback_on_conflicts: bool = True,
    fallback_on_historical: bool = False,
):
    # Create the list of true raw variables to be kept by taking out the optional cases
    all_columns = list(schema.to_schema().columns.keys())
    optional_columns = []
    for column in all_columns:
        if schema.to_schema().columns[column].required == False:
            optional_columns.append(column)
    raw_columns = [column for column in all_columns if column not in optional_columns]

    print(f"\tFile Uploaded:")
    for filename in files:
        # Make sure you sort the data and place the headers
        df = pd.read_csv(filename, header=None)
        # Pandas will silently cast the type of any numeric column with a
        # missing value to np.float64. In the context of Frontier Counts,
        # this is **never** the intended behaviour (i.e. we are always
        # counting travellers/vehicles and all of their characteristics are
        # enumerable types or dates). The ONE exception to this is when we
        # are triaging the seasonally adjusted data that arrives in the inbox.
        # In the case of ndm_adjusted data, we do not perform this type
        # conversion.
        if datasource != DataSource.ndm_adjusted:
            try:
                df.loc[:, df.dtypes == np.float64] = (
                    df.loc[:, df.dtypes == np.float64]
                    .astype("Int64")
                    .astype("string")
                    .astype("object")
                )
            # Exception can occur in E63 Excel files in the TIME field where it is recorded
            # as a float that cannot be coerced to an integer, so in the exception block
            # we send it directly to string and on to object
            except TypeError:
                df.loc[:, df.dtypes == np.float64] = (
                    df.loc[:, df.dtypes == np.float64].astype("string").astype("object")
                )
        df.columns = raw_columns
        df = df.sort_values(by=sort_keys)
        df.to_csv(filename, index=False, header=raw_columns)
        # upload to the staging area
        dst = client.upload_file_to_stage(
            filename,
            stage,
            datasource,
            basename=basename(filename),
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )
        print(f"\t\t{dst}")


def partition_historical_validation(ndm_df: pd.DataFrame, ndm_product: DataSource):
    """
    Parititions an old NDM table from the StatCan website into year/month partitions.
    This was used for the historical NDM validation task. A function was added to a module
    like src/datasource/ndm_24100050.py as follows:

    def validation(client: S3Client, stage:Stage, location: S3Location) -> bool:
        \"\"\"
        Extracts Transform and Load pik data from the momentary S3Location.
        This is the loader entry point for the pik datasource.

        Args:
            client: an instance of S3Client.
            location: an instance of S3Location.

        Returns: True
        \"\"\"
        ndm_df = client.get_CSVs(location)
        partition_historical_validation(ndm_df, DataSource.ndm_24100053)
        return True

    """
    s3client = S3Client.get_client()
    # ndm_old = s3client.get_CSV(loc)
    gdf = ndm_df.groupby("REF_DATE")
    tmpdir = tempfile.mkdtemp()
    localnames = set([])
    for date in gdf.groups:
        _df = gdf.get_group(date)
        df_date = datetime.strptime(str(date), "%Y-%m")
        year = int(df_date.year)
        month = int(df_date.month)
        basename = S3.get_s3_basename(Stage.VALIDATION, ndm_product, year, month, 1)
        localname = os.path.join(tmpdir, basename)
        localnames.add(localname)
        _df.to_csv(localname, index=False)
    for filename in localnames:
        # upload to the staging area
        dst = s3client.upload_file_to_stage(
            filename,
            Stage.VALIDATION,
            ndm_product,
            basename=os.path.basename(filename),
            fallback_on_historical=True,
        )
        print(f"\t\t{dst}")
