import json
from typing import Dict
import os
import io

from jinja2 import Environment, FileSystemLoader
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

import io
import base64

from config.api import S3, S3Location, Mode, Stage, DataSource

from modules.s3client import S3Client

from datasource.travellers.schema import TransformedSchema as TravellersSchema

from datasource.common.dim import MODE, VEHICLE_TYPE, PLATE_COUNTRY, DATA_SOURCE
from datasource.travellers.dim import (
    ARRIVING_FROM,
    COUNTRY_OF_RESIDENCE,
    PURPOSE4 as TRAVELLERS_PURPOSE4,
    PURPOSE9 as TRAVELLERS_PURPOSE9,
    TRAVELLER_TYPE,
)


def province_template(province: str, province_code: int, main_heading: str, query: str):

    return {
        [
            {
                "functions": [
                    {"func": "generate_coverage_comparison_table", "kwargs": {}},
                    {
                        "func": "percentage_travellers",
                        "kwargs": {"province": province_code},
                    },
                ],
                "data": "travellers_leading",
                "query": query,
                "kwargs": {},
                "name": "Ports",
                "template": "non_resident_commercial_aircraft.html",
                "province": province,
                "main_heading": main_heading,
                "sub_heading": f"Summary - {province}",
            }
        ]
    }


def generate_port_configs():
    config = get_configuration("leading_indicator_config.json")
    config_args = [
        {
            "province": "Newfoundland and Labrador",
            "province_code": 10,
            "main_heading": "Coverage - Newfoundland and Labrador",
            "query": "(country_of_residence != '11124') & (traveller_type == '1' | traveller_type == '2')",
        },
        {
            "province": "Prince Edward Island",
            "province_code": 11,
            "main_heading": "Coverage - Prince Edward Island",
            "query": "(country_of_residence != '11124') & (traveller_type == '1' | traveller_type == '2')",
        },
    ]
    for i in config_args:
        config[1]["config_list"].append(province_template(**i))

    return config


def get_configuration(config_name: str) -> Dict:
    # Get downstream validation config
    with open(os.path.join("config", config_name), "r") as fd:
        dv = json.load(fd)
    return dv


MONTHS = {
    1: "JAN",
    2: "FEB",
    3: "MAR",
    4: "APR",
    5: "MAY",
    6: "JUN",
    7: "JUL",
    8: "AUG",
    9: "SEP",
    10: "OCT",
    11: "NOV",
    12: "DEC",
}

TRAVELLERS = {1: "Excursionists", 2: "Tourists"}
ARRIVING = {
    1: "United States only,États-Unis seulement",
    2: "Other country direct,Autre pays direct",
    3: "Other country via the United States",
}
PURPOSE9 = {
    21: "Crew",
    31: "Work",
    41: "Immigration",
    42: "Military",
    43: "Other purpose",
}
VEHICLES = {
    111: "Commercial aircraft",
    112: "Cargo aircraft",
    121: "Private aircraft",
    199: "Air (Not available)",
    211: "Automobile",
    212: "Motorcycle",
    213: "Other land vehicle",
    214: "Truck",
    215: "Bus",
    216: "Train",
    217: "Pedestrian",
    299: "Land (Not available)",
    311: "Cruise ship or other commercial boat",
    312: "Cargo ship",
    313: "Ferry (Private vehicle)",
    314: "Ferry (Pedestrian)",
    315: "Ferry (Unknown)",
    321: "Private boat",
    399: "Water (Not available)",
    999: "Not available",
}

PDF_OPTIONS = {
    "page-size": "Letter",
    "margin-top": "0.00in",
    "margin-right": "0.75in",
    "margin-bottom": "0.00in",
    "margin-left": "0.75in",
    "encoding": "UTF-8",
    "custom-header": [("Accept-Encoding", "gzip")],
    "cookie": [("cookie-name1", "cookie-value1"), ("cookie-name2", "cookie-value2"),],
    "no-outline": None,
}


def get_cumulative_travellers_leading(
    YEAR1: int, YEAR2: int, YEAR3: int
) -> pd.DataFrame:
    """
    **Description:**

    Gets all SA_IN files in the date range requested. At the time of writing this, MinIO doesn't
    seem to support seraching prefix patterns with regular expressions. As such, the implementation
    is as follows:

        1. Construct the prefix pattern for all years between start_date and end_date (inclusive).
        2. Use S3Client.get_CSVs to get all SA_IN tables for that year.
        3. If there are any extra months in the start year or end year, exclude them from the
           final result.
        4. Return the concatenation of the SA_IN tables.

    Args:
        start_date: datetime.date
            [description]. Valid Values are [values]
        end_date: datetime.date
            [description]. Valid Values are [values]

    Returns:
        pd.DataFrame:
            [description]. Valid Values are [values]
    """
    # Get MinIO client
    client = S3Client.get_client()
    # Generate a S3Location for each year between start_date.year and end_date.year (inclusive)
    locs = [
        S3.prefix(Stage.AGGREGATED, Mode.file, DataSource.travellers_leading, year=year)
        for year in [YEAR1, YEAR2, YEAR3]
    ]
    # Get all travellers_leading tables for time range specified
    dfs = pd.concat([client.get_CSVs(loc) for loc in locs], ignore_index=True)
    # Keep only the months requested
    return dfs


def get_cumulative_vehicles_main(YEAR1: int, YEAR2: int, YEAR3: int) -> pd.DataFrame:
    """
    **Description:**

    Gets all SA_IN files in the date range requested. At the time of writing this, MinIO doesn't
    seem to support seraching prefix patterns with regular expressions. As such, the implementation
    is as follows:

        1. Construct the prefix pattern for all years between start_date and end_date (inclusive).
        2. Use S3Client.get_CSVs to get all SA_IN tables for that year.
        3. If there are any extra months in the start year or end year, exclude them from the
           final result.
        4. Return the concatenation of the SA_IN tables.

    Args:
        start_date: datetime.date
            [description]. Valid Values are [values]
        end_date: datetime.date
            [description]. Valid Values are [values]

    Returns:
        pd.DataFrame:
            [description]. Valid Values are [values]
    """
    # Get MinIO client
    client = S3Client.get_client()
    # Generate a S3Location for each year between start_date.year and end_date.year (inclusive)
    locs = [
        S3.prefix(Stage.AGGREGATED, Mode.file, DataSource.vehicles_leading, year=year)
        for year in [YEAR1, YEAR2, YEAR3]
    ]
    # Get all vehicles_leading tables for time range specified
    dfs = pd.concat([client.get_CSVs(loc) for loc in locs], ignore_index=True)
    # Keep only the months requested
    return dfs


def generate_monthly_comparison_table(df):
    df = generate_yearly_comparison_table(df)["yearly_comparison_table"]
    df = (
        df[set([YEAR1, YEAR2, YEAR3])]
        .reset_index()
        .melt(id_vars=[TravellersSchema.month])
    )
    df["percent_change"] = df["value"].pct_change() * 100
    # Rename columns
    df.columns = [
        TravellersSchema.month,
        TravellersSchema.year,
        TravellersSchema.count_of_entries,
        "percent_change",
    ]
    # format percent change column in the clients' preferred format.
    df["percent_change"] = (
        df["percent_change"]
        .round(2)
        .fillna("")
        .astype("str")
        .apply(lambda x: f"{x}%" if x != "" else x)
    )
    return {"monthly_comparison_table": df}


def generate_yearly_comparison_table(df):
    df = df.groupby(
        by=[TravellersSchema.year, TravellersSchema.month], dropna=False, as_index=False
    )
    df = df[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    # Note: df.pivot_table silently coerces integer types to float
    df = df.pivot_table(
        values=TravellersSchema.count_of_entries,
        index=TravellersSchema.month,
        columns=TravellersSchema.year,
        aggfunc="first",
    ).astype("Int64")
    df.index = df.index.map(MONTHS)
    if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df.columns).all():
        # The table should report percent changes increasing in time, but user may
        # enter years in arbitrary order. Need to ensure results are shown in an
        # order that makes sense.
        loc_year1, loc_year2, loc_year3 = sorted((YEAR1, YEAR2, YEAR3), reverse=True)
        df[f"{loc_year3}/{loc_year1}"] = (
            (df[loc_year1] - df[loc_year3]) / df[loc_year3]
        ) * 100
        df[f"{loc_year2}/{loc_year1}"] = (
            (df[loc_year1] - df[loc_year2]) / df[loc_year2]
        ) * 100
        df = df.round({f"{loc_year3}/{loc_year1}": 2, f"{loc_year2}/{loc_year1}": 2})
        # Clients want percentages to be displayed as XX.X %
        df[f"{loc_year3}/{loc_year1}"] = (
            df[f"{loc_year3}/{loc_year1}"]
            .fillna("")
            .astype("str")
            .apply(lambda x: f"{x}%" if x != "" else x)
        )
        df[f"{loc_year2}/{loc_year1}"] = (
            df[f"{loc_year2}/{loc_year1}"]
            .fillna("")
            .astype("str")
            .apply(lambda x: f"{x}%" if x != "" and not "%" in x else x)
        )
    return {"yearly_comparison_table": df}


def generate_yearly_comparison_plot(df):
    # df = generate_yearly_comparison_table(df)["yearly_comparison_table"]
    df = df.groupby(
        by=[TravellersSchema.year, TravellersSchema.month], dropna=False, as_index=False
    )
    df = df[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    # fig,ax = plt.subplots()
    fig = df.pivot(
        TravellersSchema.month, TravellersSchema.year, TravellersSchema.count_of_entries
    ).plot(marker="o")
    plt.xlabel("Month")
    plt.ylabel("Count of Entries (Thousands)")
    # testing
    scale_y = 1e3
    ticks_y = ticker.FuncFormatter(lambda x, pos: "{0:g}".format(x / scale_y))
    fig.yaxis.set_major_formatter(ticks_y)
    plt.xticks(range(1, 13), MONTHS.values())
    # testing
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    return {"yearly_comparison_plot": base64.b64encode(buf.getvalue())}


def generate_daily_comparison_plot(df):
    # temporarily overwrite day column with random numbers 1-31
    df = df.copy()
    df["day"] = np.random.randint(1, 32, df.shape[0])
    df = df[df["month"].isin([MONTH1, MONTH2, MONTH3])].groupby(
        by=[TravellersSchema.year, TravellersSchema.month, TravellersSchema.day],
        dropna=False,
        as_index=False,
    )
    df = df[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    df[TravellersSchema.month] = (
        df.month.map(MONTHS) + "-" + df[TravellersSchema.year].astype(str)
    )
    df = df.drop(columns=[TravellersSchema.year])
    # fig,ax = plt.subplots()
    fig = df.pivot(
        TravellersSchema.day, TravellersSchema.month, TravellersSchema.count_of_entries
    ).plot()
    plt.xlabel("Day")
    plt.ylabel("Count of Entries (Thousands)")
    # testing
    scale_y = 1e3
    ticks_y = ticker.FuncFormatter(lambda x, pos: "{0:g}".format(x / scale_y))
    fig.yaxis.set_major_formatter(ticks_y)
    plt.xticks(np.arange(1, 32, step=2))
    # testing
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    return {"daily_comparison_plot": base64.b64encode(buf.getvalue())}


def generate_daily_comparison_table(df):
    # (1) SUM count_of_entries GROUP BY year, month day FROM df as agg1
    agg1 = (
        df[df[TravellersSchema.month].isin([MONTH1, MONTH2, MONTH3])][
            [
                TravellersSchema.year,
                TravellersSchema.month,
                TravellersSchema.day,
                TravellersSchema.count_of_entries,
            ]
        ]
        .groupby(
            [TravellersSchema.year, TravellersSchema.month, TravellersSchema.day],
            as_index=False,
        )
        .sum()
    )
    # (2) MIN(count_of_entries), MAX(count_of_entries) GROUP BY year, month FROM agg1
    res = agg1.groupby(
        by=[TravellersSchema.year, TravellersSchema.month], as_index=False
    ).apply(lambda x: pd.Series([min(x.count_of_entries), max(x.count_of_entries)]))
    res.columns = [
        TravellersSchema.year,
        TravellersSchema.month,
        "Lowest Day",
        "Highest Day",
    ]
    return {"daily_comparison_table": res}


def generate_coverage_table(df):
    df = df.copy()
    df = df.groupby(by=["sgc_code", "ports"], dropna=False, as_index=False)
    df = df[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    ## TODO: Incomplete, need to test with data that has sgc_code column


def generate_yearly_coverage(df):
    df = df.copy()
    # config will already filter this down by vehicle_type = 111 and traveller_type = 1 or 2
    df_new = df[df[TravellersSchema.data_source] == DATA_SOURCE.PIK.value]
    df_new = df.groupby(by=[TravellersSchema.year], dropna=False, as_index=False)
    df_new = df[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    df = df.groupby(by=[TravellersSchema.year], dropna=False, as_index=False)
    df = df[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    df_new[TravellersSchema.count_of_entries] = (
        df_new[TravellersSchema.count_of_entries]
        / df[TravellersSchema.count_of_entries]
    )
    return {"yearly_coverage": df_new}


def style_negative(cell_value):
    highlight1 = "background-color: yellow"
    highlight2 = "background-color: orange"
    highlight3 = "background-color: red"
    default = ""
    if type(cell_value) in [float, int]:
        if 10 <= abs(cell_value) < 50:
            return highlight1
        if 50 <= abs(cell_value) < 100:
            return highlight2
        if abs(cell_value) > 100:
            return highlight3
    return default


def generate_coverage_comparison_table(df, sorting_argument, province_port_number):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    df_USA = df[
        (
            df[TravellersSchema.traveller_type].isin(
                [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
            )
        )
        & (
            df[TravellersSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.united_states.value
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_USA.empty:
        df_USA = df_USA.groupby(
            by=[TravellersSchema.year, TravellersSchema.traveller_type],
            dropna=False,
            as_index=False,
        )
        df_USA = df_USA[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_USA = df_USA.pivot(
            TravellersSchema.traveller_type,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_USA.index = df_USA.index.map(TRAVELLERS)
        df_USA.loc["Visitors(total)"] = df_USA.sum()
        df_USA = (
            df_USA.reset_index()
            .set_index([pd.Index(["USA"] * len(df_USA))])
            .rename_axis(None, axis=1)
        )
    else:
        df_USA = pd.DataFrame(
            columns=[TravellersSchema.traveller_type, YEAR1, YEAR2, YEAR3]
        )

    df_OVS = df[
        (
            df[TravellersSchema.traveller_type].isin(
                [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
            )
        )
        & (
            ~df[TravellersSchema.country_of_residence].isin(
                [
                    COUNTRY_OF_RESIDENCE.canada.value,
                    COUNTRY_OF_RESIDENCE.united_states.value,
                ]
            )
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_OVS.empty:
        df_OVS = df_OVS.groupby(
            by=[TravellersSchema.year, TravellersSchema.traveller_type],
            dropna=False,
            as_index=False,
        )
        df_OVS = df_OVS[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_OVS = df_OVS.pivot(
            TravellersSchema.traveller_type,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_OVS.index = df_OVS.index.map(TRAVELLERS)
        df_OVS.loc["Visitors(total)"] = df_OVS.sum()
        df_OVS = (
            df_OVS.reset_index()
            .set_index([pd.Index(["OVS"] * len(df_OVS))])
            .rename_axis(None, axis=1)
        )
    else:
        df_OVS = df_USA.iloc[:0].copy()

    df_CAN = df[
        (
            df[TravellersSchema.traveller_type].isin(
                [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
            )
        )
        & (
            df[TravellersSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.canada.value
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_CAN.empty:
        df_CAN = df_CAN.groupby(
            by=[TravellersSchema.year, TravellersSchema.traveller_type],
            dropna=False,
            as_index=False,
        )
        df_CAN = df_CAN[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_CAN = df_CAN.pivot(
            TravellersSchema.traveller_type,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_CAN.index = df_CAN.index.map(TRAVELLERS)
        df_CAN.loc["Visitors(total)"] = df_USA.sum()
        df_CAN = (
            df_CAN.reset_index()
            .set_index([pd.Index(["CAN"] * len(df_CAN))])
            .rename_axis(None, axis=1)
        )
    else:
        df_CAN = df_USA.iloc[:0].copy()

    df_new = df_USA.append([df_OVS, df_CAN])
    df_total = df_new.groupby(by=[TravellersSchema.traveller_type]).sum().reset_index()
    df_new = df_new.append(df_total.set_index([pd.Index(["Total"] * len(df_total))]))

    if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_new.columns).all():
        df_new[f"{YEAR3}/{YEAR1}"] = (
            (df_new[YEAR3] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new[f"{YEAR2}/{YEAR1}"] = (
            (df_new[YEAR2] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new = df_new.round({f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2})
        df_new = df_new.reset_index().style.applymap(
            style_negative, subset=[f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"]
        )

    return {"coverage_comparison_table": df_new}


def percentage_travellers(df, sorting_argument, province_port_number):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    numerator = df[
        (df[TravellersSchema.month] == MONTH3)
        & (df[f"{sorting_argument}"] == province_port_number)
    ]
    numerator = numerator.groupby(
        by=[TravellersSchema.month], dropna=False, as_index=False
    )
    numerator = numerator[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    if sorting_argument == "province":
        denominator = df[(df[TravellersSchema.month] == MONTH3)]
    else:
        denominator = df[
            (df[TravellersSchema.month] == MONTH3)
            & (df["province"] == int(str(province_port_number)[0:2]))
        ]
    denominator = denominator.groupby(
        by=[TravellersSchema.month], dropna=False, as_index=False
    )
    denominator = denominator[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    if numerator.empty or denominator.empty:
        percent = 0.0
    else:
        percent = (
            int(numerator[TravellersSchema.count_of_entries])
            / int(denominator[TravellersSchema.count_of_entries])
        ) * 100
    return {"percentage_travellers": percent}


def percentage_visitors(df, sorting_argument, province_port_number):
    percents = []
    for modes in [MODE.air.value, MODE.land.value]:
        df = df.copy()
        df["province"] = (
            df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
        )
        numerator = df[
            (df[TravellersSchema.month] == MONTH3)
            & (df[f"{sorting_argument}"] == province_port_number)
            & (
                df[TravellersSchema.traveller_type].isin(
                    [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
                )
            )
            & (df[TravellersSchema.mode] == int(modes))
        ]
        numerator = numerator.groupby(
            by=[TravellersSchema.month], dropna=False, as_index=False
        )
        numerator = numerator[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        if sorting_argument == "province":
            denominator = df[
                (df[TravellersSchema.month] == MONTH3)
                & (
                    df[TravellersSchema.traveller_type].isin(
                        [
                            TRAVELLER_TYPE.excursionist.value,
                            TRAVELLER_TYPE.tourist.value,
                        ]
                    )
                )
                & (df[TravellersSchema.mode] == int(modes))
            ]
        else:
            denominator = df[
                (df[TravellersSchema.month] == MONTH3)
                & (
                    df[TravellersSchema.traveller_type].isin(
                        [
                            TRAVELLER_TYPE.excursionist.value,
                            TRAVELLER_TYPE.tourist.value,
                        ]
                    )
                )
                & (df[TravellersSchema.mode] == int(modes))
                & (df["province"] == int(str(province_port_number)[0:2]))
            ]
        denominator = denominator.groupby(
            by=[TravellersSchema.month], dropna=False, as_index=False
        )
        denominator = denominator[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        if numerator.empty or int(numerator[TravellersSchema.count_of_entries]) == 0:
            percent = 0.0
            percents.append("N/A")
        else:
            percent = (
                int(numerator[TravellersSchema.count_of_entries])
                / int(denominator[TravellersSchema.count_of_entries])
            ) * 100
            percents.append(round(percent, 3))

    return {"percentage_visitors": percents}


def percentage_other(df, sorting_argument, province_port_number):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    numerator = df[
        (df[TravellersSchema.month] == MONTH3)
        & (df[f"{sorting_argument}"] == province_port_number)
        & (
            df[TravellersSchema.traveller_type]
            == int(TRAVELLER_TYPE.other_traveller.value)
        )
    ]
    numerator = numerator.groupby(
        by=[TravellersSchema.month], dropna=False, as_index=False
    )
    numerator = numerator[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    if sorting_argument == "province":
        denominator = df[
            (df[TravellersSchema.month] == MONTH3)
            & (
                df[TravellersSchema.traveller_type]
                == int(TRAVELLER_TYPE.other_traveller.value)
            )
        ]
    else:
        denominator = df[
            (df[TravellersSchema.month] == MONTH3)
            & (
                df[TravellersSchema.traveller_type]
                == int(TRAVELLER_TYPE.other_traveller.value)
            )
            & (df["province"] == int(str(province_port_number)[0:2]))
        ]
    denominator = denominator.groupby(
        by=[TravellersSchema.month], dropna=False, as_index=False
    )
    denominator = denominator[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    if numerator.empty or int(numerator[TravellersSchema.count_of_entries]) == 0:
        percent = 0.0
    else:
        percent = (
            int(numerator[TravellersSchema.count_of_entries])
            / int(denominator[TravellersSchema.count_of_entries])
        ) * 100
    return {"percentage_other": percent}


def percentage_air(df, sorting_argument, province_port_number):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    numerator = df[
        (df[TravellersSchema.month] == MONTH3)
        & (df[f"{sorting_argument}"] == province_port_number)
    ]
    numerator = numerator.groupby(
        by=[TravellersSchema.month], dropna=False, as_index=False
    )
    numerator = numerator[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    if sorting_argument == "province":
        denominator = df[(df[TravellersSchema.month] == MONTH3)]
    else:
        denominator = df[
            (df[TravellersSchema.month] == MONTH3)
            & (df["province"] == int(str(province_port_number)[0:2]))
        ]
    denominator = denominator.groupby(
        by=[TravellersSchema.month], dropna=False, as_index=False
    )
    denominator = denominator[[TravellersSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    if numerator.empty or int(numerator[TravellersSchema.count_of_entries]) == 0:
        percent = 0.0
    else:
        percent = (
            int(numerator[TravellersSchema.count_of_entries])
            / int(denominator[TravellersSchema.count_of_entries])
        ) * 100
    return {"percentage_air": percent}


def generate_country_coverage_comparison_table(
    df, sorting_argument, province_port_number
):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    df_OVS_Excursionist = df[
        (df[TravellersSchema.traveller_type] == int(TRAVELLER_TYPE.excursionist.value))
        & (
            ~df[TravellersSchema.country_of_residence].isin(
                [
                    COUNTRY_OF_RESIDENCE.canada.value,
                    COUNTRY_OF_RESIDENCE.united_states.value,
                ]
            )
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_OVS_Excursionist.empty:
        df_OVS_Excursionist = df_OVS_Excursionist.groupby(
            by=[TravellersSchema.year, TravellersSchema.traveller_type],
            dropna=False,
            as_index=False,
        )
        df_OVS_Excursionist = df_OVS_Excursionist[
            [TravellersSchema.count_of_entries]
        ].apply(lambda x: x.astype("Int64").sum())
        df_OVS_Excursionist = df_OVS_Excursionist.pivot(
            TravellersSchema.country_of_residence,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        ).reset_index()
        if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_OVS_Excursionist.columns).all():
            df_temp = df_OVS_Excursionist.nlargest(3, columns=[YEAR1, YEAR2, YEAR3])
            df_temp = df_temp.append(
                df_OVS_Excursionist.loc[
                    ~df_OVS_Excursionist.country_of_residence.isin(
                        df_temp.country_of_residence
                    ),
                    [YEAR1, YEAR2, YEAR3],
                ].sum(),
                ignore_index=True,
            ).rename_axis(None, axis=1)
            df_temp.loc[
                df_temp.country_of_residence.isnull(),
                TravellersSchema.country_of_residence,
            ] = "Other"
            df_OVS_Excursionist = df_temp
            df_OVS_Excursionist = df_OVS_Excursionist.set_index(
                [pd.Index(["OVS_Excursionists"] * len(df_OVS_Excursionist))]
            )
    else:
        df_OVS_Excursionist = pd.DataFrame(
            columns=[TravellersSchema.arriving_from, YEAR1, YEAR2, YEAR3]
        )

    df_OVS_Tourists = df[
        (df[TravellersSchema.traveller_type] == int(TRAVELLER_TYPE.tourist.value))
        & (
            ~df[TravellersSchema.country_of_residence].isin(
                [
                    COUNTRY_OF_RESIDENCE.canada.value,
                    COUNTRY_OF_RESIDENCE.united_states.value,
                ]
            )
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_OVS_Tourists.empty:
        df_OVS_Tourists = df_OVS_Tourists.groupby(
            by=[TravellersSchema.year, TravellersSchema.country_of_residence],
            dropna=False,
            as_index=False,
        )
        df_OVS_Tourists = df_OVS_Tourists[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_OVS_Tourists = df_OVS_Tourists.pivot(
            TravellersSchema.country_of_residence,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        ).reset_index()
        if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_OVS_Tourists.columns).all():
            df_temp = df_OVS_Tourists.nlargest(3, columns=[YEAR1, YEAR2, YEAR3])
            df_temp = df_temp.append(
                df_OVS_Tourists.loc[
                    ~df_OVS_Tourists.country_of_residence.isin(
                        df_temp.country_of_residence
                    ),
                    [YEAR1, YEAR2, YEAR3],
                ].sum(),
                ignore_index=True,
            ).rename_axis(None, axis=1)
            df_temp.loc[
                df_temp.country_of_residence.isnull(),
                TravellersSchema.country_of_residence,
            ] = "Other"
            df_OVS_Tourists = df_temp
            df_OVS_Tourists = df_OVS_Tourists.set_index(
                [pd.Index(["OVS_Tourists"] * len(df_OVS_Tourists))]
            )
    else:
        df_OVS_Tourists = pd.DataFrame(
            columns=[TravellersSchema.arriving_from, YEAR1, YEAR2, YEAR3]
        )

    if not df_OVS_Excursionist.empty and not df_OVS_Tourists.empty:
        df_new = df_OVS_Excursionist.append(df_OVS_Tourists)
    elif not df_OVS_Excursionist.empty:
        df_new = df_OVS_Excursionist
    else:
        df_new = df_OVS_Tourists

    if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_new.columns).all() & (not df_new.empty):
        df_new[f"{YEAR3}/{YEAR1}"] = (
            (df_new[YEAR3] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new[f"{YEAR2}/{YEAR1}"] = (
            (df_new[YEAR2] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new = df_new.round({f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2})
    return {"coverage_country_comparison_table": df_new}


def generate_coverage_arriving_comparison_table(
    df, sorting_argument, province_port_number
):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    df_USA = df[
        (
            df[TravellersSchema.arriving_from].isin(
                [
                    ARRIVING_FROM.us_only.value,
                    ARRIVING_FROM.ovs_direct.value,
                    ARRIVING_FROM.ovs_via_us.value,
                ]
            )
        )
        & (
            df[TravellersSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.united_states.value
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_USA.empty:
        df_USA = df_USA.groupby(
            by=[TravellersSchema.year, TravellersSchema.arriving_from],
            dropna=False,
            as_index=False,
        )
        df_USA = df_USA[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_USA = df_USA.pivot(
            TravellersSchema.arriving_from,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_USA.index = df_USA.index.map(ARRIVING)
        df_USA = (
            df_USA.reset_index()
            .set_index([pd.Index(["USA"] * len(df_USA))])
            .rename_axis(None, axis=1)
        )
    else:
        df_USA = pd.DataFrame(
            columns=[TravellersSchema.arriving_from, YEAR1, YEAR2, YEAR3]
        )

    df_OVS = df[
        (
            df[TravellersSchema.arriving_from].isin(
                [
                    ARRIVING_FROM.us_only.value,
                    ARRIVING_FROM.ovs_direct.value,
                    ARRIVING_FROM.ovs_via_us.value,
                ]
            )
        )
        & (
            ~df[TravellersSchema.country_of_residence].isin(
                [
                    COUNTRY_OF_RESIDENCE.canada.value,
                    COUNTRY_OF_RESIDENCE.united_states.value,
                ]
            )
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_OVS.empty:
        df_OVS = df_OVS.groupby(
            by=[TravellersSchema.year, TravellersSchema.arriving_from],
            dropna=False,
            as_index=False,
        )
        df_OVS = df_OVS[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_OVS = df_OVS.pivot(
            TravellersSchema.arriving_from,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_OVS.index = df_OVS.index.map(ARRIVING)
        df_OVS = (
            df_OVS.reset_index()
            .set_index([pd.Index(["OVS"] * len(df_OVS))])
            .rename_axis(None, axis=1)
        )
    else:
        df_OVS = df_USA.iloc[:0].copy()

    df_CAN = df[
        (
            df[TravellersSchema.arriving_from].isin(
                [
                    ARRIVING_FROM.us_only.value,
                    ARRIVING_FROM.ovs_direct.value,
                    ARRIVING_FROM.ovs_via_us.value,
                ]
            )
        )
        & (
            df[TravellersSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.canada.value
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_CAN.empty:
        df_CAN = df_CAN.groupby(
            by=[TravellersSchema.year, TravellersSchema.arriving_from],
            dropna=False,
            as_index=False,
        )
        df_CAN = df_CAN[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_CAN = df_CAN.pivot(
            TravellersSchema.arriving_from,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_CAN.index = df_CAN.index.map(ARRIVING)
        df_CAN = (
            df_CAN.reset_index()
            .set_index([pd.Index(["CAN"] * len(df_CAN))])
            .rename_axis(None, axis=1)
        )
    else:
        df_CAN = df_USA.iloc[:0].copy()

    df_new = df_USA.append([df_OVS, df_CAN])
    df_total = df_new.groupby(by=[TravellersSchema.arriving_from]).sum().reset_index()
    df_new = df_new.append(df_total.set_index([pd.Index(["Total"] * len(df_total))]))

    if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_new.columns).all() & (not df_new.empty):
        df_new[f"{YEAR3}/{YEAR1}"] = (
            (df_new[YEAR3] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new[f"{YEAR2}/{YEAR1}"] = (
            (df_new[YEAR2] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new = df_new.round({f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2})
    # df_new = df_new.reset_index().style.applymap(style_negative, subset=[f"{YEAR3}/{YEAR1}",f"{YEAR2}/{YEAR1}"])

    return {"coverage_arriving_comparison_table": df_new}


def generate_coverage_plate_comparison_table(
    df, sorting_argument, province_port_number
):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    df_CAN = df[
        (df[TravellersSchema.plate_country] == PLATE_COUNTRY.canada.value)
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_CAN.empty:
        df_CAN = df_CAN.groupby(
            by=[TravellersSchema.year, TravellersSchema.plate_country],
            dropna=False,
            as_index=False,
        )
        df_CAN = df_CAN[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_CAN = df_CAN.pivot(
            TravellersSchema.plate_country,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        ).reset_index()
        if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_CAN.columns).all():
            df_temp = df_CAN.nlargest(3, columns=[YEAR1, YEAR2, YEAR3])
            df_temp = df_temp.append(
                df_CAN.loc[
                    ~df_CAN.plate_country.isin(df_temp.plate_country),
                    [YEAR1, YEAR2, YEAR3],
                ].sum(),
                ignore_index=True,
            ).rename_axis(None, axis=1)
            df_temp.loc[
                df_temp.plate_country.isnull(), TravellersSchema.plate_country
            ] = "Other"
            df_CAN = df_temp
            df_CAN = df_CAN.set_index([pd.Index([pd.Index(["CAN"] * len(df_CAN))])])
    else:
        df_CAN = pd.DataFrame(
            columns=[TravellersSchema.plate_country, YEAR1, YEAR2, YEAR3]
        )

    df_USA = df[
        (df[TravellersSchema.plate_country] == PLATE_COUNTRY.united_states.value)
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_USA.empty:
        df_USA = df_USA.groupby(
            by=[TravellersSchema.year, TravellersSchema.plate_country],
            dropna=False,
            as_index=False,
        )
        df_USA = df_USA[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_USA = df_USA.pivot(
            TravellersSchema.plate_country,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        ).reset_index()
        if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_USA.columns).all():
            df_temp = df_USA.nlargest(5, columns=[YEAR1, YEAR2, YEAR3])
            df_temp = df_temp.append(
                df_USA.loc[
                    ~df_USA.plate_country.isin(df_temp.plate_country),
                    [YEAR1, YEAR2, YEAR3],
                ].sum(),
                ignore_index=True,
            ).rename_axis(None, axis=1)
            df_temp.loc[
                df_temp.plate_country.isnull(), TravellersSchema.plate_country
            ] = "Other"
            df_USA = df_temp
            df_USA = df_USA.set_index([pd.Index([pd.Index(["USA"] * len(df_CAN))])])
    else:
        df_USA = df_CAN.iloc[:0].copy()
    if not df_CAN.empty and not df_USA.empty:
        df_new = df_USA.append(df_CAN)
    elif not df_CAN.empty:
        df_new = df_CAN
    else:
        df_new = df_USA
    if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_new.columns).all() & (not df_new.empty):
        df_new[f"{YEAR3}/{YEAR1}"] = (
            (df_new[YEAR3] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new[f"{YEAR2}/{YEAR1}"] = (
            (df_new[YEAR2] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new = df_new.round({f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2})
    return {"coverage_plate_comparison_table": df_new}


def generate_coverage_purpose_comparison_table(
    df, sorting_argument, province_port_number
):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    df_Other = df[
        (
            df[TravellersSchema.purpose9].isin(
                [
                    TRAVELLERS_PURPOSE9.crew.value,
                    TRAVELLERS_PURPOSE9.work.value,
                    TRAVELLERS_PURPOSE9.immigration.value,
                    TRAVELLERS_PURPOSE9.military.value,
                    TRAVELLERS_PURPOSE9.other_purpose.value,
                ]
            )
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_Other.empty:
        df_Other = df_Other.groupby(
            by=[TravellersSchema.year, TravellersSchema.purpose9],
            dropna=False,
            as_index=False,
        )
        df_Other = df_Other[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_Other.index.map(PURPOSE9)
        df_Other = (
            df_Other.pivot(
                TravellersSchema.purpose9,
                TravellersSchema.year,
                TravellersSchema.count_of_entries,
            )
            .reset_index()
            .rename_axis(None, axis=1)
        )

    df_new = df_Other
    if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_new.columns).all() & (not df_new.empty):
        df_new[f"{YEAR3}/{YEAR1}"] = (
            (df_new[YEAR3] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new[f"{YEAR2}/{YEAR1}"] = (
            (df_new[YEAR2] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new = df_new.round({f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2})
    return {"coverage_purpose_comparison_table": df_new}


def generate_other_coverage_comparison_table(
    df, sorting_argument, province_port_number
):
    df = df.copy()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    df_USA = df[
        (
            df[TravellersSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.united_states.value
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_USA.empty:
        df_USA = df_USA.groupby(
            by=[TravellersSchema.year, TravellersSchema.vehicle_type],
            dropna=False,
            as_index=False,
        )
        df_USA = df_USA[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_USA = df_USA.pivot(
            TravellersSchema.vehicle_type,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_USA.index = df_USA.index.map(VEHICLES)
        df_USA.loc["Total"] = df_USA.sum()
        df_USA = (
            df_USA.reset_index()
            .set_index([pd.Index(["USA"] * len(df_USA))])
            .rename_axis(None, axis=1)
        )
    else:
        df_USA = pd.DataFrame(
            columns=[TravellersSchema.vehicle_type, YEAR1, YEAR2, YEAR3]
        )

    df_OVS = df[
        (
            ~df[TravellersSchema.country_of_residence].isin(
                [
                    COUNTRY_OF_RESIDENCE.canada.value,
                    COUNTRY_OF_RESIDENCE.united_states.value,
                ]
            )
        )
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_OVS.empty:
        df_OVS = df_OVS.groupby(
            by=[TravellersSchema.year, TravellersSchema.vehicle_type],
            dropna=False,
            as_index=False,
        )
        df_OVS = df_OVS[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_OVS = df_OVS.pivot(
            TravellersSchema.vehicle_type,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_OVS.index = df_OVS.index.map(VEHICLES)
        df_OVS.loc["Total"] = df_OVS.sum()
        df_OVS = (
            df_OVS.reset_index()
            .set_index([pd.Index(["OVS"] * len(df_OVS))])
            .rename_axis(None, axis=1)
        )
    else:
        df_OVS = df_USA.iloc[:0].copy()

    df_CAN = df[
        (df[TravellersSchema.country_of_residence] == COUNTRY_OF_RESIDENCE.canada.value)
        & (df[sorting_argument] == province_port_number)
    ]
    if not df_CAN.empty:
        df_CAN = df_CAN.groupby(
            by=[TravellersSchema.year, TravellersSchema.vehicle_type],
            dropna=False,
            as_index=False,
        )
        df_CAN = df_CAN[[TravellersSchema.count_of_entries]].apply(
            lambda x: x.astype("Int64").sum()
        )
        df_CAN = df_CAN.pivot(
            TravellersSchema.vehicle_type,
            TravellersSchema.year,
            TravellersSchema.count_of_entries,
        )
        df_CAN.index = df_CAN.index.map(VEHICLES)
        df_CAN.loc["Total"] = df_USA.sum()
        df_CAN = (
            df_CAN.reset_index()
            .set_index([pd.Index(["CAN"] * len(df_CAN))])
            .rename_axis(None, axis=1)
        )
    else:
        df_CAN = df_USA.iloc[:0].copy()

    df_new = df_USA.append([df_OVS, df_CAN])
    df_total = df_new.groupby(by=[TravellersSchema.vehicle_type]).sum().reset_index()
    df_new = df_new.append(df_total.set_index([pd.Index(["Total"] * len(df_total))]))

    if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_new.columns).all() & (not df_new.empty):
        df_new[f"{YEAR3}/{YEAR1}"] = (
            (df_new[YEAR3] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new[f"{YEAR2}/{YEAR1}"] = (
            (df_new[YEAR2] - df_new[YEAR1]) / df_new[YEAR1]
        ) * 100
        df_new = df_new.round({f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2})
        df_new = df_new.reset_index().style.applymap(
            style_negative, subset=[f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"]
        )

    return {"coverage_other_comparison_table": df_new}


def generate_passengers_coverage_comparison_table(
    df, sorting_argument, province_port_number
):
    vehicles_main = get_cumulative_vehicles_main(YEAR1, YEAR2, YEAR3)
    df = df.copy()
    df_new = pd.DataFrame()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    vehicles_main["province"] = (
        vehicles_main[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    )
    for vehicle in [
        VEHICLE_TYPE.automobile.value,
        VEHICLE_TYPE.motorcycle.value,
        VEHICLE_TYPE.other_land_vehicle.value,
        VEHICLE_TYPE.truck.value,
        VEHICLE_TYPE.ferry_private_vehicle.value,
    ]:
        df_passenger = df[
            (df[TravellersSchema.vehicle_type] == vehicle)
            & (df[sorting_argument] == province_port_number)
        ]
        if not df_passenger.empty:
            df_passenger = df_passenger.groupby(
                by=[TravellersSchema.year, TravellersSchema.vehicle_type],
                dropna=False,
                as_index=False,
            )
            df_passenger = df_passenger[[TravellersSchema.count_of_entries]].apply(
                lambda x: x.astype("Int64").sum()
            )
            df_passenger = df_passenger.pivot(
                TravellersSchema.vehicle_type,
                TravellersSchema.year,
                TravellersSchema.count_of_entries,
            )
            df_passenger.index = df_passenger.index.map(VEHICLES)
            df_vehicle = vehicles_main[
                (vehicles_main[TravellersSchema.vehicle_type] == vehicle)
                & (vehicles_main[sorting_argument] == province_port_number)
            ]
            df_vehicle = df_vehicle.groupby(
                by=[TravellersSchema.year, TravellersSchema.vehicle_type],
                dropna=False,
                as_index=False,
            )
            df_vehicle = df_vehicle[[TravellersSchema.count_of_entries]].apply(
                lambda x: x.astype("Int64").sum()
            )
            df_vehicle = df_vehicle.pivot(
                TravellersSchema.vehicle_type,
                TravellersSchema.year,
                TravellersSchema.count_of_entries,
            )
            df_vehicle.index = df_vehicle.index.map(VEHICLES)
            df_passenger = (
                df_passenger.append(df_vehicle).rename_axis(None, axis=1).reset_index()
            )
            df_passenger.insert(
                loc=1, column="", value=["passengers(visitors)", "Vehicles"]
            )
            if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_passenger.columns).all() & (
                not df_passenger.empty
            ):
                df_passenger[f"{YEAR3}/{YEAR1}"] = (
                    (df_passenger[YEAR3] - df_passenger[YEAR1]) / df_passenger[YEAR1]
                ) * 100
                df_passenger[f"{YEAR2}/{YEAR1}"] = (
                    (df_passenger[YEAR2] - df_passenger[YEAR1]) / df_passenger[YEAR1]
                ) * 100
                df_passenger = df_passenger.round(
                    {f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2}
                )
            if pd.Series([f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"]).isin(
                df_passenger.columns
            ).all() & (not (df_passenger.loc[1] == 0).any()):
                df_passenger.loc[2] = (
                    df_passenger.loc[0][[YEAR1, YEAR2, YEAR3]]
                    / df_passenger.loc[1][[YEAR1, YEAR2, YEAR3]]
                )
                df_passenger.loc[
                    df_passenger[TravellersSchema.vehicle_type].isnull(),
                    [TravellersSchema.vehicle_type, ""],
                ] = [df_passenger.iloc[0, 0], "Ratio"]
            else:
                df_passenger.loc[2] = "N/A"
        else:
            df_passenger = pd.DataFrame(
                columns=[TravellersSchema.vehicle_type, YEAR1, YEAR2, YEAR3]
            )

        df_new = df_new.append(df_passenger)

    if (
        pd.Series([f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"])
        .isin(df_passenger.columns)
        .all()
    ):
        df_new = df_new.reset_index().style.applymap(
            style_negative, subset=[f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"]
        )

    return {"coverage_passengers_comparison_table": df_new}


def generate_passengers_commercial_coverage_comparison_table(
    df, sorting_argument, province_port_number
):
    df = df.copy()
    df_new = pd.DataFrame()
    df["province"] = df[TravellersSchema.port].astype(str).str.slice(stop=2).astype(int)
    for vehicle in [
        VEHICLE_TYPE.commercial_aircraft.value,
        VEHICLE_TYPE.cruise_ship.value,
    ]:
        df_passenger = df[
            (df[TravellersSchema.vehicle_type] == vehicle)
            & (df[sorting_argument] == province_port_number)
        ]
        if not df_passenger.empty:
            df_passenger = df_passenger.groupby(
                by=[TravellersSchema.year, TravellersSchema.vehicle_type],
                dropna=False,
                as_index=False,
            )
            df_passenger = df_passenger[[TravellersSchema.count_of_entries]].apply(
                lambda x: x.astype("Int64").sum()
            )
            df_passenger = df_passenger.pivot(
                TravellersSchema.vehicle_type,
                TravellersSchema.year,
                TravellersSchema.count_of_entries,
            )
            df_passenger.index = df_passenger.index.map(VEHICLES)
            df_crew = df[
                (df[TravellersSchema.vehicle_type] == vehicle)
                & (df[sorting_argument] == province_port_number)
                & (df[TravellersSchema.purpose4] == int(TRAVELLERS_PURPOSE4.crew.value))
            ]
            df_crew = df_crew.groupby(
                by=[TravellersSchema.year, TravellersSchema.vehicle_type],
                dropna=False,
                as_index=False,
            )
            df_crew = df_crew[[TravellersSchema.count_of_entries]].apply(
                lambda x: x.astype("Int64").sum()
            )
            df_crew = df_crew.pivot(
                TravellersSchema.vehicle_type,
                TravellersSchema.year,
                TravellersSchema.count_of_entries,
            )
            df_crew.index = df_crew.index.map(VEHICLES)
            df_passenger = (
                df_passenger.append(df_crew).rename_axis(None, axis=1).reset_index()
            )
            df_passenger.insert(
                loc=1, column="", value=["passengers(visitors)", "Crew"]
            )
            if pd.Series([YEAR1, YEAR2, YEAR3]).isin(df_new.columns).all() & (
                not df_passenger.empty
            ):
                df_passenger[f"{YEAR3}/{YEAR1}"] = (
                    (df_passenger[YEAR3] - df_passenger[YEAR1]) / df_passenger[YEAR1]
                ) * 100
                df_passenger[f"{YEAR2}/{YEAR1}"] = (
                    (df_passenger[YEAR2] - df_passenger[YEAR1]) / df_passenger[YEAR1]
                ) * 100
                df_passenger = df_passenger.round(
                    {f"{YEAR3}/{YEAR1}": 2, f"{YEAR2}/{YEAR1}": 2}
                )
            if pd.Series([f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"]).isin(
                df_passenger.columns
            ).all() & (not (df_passenger.loc[1] == 0).any()):
                df_passenger.loc[2] = (
                    df_passenger.loc[0][[YEAR1, YEAR2, YEAR3]]
                    / df_passenger.loc[1][[YEAR1, YEAR2, YEAR3]]
                )
                df_passenger.loc[
                    df_passenger[TravellersSchema.vehicle_type].isnull(),
                    [TravellersSchema.vehicle_type, ""],
                ] = [df_passenger.iloc[0, 0], "Ratio"]
            else:
                df_passenger.loc[2] = "N/A"
        else:
            df_passenger = pd.DataFrame(
                columns=[TravellersSchema.vehicle_type, YEAR1, YEAR2, YEAR3]
            )

        df_new = df_new.append(df_passenger)

    if (
        pd.Series([f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"])
        .isin(df_passenger.columns)
        .all()
    ):
        df_new = df_new.reset_index().style.applymap(
            style_negative, subset=[f"{YEAR3}/{YEAR1}", f"{YEAR2}/{YEAR1}"]
        )

    return {"coverage_passengers_commercial_comparison_table": df_new}


def main(params):
    global YEAR1, YEAR2, YEAR3, MONTH1, MONTH2, MONTH3
    YEAR1, YEAR2, YEAR3, MONTH1, MONTH2, MONTH3 = params.values()
    out_files = dict()
    dv = get_configuration("leading_indicator_config.json")
    env = Environment(loader=FileSystemLoader("templates"))
    travellers_leading = get_cumulative_travellers_leading(YEAR1, YEAR2, YEAR3)
    FUNCTIONS = {
        "generate_yearly_comparison_table": generate_yearly_comparison_table,
        "generate_yearly_comparison_plot": generate_yearly_comparison_plot,
        "generate_monthly_comparison_table": generate_monthly_comparison_table,
        "generate_daily_comparison_plot": generate_daily_comparison_plot,
        "generate_daily_comparison_table": generate_daily_comparison_table,
        "generate_yearly_coverage": generate_yearly_coverage,
        "generate_coverage_comparison_table": generate_coverage_comparison_table,
        "percentage_travellers": percentage_travellers,
        "percentage_visitors": percentage_visitors,
        "percentage_other": percentage_other,
        "percentage_air": percentage_air,
        "generate_country_coverage_comparison_table": generate_country_coverage_comparison_table,
        "generate_coverage_arriving_comparison_table": generate_coverage_arriving_comparison_table,
        "generate_coverage_plate_comparison_table": generate_coverage_plate_comparison_table,
        "generate_coverage_purpose_comparison_table": generate_coverage_purpose_comparison_table,
        "generate_other_coverage_comparison_table": generate_other_coverage_comparison_table,
        "generate_passengers_coverage_comparison_table": generate_passengers_coverage_comparison_table,
        "generate_passengers_commercial_coverage_comparison_table": generate_passengers_commercial_coverage_comparison_table,
    }
    TABLES = {"travellers_leading": travellers_leading}
    # def main(YEAR1,YEAR2,YEAR3,):
    dv = get_configuration("leading_indicator_config.json")
    env = Environment(loader=FileSystemLoader("templates"))
    # dv = generate_port_configs()
    config_list = []
    template = env.get_template(dv["template"])
    for config in dv["config_list"]:
        # Get table and subset
        df = TABLES[config["data"]][TABLES[config["data"]].eval(config["query"])]
        out_objs = []
        for func in config["functions"]:
            res = FUNCTIONS[func["func"]](df, **func["kwargs"])
            out_objs.append(res)
        out_tables = {}
        out_plots = {}
        out_strings = {}
        out_floats = {}
        for obj in out_objs:
            if isinstance(list(obj.values())[0], pd.DataFrame):
                out_tables = {
                    **out_tables,
                    **{
                        k: v.to_html(classes="table", justify="left")
                        for k, v in obj.items()
                    },
                }
            elif isinstance(list(obj.values())[0], bytes):
                out_plots = {
                    **out_plots,
                    **{k: v.decode("utf-8") for k, v in obj.items()},
                }
            elif isinstance(list(obj.values())[0], pd.io.formats.style.Styler):
                out_tables = {
                    **out_tables,
                    **{k: v.render(classes="table") for k, v in obj.items()},
                }
            elif isinstance(list(obj.values())[0], float):
                out_floats = {**out_floats, **{k: round(v, 2) for k, v in obj.items()}}
            elif isinstance(list(obj.values())[0], str):
                out_strings = {**out_strings, **{k: v for k, v in obj.items()}}
            elif isinstance(list(obj.values())[0], list):
                out_strings = {**out_strings, **{k: v for k, v in obj.items()}}
            else:
                print("Neither bytes nor pd.DataFrame")
        config_list.append(
            {
                "main_heading": config["main_heading"],
                "sub_heading": config["sub_heading"],
                "province": config["province"] if "province" in config.keys() else None,
                **out_tables,
                **out_plots,
                **out_floats,
                **out_strings,
            }
        )
        output_html = template.render(config_list=config_list)
        # Save output report to MinIO
        s3client = S3Client.get_client()
        # Write the ndm between-tables validation to MinIO
        html_bytes = output_html.encode("utf-8")
        html_buffer = io.BytesIO(html_bytes)
        # TODO: I'm assuming the first year/month is the intended location of this
        # report - if this is not the case we need to rethink what these outputs
        # look like.
        downstream_loc = S3Location(
            Stage.VALIDATION.value.bucket,
            os.path.join(
                Stage.VALIDATION.name.lower(),
                "leading_indicator",
                str(YEAR1),
                str(MONTH1),
            ),
            f"{YEAR1}-{MONTH1}-{YEAR2}-{MONTH2}-{YEAR3}-{MONTH3}-leading-indicator-validation.html",
        )
        s3client.put_loc(
            downstream_loc, html_buffer, len(html_bytes), content_type="text/html"
        )


# if __name__ == "__main__":
#     main()

