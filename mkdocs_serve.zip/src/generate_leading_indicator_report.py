from modules.utils.leading_indicator_helpers import main
from argparse import ArgumentParser


def get_parser():
    """
    Sets up argo helper CLI
    """
    parser = ArgumentParser(
        prog="downstream_parser",
        description="Command line tool to produce SA_IN and SA_PARAMETERS files",
    )
    # Start date (set by default to January 1 2000 but can change in the future)
    parser.add_argument(
        "-y1",
        "--year1",
        type=int,
        help="""
        the first filter year.
        """,
    )
    # Current date (i.e. date for the data being run)
    parser.add_argument(
        "-y2",
        "--year2",
        type=int,
        help="""
        the first filter year.
        """,
    )
    # Parameters for number of periods and force
    parser.add_argument(
        "-y3",
        "--year3",
        type=int,
        help="""
        the first filter year.
        """,
    )
    parser.add_argument(
        "-m1",
        "--month1",
        type=int,
        help="""
        the first filter year.
        """,
    )
    parser.add_argument(
        "-m2",
        "--month2",
        type=int,
        help="""
        the first filter year.
        """,
    )
    parser.add_argument(
        "-m3",
        "--month3",
        type=int,
        help="""
        the first filter year.
        """,
    )
    return parser


if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()
    # These are parameters that are passed to the CLI program
    # global MONTH1, MONTH2, MONTH3, YEAR1, YEAR2, YEAR3
    MONTH1 = args.month1
    MONTH2 = args.month2
    MONTH3 = args.month3
    YEAR1 = args.year1
    YEAR2 = args.year2
    YEAR3 = args.year3
    params = {k: v for (k, v) in args._get_kwargs()}
    main(params)
