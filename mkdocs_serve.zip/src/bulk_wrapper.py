"""
CLI program to perform many workloads in bulk. Currently supports:

1. ndm_unadjusted pipeline
2. ndm_adjusted pipeline

Note: for ndm_unadjusted pipeline, the parallelization happens within the business rule
implementation. Therefore, do not use multiprocessing when running this job (it will just create
N^2 processes (where N is # logical CPU cores) which will create a ton of CPU scheduling overhead).

E.g.

time python bulk_wrapper.py --workflow ndm_unadjusted --start-date 1972-01 --end-date 2022-01 \
    --cli-args="--pipeline-class PipelineTransformedAggregated --data-source travellers"

time python bulk_wrapper.py --workflow ndm_adjusted --start-date 2010-01 --end-date 2021-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_24100050"

time python bulk_wrapper.py --workflow ndm_adjusted --start-date 2010-01 --end-date 2021-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_24100051"

time python bulk_wrapper.py --workflow ndm_adjusted --start-date 2010-01 --end-date 2021-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_24100052"

time python bulk_wrapper.py --workflow ndm_adjusted --start-date 2010-01 --end-date 2021-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_24100053"

time python bulk_wrapper.py --workflow ndm_adjusted --start-date 2010-01 --end-date 2021-12 \
    --cli-args="--pipeline-class PipelineAggregated --data-source ndm_24100054"

"""
import time
import os
from multiprocessing import Pool

from dateutil import rrule
from datetime import datetime
from argparse import ArgumentParser

from modules.s3client import S3Client
from config.env import environ


def get_parser():
    """
    Sets up argo helper CLI
    """
    parser = ArgumentParser(
        prog="bulk_wrapper", description="Command line tool to batch process other CLI tools"
    )
    parser.add_argument(
        "-w",
        "--workflow",
        type=str,
        help="The automation workflow we want to run.",
    )
    # Force option
    parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="""
        Force option to redo calculations (default behaviour is to skip if input data timestamp is
        earlier than the output data timestamp - i.e. only update if there is a change)
        """
    )
    # Multiprocessing Option
    parser.add_argument(
        "-mp",
        "--multiprocessing",
        action="store_true",
        default=False,
        help="""
        If true, parallelizes work over number of CPU cores on the host machine.
        """
    )
    # Current date (i.e. date for the data being run)
    parser.add_argument(
        "-sd",
        "--start-date",
        type=str,
        help="The start date of data that we are processing.",
    )
    # Parameters for number of periods and force
    parser.add_argument(
        "-ed",
        "--end-date",
        type=str,
        help="End date for the data we are processing",
    )
    # Argument to list workflows in argo
    parser.add_argument(
        "--cli-args",
        help="The positional args we want to pass to the CLI script."
    )
    return parser


SCRIPT = {
    "ndm_unadjusted": "run_pipeline.py",
    "ndm_adjusted": "run_pipeline.py"
}

if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()
    workflow = args.workflow
    script_name = SCRIPT[workflow]
    force = args.force
    PARALLEL = args.multiprocessing
    start_date = args.start_date
    end_date = args.end_date
    cli_args = args.cli_args
    # Get date difference
    d1 = datetime.strptime(start_date, "%Y-%m")
    d2 = datetime.strptime(end_date, "%Y-%m")
    # S3 Client
    client = S3Client.get_client()
    # List of commands that need to be run
    cmd_list = []
    for dt in rrule.rrule(rrule.MONTHLY, dtstart=d1, until=d2):
        # Get the args that will be passed to the CLI program
        cmd_args = cli_args + f" --date {dt.strftime('%Y-%m-%d')}"
        # os.system(f"python {script_name} {cmd_args}")
        cmd_list.append(f"python {script_name} {cmd_args}")
        # os.system(f"python {script_name} {cmd_args}")
        # print(f"finished {dt.strftime('%Y-%m-%d')}")
    t1 = time.time()
    if PARALLEL:
        # Defaults to number of logical CPU cores on host machine (i.e. if host CPU has chip
        # multithreading (e.g. hyperthreading), then this picks up 2 logical CPUs for every
        # physical CPU core.
        pool = Pool()
        pool.map(os.system, cmd_list)
        pool.close()
        pool.join()
        if environ().FC_VERBOSE:
            print("Parallel processing finished.")
    else:
        for cmd in cmd_list:
            if environ().FC_VERBOSE:
                print(f"Starting: {cmd}")
            os.system(cmd)
            if environ().FC_VERBOSE:
                print(f"Finished {cmd}")
        if environ().FC_VERBOSE:
            print(f"Serial processing finished.")
    if environ().FC_VERBOSE:
        print(f"Processing time is: {time.time() - t1} seconds")