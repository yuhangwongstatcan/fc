from __future__ import annotations
import importlib
import json
import os
import re
from pathlib import Path

from typing import Dict, Optional, Callable

import pandas as pd
import pandera as pa

from pytest_cases import parametrize
from pandas.testing import assert_frame_equal
from pandas.api.types import is_numeric_dtype

from pydantic import BaseModel
from pydantic.types import FilePath
from pydantic.types import DirectoryPath


# When invoking a specific test with the VSCode testing GUI, the CWD defaults
# to the project root. In all cases, we want to make sure the test runner is invoked
# from the src folder.
test_cwd = Path(os.getcwd())
if "src" not in test_cwd.parts:
    os.chdir(Path(test_cwd, "src"))

# Any custom modules need to be imported after we are certain the test runner is
# running from cwd = src
from config.api import DataSource
from config.api import Stage

from modules.utils.schema import load_datasource_schema
from modules.io_helpers import safe_read_pandas

datasource_path = Path(__file__).parent / "datasource"


class FCTestConfig(BaseModel):
    """
    A pydantic model for the FC Test configuration.
    """

    datasource: str
    stage: str
    test_name: str
    test_folder_path: DirectoryPath
    input: str
    output: str
    doc: Optional[str]
    reference_year: Optional[str]
    test_function: Callable
    second_function: Optional[Callable]


def load_test_data(filepath: FilePath, schema: pa.SchemaModel) -> pd.DataFrame:
    """
    """
    # For E311 and IPIL_Air, some columns have meaningful leading zeros, so in order to retain them, read as string immediately
    if filepath.parts.__contains__("e311"):
        df = pd.read_csv(
            filepath,
            keep_default_na=False,
            na_values="",
            dtype={
                "batch_id": str,
                "month": str,
                "doc_num": str,
                "traveller_flow": str,
                "arriving_by_boxes": str,
                "purpose_of_trip": str,
                "arriving_from": str,
            },
        )
    elif filepath.parts.__contains__("ipil_air"):
        df = pd.read_csv(
            filepath,
            keep_default_na=False,
            na_values="",
            dtype={
                "port_of_entry": str,
                "wloc": str,
                "country_of_residence": str,
            },
        )
    elif filepath.parts.__contains__("nghh"):
        df = pd.read_csv(
            filepath,
            keep_default_na=False,
            na_values="",
            dtype={
                "port_of_entry": str,
                "wloc": str,
                "country_of_residence": str,
            },
        )
    else:
        df = pd.read_csv(filepath, keep_default_na=False, na_values="",)

    # check each column's dtype and cast to int64 if it's float64
    for col in df.columns:
        if is_numeric_dtype(df[col]):
            df[col] = df[col].astype("Int64")

    df = df.fillna(pd.NA)
    # If there is a "unix_timestamp" column, convert its type so that it can be compared to
    # the output of the test function.
    if "unix_timestamp" in df:
        df["unix_timestamp"] = pd.to_datetime(df["unix_timestamp"], unit="s")

    return df


def unit_test_generator(datasource_path: Path):
    """
    **Description:**

    Generates cases for all of the unit tests at a given path.

    Args:
        datasource_path: Path
            [description]. Valid Values are [values]

    Kwargs:
        dataset: Dataset=None
            [description]. Valid Values are [values]

    Yields:
        [type]:
            [description]. Valid Values are [values]
    """
    for path in datasource_path.rglob("fctest.config.json"):
        # Test config path
        fc_test_config_path = FilePath.validate(value=path)
        # Test folder path
        test_folder_path = DirectoryPath.validate(fc_test_config_path.parent)
        # Test name
        test_name = fc_test_config_path.parent.stem
        # Load the test config into a dictionary
        fc_test_config: Dict[str, str] = json.loads(
            Path(fc_test_config_path).read_text()
        )
        # Load function in test
        datasource = test_folder_path.parent.parent.stem
        # Modules always follow naming 'datasource_\d\d\d', so even if the
        # function under test is a validation, we need to import the module
        # with naming 'datasource_\d\d\d'.
        test_module_name = re.sub(
            r"_v\d{3}",
            lambda match: "_" + match.group(0)[2:],
            fc_test_config["test_function"],
        )
        test_function_module_parts = [
            "datasource",
            datasource,
            "data_processing",
            # Modules always follow naming 'datasource_\d\d\d', so even if the
            # function under test is a validation, we need to import the module
            # with naming 'datasource_\d\d\d'.
            test_module_name,
        ]
        test_function_module_str = ".".join(test_function_module_parts)
        test_function_module = importlib.import_module(test_function_module_str)
        # Get the function under test
        test_function = getattr(test_function_module, fc_test_config["test_function"])
        # If there is a business rule, we need to add this business rule to the test
        # config
        # Test module name and business rule name are the same, so that's why
        # `test_module_name` is being used to import the business rule from the
        # test function module.
        business_rule = (
            getattr(test_function_module, test_module_name)
            if test_module_name in test_function_module.__dict__.keys()
            else None
        )
        function_under_test_is_validation = re.search(
            r"_v\d{3}", fc_test_config["test_function"]
        )
        # Define the second function to be the business rule if the function under
        # test is a validation and there exists a business rule in the same module, else None
        second_function = (
            business_rule
            if business_rule and function_under_test_is_validation
            else None
        )
        fc_test_config["test_function"] = test_function
        # Get all of the data associated with the test case in question.
        yield FCTestConfig(
            datasource=datasource,
            test_name=test_name,
            test_folder_path=test_folder_path,
            **fc_test_config,
            second_function=second_function
        )


def run_test_case(test_case_instance):
    TestSchema = load_datasource_schema(
        DataSource[test_case_instance.datasource], Stage[test_case_instance.stage]
    )

    if Path(test_case_instance.test_folder_path, test_case_instance.input).parts.__contains__("ipil_air"):
        input_df = TestSchema(
            pd.read_csv(
                Path(test_case_instance.test_folder_path, test_case_instance.input),
                dtype={
                    "port_of_entry": str,
                    "wloc": str,
                    "country_of_residence": str,
                },
                )
            ).fillna(pd.NA)
    elif Path(test_case_instance.test_folder_path, test_case_instance.input).parts.__contains__("nghh"):
        input_df = TestSchema(
            pd.read_csv(
                Path(test_case_instance.test_folder_path, test_case_instance.input),
                dtype={
                    "port_of_entry": str,
                    "wloc": str,
                    "country_of_residence": str,
                },
                )
            ).fillna(pd.NA)
    else:
        input_df = safe_read_pandas(
            Path(test_case_instance.test_folder_path, test_case_instance.input), TestSchema
        )
    # Expected df needs to be loaded later in the test runner because
    # It might be a validation or a business rule - need to load the
    # validation schema in the case of validation
    # expected_df = safe_read_pandas(Path(test_case_instance.test_folder_path, test_case_instance.output), TestSchema)
    expected_df = load_test_data(
        Path(test_case_instance.test_folder_path, test_case_instance.output), TestSchema
    )
    # Cases 1 and 2: just a business rule or just a validation (i.e. we never store a business
    # rule since the function under test is sufficient)
    if not test_case_instance.second_function and not test_case_instance.reference_year:
        obj = test_case_instance.test_function(input_df)
        # TODO: need additional check if name matches v### then unpack _, actual_df
        # else unpack actual_df, _
        if isinstance(obj, tuple):
            # If the function returning a tuple is a validation it outputs (df, validation_df) so take the latter
            if re.search(r"_v\d{3}", test_case_instance.test_name):
                _, actual_df = obj
            # If the function returning a tuple is a business rule it outputs (df, auxiilary_df) so take the former
            else:
                actual_df, _ = obj
        else:
            actual_df = obj
    # Case 3: validation and a business rule, need to run business rule first and capture outputs
    # If the test function contains '_v\d\d\d', it is a validation, else it is a data processing function.
    # No reference year required
    elif not test_case_instance.reference_year:

        obj = test_case_instance.second_function(input_df)
        # A business rule may or may not return an auxiliary_df, so we need to check both cases
        # and unpack the 2-tuple if one was returned.
        if isinstance(obj, tuple):
            df, auxiliary_df = obj
            actual_df = test_case_instance.test_function(df, auxiliary_df)
        else:
            df = obj
            actual_df = test_case_instance.test_function(df)
    # Case 4: Reference year required as an input to the function.
    # For now, this only applies to the manual entry data sources (manual_entry_vehicles and manual_entry_travellers)
    else:
        actual_df = test_case_instance.test_function(
            input_df, test_case_instance.reference_year
        )

    # Cast all columns of both dataframes to string type as we only care about comparing their values.
    actual_df = (
        actual_df.astype(str)
        .sort_values(list(actual_df.columns))
        .reset_index(drop=True)
    )
    expected_df = (
        expected_df.astype(str)
        .sort_values(list(expected_df.columns))
        .reset_index(drop=True)
    )
    assert_frame_equal(actual_df, expected_df, check_dtype=False)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "nexus_hwy")))
def test_nexus_hwy(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "e63_1")))
def test_e63_1(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "ipil_air")))
def test_ipil_air(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "nghh")))
def test_nghh(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "ipil_hwy")))
def test_ipil_hwy(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "pik")))
def test_pik(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "e311")))
def test_e311(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "trc")))
def test_trc(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "manual_entry_vehicles")))
def test_manual_entry_vehicles(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "manual_entry_travellers")))
def test_manual_entry_travellers(test_case_instance):
    run_test_case(test_case_instance)

@parametrize(test_case_instance=unit_test_generator(Path(datasource_path, "e63")))
def test_e63(test_case_instance):
    run_test_case(test_case_instance)

