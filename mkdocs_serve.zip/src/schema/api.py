#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
**Author(s)**

- Andres Solis Montero - `andres.solismontero@canada.ca`

**Created On:** April 15 2021

**Description:**

Schema loader and doc generator

**Examples:**

```python
[description]
```
"""
from genericpath import exists
import re
import yaml
from os.path import join
from os.path import dirname
from os import makedirs
import numpy as np
import pandas as pd
from dataclasses import dataclass
from dataclasses import field
from dataclasses import asdict
from modules.utils.schema import tuplify
from modules.utils.schema import naming
from config.api import DataSource
from config.api import Stage
from config.api import AutoEnum
from config.api import ValParams
from modules.utils.schema import namedtupe_from_mappping
from enum import auto
from typing import List
from typing import Optional
from cachetools import cached
from cachetools.keys import hashkey

class RecursiveSchemaDefinition(Exception):
    pass

class Load(AutoEnum):
    datasource    = auto()
    business_rule = auto()
    validation    = auto()


class FuncParams(AutoEnum):
    input = auto()
    output= auto()

@dataclass
class Extends:
    base: str
    exclude: Optional[list] = field(default_factory=lambda:[])

@dataclass
class Column:
    name:    str
    ptype:   str
    dtype:   Optional[str] = None
    ref:     Optional[str] = None
    desc_en: Optional[str] = None
    desc_fr: Optional[str] = None

@dataclass
class Schema:
    id: str
    extends: Optional[Extends]      = None
    keys   : Optional[List[str]]    = field(default_factory=lambda: [])
    columns: Optional[List[Column]] = field(default_factory=lambda: [])

    @staticmethod
    @cached(cache={}, key=lambda ref_id, loaded=None: hashkey(ref_id))
    def load(ref_id:str, loaded=None) -> 'Schema':
        """
        **Description:**

        Loads a generic schema from a json file given an unique ref_id.

        **Examples:**

        ```python
        a = Schema.load('business_rule/ipil_hwy_010/input')
        ```

        Returns:
            Schema:
                Returns a general schema object. This object can be used to generate markdown doc
                or an usuable tuplify schema transform.
        """
        if loaded is None:
            loaded = set([])
        if ref_id in loaded:
            raise RecursiveSchemaDefinition
        else:
            loaded.add(ref_id)
        schema = None
        try:
            path = Schema.get_schema_path(ref_id)
            with open(path) as f:
                schema = Schema(**ValParams.kwargs(Schema, yaml.safe_load(f)))
                if schema.extends is not None:
                    schema.extends = Extends(**ValParams.kwargs(Extends,schema.extends))
                    base           = Schema.load(schema.extends.base, loaded=loaded)
                    base_cols      = [c for c in base.columns if c.name not in schema.extends.exclude]
                    schema.columns = base_cols + [Column(**ValParams.kwargs(Column,c)) for c in schema.columns]
                    base_keys      = [k for k in base.keys if k not in schema.extends.exclude]
                    schema.keys    = base_keys if not schema.keys else schema.keys
                else:
                    schema.columns = [Column(**ValParams.kwargs(Column,c)) for c in schema.columns]
        except:
            print("Exception")
        return schema

    @staticmethod
    def get_schema_path(ref_id: str) -> str:
        return f"{join(dirname(__file__), *ref_id.split('/'))}.yaml"

    @staticmethod
    def load_datasource_schema(datasource: DataSource, stage: Stage) -> 'Tuplify':
        """
        **Description:**

        loads a schema transform given a datasource and its stage

        **Examples:**

        ```python
        schema = load_datasource_schema(Datasource.ipil_hwy, Stage.raw)
        ```

        Returns:
            Tuplify:
                [description].
        """
        ref_id = join(Load.datasource.value, datasource.value, stage.name.lower())
        return Schema.load(ref_id).transform()

    @staticmethod
    def load_rule_schema(rule_name:str , params: FuncParams) -> Optional['Tuplify']:
        if re.match(r".*_v\d\d\d$", rule_name):
            return Schema.load_validation_schema(rule_name, params)
        else:
            return Schema.load_business_rule_schema(rule_name, params)

    @staticmethod
    def load_business_rule_schema(br_name:str, params: FuncParams) -> Optional['Tuplify']:
        ref_id = join(Load.business_rule.value, br_name.lower(), params.value)
        schema = Schema.load(ref_id)
        return schema.transform() if schema else None

    @staticmethod
    def load_validation_schema(v_name:str, params: FuncParams) -> Optional['Tuplify']:
        ref_id = join(Load.validation.value, v_name.lower(), params.value)
        schema = Schema.load(ref_id)
        if schema and not schema.keys and FuncParams.output == params:
            schema.keys = [col.name for col in schema.columns if col.name != 'count']
        return schema.transform() if schema else None

    @staticmethod
    def convert_index_to_yaml(df: pd.DataFrame, stage: Stage, datasource: DataSource):
        """
        **Description:**

        Converts an index csv file into a yaml file

        Args:
            stage: Stage
                [description]. Valid Values are [values]
            datasource: DataSource
                [description]. Valid Values are [values]
            object_name: str
                [description]. Valid Values are [values]
        """
        df = df.replace(pd.NA, '', regex=True)
        keys = [row["variable"] for _, row in df.iterrows() if row["primary_key"] == 1]
        sch_id = f"datasource/{datasource.value}/{stage.name.lower()}"


        _ptype = {
            "integer": "Int64",
            "int":"Int64",
            "float":"float64"
        }

        columns = [
            Column(
                name=row["variable"],
                ptype=_ptype[row["data_type"]] if row["data_type"] in _ptype else "object",
                dtype=row["data_type"],
                ref="datasource/dimension/reference" if row["data_type"] in ["dimension","dim"] else None,
                desc_en=row["desc_en"],
                desc_fr=row["desc_fr"] if isinstance(row["desc_fr"], np.float64) else row["desc_en"]
            )
            for _, row in df.iterrows()
        ]
        schema = Schema(id=sch_id, keys=keys, columns=columns)
        schema = asdict(schema)
        sch_path = Schema.get_schema_path(sch_id)
        sch_dir  = dirname(sch_path)
        if not exists(sch_dir):
            makedirs(sch_dir)

        with open(sch_path, "w") as fd:
            yaml.dump(schema, fd, sort_keys=False)
        return df

    def markdown(self) -> str:
        """
        **Description:**

        Generates markdown table from Schema

        **Examples:**

        ```python

        ```
        """

    @cached(cache={}, key=lambda self: hashkey(self.id))
    def transform(self) -> 'Tuplify':
        """
        **Description:**

        Returns a Tuplify object relevant to schema

        **Examples:**

        ```python
        a = Schema.load('rule/ipil_hwy_010/input')
        t = a.transform()
        ```

        Returns:
            Tuplify:
                named tuple where all the columns are attributes in lower case and stripped of
                weird characters.
                From each column attribute you can access, its index, name, and type.
                the attribute COLUMNS contains the ordered list of columns
                the attribute TYPES contains the ordered list of types
                the attribute NAME contains the Schema's id
                the attribute KEYS containsthe ordered list of keys
                the attribute IKEYS contains the ordered list of keys indices
        """


        cols = [(c.name, c.ptype, c.ref) for c in self.columns]

        transform = {
            naming(n): {"idx":i, "name": n, "type": t, "ref": r}
            for i, (n, t, r) in enumerate(cols)
        }
        keys_idx = [transform[naming(k)]['idx'] for k in self.keys]
        transform.update(
            {
                "COLUMNS": [c.name  for c in self.columns ],
                "TYPES":   [c.ptype for c in self.columns],
                "REFS":    [c.name  for c in self.columns if c.ref ],
                "DIMS":    [c.name for c in self.columns if c.ref and c.ref.startswith(join(Load.datasource.value, DataSource.dimension.value))],
                "TYPE": namedtupe_from_mappping({
                    "value": {c.name: c.ptype for c in self.columns}
                }),
                "NAME":    self.id,
                "KEYS":    self.keys,
                "IKEYS":   keys_idx,
            }
        )
        return tuplify(transform)


if __name__ == "__main__":
    from modules.utils.loaders import Loader
    # List of indices files
    # countries, ports, provinces_and_territories, us_states, work_locations
    list_idxs = []

    # Automatically include all REFERENCE file-base data sources
    timebased = DataSource.timebased()

    for stage in Stage:
        for datasource in DataSource:
            if datasource != DataSource.unknown:
                list_idxs.append((stage, datasource))


    for stage, datasource in list_idxs:
        try:
            df = Loader.get_datasource_index(stage, datasource)
            sch = Schema.convert_index_to_yaml(df, stage, datasource)
            print(stage, datasource)
        except Exception as e:
            # print(f"{stage}:{datasource}: No index file found")
            pass