#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: collin brown (collin.brown@canada.ca)
@created_at: March 4, 2020

This module contains a simple CLI to illustrate different releases that will
have to be performed in production.

@modified: Andres Solis Montero
Refactored and simplified 
"""
import argparse
import logging
import inspect

from typing import Callable, Dict

from modules.s3client import S3Client
from config.api import S3
from config.api import Stage
from config.api import DataSource
from dataclasses import dataclass

from analysis_reports import extract, utilities
from analysis_reports.data_processing.leading_report import (
    EXPORTED_MEMBERS as LEADING_REPORT_FUNCTIONS,
)
from analysis_reports.data_processing.main_report import (
    EXPORTED_MEMBERS as MAIN_REPORT_FUNCTIONS,
)

from datasource.travellers.dim import (
    DATA_SOURCE,
    TRAVELLER_TYPE,
    VEHICLE_TYPE,
    COUNTRY_OF_RESIDENCE,
    PLATE_COUNTRY,
)
from datasource.travellers.schema import TransformedSchema


@dataclass
class Location:
    stage: Stage
    datasource: DataSource
    year: int
    month: int
    day: int


@dataclass
class CopyOperation:
    src: Location
    dst: Location


@dataclass
class Release:
    src: Stage
    dst: Stage


def copy(client, A: Location, B: Location):
    basenameA = S3.get_s3_basename(A.stage, A.datasource, A.year, A.month, A.day)
    locA = S3.get_loc(A.stage, A.datasource, basenameA)
    basenameB = S3.get_s3_basename(B.stage, B.datasource, B.year, B.month, B.day)
    locB = S3.get_loc(B.stage, B.datasource, basenameB)
    if client.stat_loc(locA):
        client.cp_loc(locA, locB)
        print(
            f"""
            Succesful copy with the following details:
            Source location: {locA}
            Target location: {locB}
            """
        )


def _get_func_args(func: Callable, possible_args: Dict):
    spec = inspect.getfullargspec(func)  # Get the function's full specification
    defaults = (
        dict(zip(spec.args[-len(spec.defaults) :], spec.defaults))
        if spec.defaults
        else {}
    )
    func_args = [
        arg for arg in spec.args if arg not in defaults or arg not in possible_args
    ]

    # Filter the dictionary to only include the arguments needed by the function
    return {k: v for k, v in possible_args.items() if k in func_args}


def leading_release(release: Release, year: int, month: int):
    """
    Performs the leading release for a given year and month.
    """
    # Get S3Client
    client = S3Client.get_client()

    operations = [
        CopyOperation(
            Location(release.src, DataSource.vehicles_leading, year, month, 1),
            Location(release.dst, DataSource.vehicles_leading, year, month, 1),
        ),
        CopyOperation(
            Location(release.src, DataSource.travellers_leading, year, month, 1),
            Location(release.dst, DataSource.travellers_leading, year, month, 1),
        ),
    ]
    for operation in operations:
        copy(client, operation.src, operation.dst)

    if release.dst == Stage.PRE_RELEASE:
        # Only run this on pre-release
        overall_data = extract.load_reference_periods(year, month)
        # As of August 2023, we expect to have some invalid country of residence entries that were processed before
        # validations were implemented on data intake. We have to remove these invalid entries when doing calculations
        invalid_country_mask = (
            overall_data[TransformedSchema.country_of_residence].astype(str).str.len()
            == 5
        )
        overall_data = TransformedSchema(overall_data[invalid_country_mask])

        # Define and apply leading datasource masks
        datasource_mask = overall_data[TransformedSchema.data_source].isin(
            [DATA_SOURCE.IPIL_Highway.value, DATA_SOURCE.PIK.value]
        )
        traveller_mask = overall_data[TransformedSchema.traveller_type].isin(
            [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
        )
        vehicle_mask = overall_data[TransformedSchema.vehicle_type].isin(
            [VEHICLE_TYPE.commercial_aircraft.value, VEHICLE_TYPE.automobile.value]
        )
        nan_resident_mask = (
            overall_data[TransformedSchema.country_of_residence]
            != COUNTRY_OF_RESIDENCE.not_applicable
        )
        plate_mask = overall_data[TransformedSchema.plate_country].isin(
            [
                PLATE_COUNTRY.canada.value,
                PLATE_COUNTRY.united_states.value,
                PLATE_COUNTRY.not_available.value,
            ]
        )

        overall_data = overall_data[
            datasource_mask
            & traveller_mask
            & vehicle_mask
            & nan_resident_mask
            & plate_mask
        ]

        # Set possible arguments to pass to each function
        possible_args = {"data": overall_data, "year": int(year), "month": int(month)}

        excel_config = []

        for func in LEADING_REPORT_FUNCTIONS:
            logging.info(f"Running {func}")
            matched_args = _get_func_args(
                func, possible_args
            )  # Collect the arguments to pass to the function
            excel_config.append(func(**matched_args))

        utilities.report_to_excel(
            "leading_cad_report",
            utilities.ExcelConfig(data=excel_config),
            year,
            month,
        )

        utilities.write_report_to_azure("leading_cad_report", client, year, month)


def main_release(release: Release, year: int, month: int):
    """
    Performs the leading release for a given year and month.
    """
    # Get S3Client
    client = S3Client.get_client()

    operations = [
        CopyOperation(
            Location(release.src, DataSource.vehicles_main, year, month, 1),
            Location(release.dst, DataSource.vehicles_main, year, month, 1),
        ),
        CopyOperation(
            Location(release.src, DataSource.travellers_main, year, month, 1),
            Location(release.dst, DataSource.travellers_main, year, month, 1),
        ),
        CopyOperation(
            Location(release.src, DataSource.ndm_adjusted, year, month, 1),
            Location(release.dst, DataSource.ndm_adjusted, year, month, 1),
        ),
    ]
    for operation in operations:
        copy(client, operation.src, operation.dst)

    if release.dst == Stage.PRE_RELEASE:
        overall_data = extract.load_reference_periods(year, month)
        # As of August 2023, we expect to have some invalid country of residence entries that were processed before
        # validations were implemented on data intake. We have to remove these invalid entries when doing calculations
        invalid_country_mask = (
            overall_data[TransformedSchema.country_of_residence].astype(str).str.len()
            == 5
        )
        overall_data = TransformedSchema(overall_data[invalid_country_mask])

        # Define and apply main datasource masks
        traveller_mask = overall_data[TransformedSchema.traveller_type].isin(
            [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
        )
        nan_resident_mask = (
            overall_data[TransformedSchema.country_of_residence]
            != COUNTRY_OF_RESIDENCE.not_applicable.value
        )

        overall_data = overall_data[traveller_mask & nan_resident_mask]

        # Set possible arguments to pass to each function
        possible_args = {"data": overall_data, "year": int(year), "month": int(month)}

        excel_config = []

        for func in MAIN_REPORT_FUNCTIONS:
            logging.info(f"Running {func}")
            matched_args = _get_func_args(
                func, possible_args
            )  # Collect the arguments to pass to the function
            excel_config.append(func(**matched_args))

        utilities.report_to_excel(
            "main_cad_report",
            utilities.ExcelConfig(data=excel_config),
            year,
            month,
        )

        utilities.write_report_to_azure("main_cad_report", client, year, month)


if __name__ == "__main__":
    """
    CLI arguments:

    --leading-pre-release
    --leading-release
    --main-pre-release
    --main-release

    --year
    --month
    """

    arguments = {
        ("--leading-pre-release", "Performs the leading pre_release"),
        ("--leading-release", "Performs the leading release"),
        ("--main-pre-release", "Performs the main pre_release"),
        ("--main-release", "Performs the main release"),
    }
    parser = argparse.ArgumentParser(description="Loading")
    for arg in arguments:
        parser.add_argument(arg[0], help=arg[1], action="store_true")
    # Year and month information
    parser.add_argument(
        "--year", type=int, help="The year for the release", required=True
    )
    parser.add_argument(
        "--month", type=int, help="The month for the release", required=True
    )

    args = parser.parse_args()

    pre_release = Release(Stage.AGGREGATED, Stage.PRE_RELEASE)
    release = Release(Stage.PRE_RELEASE, Stage.RELEASE)

    if args.leading_pre_release:
        leading_release(pre_release, args.year, args.month)
    if args.leading_release:
        leading_release(release, args.year, args.month)
    if args.main_pre_release:
        main_release(pre_release, args.year, args.month)
    if args.main_release:
        main_release(release, args.year, args.month)
