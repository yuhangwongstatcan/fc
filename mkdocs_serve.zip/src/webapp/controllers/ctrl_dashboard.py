#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# ------------------------------------------------------
import time
from flask import jsonify
from webapp import app

from webapp.models.session import init_session
from webapp.models.dashboard import (
    list_latests_run,
    run_leading_indicator_form,
    run_sequential_pipeline_form,
)
from modules.argo import argo_dag_entrypoint, argo_entrypoint, argo_ndm_out_entrypoint

from webapp.models.dashboard import check_inbox_form
from webapp.models.dashboard import demography_PIK_report_form
from webapp.models.dashboard import run_pipeline_form
from webapp.models.dashboard import run_sa_form
from webapp.models.dashboard import run_sign_off_form
from webapp.models.dashboard import run_validation_form

from webapp.models.io import (
    LeadingIndicatorReportParams,
    RunCompositePipelineParams,
    RunPipelineParams,
    demographyPIKreportParams,
    SAParams,
    SignOffParams,
    NDMValidationParams,
    NdmOutboxParams,
)

from webapp.models.dashboard import run_prepare_ndm
from webapp.models.translation import tr

from webapp.models.dashboard import Triggers


@app.route("/check_inbox", methods=["POST", "GET"])
def check_inbox():
    init_session()
    argo_entrypoint(
        cli_script="loader.py", cmd=["--check-inbox"], pipeline_name="Check Inbox"
    )
    time.sleep(2)
    return jsonify(check_inbox_form(check_inbox.__name__))


@app.route("/demography_PIK_report", methods=["POST", "GET"])
def demography_PIK_report():
    init_session()
    params = demographyPIKreportParams.form()
    if params.isValid():
        argo_entrypoint(
            cli_script="pik_report.py",
            cmd=[
                "--date",
                params.date,
            ],
            pipeline_name=f"Demography PIK Report ({params.date})",
        )
    time.sleep(2)
    return jsonify(demography_PIK_report_form(demography_PIK_report.__name__, params))


@app.route("/run_pipeline", methods=["POST", "GET"])
def run_pipeline():
    init_session()
    params = RunPipelineParams.form()
    if params.isValid():
        argo_entrypoint(
            cli_script="run_pipeline.py",
            cmd=[
                "--data-source",
                params.datasource,
                "--date",
                params.date,
                "--pipeline-class",
                params.pipeline,
                f"--reference_year {params.reference_year}"
                if params.reference_year
                else "",
            ],
            pipeline_name=f"{params.datasource}: {params.pipeline} ({params.date})",
        )
    time.sleep(2)
    return jsonify(run_pipeline_form(run_pipeline.__name__, params))


@app.route("/run_sequential_pipeline", methods=["POST", "GET"])
def run_sequential_pipeline():
    init_session()
    params = RunCompositePipelineParams.form()
    if params.isValid():
        argo_dag_entrypoint(
            composite_pipeline=params.pipeline,
            cmd=[
                "--date",
                params.date,
                f"--reference_year {params.reference_year}"
                if params.reference_year
                else "",
            ],
        )
    time.sleep(2)
    return jsonify(
        run_sequential_pipeline_form(run_sequential_pipeline.__name__, params)
    )


@app.route("/run_sa", methods=["POST", "GET"])
def run_sa():
    init_session()
    params = SAParams.form()
    if params.isValid():
        argo_entrypoint(
            cli_script="sa_in.py",
            cmd=[
                "--num-periods",
                params.periods,
                "--force",
                params.force,
                "--date",
                params.date,
            ],
            pipeline_name=f"Seasonal Adjustment Prep ({params.date})",
        )
    time.sleep(2)
    return jsonify(run_sa_form(run_sa.__name__, params))


@app.route("/run_sign_off", methods=["POST", "GET"])
def run_sign_off():
    init_session()
    params = SignOffParams.form()
    if params.isValid():
        argo_entrypoint(
            cli_script="release.py",
            cmd=params.cliArgsFromForm(),
            pipeline_name=f"{params.release}: {params.location} ({params.date})",
        )
    time.sleep(2)
    return jsonify(run_sign_off_form(run_sign_off.__name__, params))


@app.route("/run_leading_indicator", methods=["POST", "GET"])
def run_leading_indicator():
    init_session()
    params = LeadingIndicatorReportParams.form()
    if params.isValid():
        argo_entrypoint(
            cli_script="generate_leading_indicator_report.py",
            cmd=params.cliArgsFromForm(),
            pipeline_name=f"leading indicator report ({params.year1}, {params.year2}, {params.year3}, {params.month1}, {params.month2}, {params.month3})",
        )
    time.sleep(2)
    return jsonify(run_leading_indicator_form(run_leading_indicator.__name__, params))


@app.route("/run_ndm_validation", methods=["POST", "GET"])
def run_ndm_validation():
    init_session()
    params = NDMValidationParams.form()
    if params.isValid():
        argo_entrypoint(
            cli_script=f"{params.validation}.py",
            cmd=params.cliArgsFromForm(),
            pipeline_name=f"{params.validation} ({params.date1})",
        )
    time.sleep(2)
    return jsonify(run_validation_form(run_ndm_validation.__name__, params))


@app.route("/run_ndm_outbox", methods=["POST", "GET"])
def run_ndm_outbox():
    init_session()
    params = NdmOutboxParams.form()
    if params.isValid():
        argo_ndm_out_entrypoint(params.periods, params.date)
    time.sleep(2)
    return jsonify(run_prepare_ndm(run_ndm_outbox.__name__, params))


@app.route("/triggers", methods=["GET", "POST"])
def triggers():
    init_session()
    return jsonify(
        Triggers(
            title=tr("Actions"),
            forms=[
                check_inbox_form(check_inbox.__name__),
                run_sequential_pipeline_form(run_sequential_pipeline.__name__),
                run_pipeline_form(run_pipeline.__name__),
                run_sa_form(run_sa.__name__),
                run_sign_off_form(run_sign_off.__name__),
                run_leading_indicator_form(run_leading_indicator.__name__),
                run_validation_form(run_ndm_validation.__name__),
                run_prepare_ndm(run_ndm_outbox.__name__),
                demography_PIK_report_form(demography_PIK_report.__name__),
            ],
        )
    )


@app.route("/runs", methods=["POST", "GET"])
def runs():
    """
    List latest KFP pipeline runs and status

    None -> RunOutput
    """
    init_session()
    return jsonify(list_latests_run())
