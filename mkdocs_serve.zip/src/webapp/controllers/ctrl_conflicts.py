#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
from flask import jsonify
from webapp import app
from webapp.models.conflicts_historical import get_stage

from webapp.models.session import init_session
from webapp.models.io import StageParams
from config.api import Mode

@app.route("/get_conflicts", methods=["POST"])
def get_conflicts():
    """
    List all the existing conflicts in a Stage

    StageParams -> StageOutput
    """
    init_session()
    params = StageParams.load()
    
    return jsonify(get_stage(params, Mode.conflicts))
