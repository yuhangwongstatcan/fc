#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------

from flask import jsonify
from webapp import app
from webapp.models.session import init_session
from config.api import DataSource
from modules.s3client import S3Client
from os.path import basename
from config.api import Stage
from config.api import S3
from webapp.models.diff import auto_merge
from webapp.models.io import DiffControlParams
from config.api import Mode
from webapp.models.io import DiffParams
from webapp.models.diff import compute_diff


@app.route("/diff", methods=["POST"])
def diff():
    """
    Computes diff between two S3 Locations specified in DiffParams

    DiffParams -> DiffData
    """
    init_session()

    params = DiffParams.load()
    stage = Stage[params.stage]
    datasource = DataSource[params.datasource]

    A = S3.get_loc(stage=stage, datasource=datasource, basename=params.basename)

    if params.mode == Mode.conflicts.value:
        B = S3.get_conflicts_loc(
            stage=stage, datasource=datasource, basename=params.basename
        )
    else:
        loc = S3.get_historical_loc(
            stage=stage, datasource=datasource, basename=params.basename
        )
        client = S3Client.get_client()
        for version in client.ls_objs(
            loc.bucket,
            loc.prefix,
            only_files=True,
            recursive=True,
            default_folder_file=False,
        ):

            B = S3.obj_to_loc(version.bucket_name, version.object_name)
            if params.version == basename(version.object_name):
                break

    return jsonify(
        compute_diff(
            datasource,
            stage,
            params.basename,
            A,
            B,
            page=params.page,
            filters=params.filters,
            limit=100,
        )
    )


@app.route("/discard", methods=["POST"])
def discard():
    """ Discard conflicted file """
    init_session()
    opt = DiffControlParams.load()
    client = S3Client.get_client()
    client.remove_object(opt.path_bucket, opt.path)
    return jsonify(True)


@app.route("/accept", methods=["POST"])
def accept():
    """ Accepts the conflicted file , creates a new version from the previous file"""
    init_session()
    opt = DiffControlParams.load()
    client = S3Client.get_client()

    # A_loc  = S3.obj_to_loc(opt.org_bucket, opt.original)
    B_loc = S3.obj_to_loc(opt.path_bucket, opt.path)

    stage = Stage[opt.stage]
    datasource = DataSource[opt.datasource]

    client.cp_loc_to_stage(
        B_loc, stage, datasource, opt.basename, fallback_on_historical=True
    )
    client.remove_object(B_loc.bucket, S3.loc_to_obj(B_loc))
    return jsonify(True)


@app.route("/rollback", methods=["POST"])
def rollback():
    """ Rollbacks a version of a file to the current state"""
    init_session()
    opt = DiffControlParams.load()
    client = S3Client.get_client()
    A_loc = S3.obj_to_loc(opt.org_bucket, opt.original)
    B_loc = S3.obj_to_loc(opt.path_bucket, opt.path)

    stage = Stage[opt.stage]
    datasource = DataSource[opt.datasource]

    hist_loc = S3.get_historical_loc(stage, datasource, opt.basename)

    client.mv_loc(A_loc, hist_loc)
    client.cp_loc(B_loc, A_loc)
    return jsonify(True)


@app.route("/merge", methods=["POST"])
def merge():
    init_session()
    opt = DiffControlParams.load()
    client = S3Client.get_client()
    A_loc = S3.obj_to_loc(opt.org_bucket, opt.original)
    B_loc = S3.obj_to_loc(opt.path_bucket, opt.path)

    stage = Stage[opt.stage]
    datasource = DataSource[opt.datasource]

    merge = auto_merge(datasource, stage, A_loc, B_loc)
    # Note: the "nan" values produced are type string, so need to replace them so that "nan" values
    # don't get written to the CSV produced.
    merge = merge.replace("<NA>", "")
    merge = merge.replace("nan", "")
    stage = Stage[opt.stage]
    datasource = DataSource[opt.datasource]

    client.upload_df_to_stage(
        merge, stage, datasource, opt.basename, fallback_on_historical=True
    )
    client.remove_object(B_loc.bucket, S3.loc_to_obj(B_loc))

    return jsonify(True)
