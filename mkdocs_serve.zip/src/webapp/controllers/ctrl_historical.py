#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
import re
from flask import jsonify
from webapp import app
from webapp import prefix_url_for as url_for
from webapp.models.session import init_session
from config.api import DataSource
from modules.s3client import S3Client
from os.path import basename
from config.api import Stage
from config.api import S3
from webapp.models.translation import tr
from webapp.models.conflicts_historical import get_stage

from config.api import Mode
from webapp.models.io import DataItemOutput
from webapp.models.io import DataEventOutput
from webapp.models.io import TimelineOutput
from webapp.models.io import StageParams
from webapp.models.io import DiffParams

@app.route("/get_historical", methods=["POST"])
def get_historical():
    """ Returns historical timeline information for the specific stage and year"""
    init_session()
    params = StageParams.load()

    return jsonify(get_stage(params, Mode.historical))


@app.route("/file_history", methods=["POST"])
def file_history():
    """ Gets the history of a particular file """
    init_session()
    params = DiffParams.load()
    client = S3Client.get_client()
    stage = Stage[params.stage]
    datasource = DataSource[params.datasource]
    original = S3.get_loc(stage, datasource, params.basename)
    historical = S3.get_historical_loc(stage, datasource, params.basename)

    timeline = TimelineOutput(
        datasource=f"{S3.loc_to_obj(original)}",
        count=0,
        count_label=tr("Version(s)"),
        timeline=[],
    )
    regex = re.compile("(\d{4})_(\d{2})_(\d{2})_(\d{2})_(\d{2})_(\d{2})\.\d+")

    events = {}
    found, last = None, None
    for history in client.ls_objs(
        historical.bucket,
        historical.prefix,
        only_files=True,
        recursive=True,
        default_folder_file=False,
    ):
        try:
            name = basename(history.object_name)
            year, month, day, hour, mins, _ = regex.match(name).groups()
            href = url_for(
                "history",
                stage=stage.name,
                datasource=datasource.value,
                basename=params.basename,
                version=name,
            )

            label = f"{hour}:{mins}"
            event = f"{year}/{month}/{day}"

            item = DataItemOutput(label=label, href=href, style="")
            timeline.count += 1
            if event in events:
                events[event].content.append(item)
            else:
                events[event] = DataEventOutput(event=event, content=[item])

            if name == params.version:
                found = item
            last = item
        except Exception:
            continue

    if found is None:
        found = last
    found.label = f"{found.label} *"

    events = sorted(events.values(), key=lambda x: x.event)
    events.insert(0, DataEventOutput(event=tr("Initial"), content=[]))
    events.append(DataEventOutput(event=tr("Now"), content=[]))
    timeline.timeline = events

    return jsonify(timeline)
