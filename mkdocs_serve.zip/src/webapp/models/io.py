#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
import datetime
from typing import List
from dataclasses import dataclass
from dataclasses import field
from enum import auto
from config.api import AutoEnum
from config.api import Mode
from config.api import DataSource
from config.api import Stage
from flask import request
from config.argo import fc_composite_pipelines
from modules.pipeline import get_pipelines
import re

from config.api import NDMValidations


def GETasdict(args):
    return {
        (k[:-2] if k[-2:] == "[]" else k): (
            args.getlist(k) if k[-2:] == "[]" else args.get(k)
        )
        for k in args.keys()
    }


@dataclass
class GetParams(object):
    pass

    @classmethod
    def load(cls):
        return cls(**GETasdict(request.args))


@dataclass
class PostParams(object):
    pass

    @classmethod
    def load(cls):
        obj = request.get_json()
        obj = {} if obj is None else obj
        return cls(**obj)

    @classmethod
    def form(cls):
        obj = request.get_json(force=True)
        obj = {} if obj is None else obj
        return cls(**{o["name"]: o["value"] for o in obj})


@dataclass
class DataItemOutput:
    label: str
    href: str
    style: str


@dataclass
class DataEventOutput:
    event: str
    content: List[DataItemOutput]


@dataclass
class TimelineOutput:
    datasource: str
    count: int
    count_label: str
    timeline: List[DataEventOutput]


@dataclass
class StageOutput:
    header: str
    desc: str
    mode: Mode
    bucket: str
    stage: str
    year: str
    count: int
    label: str
    arial_label: str
    timelines: TimelineOutput


@dataclass
class StageParams(PostParams):
    stage: str
    year: str


@dataclass
class DiffParams(PostParams):
    mode: str
    version: str
    stage: str
    datasource: str
    basename: str
    page: int = 1
    filters: List = field(default_factory=list)


@dataclass
class DiffControlParams(PostParams):
    basename: str = None
    stage: str = None
    datasource: str = None
    path_bucket: str = None
    path: str = None
    org_bucket: str = None
    original: str = None


@dataclass
class RunRowOutput:
    name: str
    status: str
    start: str
    duration: str


@dataclass
class RunHeader:
    name: str
    status: str
    start: str
    duration: str


@dataclass
class RunOutput:
    label: str
    header: RunHeader
    caption: str
    data: List[RunRowOutput]


class Release(AutoEnum):
    main = auto()
    leading = auto()


class Force(AutoEnum):
    YES = auto()
    NO = auto()


@dataclass
class demographyPIKreportParams(PostParams):
    date: str

    def isValid(self):
        return (
            self.isDateValid()
        )

    def isDateValid(self):
        return re.match("\d{4}-\d{2}-\d{2}", self.date)



@dataclass
class RunPipelineParams(PostParams):
    datasource: str
    pipeline: str
    date: str
    reference_year: str

    def isValid(self):
        return (
            self.isDataSourceValid()
            and self.isPipelineValid()
            and self.isDateValid()
            and self.isReferenceYearValid()
        )

    def isDataSourceValid(self):
        return DataSource[self.datasource] in DataSource.timebased()

    def isPipelineValid(self):
        return self.pipeline in [
            name for name, _ in get_pipelines(DataSource[self.datasource])
        ]

    def isDateValid(self):
        return re.match("\d{4}-\d{2}-\d{2}", self.date)

    def isReferenceYearValid(self):
        # This regex will require a code refactor in around 8,000 years
        return re.match("^(?:\d{4}|)$", self.reference_year)


@dataclass
class RunCompositePipelineParams(PostParams):
    pipeline: str
    date: str
    reference_year: str

    def isValid(self):
        return (
            self.isPipelineValid()
            and self.isDateValid()
            and self.isReferenceYearValid()
        )

    def isPipelineValid(self):
        return self.pipeline in fc_composite_pipelines().keys()

    def isDateValid(self):
        return re.match("\d{4}-\d{2}-\d{2}", self.date)

    def isReferenceYearValid(self):
        # This regex will require a code refactor in around 8,000 years
        return re.match("^(?:\d{4}|)$", self.reference_year)


@dataclass
class SAParams(PostParams):
    periods: str
    force: str
    date: str

    def isValid(self):
        return self.isPeriodValid() and self.isForceValid() and self.isDateValid()

    def isPeriodValid(self):
        return self.periods and self.periods.isdigit() and int(self.periods) > 0

    def isForceValid(self):
        return Force[self.force] in [Force.YES, Force.NO]

    def isDateValid(self):
        return re.match("\d{4}-\d{2}-\d{2}", self.date)


@dataclass
class NDMValidationParams(PostParams):
    validation: str
    date1: str

    def isValid(self):
        return self.isValidationValid() and self.isDateValid()

    def isValidationValid(self):
        return self.validation in NDMValidations.aslist()

    def isDateValid(self):
        """
        Rationale for this validation is that certain validations expect
        different numbers of dates.
        """
        return re.match("\d{4}-\d{2}-\d{2}", self.date1)

    def cliArgsFromForm(self):
        """
        Create the CLI arguments corresponding to the form submission.
        """
        return [
            "--year",
            str(datetime.datetime.strptime(self.date1, "%Y-%m-%d").year),
            "--month",
            str(datetime.datetime.strptime(self.date1, "%Y-%m-%d").month),
        ]


@dataclass
class LeadingIndicatorReportParams(PostParams):
    year1: str
    year2: str
    year3: str
    month1: str
    month2: str
    month3: str

    def isValid(self):
        return (
            self.isYear1Valid()
            and self.isYear2Valid()
            and self.isYear3Valid()
            and self.isMonth1Valid()
            and self.isMonth2Valid()
            and self.isMonth3Valid()
            and self.isUniqueYear()
        )

    def isYear1Valid(self):
        if re.match("\d{4}", self.year1):
            return True
        return False

    def isYear2Valid(self):
        if re.match("\d{4}", self.year2):
            return True
        return False

    def isYear3Valid(self):
        if re.match("\d{4}", self.year3):
            return True
        return False

    def isUniqueYear(self):
        """Users should never submit a duplicate year.
        """
        if (
            self.year1 == self.year2
            or self.year1 == self.year3
            or self.year2 == self.year3
        ):
            return False
        return True

    def isMonth1Valid(self):
        if self.month1 in [str(i) for i in range(1, 13)]:
            return True
        return False

    def isMonth2Valid(self):
        if self.month2 in [str(i) for i in range(1, 13)]:
            return True
        return False

    def isMonth3Valid(self):
        if self.month3 in [str(i) for i in range(1, 13)]:
            return True
        return False

    def cliArgsFromForm(self):
        """
        Create the CLI arguments corresponding to the form submission.
        """
        return [
            "--year1",
            self.year1,
            "--year2",
            self.year2,
            "--year3",
            self.year3,
            "--month1",
            self.month1,
            "--month2",
            self.month2,
            "--month3",
            self.month3,
        ]


@dataclass
class NdmOutboxParams(PostParams):
    periods: str
    date: str

    def isValid(self):
        return self.isPeriodValid() and self.isDateValid()

    def isPeriodValid(self):
        return self.periods and self.periods.isdigit() and int(self.periods) > 0

    def isDateValid(self):
        return re.match("\d{4}-\d{2}-\d{2}", self.date)


@dataclass
class SignOffParams(PostParams):
    release: str
    location: str
    date: str

    def isValid(self):
        return self.isReleaseValid() and self.isLocationValid() and self.isDateValid()

    def isReleaseValid(self):
        return Release[self.release] in [Release.main, Release.leading]

    def isLocationValid(self):
        return Stage[self.location].name in [Stage.PRE_RELEASE.name, Stage.RELEASE.name]

    def isDateValid(self):
        return re.match("\d{4}-\d{2}-\d{2}", self.date)

    def cliArgsFromForm(self) -> List:
        """
        Creates a list of CLI arguments corresponding to the particular form
        selection. The purpose of this method is to translate semantically
        meaningful form selections from the user into arguments that can be
        passed to the release.py CLI program.
        """
        if (
            self.location == Stage.PRE_RELEASE.name
            and self.release == Release.leading.name
        ):
            flag = "--leading-pre-release"
        elif (
            self.location == Stage.RELEASE.name and self.release == Release.leading.name
        ):
            flag = "--leading-release"
        elif (
            self.location == Stage.PRE_RELEASE.name
            and self.release == Release.main.name
        ):
            flag = "--main-pre-release"
        else:
            flag = "--main-release"
        # Split date into year and month for the CLI program
        date = datetime.datetime.strptime(self.date, "%Y-%m-%d")
        year = str(date.year)
        month = str(date.month)
        return [flag, "--year", year, "--month", month]
