import re
import calendar
from os.path import basename
from enum import auto
from modules.s3client import S3Client
from config.api import DataSource
from config.api import AutoEnum
from config.api import Stage
from config.api import S3
from config.api import TIME_BASE_DATASOURCE_PATTERN
from webapp import prefix_url_for as url_for
from webapp.models.translation import tr
from webapp.models.io import Mode
from webapp.models.io import DataEventOutput
from webapp.models.io import DataItemOutput
from webapp.models.io import TimelineOutput
from webapp.models.io import StageParams
from webapp.models.io import StageOutput


class Route(AutoEnum):
    conflict = auto()
    history  = auto()

def map_datasource_basename(datasource: DataSource, basename: str) -> str:
    
    if datasource in DataSource.timebased():
        match = re.match(TIME_BASE_DATASOURCE_PATTERN, basename)
        year, month, day = match.groups()
        return f"{year}/{month}/{day}" if day else f"{year}/{month}"
    
    basename = basename.replace('.csv','')

    mapping = {
        DataSource.work_locations_trans       : basename.split('__')[-1],
        DataSource.work_locations_action      : basename.split('__')[-1],
        DataSource.work_locations_trans_action: basename.split('__')[-1],
        DataSource.dimension                  : basename.replace('dim__',''),
        DataSource.mapping                    : basename.replace('map__','')
    }
    return mapping[datasource] if datasource in mapping else basename

def list_files(client: S3Client, stage: Stage, datasource: DataSource, year: str, mode: Mode) -> set:
    """
    Returns sorted list of either conflict or historical files
    """
    loc = S3.prefix(stage, mode, datasource, year=year)
  
    #The reason for a set is because historical instances 
    #could be multiple for the same history basename. Only need 
    #to return the basename.
    files = set([])
    for obj in client.ls_objs( loc.bucket, loc.prefix,
        only_files=True, recursive=True, default_folder_file=False):

        if mode == Mode.conflicts:
            _basename = basename(obj.object_name)
        elif mode == Mode.historical:
            _basename = obj.object_name.split("/")[-2]
        else:
            raise Exception('has to be either conflict or history!')
        files.add((stage, datasource, _basename))
    return sorted(files)

def timeline_init(datasource: DataSource):
    if datasource in DataSource.timebased():
        return [DataEventOutput(event=tr(m), content=[]) for m in calendar.month_abbr if m]
    else:
        return [DataEventOutput(event=tr("File(s)"), content=[])]

def get_stage(params: StageParams, mode: Mode) -> StageOutput:
    """
    Lists all existing conflicts or historical in a Stage.
    """
    client    = S3Client.get_client()
    stage     = Stage[params.stage]
    
    routes    = {
        Mode.conflicts : Route.conflict.value,
        Mode.historical: Route.history.value
    }
    labels    = {
        Mode.conflicts : tr("Conflict(s)"),
        Mode.historical: tr("Versioned File(s)")
    }
    output_timelines = []
    for datasource in DataSource:
        if datasource == DataSource.unknown:
            continue
        timeline = TimelineOutput(
            datasource  =   datasource.value,
            count       =   0,
            count_label =   labels[mode],
            timeline    =   None
        )

        for stage, datasource, name in list_files(
            client, stage, datasource, params.year, mode
        ):
            href = url_for(
                routes[mode], stage=stage.name, datasource=datasource.value, basename=name
            )
            label = map_datasource_basename(datasource, name)
            item  = DataItemOutput(label=label, href=href, style="")
            if timeline.timeline is None:
                    timeline.timeline = timeline_init(datasource)
            loc = int(label[5:7]) - 1 if datasource in DataSource.timebased() else 0 
            timeline.timeline[loc].content.append(item)
            timeline.count += 1
        output_timelines.append(timeline)

    output_timelines = [d for d in output_timelines if d.count]
    output_timelines = sorted(output_timelines, key=lambda x: x.count, reverse=True)

    total_placehold = sum([d.count for d in output_timelines])
    total_datasource = len(output_timelines)
    output = StageOutput(
        header=f"{params.stage}",
        label= tr('Filter'),
        arial_label = tr('Filter of the year'),
        desc=f"{total_datasource} {tr('Source(s)')}, {total_placehold} {labels[mode]}",
        bucket=stage.value.bucket,
        stage=stage.name,
        mode=mode.value,
        year=params.year,
        count=total_datasource,
        timelines=output_timelines,
    )

    return output
