import json
from os.path import dirname 
from os.path import join
from dataclasses import dataclass
from dataclasses import field 
from flask import session
from webapp.models.session import Lang, LANGUAGE


@dataclass
class Translate:
    lang    : Lang = field(default=Lang.EN)
    path    : str  = field(init=False, default=join(dirname(__file__), 'lang.{}.json'))   
    library : dict = field(init=False, default_factory=dict)
    writable: bool = field(init=False, default=True)

    def __load_library__(self):
        with open(self.path.format((self.lang.value))) as r:
            self.library = json.load(r)

    def __save_library__(self):
        with open(self.path.format((self.lang.value)),'w') as w:
            json.dump(self.library, w, indent=4, ensure_ascii=False)

    def __post_init__(self):
        self.__load_library__()

    def set_lang(self, lang:Lang):
        if self.lang != lang:
            self.lang = lang
            self.__load_library__()

    def get(self, label) -> str:
        if label not in self.library:
            self.library[label] = label 
            if self.writable:
                self.__save_library__()
        return self.library[label]

class LangDict():
    def __init__(self):
        self.data = {
            'EN': Translate(lang=Lang.EN),
            'FR': Translate(lang=Lang.FR)
        }
    def set_lang(self, lang:Lang):
        pass
    def get(self, label) -> str:
        lang = session.get(LANGUAGE, Lang.EN).value
        return self.data[lang].get(label)

internationalization = LangDict()


def tr(label:str) -> str:
    return internationalization.get(label)
    