#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------

from pandas import DataFrame
from dataclasses import dataclass
from config.api import S3, DataSource, S3Location, Stage
from modules.s3client import S3Client
from modules.utils.diff import Action, TabularDiff
from webapp.models.translation import tr
from modules.utils.schema import load_datasource_schema


@dataclass
class DiffLabels:
    title: str
    stats_total: str
    stats_dupl: str
    stats_conf: str
    stats_miss: str
    stats_new: str


@dataclass
class Pagination:
    limit: int
    first: int
    prev_page: int
    current: int
    next_page: int
    last: int

    @staticmethod
    def create_paging(current: int, total: int, limit: int) -> "Pagination":
        last = (total // limit) + 1
        current = min(last, current)
        return Pagination(
            limit=limit,
            first=1,
            prev_page=max(1, current - 1),
            current=current,
            next_page=min(last, current + 1),
            last=last,
        )


@dataclass
class ToggleState:
    label: str
    value: str
    style: str


@dataclass
class Toggles:
    duplicates: ToggleState
    missing: ToggleState
    new: ToggleState
    conflicts: ToggleState

    @classmethod
    def create_toggles(cls, filters):
        toggles = [
            ToggleState(
                label=tr("Duplicates"),
                value=Action.duplicated.value,
                style="fa-toggle-on",
            ),
            ToggleState(
                label=tr("Missing"), value=Action.missing.value, style="fa-toggle-on"
            ),
            ToggleState(label="New", value=Action.new.value, style="fa-toggle-on"),
            ToggleState(
                label=tr("Conflicts"),
                value=Action.mconflict.value,
                style="fa-toggle-on",
            ),
        ]
        for toggle in toggles:
            toggle.style = (
                "fa-toggle-on"
                if not filters or toggle.value in filters
                else "fa-toggle-off"
            )

        return Toggles(*toggles)


@dataclass
class DiffData:
    caption: str
    stage: str
    basename: str
    columns: list
    body: list
    stats: dict
    datasource: str
    path: str
    original: str
    org_bucket: str
    path_bucket: str
    labels: DiffLabels
    pagination: Pagination
    toggles: Toggles


def auto_merge(
    datasource: DataSource, stage: Stage, locA: S3Location, locB: S3Location
) -> DataFrame:
    client = S3Client.get_client()
    schema = load_datasource_schema(datasource, stage)

    A = client.get_CSV(
        locA, dtype={k: v.type.name for k, v in schema.to_schema().dtypes.items()}
    )
    B = client.get_CSV(
        locB, dtype={k: v.type.name for k, v in schema.to_schema().dtypes.items()}
    )

    tabular = TabularDiff(A, B, schema.get_keys())
    return tabular.merge


def compute_diff(
    datasource: DataSource,
    stage: Stage,
    basename: str,
    locA: S3Location,
    locB: S3Location,
    page=5,
    limit=1000,
    filters=[],
) -> dict:
    client = S3Client.get_client()
    schema = load_datasource_schema(datasource, stage)

    A = client.get_CSV(
        locA, dtype={k: v.type.name for k, v in schema.to_schema().dtypes.items()}
    )
    B = client.get_CSV(
        locB, dtype={k: v.type.name for k, v in schema.to_schema().dtypes.items()}
    )

    tabular = TabularDiff(A, B, schema.get_keys())
    tabular.filter([Action.get_action(f) for f in filters])

    _diff = tabular.page(page=page, limit=limit)
    _stats = tabular.stats

    labels = DiffLabels(
        title=tr("Data Difference"),
        stats_total=tr("Total"),
        stats_dupl=tr("Duplicated"),
        stats_conf=tr("Conflicts"),
        stats_miss=tr("Missing"),
        stats_new=tr("New"),
    )

    table = DiffData(
        caption=tr("Diff Data Caption"),
        stage=stage.name,
        basename=basename,
        columns=_diff.columns.to_numpy().tolist(),
        body=_diff.to_numpy().tolist(),
        stats=_stats,
        datasource=datasource.value,
        path=S3.loc_to_obj(locB),
        original=S3.loc_to_obj(locA),
        org_bucket=locA.bucket,
        path_bucket=locB.bucket,
        labels=labels,
        pagination=Pagination.create_paging(page, _stats.filtered, limit),
        toggles=Toggles.create_toggles(filters),
    )
    return table
