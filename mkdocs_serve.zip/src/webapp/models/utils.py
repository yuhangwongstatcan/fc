from typing import List, Dict
import pandas as pd
from pandas.core.frame import DataFrame

from config.api import DataSource, Stage

from modules.utils.loaders import Loader
from modules.utils.schema import load_datasource_schema

from datasource.common.dim import (
    DAY,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
    DATA_SOURCE,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    COUNTRY_OF_RESIDENCE,
)


def get_ports():
    """Renders the ports list to show both the human readable name and the port
       number.

    Returns:
        List: List of ports with the corresponding port number in brackets.
    """
    schema = load_datasource_schema(DataSource.ports, Stage.REFERENCE)
    ports = Loader.get(Stage.REFERENCE, DataSource.ports, None)
    return ports[schema.port_name_en] + " (" + ports[schema.port].astype(str) + ")"


def name_to_code_dimension(df: DataFrame, dimension: Dict, col: str) -> DataFrame:
    # The purpose of this line is to map human readable labels back to the correct
    # dimensions for each column.
    return df.replace({col: {v: k for k, v in dimension.items()}})


def port_to_dimension(df: DataFrame) -> DataFrame:
    """
    Casts the displayed port back to the numeric value.
    """
    # Need to extract the numeric part of the port column. Note that the format
    # of this column is always "Name of Port - (\d{5})"
    df["port"] = df["port"].str.extract(r"(\d{5})")
    return df


def countries_to_dimension(df: DataFrame, col_name: str = "country_of_residence"):
    countries = Loader.get(Stage.REFERENCE, DataSource.countries, None)
    # Create a mapping between country_name_en and country_of_residence (numeric code)
    countries_dict = (
        countries[["country_name_en", "country_of_residence"]]
        .set_index("country_name_en")
        .to_dict()
    )
    # Replace the country name given in the form submission by the
    return df.replace({col_name: countries_dict["country_of_residence"]})


def get_countries_as_dim(col_name="country_name_en") -> List:
    countries = Loader.get(Stage.REFERENCE, DataSource.countries, None)
    return list(countries[col_name])


def get_sorted_countries() -> List:
    """
    Custom function to load the countries list, sort it according to the Frontier Counts team's
    specifications, then return the sorted list.

    The order should be [
        Canada,
        United States,
        countries sorted lexicographically,
        Overseas,
        Not Applicable
        ]
    """
    # Get sorted countries list
    countries = list(
        sorted(Loader.get(Stage.REFERENCE, DataSource.countries, None).country_name_en)
    )
    # Make the appropriate substitutions to get the desired list ordering. Note
    # Python list operations are inplace by default.
    countries.insert(0, countries.pop(countries.index("Canada")))
    countries.insert(1, countries.pop(countries.index("United States of America")))
    countries.append(countries.pop(countries.index("Not applicable")))
    countries.insert(-1, countries.pop(countries.index("Overseas")))
    return countries


def make_codes_pd_na(df: pd.DataFrame, datasource: DataSource) -> pd.DataFrame:
    """
    Once dimension codes have been substituted, we need to make sure all
    "not available" values are substituted with `pd.NA`. The reason for this
    is that the manual entry imputation pipeline expects to encounter pd.NA
    values to impute, not numeric codes like "99" or "99999".
    """
    schema = load_datasource_schema(datasource, Stage.RAW)
    df = schema(df)
    # Note that this check for missing codes need not be done for `port`
    # because `port` is a required value in the form (i.e. it will never
    # be set to 'not available')
    df = df.replace(
        {schema.day: DAY.not_available.value},
        {schema.day: pd.NA},
    )
    df = df.replace(
        {schema.data_source: DATA_SOURCE.Not_Available.value},
        {schema.data_source: pd.NA},
    )
    df = df.replace(
        {VEHICLE_TYPE.not_available.value},
        {schema.vehicle_type: pd.NA},
    )
    df = df.replace(
        {schema.plate_country: PLATE_COUNTRY.not_available.value},
        {schema.plate_country: pd.NA},
    )
    # Only need to check travellers columns if we are dealing with travellers manual entry
    if datasource.value == "manual_entry_travellers":
        df = df.replace(
            {schema.arriving_from: ARRIVING_FROM.not_available.value},
            {schema.arriving_from: pd.NA},
        )
        df = df.replace(
            {schema.purpose9: PURPOSE9.not_available.value},
            {schema.purpose9: pd.NA},
        )
        df = df.replace(
            {schema.purpose4: PURPOSE4.not_available.value},
            {schema.purpose4: pd.NA},
        )
        df = df.replace(
            {schema.duration2: DURATION2.not_available.value},
            {schema.duration2: pd.NA},
        )
        df = df.replace(
            {schema.country_of_residence: COUNTRY_OF_RESIDENCE.not_applicable.value},
            {schema.country_of_residence: pd.NA},
        )
    return df
