from config.api import DataSource
from config.argo import fc_composite_pipelines
from config.api import AutoEnum
from config.api import Stage
from config.api import NDMValidations
from enum import auto
from dataclasses import dataclass
from dataclasses import field
from modules.pipeline import get_pipelines
from webapp import prefix_url_for as url_for
from typing import List
from webapp.models.io import LeadingIndicatorReportParams, RunPipelineParams, demographyPIKreportParams
from webapp.models.io import RunOutput
from webapp.models.io import RunRowOutput
from webapp.models.io import RunHeader
from webapp.models.io import Force, Release
from webapp.models.io import SAParams
from webapp.models.io import SignOffParams
from webapp.models.io import NDMValidationParams
from webapp.models.io import RunCompositePipelineParams
from webapp.models.translation import tr
from modules.argo import argo_list_workflows
import datetime
from modules.utils.schema import tuplify


class Method(AutoEnum):
    POST = auto()
    GET = auto()


class Type(AutoEnum):
    submit = auto()
    select = auto()
    input = auto()
    date = auto()
    reference_year = auto()


@dataclass
class SelectTarget(object):
    id: str
    options: dict = field(default_factory=dict)


@dataclass
class Option(object):
    value: str
    label: str
    selected: bool = None


@dataclass
class Field(object):
    label: str
    name: str
    type: str
    className: str = None
    id: str = None
    value: str = None
    required: bool = None
    invalid_feedback: str = None


@dataclass
class Submit(Field):
    type: str = field(default=Type.submit.value)
    name: str = field(default="submit")
    value: str = field(default="submit")


@dataclass
class Date(Field):
    type: str = field(default=Type.date.value)
    format: str = field(default="yyyy-mm-dd")
    view_mode: str = field(default="years")
    min_view_mode: str = field(default="months")


@dataclass
class Select(Field):
    type: str = field(default=Type.select.value)
    options: List[Option] = field(default_factory=list)
    select_target: SelectTarget = None


@dataclass
class Form(object):
    action: str
    method: str
    header: str
    id: str
    fields: List[Field] = field(default_factory=list)


@dataclass
class Triggers(object):
    title: str
    forms: List[Form] = field(default_factory=list())


def check_inbox_form(action: str) -> Form:
    _submit = Submit(label=tr("Execute Check Inbox"), id=f"{action}_0")

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Check Inbox"),
        id=action,
        fields=[_submit],
    )


def demography_PIK_report_form(action: str, params:demographyPIKreportParams = None) -> Form:
    if params and not params.isDateValid():
        dateClassName = "is-invalid"
        dateInvalidFeedback = tr("Please provide a valid Date.")
    else:
        dateClassName = ""
        dateInvalidFeedback = ""

    _date = Date(
        label=tr("Date"),
        name="date",
        id=f"{action}_0",
        required=True,
        className=dateClassName,
        invalid_feedback=dateInvalidFeedback,
    )
    _submit = Submit(label=tr("Generate Demography PIK Report"), id=f"{action}_3")

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Demography PIK Report"),
        id=action,
        fields=[_date,_submit],
    )


def run_pipeline_form(action: str, params: RunPipelineParams = None) -> Form:
    if params and not params.isDataSourceValid():
        datasourceClassName = "is-invalid"
        datasourceInvalidFeedback = tr("Please select a valid Datasource.")
    else:
        datasourceClassName = ""
        datasourceInvalidFeedback = ""

    if params and not params.isPipelineValid():
        pipelineClassName = "is-invalid"
        pipelineInvalidFeedback = tr("Please select a valid Pipeline.")
    else:
        pipelineClassName = ""
        pipelineInvalidFeedback = ""

    if params and not params.isDateValid():
        dateClassName = "is-invalid"
        dateInvalidFeedback = tr("Please provide a valid Date.")
    else:
        dateClassName = ""
        dateInvalidFeedback = ""

    if params and not params.isReferenceYearValid():
        referenceYearClassName = "is-invalid"
        referenceYearInvalidFeedback = tr("Please provide a valid Reference Year")
    else:
        referenceYearClassName = ""
        referenceYearInvalidFeedback = ""

    # print("a", datasourceClassName,"b" , pipelineClassName,"c", dateClassName)

    _datasource = Select(
        label=tr("Data Source"),
        name="datasource",
        id=f"{action}_0",
        required=True,
        options=[],
        className=datasourceClassName,
        invalid_feedback=datasourceInvalidFeedback,
        select_target=SelectTarget(f"{action}_1"),
    )
    _pipeline = Select(
        label=tr("Pipeline"),
        name="pipeline",
        id=f"{action}_1",
        required=True,
        options=[],
        className=pipelineClassName,
        invalid_feedback=pipelineInvalidFeedback,
    )
    _date = Date(
        label=tr("Date"),
        name="date",
        id=f"{action}_2",
        required=True,
        className=dateClassName,
        invalid_feedback=dateInvalidFeedback,
    )
    _reference_year = Field(
        label=tr("Reference Year"),
        name="reference_year",
        id=f"{action}_4",
        required=False,
        className=referenceYearClassName,
        invalid_feedback=referenceYearInvalidFeedback,
        type=Type.reference_year.value,
    )
    _submit = Submit(label=tr("Execute Data Pipeline"), id=f"{action}_3")

    for ds in DataSource:
        if ds in DataSource.timebased():
            pipes = get_pipelines(ds)
            if pipes:
                _datasource.options.append(Option(value=ds.value, label=ds.value))
            for pipe_name, _ in pipes:
                opt = Option(value=pipe_name, label=pipe_name)

                if ds.value in _datasource.select_target.options:
                    _datasource.select_target.options[ds.value].append(opt)
                else:
                    _datasource.select_target.options[ds.value] = [opt]

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Data Pipelines"),
        id=action,
        fields=[_datasource, _pipeline, _date, _reference_year, _submit],
    )


def run_sequential_pipeline_form(action: str, params: RunCompositePipelineParams = None) -> Form:
    if params and not params.isPipelineValid():
        pipelineClassName = "is-invalid"
        pipelineInvalidFeedback = tr("Please select a valid Pipeline.")
    else:
        pipelineClassName = ""
        pipelineInvalidFeedback = ""

    if params and not params.isDateValid():
        dateClassName = "is-invalid"
        dateInvalidFeedback = tr("Please provide a valid Date.")
    else:
        dateClassName = ""
        dateInvalidFeedback = ""

    if params and not params.isReferenceYearValid():
        referenceYearClassName = "is-invalid"
        referenceYearInvalidFeedback = tr("Please provide a valid Reference Year")
    else:
        referenceYearClassName = ""
        referenceYearInvalidFeedback = ""

    # print("a", datasourceClassName,"b" , pipelineClassName,"c", dateClassName)

    _pipeline = Select(
        label=tr("Pipeline"),
        name="pipeline",
        id=f"{action}_1",
        required=True,
        options=[Option(value=key, label=key) for key in fc_composite_pipelines().keys()],
        className=pipelineClassName,
        invalid_feedback=pipelineInvalidFeedback,
    )
    _date = Date(
        label=tr("Date"),
        name="date",
        id=f"{action}_2",
        required=True,
        className=dateClassName,
        invalid_feedback=dateInvalidFeedback,
    )
    _reference_year = Field(
        label=tr("Reference Year"),
        name="reference_year",
        id=f"{action}_4",
        required=False,
        className=referenceYearClassName,
        invalid_feedback=referenceYearInvalidFeedback,
        type=Type.reference_year.value,
    )
    _submit = Submit(label=tr("Execute Composite Data Pipeline"), id=f"{action}_3")

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Composite Data Pipelines"),
        id=action,
        fields=[_pipeline, _date, _reference_year, _submit],
    )



def run_sign_off_form(action: str, params: SignOffParams = None) -> Form:
    if params and not params.isReleaseValid():
        releaseClassName = "is-invalid"
        releaseInvalidFeedback = tr("Please select a valid Release.")
    else:
        releaseClassName = ""
        releaseInvalidFeedback = ""

    if params and not params.isLocationValid():
        locationClassName = "is-invalid"
        locationInvalidFeedback = tr("Please select a valid Location.")
    else:
        locationClassName = ""
        locationInvalidFeedback = ""

    if params and not params.isDateValid():
        dateClassName = "is-invalid"
        dateInvalidFeedback = tr("Please provide a valid Date.")
    else:
        dateClassName = ""
        dateInvalidFeedback = ""

    _release = Select(
        label=tr("Release"),
        name="release",
        id=f"{action}_0",
        required=True,
        options=[
            Option(value=Release.leading.value, label=tr("Leading")),
            Option(value=Release.main.value, label=tr("Main")),
        ],
        className=releaseClassName,
        invalid_feedback=releaseInvalidFeedback,
    )

    _location = Select(
        label=tr("Location"),
        name="location",
        id=f"{action}_1",
        required=True,
        options=[
            Option(value=Stage.PRE_RELEASE.name, label=tr("PreRelease")),
            Option(value=Stage.RELEASE.name, label=tr("Release")),
        ],
        className=locationClassName,
        invalid_feedback=locationInvalidFeedback,
    )

    _date = Date(
        label=tr("Date"),
        name="date",
        id=f"{action}_2",
        required=True,
        className=dateClassName,
        invalid_feedback=dateInvalidFeedback,
    )

    _submit = Submit(label=tr("Execute Sign Off"), id=f"{action}_3")

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Sign Off"),
        id=action,
        fields=[_release, _location, _date, _submit],
    )


def run_leading_indicator_form(
    action: str, params: LeadingIndicatorReportParams = None
) -> Form:
    FEEDBACK_YEAR = "Year must contain 4 digits."
    FEEDBACK_DUPLICATE_YEAR = "Years must be unique."
    FEEDBACK_MONTH = "A month must be a number between 1 and 12."
    # Years invalid
    if params and not params.isYear1Valid():
        year1ClassName = "is-invalid"
        year1InvalidFeedback = FEEDBACK_YEAR
    else:
        year1ClassName = ""
        year1InvalidFeedback = ""
    if params and not params.isYear2Valid():
        year2ClassName = "is-invalid"
        year2InvalidFeedback = FEEDBACK_YEAR
    else:
        year2ClassName = ""
        year2InvalidFeedback = ""
    if params and not params.isYear3Valid():
        year3ClassName = "is-invalid"
        year3InvalidFeedback = FEEDBACK_YEAR
    else:
        year3ClassName = ""
        year3InvalidFeedback = ""
    # Months invalid
    if params and not params.isMonth1Valid():
        month1ClassName = "is-invalid"
        month1InvalidFeedback = FEEDBACK_MONTH
    else:
        month1ClassName = ""
        month1InvalidFeedback = ""
    if params and not params.isMonth2Valid():
        month2ClassName = "is-invalid"
        month2InvalidFeedback = FEEDBACK_MONTH
    else:
        month2ClassName = ""
        month2InvalidFeedback = ""
    if params and not params.isMonth3Valid():
        month3ClassName = "is-invalid"
        month3InvalidFeedback = FEEDBACK_MONTH
    else:
        month3ClassName = ""
        month3InvalidFeedback = ""

    # Add warning if duplicate years
    if params and not params.isUniqueYear():
        year1ClassName = "is-invalid"
        year1InvalidFeedback += FEEDBACK_DUPLICATE_YEAR
    # Create form
    _year1 = Field(
        type=Type.input.value,
        label=tr("Year 1"),
        id=f"{action}_0",
        name="year1",
        required=True,
        className=year1ClassName,
        invalid_feedback=year1InvalidFeedback,
    )
    _year2 = Field(
        type=Type.input.value,
        label=tr("Year 2"),
        id=f"{action}_1",
        name="year2",
        required=True,
        className=year2ClassName,
        invalid_feedback=year2InvalidFeedback,
    )
    _year3 = Field(
        type=Type.input.value,
        label=tr("Year 3"),
        id=f"{action}_2",
        name="year3",
        required=True,
        className=year3ClassName,
        invalid_feedback=year3InvalidFeedback,
    )
    _month1 = Field(
        type=Type.input.value,
        label=tr("Month 1"),
        id=f"{action}_3",
        name="month1",
        required=True,
        className=month1ClassName,
        invalid_feedback=month1InvalidFeedback,
    )
    _month2 = Field(
        type=Type.input.value,
        label=tr("Month 2"),
        id=f"{action}_4",
        name="month2",
        required=True,
        className=month2ClassName,
        invalid_feedback=month2InvalidFeedback,
    )
    _month3 = Field(
        type=Type.input.value,
        label=tr("Month 3"),
        id=f"{action}_5",
        name="month3",
        required=True,
        className=month3ClassName,
        invalid_feedback=month3InvalidFeedback,
    )

    _submit = Submit(label=tr("Execute Leading Indicator"), id=f"{action}_6",)

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Leading Indicator"),
        id=action,
        fields=[_year1, _year2, _year3, _month1, _month2, _month3, _submit],
    )


def run_validation_form(action: str, params: NDMValidationParams = None) -> Form:
    if params and not params.isValidationValid():
        validationClassName = "is-invalid"
        validationInvalidFeedback = tr(
            f"Validation must be one of {NDMValidations.aslist()}"
        )
    else:
        validationClassName = ""
        validationInvalidFeedback = ""

    if params and not params.isDateValid():
        date1ClassName = "is-invalid"
        date1InvalidFeedback = tr("Expected a date of the form YYYY-MM-DD")
    else:
        date1ClassName = ""
        date1InvalidFeedback = ""

    _validation = Select(
        label=tr("Validation Name"),
        name="validation",
        id=f"{action}_0",
        required=True,
        options=[Option(label=val, value=val) for val in NDMValidations.aslist()],
        className=validationClassName,
        invalid_feedback=validationInvalidFeedback,
    )

    _date1 = Date(
        label=tr("Date"),
        name="date1",
        id=f"{action}_1",
        required=True,
        className=date1ClassName,
        invalid_feedback=date1InvalidFeedback,
    )

    _submit = Submit(label=tr("Execute Validation"), id=f"{action}_4",)

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Validations"),
        id=action,
        fields=[_validation, _date1, _submit],
    )


def run_sa_form(action: str, params: SAParams = None) -> Form:
    if params and not params.isPeriodValid():
        periodClassName = "is-invalid"
        periodInvalidFeedback = tr("Please provide a valid Period.")
    else:
        periodClassName = ""
        periodInvalidFeedback = ""

    if params and not params.isForceValid():
        forceClassName = "is-invalid"
        forceInvalidFeedback = tr("Please select a valid Force.")
    else:
        forceClassName = ""
        forceInvalidFeedback = ""

    if params and not params.isDateValid():
        dateClassName = "is-invalid"
        dateInvalidFeedback = tr("Please provide a valid Date.")
    else:
        dateClassName = ""
        dateInvalidFeedback = ""

    _date = Date(
        label=tr("Date"),
        name="date",
        id=f"{action}_0",
        required=True,
        className=dateClassName,
        invalid_feedback=dateInvalidFeedback,
    )

    _periods = Field(
        type=Type.input.value,
        label=tr("Periods"),
        id=f"{action}_1",
        name="periods",
        value="18",
        required=True,
        className=periodClassName,
        invalid_feedback=periodInvalidFeedback,
    )

    _force = Select(
        label=tr("Force"),
        name="force",
        id=f"{action}_2",
        required=True,
        options=[
            Option(label=tr("YES"), value=Force.YES.value),
            Option(label=tr("NO"), value=Force.NO.value),
        ],
        className=forceClassName,
        invalid_feedback=forceInvalidFeedback,
    )

    _submit = Submit(label=tr("Execute Seasonal Adjustment"), id=f"{action}_3",)

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("Seasonal Adjustments"),
        id=action,
        fields=[_periods, _force, _date, _submit],
    )


def run_prepare_ndm(action: str, params: SAParams = None) -> Form:

    if params and not params.isPeriodValid():
        periodClassName = "is-invalid"
        periodInvalidFeedback = tr("Please provide a valid Period.")
    else:
        periodClassName = ""
        periodInvalidFeedback = ""

    if params and not params.isDateValid():
        dateClassName = "is-invalid"
        dateInvalidFeedback = tr("Please provide a valid Date.")
    else:
        dateClassName = ""
        dateInvalidFeedback = ""

    _date = Date(
        label=tr("Date"),
        name="date",
        id=f"{action}_0",
        required=True,
        className=dateClassName,
        invalid_feedback=dateInvalidFeedback,
    )

    _periods = Field(
        type=Type.input.value,
        label=tr("Periods"),
        id=f"{action}_1",
        name="periods",
        value="18",
        required=True,
        className=periodClassName,
        invalid_feedback=periodInvalidFeedback,
    )

    _submit = Submit(label=tr("Execute NDM Prepare Outbox"), id=f"{action}_2",)

    return Form(
        action=url_for(action),
        method=Method.POST.value,
        header=tr("NDM Prepare Outbox"),
        id=action,
        fields=[_periods, _date, _submit],
    )


def list_latests_run(
    experiment_name: str = "frontier-counts-dev", last: int = 10
) -> RunOutput:

    header = RunHeader(
        name=tr("Pipeline Name"),
        status=tr("Status"),
        start=tr("Start"),
        duration=tr("Duration"),
    )
    runs = argo_list_workflows()
    # Note that either an iterable of workflows can be returned, or an empty
    # list if no workflows have been submitted. If none submitted, we don't
    # want to try and calculate a duration.
    if runs:
        runs = tuplify(runs)
        data = [
            RunRowOutput(
                name=run.name,
                status=run.status,
                start=run.created_at,
                duration=str(
                    datetime.datetime.strptime(run.finished_at, "%Y-%m-%dT%H:%M:%SZ")
                    - datetime.datetime.strptime(run.created_at, "%Y-%m-%dT%H:%M:%SZ")
                    if run.finished_at
                    and datetime.datetime.strptime(
                        run.finished_at, "%Y-%m-%dT%H:%M:%SZ"
                    )
                    > datetime.datetime.strptime(run.created_at, "%Y-%m-%dT%H:%M:%SZ")
                    else "--"
                ),
            )
            for run in runs
        ]
    else:
        data = [
            RunRowOutput(
                name="No workflows available",
                status="N/A",
                start="1970-01-01T00:00:00Z",
                duration="N/A",
            )
        ]

    return RunOutput(
        label=tr("Latest Pipeline Runs"),
        header=header,
        data=data,
        caption=tr("Pipeline Runs Caption"),
    )

