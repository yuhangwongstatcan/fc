from enum import auto
from typing import Union, Dict, List

import pandas as pd
from flask_wtf import FlaskForm
from wtforms import Field, Form, IntegerField, SelectField
from wtforms.fields.simple import SubmitField
from wtforms.validators import DataRequired, NumberRange, Optional, ValidationError

from config.api import S3, AutoEnum, DataSource, Mode, S3Location, Stage
from modules.s3client import S3Client
from modules.utils.schema import load_datasource_schema
from webapp.models.rules import RequiredIf
from webapp.models.utils import (
    countries_to_dimension,
    get_ports,
    get_sorted_countries,
    make_codes_pd_na,
    name_to_code_dimension,
    port_to_dimension,
)

from datasource.common.dim import DATA_SOURCE, MONTH, DAY, VEHICLE_TYPE, PLATE_COUNTRY
from datasource.common.labels import (
    MONTH as LABEL_MONTH,
    DAY as LABEL_DAY,
    MODE as LABEL_MODE,
    VEHICLE_TYPE as LABEL_VEHICLE_TYPE,
    PLATE_COUNTRY as LABEL_PLATE_COUNTRY,
    PLATE_REGION as LABEL_PLATE_REGION,
    ARRIVING_FROM as LABEL_ARRIVING_FROM,
    PURPOSE9 as LABEL_PURPOSE9,
    PURPOSE4 as LABEL_PURPOSE4,
    DURATION2 as LABEL_DURATION2,
    DURATION3 as LABEL_DURATION3,
    DURATION5 as LABEL_DURATION5,
    TRAVELLER_TYPE as LABEL_TRAVELLER_TYPE,
    DATA_SOURCE as LABEL_DATA_SOURCE,
)
from datasource.travellers.dim import ARRIVING_FROM, PURPOSE9, PURPOSE4, DURATION2


def get_default_na_choices(dim: Dict) -> List:  # move N/A to the default choice
    choices = [member for member in dim.values()]
    choices.insert(0, choices.pop())
    return choices


class CaptureType(AutoEnum):
    travellers = auto()
    vehicles = auto()


class DependantValidation(object):
    """Custom Validator to handle dependant validations.

    An example of such a case is if "Commercial aircraft"
    is selected for vehicle-type, then plate-country should automatically
    be set as `Not available` because it is not applicable for aircraft to
    have licence plates.
    """

    def __init__(
        self,
        dependant_name: str,
        primary_values: list,
        dependant_values: Union[list, None] = None,
    ):
        self.dependant_name = dependant_name
        self.primary_values = primary_values
        # use primary values if dependant values are not specified
        if not dependant_values:
            dependant_values = primary_values
        self.dependant_values = dependant_values

    def __call__(self, form: Form, field: Field):
        primary_name = field.name.replace("_", " ").title()
        # check if combination of primary and dependant field values is valid
        if (field.data in self.primary_values) and (
            form.data[self.dependant_name] not in self.dependant_values
        ):
            raise ValidationError(
                f"Impossible combination of {self.format_str(primary_name)} and {self.format_str(self.dependant_name)} entered. Please adjust form and resubmit"
            )

    def format_str(self, value: str) -> str:
        """Removes `_` and capitalizes first character of every word

        Args:
            value (str): string to transform

        Returns:
            str: transformed string value
        """
        return value.replace("_", " ").title()


class DataCapture(FlaskForm):
    capture_type = SelectField(
        "Capture Type",
        choices=CaptureType.list(),
        validators=(DataRequired(),),
        # render_kw={"onchange": "myFunction()"},
    )
    # exclude values E62B, E62T, Bus report from the dropdown. See #613
    data_source_choices = [member for member in LABEL_DATA_SOURCE.values()]
    data_source = SelectField(
        "Datasource",
        choices=[
            item
            for item in data_source_choices
            if item not in ["E62B", "E62T", "Bus report"]
        ],
        validators=(DataRequired(),),
    )

    year = IntegerField(
        "Year",
        validators=[
            NumberRange(
                min=1000, max=9999, message="Year must be between 1000 and 9999"
            )
        ],
        description="The year of the manual entry",
    )

    month = SelectField(
        "Month",
        choices=[member for member in LABEL_MONTH.values()],
        validators=(DataRequired(),),
    )

    day = SelectField(
        "Day",
        choices=[member for member in LABEL_DAY.values()],
        validators=(DataRequired(),),
    )

    port = SelectField(
        "Port",
        choices=get_ports(),
        validators=(DataRequired(),),
    )

    vehicle_type = SelectField(
        "Vehicle Type",
        choices=[member for member in LABEL_VEHICLE_TYPE.values()],
        validators=[
            DataRequired(),
            DependantValidation(
                "plate_country",
                [
                    "Commercial aircraft",
                    "Cargo aircraft",
                    "Private aircraft",
                    "Air (Not available)",
                    "Train",
                    "Pedestrian",
                    "Cruise ship or other commercial boat",
                    "Cargo ship",
                    "Ferry (Pedestrian)",
                    "Private boat",
                    "Water (Not available)",
                ],
                ["Not available"],
            ),
            DependantValidation(
                "arriving_from",
                [
                    "Automobile",
                    "Motorcycle",
                    "Other land vehicle",
                    "Truck",
                    "Bus",
                    "Train",
                    "Pedestrian",
                    "Land (Not available)",
                ],
                [
                    "United States only",
                    "Other country via the United States",
                    "Not available",
                ],
            ),
            DependantValidation(
                "trip_purpose_detailed",
                [
                    "Automobile",
                    "Motorcycle",
                    "Pedestrian",
                    "Ferry (Private vehicle)",
                    "Ferry (Pedestrian)",
                ],
                [
                    "Personal",
                    "Business and professional",
                    "Study",
                    "Visit, not otherwise specified",
                    "Work",
                    "Immigration",
                    "Military",
                    "Other purpose",
                    "Not available",
                ],
            ),
            DependantValidation(
                "trip_purpose",
                [
                    "Automobile",
                    "Motorcycle",
                    "Pedestrian",
                    "Ferry (Private vehicle)",
                    "Ferry (Pedestrian)",
                ],
                ["Visit", "Work", "Other non-tourism", "Not available"],
            ),
        ],
    )

    plate_country = SelectField(
        "Plate Country",
        choices=get_default_na_choices(LABEL_PLATE_COUNTRY),
        validators=[
            DataRequired(),
        ],
    )

    arriving_from = SelectField(
        "Arriving From",
        choices=get_default_na_choices(LABEL_ARRIVING_FROM),
        validators=[RequiredIf(capture_type=CaptureType.travellers.value)],
    )

    country_of_residence = SelectField(
        "Country of Residence",
        choices=get_sorted_countries(),
        validators=[RequiredIf(capture_type=CaptureType.travellers.value)],
    )

    trip_purpose_detailed = SelectField(
        "Trip Purpose Detailed",
        choices=get_default_na_choices(LABEL_PURPOSE9),
        validators=[
            DependantValidation(
                "trip_purpose",
                [
                    "Personal",
                    "Business and professional",
                    "Study",
                    "Visit, not otherwise specified",
                ],
                ["Visit"],
            ),
            DependantValidation("trip_purpose", ["Crew"]),
            DependantValidation("trip_purpose", ["Work"]),
            DependantValidation(
                "trip_purpose",
                ["Immigration", "Military", "Other purpose"],
                ["Other non-tourism"],
            ),
            DependantValidation("trip_purpose_detailed", ["Not Available"]),
            DependantValidation("trip_purpose_detailed", ["Truck"], ["Crew"]),
        ],
    )

    trip_purpose = SelectField(
        "Trip Purpose",
        choices=get_default_na_choices(LABEL_PURPOSE4),
        validators=[RequiredIf(capture_type=CaptureType.travellers.value)],
    )

    duration = SelectField(
        "Duration",
        choices=[member for member in LABEL_DURATION2.values()],
        validators=[RequiredIf(capture_type=CaptureType.travellers.value)],
    )

    number_of_travellers = IntegerField(
        "Number of Travellers",
        validators=[Optional()],
        description="The number of Travellers",
    )

    number_of_vehicles = IntegerField(
        "Number of Vehicles",
        validators=[Optional()],
        description="The number of Vehicles",
    )

    submit = SubmitField("Submit")


def data_capture_to_minio(form: DataCapture):
    client = S3Client.get_client()
    datasource = (
        DataSource.manual_entry_travellers
        if form.capture_type.data == CaptureType.travellers.value
        else DataSource.manual_entry_vehicles
    )

    prefix = S3.prefix(
        Stage.RAW,
        Mode.file,
        datasource,
        year=str(form.year.data),
        month=str(form.month.choices.index(form.month.data) + 1),
    )

    basename = S3.get_manual_entry_basename(form, Stage.RAW, datasource)
    loc = S3Location(prefix.bucket, prefix.prefix, basename)
    df = form_to_pandas(form, datasource)
    print(loc)
    client.upload_df_to_loc(df, loc)


def form_to_pandas(form: DataCapture, datasource: DataSource) -> pd.DataFrame:
    schema = load_datasource_schema(datasource, Stage.RAW)
    df = pd.json_normalize(form.data)
    if form.capture_type.data == CaptureType.travellers.value:
        df[schema.count_of_entries] = df["number_of_travellers"]
        df[schema.duration2] = df["duration"]
        df[schema.purpose4] = df["trip_purpose"]
        df[schema.purpose9] = df["trip_purpose_detailed"]
    else:
        df[schema.count_of_entries] = df["number_of_vehicles"]

    df[schema.year] = form.year.data
    # Month and day expect certain values that differ from what is presented on the
    # form choices. Month must be an int between 1 and 12, and if the day is not
    # available, it must be replaced with "99".
    df[schema.month] = form.month.choices.index(form.month.data) + 1
    df[schema.day] = form.day.data if form.day.data != "Not available" else "99"

    df = name_to_code_dimension(df, LABEL_DATA_SOURCE, "data_source")
    df = port_to_dimension(df)
    df = name_to_code_dimension(df, LABEL_VEHICLE_TYPE, "vehicle_type")
    df = name_to_code_dimension(df, LABEL_PLATE_COUNTRY, "plate_country")
    df = name_to_code_dimension(df, LABEL_ARRIVING_FROM, "arriving_from")
    df = countries_to_dimension(df)
    df = name_to_code_dimension(df, LABEL_PURPOSE9, "purpose9")
    df = name_to_code_dimension(df, LABEL_PURPOSE4, "purpose4")
    df = name_to_code_dimension(df, LABEL_DURATION2, "duration2")
    # Replace "Not Available" codes with pd.NA
    df = make_codes_pd_na(df, datasource)

    return df[list(schema.to_schema().columns.keys())]
