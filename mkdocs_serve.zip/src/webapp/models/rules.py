import os

import pandas as pd

from flask_wtf import FlaskForm
from pandas.core.frame import DataFrame
from wtforms.fields import (
    StringField,
    FormField,
    FieldList,
    SelectField,
    SelectMultipleField,
    SubmitField,
    DecimalField,
)
from wtforms.fields.html5 import DateField
from wtforms.form import Form
from wtforms.validators import DataRequired, Optional, AnyOf
from config.api import DataSource, S3Location, Stage
from modules.utils.loaders import Loader
from modules.s3client import S3Client
from modules.utils.data_manipulation import explode
from modules.utils.schema import load_datasource_schema

from webapp.models.utils import (
    get_sorted_countries,
    name_to_code_dimension,
)
from webapp.models.utils import countries_to_dimension
from webapp.models.utils import get_countries_as_dim
from webapp.models.utils import get_ports
from webapp.models.utils import port_to_dimension

from config.api import FixedProportionVars

from datasource.common.dim import DATA_SOURCE, VEHICLE_TYPE, PLATE_COUNTRY
from datasource.common.labels import (
    MONTH as LABEL_MONTH,
    DAY as LABEL_DAY,
    MODE as LABEL_MODE,
    VEHICLE_TYPE as LABEL_VEHICLE_TYPE,
    PLATE_COUNTRY as LABEL_PLATE_COUNTRY,
    PLATE_REGION as LABEL_PLATE_REGION,
    ARRIVING_FROM as LABEL_ARRIVING_FROM,
    PURPOSE9 as LABEL_PURPOSE9,
    PURPOSE4 as LABEL_PURPOSE4,
    DURATION2 as LABEL_DURATION2,
    DURATION3 as LABEL_DURATION3,
    DURATION5 as LABEL_DURATION5,
    TRAVELLER_TYPE as LABEL_TRAVELLER_TYPE,
    DATA_SOURCE as LABEL_DATA_SOURCE,
)
from datasource.travellers.dim import ARRIVING_FROM, PURPOSE4, DURATION2

from uuid import uuid4

# Mapping between what was displayed in the "Fixed Proportion Variable"
# form selection and the corresponding dimension.
FORM_TO_DIM_MAP = {
    FixedProportionVars.vehicle_type.value: LABEL_VEHICLE_TYPE,
    FixedProportionVars.plate_country.value: LABEL_PLATE_COUNTRY,
    FixedProportionVars.arriving_from.value: LABEL_ARRIVING_FROM,
    FixedProportionVars.purpose4.value: LABEL_PURPOSE4,
    FixedProportionVars.duration2.value: LABEL_DURATION2,
    "data_source": LABEL_DATA_SOURCE,
}


class RequiredIf(DataRequired):
    """Validator which makes a field required if another field is set and has a truthy value.

    Sources:
        - http://wtforms.simplecodes.com/docs/1.0.1/validators.html
        - http://stackoverflow.com/questions/8463209/how-to-make-a-field-conditionally-optional-in-wtforms
        - https://gist.github.com/devxoul/7638142#file-wtf_required_if-py
    """

    field_flags = ("requiredif",)

    def __init__(self, message=None, *args, **kwargs):
        super(RequiredIf).__init__()
        self.message = message
        self.conditions = kwargs

    # field is requiring that name field in the form is data value in the form
    def __call__(self, form, field):
        for name, data in self.conditions.items():
            other_field = form[name]
            if other_field is None:
                raise Exception('no field named "%s" in form' % name)
            if other_field.data == data and not field.data:
                DataRequired.__call__(self, form, field)
            Optional()(form, field)


class ProportionField(DecimalField):
    def pre_validate(self, form):
        return super().pre_validate(form)


class SelectMultipleItemsField(SelectMultipleField):
    """
    The upstream SelectMultipleField expects choices in an unusual format.
    This class overrides the relevant methods so that we don't have to
    refactor many of the form choices.
    """

    def iter_choices(self):
        """Overrides iter_choices generator in SelectMultipleField to automatically
        cast to list of tuples.
        """
        if not self.choices:
            choices = []
        elif isinstance(self.choices[0], (list, tuple)):
            choices = self.choices
        else:
            choices = zip(self.choices, self.choices)

        for value, label in choices:
            yield (value, label, self.coerce(value) == self.data)

    def pre_validate(self, form):
        """
        Checks if the selected item(s) belong in the list of acceptable values.
        The parent implementation checks this incorrectly, so this overrides
        to correctly check if the selected choices were valid.
        """
        if self.data:
            for d in self.data:
                if d not in self.choices:
                    raise ValueError(
                        self.gettext("'%(value)s' is not a valid choice for this field")
                        % dict(value=d)
                    )


class InputGridRecordForm(Form):
    """A form for entering inputgrid record row data"""

    proportion_label = StringField("Col Val")
    select = ProportionField("Select")


class FixedRules(FlaskForm):
    data_source = SelectField(
        "Datasource",
        choices=["all"] + [member for member in LABEL_DATA_SOURCE.values()],
        validators=(DataRequired(),),
    )

    port = SelectField(
        "Port",
        choices=get_ports(),
        validators=(DataRequired(),),
    )

    valid_from = DateField(
        "Valid From", format="%Y-%m-%d", validators=(DataRequired(),)
    )

    valid_to = DateField("Valid To", format="%Y-%m-%d", validators=(DataRequired(),))

    vehicle_type = SelectMultipleItemsField(
        "Vehicle",
        choices=["all"] + [member for member in LABEL_VEHICLE_TYPE.values()],
    )

    plate_country = SelectMultipleItemsField(
        "Plate Country",
        choices=["all"] + [member for member in LABEL_PLATE_COUNTRY.values()],
    )

    arriving_from = SelectMultipleItemsField(
        "Arriving From",
        choices=["all"] + [member for member in LABEL_ARRIVING_FROM.values()],
    )

    country_of_residence = SelectMultipleItemsField(
        choices=["all"] + get_sorted_countries(),
    )

    purpose4 = SelectMultipleItemsField(
        "Trip Purpose",
        choices=["all"] + [member for member in LABEL_PURPOSE4.values()],
    )

    duration2 = SelectMultipleItemsField(
        "Duration",
        choices=["all"] + [member for member in LABEL_DURATION2.values()],
    )

    fixed_prop_variable = SelectField(
        "Fixed Proportion Variable",
        choices=["--"] + FixedProportionVars.list(),
        validators=(
            DataRequired(),
            AnyOf(
                FixedProportionVars.aslist(),
                message="Must select a value for Fixed Proportion",
            ),
        ),
        default="--",
        # render_kw={"onchange": "renderFixedProportion()"},
    )

    vehicle_type_proportions = FieldList(FormField(InputGridRecordForm))
    plate_country_proportions = FieldList(FormField(InputGridRecordForm))
    arriving_from_proportions = FieldList(FormField(InputGridRecordForm))
    country_of_residence_proportions = FieldList(FormField(InputGridRecordForm))
    purpose4_proportions = FieldList(FormField(InputGridRecordForm))
    duration2_proportions = FieldList(FormField(InputGridRecordForm))

    submit = SubmitField("Submit")


class InputFormSet(FlaskForm):
    inputs = FieldList(FormField(FixedRules))


def format_fixed_proportions(df: pd.DataFrame, imputation_target: str) -> pd.DataFrame:
    """
    Applies datasource-specific formatting to fixed proportions dataframe.

    Convert code to dimension depending on whether the impute target is
    country_of_residence or a dimension. Note that all dimensions are "recoded"
    in the same way, but countries is a datasource, which is why there is a
    distinction.
    """
    if imputation_target == "COUNTRY_OF_RESIDENCE":
        df = countries_to_dimension(df, col_name="value")
    else:
        df = name_to_code_dimension(df, FORM_TO_DIM_MAP[imputation_target], "value")
    return df


def format_fixed_proportion_rule(df: pd.DataFrame) -> pd.DataFrame:
    """
    If we are adding a row to fixed_proportion_rules we need to convert
    **all** the columns to their corresponding numeric codes.
    """
    df = countries_to_dimension(df, col_name="country_of_residence")
    df = port_to_dimension(df)
    for k, v in FORM_TO_DIM_MAP.items():
        df = name_to_code_dimension(df, v, k)
    return df


def fixed_proportions_invalid(
    df: pd.DataFrame, form: FixedRules, loc: S3Location
) -> bool:
    """
    Checks whether the fixed proportions entered conflict with the existing
    table entries. This should only ever happen if a human user manually changed
    the table and re-uploaded it to MinIO.
    """
    # Check for the existing table - if there is no table then the form submission
    # is valid because there can't be a conflict if no data exists.
    client = S3Client.get_client()
    if not client.stat_loc(loc):
        return False
    existing_df = Loader.get(Stage.REFERENCE, DataSource.fixed_proportions, None)
    schema = load_datasource_schema(DataSource.fixed_proportions, Stage.REFERENCE)
    full_table = pd.concat([existing_df, df]).reset_index()
    # A duplicate in the proportions table is simply a row that contains an
    # identical rule_id and value to another row.
    if not full_table.duplicated(subset=schema.get_keys()).any():
        return False
    return True


def fixed_proportion_rule_invalid(
    df: pd.DataFrame, form: FixedRules, loc: S3Location
) -> bool:
    """Checks whether the fixed_proportion_rule submitted conflicts with
       an existing rule. If there is a conflict, it returns true and returns
       false otherwise.

    Returns:
        bool: True if there is a conflict and False otherwise.
    """
    # Check for the existing table - if there is no table then the form submission
    # is valid because there can't be a conflict if no data exists.
    client = S3Client.get_client()
    if not client.stat_loc(loc):
        return False
    existing_df = Loader.get(Stage.REFERENCE, DataSource.fixed_proportion_rules, None)
    schema = load_datasource_schema(DataSource.fixed_proportion_rules, Stage.REFERENCE)
    # Case valid_from/valid_to to datetime so that we can use
    # comparison operators on datetimes.
    existing_df.valid_from = pd.to_datetime(existing_df.valid_from)
    existing_df.valid_to = pd.to_datetime(existing_df.valid_to)
    df.valid_from = pd.to_datetime(df.valid_from)
    df.valid_to = pd.to_datetime(df.valid_to)
    # For performance reasons, disregard any existing rules whose valid_to dates
    # are earlier than the candidate rule - no need to check conflicts with
    # expired rules.
    existing_df = existing_df.loc[existing_df.valid_to > df.valid_from.squeeze(), :]
    # If existing_df is empty, there can't be a conflict because all of the existing
    # rules don't conflict with
    if existing_df.empty:
        return False
    # Substitute "all" collumns in both df and existing_df
    for col in schema.get_keys():
        # Note that 'country_of_residence' is not a dimension, rather it's its own
        # reference table, so we need to get the enumerations of this column with
        # a different function.
        if col == schema.country_of_residence:
            df[col] = df[col].apply(
                lambda x: (
                    get_countries_as_dim(col_name="country_of_residence")
                    if not isinstance(x, list) and not pd.isna(x) and x == "all"
                    else x
                )
            )
            existing_df[col] = existing_df[col].apply(
                lambda x: (
                    get_countries_as_dim(col_name="country_of_residence")
                    if not isinstance(x, list) and not pd.isna(x) and x == "all"
                    else x
                )
            )
        else:
            df[col] = df[col].apply(
                lambda x: (
                    list(FORM_TO_DIM_MAP[col].keys())
                    if not isinstance(x, list) and not pd.isna(x) and x == "all"
                    else x
                )
            )
            existing_df[col] = existing_df[col].apply(
                lambda x: (
                    list(FORM_TO_DIM_MAP[col].keys())
                    if not isinstance(x, list) and not pd.isna(x) and x == "all"
                    else x
                )
            )
    # 1. explode df (candidate row we want to add) into all combinations of 'all'
    EXPLODE_COLUMNS = [
        col for col in df.columns if df[col].apply(lambda x: isinstance(x, list)).any()
    ]
    for col in EXPLODE_COLUMNS:
        # At this point in the code, each row contains *either* a list of
        # every enumerable value that column could take on OR a single value
        # (the current form submission has already been exploded before
        # this point). Therefore, for a given column, all rows that contain
        # a list will have the *same dimension*, so we can safely call
        # explode on the subset of the table where the column contains a list
        # value (i.e. the contents of that cell are a python List rather than
        # a string).
        EXPLODE_MASK = df[col].apply(lambda x: isinstance(x, list))
        to_explode = df.loc[EXPLODE_MASK]
        singles = df.loc[~EXPLODE_MASK]
        # Explode the subset of the dataframe with lists, then concatenate the
        # exploded table with the singles.
        exploded = explode(to_explode, [col])
        df = pd.concat([singles, exploded])
    # 2. explode existing df (all existing rows) into all combinations of 'all'
    EXPLODE_COLUMNS = [
        col
        for col in existing_df.columns
        if existing_df[col].apply(lambda x: isinstance(x, list)).any()
    ]
    for col in EXPLODE_COLUMNS:
        EXPLODE_MASK = existing_df[col].apply(lambda x: isinstance(x, list))
        to_explode = existing_df.loc[EXPLODE_MASK]
        singles = existing_df.loc[~EXPLODE_MASK]
        exploded = explode(to_explode, [col])
        existing_df = pd.concat([singles, exploded])
    # 3. Do an inner join on schema primary keys
    dtypes = dict(
        zip(
            list(schema.to_schema().columns.keys()),
            [d.type.name for d in schema.to_schema().dtypes.values()],
        )
    )
    df = df.astype(dtypes)
    existing_df = existing_df.astype(dtypes)
    inner = pd.merge(df, existing_df, on=schema.get_keys(), how="inner")
    # 4. If inner join is empty, accept automatically
    if inner.empty:
        return False
    # 5. If innter join is not empty, check
    # 5.1 df.valid_from < existing_df.valid_to
    DATE_OVERLAP_1 = inner[f"{schema.valid_from}_x"] < inner[f"{schema.valid_to}_y"]
    DATE_OVERLAP_2 = inner[f"{schema.valid_to}_x"] > inner[f"{schema.valid_from}_y"]
    DATE_OVERLAP = DATE_OVERLAP_1 & DATE_OVERLAP_2
    # 5.2 df.valid_to > existing_df.valid_from
    # If 5.1 AND 5.2 there is a conflict, else no conflict.
    if DATE_OVERLAP.any():
        form.data_source.errors.append(
            f"The current form submission conflicts with a rule that already exists."
        )
        return True
    return False


def fixed_rules_table(form: FixedRules) -> bool:
    """
    Formats, validates, and creates or uploads the form submission to the
    Reference tables stored in s3 storage.
    """
    # Generate UID for the rule we are about to create
    RULE_ID = uuid4().hex
    # Format the fixed proportions and fixed proportion rule
    fixed_proportions = get_fixed_proportions(form, RULE_ID)
    fixed_proportion_rule = get_fixed_proportion_rule(form, RULE_ID)
    # Apply the appropriate datasource-specific formatting to each table
    fixed_proportions = format_fixed_proportions(
        fixed_proportions, imputation_target=form.fixed_prop_variable.data
    )
    fixed_proportion_rule = format_fixed_proportion_rule(fixed_proportion_rule)
    # Setup s3 locations
    fixed_proportion_rules_prefix = os.path.join(
        Stage.REFERENCE.name.lower(), DataSource.fixed_proportion_rules.name
    )
    fixed_proportions_prefix = os.path.join(
        Stage.REFERENCE.name.lower(), DataSource.fixed_proportions.name
    )
    loc_fixed_proportion_rules = S3Location(
        bucket=Stage.REFERENCE.value.bucket,
        prefix=fixed_proportion_rules_prefix,
        basename=f"{DataSource.fixed_proportion_rules.name}.csv",
    )
    loc_fixed_proportions = S3Location(
        bucket=Stage.REFERENCE.value.bucket,
        prefix=fixed_proportions_prefix,
        basename=f"{DataSource.fixed_proportions.name}.csv",
    )
    # Validate whether the new tables create a conflict with the existing tables.
    # Note that we pass a copy since we don't want to mutate the original dataframe
    # in the function calls.
    if fixed_proportions_invalid(
        fixed_proportions.copy(), form, loc_fixed_proportions
    ) or fixed_proportion_rule_invalid(
        fixed_proportion_rule.copy(), form, loc_fixed_proportion_rules
    ):
        return False
    # Create or update the files at the given locations
    create_or_update(
        fixed_proportions, loc_fixed_proportions, DataSource.fixed_proportions
    )
    create_or_update(
        fixed_proportion_rule,
        loc_fixed_proportion_rules,
        DataSource.fixed_proportion_rules,
    )
    return True


def create_or_update(df: DataFrame, loc: str, datasource: DataSource):
    client = S3Client.get_client()

    if client.stat_loc(loc):
        append_to_table(df, loc, datasource)
    else:
        client.upload_df_to_loc(df, loc)


def append_to_table(df: DataFrame, loc: S3Location, datasource: DataSource):
    client = S3Client.get_client()
    # Get existing dataframe from loc
    existing_df = Loader.get(Stage.REFERENCE, datasource, None)
    # Append df to existing_df
    existing_df = pd.concat([existing_df, df])
    # Write output back to the same location (overwriting the old value)
    client.upload_df_to_loc(existing_df, loc)


def get_fixed_proportions(form: FixedRules, rule_id: str):
    schema = load_datasource_schema(DataSource.fixed_proportions, Stage.REFERENCE)
    proportions_name = f"{form.fixed_prop_variable.data.lower()}_proportions"
    proportions_data = getattr(form, proportions_name)

    df = pd.DataFrame(proportions_data.data)
    df.columns = [schema.value, schema.proportion]
    df[schema.rule_id] = rule_id

    return df[list(schema.to_schema().columns.keys())]


def get_fixed_proportion_rule(form: FixedRules, rule_id: str):
    schema = load_datasource_schema(DataSource.fixed_proportion_rules, Stage.REFERENCE)
    df = pd.DataFrame(
        {
            k: [v]
            for k, v in form.data.items()
            if k in list(schema.to_schema().columns.keys())
        }
    )
    # Create the Rule UID column and assign it the UID passed as argument
    df[schema.rule_id] = rule_id
    # Whichever column was selected as the fixed proportion variable will
    # have a value of [] (i.e. empty selection) - this should just be cast
    # to pd.NA
    df[form.fixed_prop_variable.data] = pd.NA
    # Explode one-by-one each row that contains a list. Note that the explode
    # function below only works if the column lists are conformable; calling it
    # on one column at a time guarantees that there won't be an error due to
    # dimension mismatch.
    explode_columns = [col for col in df.columns if isinstance(df[col][0], list)]
    for col in explode_columns:
        df = explode(df, [col])
    return df[list(schema.to_schema().columns.keys())]
