"""
Module for ad-hoc form validation functions.
"""
import numpy as np

from config.api import FixedProportionVars


def validate_non_proportion_variables(form: "FixedRules") -> bool:
    """
    Users are required to select one or more options for the various "green"
    variables, but only if the particular variable isn't being selected for
    imputation (in this case there should be no input since this is the
    imputation target).

    **Note for maintainers:** Data capture and fixed rules are destined to be
    deprecated in the near future. Unless requirements have changed, it is
    probably not worth figuring out how to implement this check properly in a
    WTForms validator.
    """
    # Whichever column was selected as the fixed proportion variable will
    # have a value of [] (i.e. empty selection) - this should be ignored
    # from the validation below.
    COLS_TO_CHECK = FixedProportionVars.aslist()
    COLS_TO_CHECK.remove(form.fixed_prop_variable.data)
    num_errors = 0
    for col in COLS_TO_CHECK:
        if form[col].data == []:
            form[col].errors.append(f"Selection required for variable {col}")
            num_errors = num_errors + 1
    if num_errors > 0:
        return False
    return True


def validate_proportions(form: "FixedRules") -> bool:
    """
    Validates if the proportions submitted sum to 1.
    """
    # Depending on what the imputation target it, get a reference to the
    # entered proportions.
    form_to_props_map = {
        FixedProportionVars.vehicle_type.value: form.vehicle_type_proportions,
        FixedProportionVars.plate_country.value: form.plate_country_proportions,
        FixedProportionVars.arriving_from.value: form.arriving_from_proportions,
        FixedProportionVars.purpose4.value: form.purpose4_proportions,
        FixedProportionVars.duration2.value: form.duration2_proportions,
        FixedProportionVars.country_of_residence.value: form.country_of_residence_proportions
    }
    # Get the proportions entered for the current imputation target
    imputation_target_props = form_to_props_map[form.fixed_prop_variable.data]
    # Get the sum of the proportions entered
    props_sum = np.array([float(decimal.data["select"]) for decimal in imputation_target_props.entries]).sum()
    # If the sum does not equal 1.0, then there is an error
    if props_sum > 1.0:
        form.fixed_prop_variable.errors.append("Sum of proportions is greater than 1.0")
        return False
    elif props_sum < 1.0:
        form.fixed_prop_variable.errors.append("Sum of proportions is less than 1.0")
        return False
    else:
        return True
