#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
from webapp import app
from flask import session
from datetime import timedelta
from config.api import AutoEnum
from enum import Enum
from enum import auto


class Lang(AutoEnum):
    FR = auto()
    EN = auto()


class DisplayLang(Enum):
    FR = "Français"
    EN = "English"


# Datastructure keys
APP      = "app"
LANGUAGE = "language"
ALT_LANG = 'alt_language'
DISPLAY_LANG = 'display_language'


def init_session():
    """ Initializes the session variables if not set"""
    if APP not in session:
        session.permanent = True
        app.permanent_session_lifetime = timedelta(days=1)
        session[APP]      = True
        session[LANGUAGE] = Lang.EN
        session[ALT_LANG] = Lang.FR
        session[DISPLAY_LANG] = DisplayLang.FR

def toggle_session_lang():
    session[LANGUAGE] = Lang.EN if session[LANGUAGE] == Lang.FR else Lang.FR
    session[ALT_LANG] = Lang.EN if session[ALT_LANG] == Lang.FR else Lang.FR
    session[DISPLAY_LANG] = DisplayLang.FR if session[ALT_LANG] == Lang.FR else DisplayLang.EN

def clear_session():
    """ removes the temp session folder and clears the session variables"""
    session.clear()
