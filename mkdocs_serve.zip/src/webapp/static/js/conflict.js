$(document).ready(function () {
    display_loader('#content');
    //var reload = setTimeout(function(){location.reload(true);}, 90*1000);

    // Parameters
    const DiffParams = JSON.parse(document.getElementById('diff-params').getAttribute('data-url'));
    // URLs
    const discardUrl = document.getElementById('discard-url').getAttribute('data-url');
    const conflictsUrl = document.getElementById('conflicts-url').getAttribute('data-url');
    const acceptUrl = document.getElementById('accept-url').getAttribute('data-url');
    const mergeUrl = document.getElementById('merge-url').getAttribute('data-url');
    const diffUrl = document.getElementById('diff-url').getAttribute('data-url');
    const downloadUrl = document.getElementById('download-url').getAttribute('data-url');
    // Translations
    const keepOriginalTranslation = document.getElementById('keep-original-translation').getAttribute('data-url');
    const acceptNewTranslation = document.getElementById('accept-new-translation').getAttribute('data-url');
    const mergeTranslation = document.getElementById('merge-translation').getAttribute('data-url');
    const originalTranslation = document.getElementById('original-translation').getAttribute('data-url');
    const newTranslation = document.getElementById('new-translation').getAttribute('data-url');

    var DiffControlParams = {
        "basename": '',
        "stage": '',
        "datasource": '',
        "original": '',
        "path": '',
        "org_bucket": '',
        "path_bucket": ''
    }
    function set_opt(obj) {
        DiffControlParams.basename = obj.basename
        DiffControlParams.stage = obj.stage
        DiffControlParams.datasource = obj.datasource
        DiffControlParams.original = obj.original
        DiffControlParams.path = obj.path
        DiffControlParams.org_bucket = obj.org_bucket
        DiffControlParams.path_bucket = obj.path_bucket
    }

    function format_location(str) {
        return str.replace("%24", "$").replace("%7B", "{").replace("%7D", "}")
    }

    function generate_download_url(baseUrl, bucket, path) {
        var bucketFormatted = format_location(bucket)
        var pathFormatted = format_location(path)

        return baseUrl.replace("__BUCKET__", bucketFormatted).replace("__PATH__", pathFormatted)
    }

    const downloadOrigUrl = generate_download_url(downloadUrl, DiffControlParams.org_bucket, DiffControlParams.original)
    const downloadPathUrl = generate_download_url(downloadUrl, DiffControlParams.path_bucket, DiffControlParams.path)

    function discard(e) {
        set_opt(e.obj);
        postJson(discardUrl, DiffControlParams, function (response) {
            window.location.href = conflictsUrl;
        });

    }
    function accept(e) {
        set_opt(e.obj);
        postJson(acceptUrl, DiffControlParams, function (response) {
            window.location.href = conflictsUrl;
        });
    }
    function auto_merge(e) {
        set_opt(e.obj);
        postJson(mergeUrl, DiffControlParams, function (response) {
            window.location.href = conflictsUrl;
        });
    }


    var controls = [
        {
            "<>": "div", "class": "btn-group ", "role": "group", "html": [
                { "<>": "button", "type": "button", "class": "btn btn-outline-primary  ", "html": keepOriginalTranslation, "onclick": discard },
                { "<>": "button", "type": "button", "class": "btn btn-outline-primary  ", "html": acceptNewTranslation, "onclick": accept },
                { "<>": "button", "type": "button", "class": "btn btn-outline-primary  ", "html": mergeTranslation, "onclick": auto_merge }
            ]
        },
        {
            "<>": "div", "class": "btn-group ml-3", "role": "group", "html": [
                {
                    "<>": "a", "class": "btn btn btn-outline-primary   ", "role": "button", "html": [
                        { "<>": "i", "class": "fas fa-download fa-sm " },
                        { "<>": "span", "html": originalTranslation }
                    ], "href": downloadOrigUrl
                },
                {
                    "<>": "a", "class": "btn btn-outline-primary  ", "role": "button", "html": [
                        { "<>": "i", "class": "fas fa-download fa-sm " },
                        { "<>": "span", "html": newTranslation }
                    ], "href": downloadPathUrl
                }
            ]
        }
    ];

    display_diff(diffUrl, DiffParams, '#content', controls);

});