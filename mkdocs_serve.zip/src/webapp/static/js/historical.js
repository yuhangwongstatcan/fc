$(document).ready(function () {
    display_loader('#content');
    var reload = setTimeout(function () { location.reload(true); }, 90 * 1000);

    // Parameters
    const StageParams = JSON.parse(document.getElementById('stage-params').getAttribute('data-url'));
    // URLs
    const getHistoricalUrl = document.getElementById('get-historical-url').getAttribute('data-url');
    const historicalUrl = document.getElementById('historical-url').getAttribute('data-url');

    postJson(getHistoricalUrl, StageParams, function (data) {
        clearTimeout(reload);
        display_timelines('#content', data, historicalUrl);
    });

});