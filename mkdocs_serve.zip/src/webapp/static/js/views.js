/*
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
*/

var timeout = undefined;
var interval = 1000;

//Helper function to send post data to FASTAPI
function postJson(url, data, callback) {
  return $.ajax({
    type: 'POST',
    url: url,
    contentType: "application/json",
    dataType: 'json',
    data: JSON.stringify(data),
    success: callback
  });
}

function prefix_index(prefix) {
  return function (o, index) {
    return prefix + index;
  }
}

// toggle accessibility box
function handleFirstTab(e) {
  if (e.keyCode === 9) {
    document.body.classList.add('user-is-tabbing');
    window.removeEventListener('keydown', handleFirstTab);
  }
}

window.addEventListener('keydown', handleFirstTab);

function timeline(data) {
  /*
    data = [ object, ...]
    object = { count: int,
        count_label: str,
        datasource: str,
        timeline: Array[event]
    }
    event = {
      event: str,
      content: Array[item]
    }
    item = {
      href: str,
      label: str,
    }
    */
  var transform = {
    "card": {
      "<>": "div", "class": "card mb-3 shadow", "html": [
        {
          "<>": "a", "href": prefix_index('#section'), "class": "d-block card-header collapse", "data-toggle": "collapse", "role": "button", "html": [
            {
              "<>": "div", "class": "text-primary", "html": [
                { "<>": "i", "class": "fa fa-database", "html": " " },
                { "<>": "span", "class": "font-weight-bold text-uppercase", "html": " ${datasource} " }
              ]
            },
            { "<>": "small", "class": "mb-0 text-dark font-weight-bold text-uppercase", "html": "${count} ${count_label}" }
          ]
        },
        {
          "<>": "div", "class": "collapse", "id": prefix_index('section'), "html": [
            {
              "<>": "div", "class": "card-body", "html": [
                {
                  "<>": "ul", "html": function (o) {
                    return $.json2html(o, transform.timeline);
                  }
                }
              ]
            }
          ]
        }
      ]
    },
    "timeline": {
      "<>": "ul", "class": "timeline", "html": function (o) {
        return $.json2html(o.timeline, transform.event);
      }
    },
    "event": {
      "<>": "li", 'html': [
        { "<>": "span", "class": "event", "html": "${event}" },
        {
          "<>": "ul", "class": "content", "html": function (o) {
            return $.json2html(o.content, transform.item);
          }
        }
      ]
    },
    "item": {
      "<>": "li", "html": [
        { "<>": "a", "href": "${href}", "html": "${label}" }
      ]
    }
  };
  return $.json2html(data, transform.card);
}

function display_timelines(container_id, data, baseurl) {


  function filter(e) {
    location.href = baseurl.replace('REPLACE', $(container_id + "year").val());
  }
  var transform = {
    "page": [
      {
        "<>": "div", "class": "mb-4", "html": [
          { "<>": "h1", "class": "my-0 py-0 text-primary text-uppercase", "html": "${header}" },
          { "<>": "small", "class": " font-weight-bold text-dark text-uppercase", "html": "${desc}" },

          {
            "<>": "ol", "class": "breadcrumb mt-3", "html": [
              { "<>": "li", "class": "breadcrumb-item text-lowercase text-dark", "html": "${bucket}" },
              { "<>": "li", "class": "breadcrumb-item text-lowercase text-dark", "html": "${mode}" },
              { "<>": "li", "class": "breadcrumb-item text-lowercase text-dark", "html": "${stage}" },
              { "<>": "span", "class": "text-lowercase text-dark", "html": "&nbsp;/" },
              {
                "<>": "li", "class": "ml-1 ", "html": [
                  {
                    "<>": "div", "class": "input-group input-group-sm mt-n1", "html": [
                      { "<>": "label", "class": "d-none", "for": container_id.substring(1) + "year", "html": "${arial_label}" },
                      {
                        "<>": "input", "type": "text", "class": "form-control text-dark", 'value': "${year}", "id": container_id.substring(1) + "year", "onkeydown": function (e) {
                          // If user pressed enter, trigger filter function
                          if (e.event.keyCode == 13) {
                            filter(e);
                          }
                        }
                      },
                      {
                        "<>": "div", "class": "input-group-append", "html": [
                          {
                            "<>": "button", "class": "btn btn-outline-dark", "type": "button", "html": [
                              { "<>": "i", "class": "fas fa-filter", "html": "&nbsp;" },
                              { "<>": "span", "html": "${label}", "class": "" }
                            ], "onclick": filter
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }

        ]
      },
      {
        "<>": "div", "html": function (o) {
          return timeline(o.timelines);
        }
      }
    ]
  };

  $(container_id).html('');
  $(container_id).json2html(data, transform.page);


}
function conflict_columns(str) {
  var conflicts = []
  if (str.length > 2 && str[1] == '@') {
    str = str.slice(2)
    conflicts = str.split(',').map(Number)
  }
  return conflicts
}
const Action = Object.freeze({
  "new": "table-success",
  "miss": "table-danger",
  "same": "same",
  "conf": "table-info"
})
function class_row(row, index) {
  if (row[1][0] == '-') return Action.miss;
  if (row[1][0] == '+') return Action.new;
  return Action.same;
}
function display_diff(controller, options, container_id, controls) {


  function display(options) {
    postJson(controller, options, function (data) {
      $(container_id).html('');
      $(container_id).json2html(data, transform.card);
    });
  }


  function page(e) {
    $(e.event.currentTarget.children[0]).removeClass().addClass('fa-spinner fas fa-spin')
    options.page = $(e.event.currentTarget).data('page')
    options.filters = $(container_id + ' .fa-toggle-on').map(function (i, v) {
      return ($(v).data('filter'));
    }).get();
    display(options);
  }

  function toggle_rows(action) {
    return function (e) {

      $(e.event.currentTarget).toggleClass('fa-toggle-off')
      $(e.event.currentTarget).toggleClass('fa-toggle-on')

      options.page = 1
      options.filters = $(container_id + ' .fa-toggle-on').map(function (i, v) {
        return ($(v).data('filter'));
      }).get();

      if ($(e.event.currentTarget).hasClass('fa-toggle-on')) {
        $(e.event.currentTarget).removeClass('fa-toggle-on')
        $(e.event.currentTarget).addClass('fa-spinner fa-spin')
        display(options);
      }
      else {
        $(e.event.currentTarget).removeClass('fa-toggle-off')
        $(e.event.currentTarget).addClass('fa-spinner fa-spin')
        display(options);
      }
    }
  }
  var transform = {
    "card": {
      "<>": "div", "class": "card   shadow ", "html": [
        {
          "<>": "div", "class": "card-header container-fluid", "html": [
            {
              "<>": "div", "class": "row", "html": [
                {
                  "<>": "div", "class": "col-lg-8 col-md-12  col-xs-12  text-primary", "html": [
                    {
                      "<>": "div", "class": "", "html": [
                        { "<>": "i", "class": "fa fa-copy", "html": " " },
                        {
                          "<>": "span", "class": "font-weight-bold text-uppercase", "html": [
                            { "<>": "h1", "html": " ${labels.title}" }
                          ]
                        }
                      ]
                    },
                    // {"<>":"div", "class":"mt-2 text-xs text-dark font-weight-bold text-uppercase", "html":"${original}"},
                    { "<>": "small", "class": "mb-0 text-dark font-weight-bold text-uppercase", "html": "${path}" }
                  ]
                },
                { "<>": "div", "class": "col-lg-4 col-md-12 col-xs-12 text-right  mt-1 ", "html": controls }
              ]
            }
          ]
        },
        {
          "<>": "div", "class": "card-body", "html": [

            {
              "<>": "div", "class": "ml-2 mb-2 text-md text-primary", "html": [
                { "<>": "a", "href": "#", "class": "fas ${toggles.duplicates.style}", "data-filter": "${toggles.duplicates.value}", "aria-label": "${toggles.duplicates.label}", "role": "button", "onclick": toggle_rows(Action.same) },
                { "<>": "span", "html": " ${toggles.duplicates.label}" },
                { "<>": "a", "href": "#", "class": "ml-4 fas ${toggles.missing.style}", "data-filter": "${toggles.missing.value}", "aria-label": "${toggles.missing.label}", "role": "button", "onclick": toggle_rows(Action.miss) },
                { "<>": "span", "html": " ${toggles.missing.label}" },
                { "<>": "a", "href": "#", "class": "ml-4 fas ${toggles.new.style}", "data-filter": "${toggles.new.value}", "aria-label": "${toggles.new.label}", "role": "button", "onclick": toggle_rows(Action.new) },
                { "<>": "span", "html": " ${toggles.new.label}" },
                { "<>": "a", "href": "#", "class": "ml-4 fas ${toggles.conflicts.style}", "data-filter": "${toggles.conflicts.value}", "aria-label": "${toggles.conflicts.label}", "role": "button", "onclick": toggle_rows(Action.conf) },
                { "<>": "span", "html": " ${toggles.conflicts.label}" }
              ]
            },
            {
              "<>": "div", "class": "d-flex", "html": function (o, index) {
                return $.json2html(o, transform.pagination);
              }
            },
            {
              "<>": "div", "class": " diff-container", "html": [
                {
                  "<>": "table", "class": "table table-striped table-sm table-diff", "html": [
                    { "<>": "caption", "class": "bg-info text-white text-center", "html": function (o) { return o.caption } },
                    {
                      "<>": "thead", "html": function (table) {
                        return $.json2html(table, transform.thr);
                      }
                    },
                    {
                      "<>": "tbody", "html": function (table) {
                        return $.json2html(table.body, transform.tr);
                      }
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    },
    "tr": {
      "<>": "tr", "html": function (row, index) {
        conflict_columns(row[1]).forEach(element => {
          row[element] = '<del>' + row[element] + '</del>';
        });

        return $.json2html(row, transform.td);
      }, "class": class_row
    },
    "thr": {
      "<>": "tr", "html": function (table) {
        return $.json2html(table.columns, transform.th);
      }
    },
    "td": { "<>": "td", "html": "${value}" },
    "th": { "<>": "th", "html": "${value}" },
    "pagination": [
      {
        "<>": "div", "class": "mt-3  ", "html": [
          { "<>": "span", "class": " badge-light p-2 mx-1 font-weight-bold alert-info", "html": ' ${labels.stats_total}: ${stats.total}  ' },
          { "<>": "span", "class": " badge-light p-2 mx-1", "html": ' ${labels.stats_dupl}: ${stats.duplicated} ' },
          { "<>": "span", "class": " badge-light p-2 mx-1 alert-warning", "html": ' ${labels.stats_conf}: ${stats.conflicts}' },
          { "<>": "span", "class": " badge-light p-2 mx-1 alert-danger", "html": ' ${labels.stats_miss}: ${stats.missing}' },
          { "<>": "span", "class": " badge-light p-2 mx-1 alert-success", "html": ' ${labels.stats_new}: ${stats.new} ' }

        ]
      },
      { "<>": "div", "class": "", "html": "" },
      {
        "<>": "ul", "class": "ml-auto pagination  pt-1", "html": [
          {
            "<>": "li", "class": "page-item", "html": [
              { "<>": "a", "class": "page-link", "href": "#", "data-page": "${pagination.first}", "aria-label": "Skip to first page", "onclick": page, "html": [{ "<>": "i", "class": "fas fa-angle-double-left" }] }
            ]
          },
          {
            "<>": "li", "class": "page-item", "html": [
              { "<>": "a", "class": "page-link", "href": "#", "data-page": "${pagination.prev_page}", "aria-label": "Previous page", "onclick": page, "html": [{ "<>": "i", "class": "fas fa-angle-left" }] }
            ]
          },
          {
            "<>": "li", "class": "page-item active", "html": [
              { "<>": "a", "class": "page-link", "aria-label": "Current Page", "html": "${pagination.current}" }
            ]
          },
          {
            "<>": "li", "class": "page-item", "html": [
              { "<>": "a", "class": "page-link", "href": "#", "data-page": "${pagination.next_page}", "aria-label": "Next page", "onclick": page, "html": [{ "<>": "i", "class": "fas fa-angle-right" }] }
            ]
          },
          {
            "<>": "li", "class": "page-item", "html": [
              { "<>": "a", "class": "page-link", "href": "#", "data-page": "${pagination.last}", "aria-label": "Skip to last page", "onclick": page, "html": [{ "<>": "i", "class": "fas fa-angle-double-right" }] }
            ]
          }
        ]
      }
    ]

  };
  display(options);
}

function display_loader(container_id) {
  var transform = {
    "<>": "div", "id": "content", "class": "text-center d-flex min-height", "html": [
      {
        "<>": "div", "class": "h-100 mx-auto my-auto", "html": [
          {
            "<>": "div", "class": "spinner-border text-primary mx-1", "role": "status", "html": [
              { "<>": "span", "class": "sr-only", "html": "Loading..." }
            ]
          },
          {
            "<>": "div", "class": "spinner-border text-secondary mx-1", "role": "status", "html": [
              { "<>": "span", "class": "sr-only", "html": "Loading..." }
            ]
          },
          {
            "<>": "div", "class": "spinner-border text-success mx-1", "role": "status", "html": [
              { "<>": "span", "class": "sr-only", "html": "Loading..." }
            ]
          },
          {
            "<>": "div", "class": "spinner-border text-danger mx-1", "role": "status", "html": [
              { "<>": "span", "class": "sr-only", "html": "Loading..." }
            ]
          },
          {
            "<>": "div", "class": "spinner-border text-warning mx-1", "role": "status", "html": [
              { "<>": "span", "class": "sr-only", "html": "Loading..." }
            ]
          }
        ]
      }
    ]
  }
  $(container_id).json2html([0], transform);
}


function display_latest_runs(controller, container_id) {


  function status_class(o) {
    var icon_class = '';
    if (o.status) {
      if (o.status.toLowerCase() == 'running')
        icon_class = 'fas fa-spinner fa-spin text-info';
      else if (o.status.toLowerCase() == 'succeeded')
        icon_class = 'fas fa-check-circle text-success';
      else if (o.status.toLowerCase() == 'failed')
        icon_class = 'fas fa-exclamation-triangle text-danger'
      else if (o.status.toLowerCase() == 'terminating')
        icon_class = 'fas fa-ban text-warning'
      else if (o.status.toLowerCase() == 'conflict')
        icon_class = 'fas fa-folder text-primary'
      else if (o.status.toLowerCase() == 'error file')
        icon_class = 'fas fa-file-csv text-warning'
      else if (o.status.toLowerCase() == 'unknown file')
        icon_class = 'fas fa-question-circle'
    }
    else icon_class = 'fas fa-question-circle text-dark'

    return icon_class
  }


  var transform = {
    "card": {
      "<>": "div", "class": "card shadow mb-4", "html": [
        {
          "<>": "div", "class": "card-header py-3", "html": [
            {
              "<>": "div", "class": "text-primary", "html": [
                { "<>": "i", "class": "fas fa-tasks", "html": " " },
                { "<>": "span", "class": "font-weight-bold text-uppercase", "html": " ${label} " }
              ]
            }
          ]
        },
        { "<>": "div", "class": "card-body overflow-auto", "html": function (o) { return $.json2html(o, transform.table); } },
      ]
    },
    "header": {
      "<>": "tr", "html": [
        { "<>": "th", "scope": "col", "html": "${name}" },
        { "<>": "th", "scope": "col", "html": "${status}" },
        { "<>": "th", "scope": "col", "html": "${start}" },
        { "<>": "th", "scope": "col", "html": "${duration} (hh:mm:ss)" }
      ]
    },
    "row": {
      "<>": "tr", "html": [
        { "<>": "td", "html": "${name}" },
        {
          "<>": "td", "html": [
            { "<>": "i", "class": status_class, "html": "" },
            { "<>": "span", "class": "", "html": " ${status}" }
          ]
        },
        {
          "<>": "td", "html": function ({ start }) {
            //return new Date(Date.parse(start)).toString();
            return new Date(Date.parse(start)).toLocaleString();
          }
        },
        { "<>": "td", "html": "${duration}" }
      ]
    },
    "table": {
      "<>": "table", "class": "table table-bordered ", "html": [
        { "<>": "caption", "class": "bg-info text-white text-center", "html": function (o) { return o.caption } },
        { "<>": "thead", "class": "bg-info text-white", "html": function (o) { return $.json2html(o.header, transform.header); } },
        { "<>": "tbody", "html": function (o) { return $.json2html(o.data, transform.row) } }
      ]
    }
  }
  postJson(controller, {}, function (response) {
    $(container_id).html('')
    $(container_id).json2html(response, transform.card)
  });
}

// Defaults for datepicker
$.fn.datepicker.defaults.format = 'yyyy-mm-dd';
$.fn.datepicker.defaults.startView = 2;
$.fn.datepicker.defaults.minViewMode = 1;
$.fn.datepicker.defaults.autoclose = true;
$.fn.datepicker.defaults.orientation = 'bottom auto';


function display_triggers(controller, container_id, refresh) {
  const input_type = Object.freeze({
    "input": "input",
    "select": "select",
    "submit": "submit",
    "date": "date",
    "reference_year": "reference_year"
  });
  function submit(e) {
    e.event.preventDefault();
    var submitted_form = e.obj._parent;
    var form_elem = $('#' + submitted_form.id)
    var data = form_elem.serializeArray();

    if (form_elem[0].checkValidity()) {
      $('#' + e.obj.id).toggleClass('disabled')
      $("#" + e.obj.id + "_spinner").toggleClass('fa-play');
      $("#" + e.obj.id + "_spinner").toggleClass('fa-spinner fa-spin');

      postJson(submitted_form.action, data, function (result) {
        $("#" + submitted_form.id).html('')
        $("#" + submitted_form.id).json2html(result, transform.form, { replace: true })
        $("#" + submitted_form.id + " .datepicker").datepicker();
        $("#" + submitted_form.id + " select").change();
        $(document).on('keyup', function (e) {
          if (e.key == "Escape") $(container_id + " .datepicker").datepicker('hide');
        });
        refresh();
      })
    }
    else {
      form_elem[0].reportValidity();
    }
  }
  function select_change(e) {
    var curr = $(e.event.target).val();
    var select_target = e.obj.select_target;
    if (!jQuery.isEmptyObject(select_target)) {
      var opts = select_target.options[curr];
      var target = '#' + select_target.id;
      $(target).html('')
      $(target).json2html(opts, transform.options) //, {replace:true}) // TODO: Is this the correct fix? - Collin

    }
  }

  var transform = {
    "card": {
      "<>": "div", "class": "card shadow mb-4", "html": [
        {
          "<>": "div", "class": "card-header py-3", "html": [
            {
              "<>": "div", "class": "text-primary", "html": [
                { "<>": "i", "class": "fas fa-stream", "html": " " },
                { "<>": "span", "class": "font-weight-bold text-uppercase", "html": "<h5> ${title} </h5>" }
              ]
            }
          ]
        },
        {
          "<>": "div", "class": "card-body", "html": function ({ forms }) {
            return $.json2html(forms, transform.form)
          }
        }
      ]
    },
    "form": {
      "<>": "form", "class": "action", "id": "${id}", "autocomplete": "off", "action": "${action}", "method": "${method}", "html": [
        { "<>": "h6", "class": "text-dark text-uppercase", "html": "${header}" },
        {
          "<>": "div", "class": "form-row mb-5 mt-1", "html": function (form, index) {
            form.fields.forEach(element => {
              element._parent = form;
            });
            return $.json2html(form.fields, transform.case)
          }
        }
      ]
    },
    "case": {
      "<>": "div", "class": "col-auto ", "html": function (field, index) {
        if (field.type == input_type.submit)
          return $.json2html(field, transform.submit);
        else if (field.type == input_type.select)
          return $.json2html(field, transform.select);
        else if (field.type == input_type.input)
          return $.json2html(field, transform.input);
        else if (field.type == input_type.date)
          return $.json2html(field, transform.date);
        else if (field.type == input_type.reference_year)
          return $.json2html(field, transform.input);
      }
    },
    "submit": {
      "<>": "button", "type": "submit", "class": "btn btn-success px-4 ${className}", "name": "${name}", "value": "${value}", "id": "${id}", "onclick": submit, "html": [
        { "<>": "span", "class": "fa fa-play", "id": "${id}_spinner" },
        { "<>": "span", "class": "", "html": " ${label} " }
      ]
    },
    "input": {
      "<>": "div", "class": "input-group  mb-1  flex-nowrap", "html": [
        {
          "<>": "div", "class": "input-group-prepend ", "html": [
            { "<>": "label", "class": "input-group-text text-dark", "for": "${id}", "html": "${label}" }
          ]
        },
        { "<>": "input", "type": "text", "class": "form-control text-dark ${className}", "id": "${id}", "name": "${name}", "value": "${value}" },
        { "<>": "div", "class": "invalid-tooltip ml-dash", "html": "${invalid_feedback}" },
      ]
    },
    "date": {
      "<>": "div", "class": "input-group  mb-1  flex-nowrap", "html": [
        {
          "<>": "div", "class": "input-group-prepend ", "html": [
            { "<>": "label", "class": "input-group-text text-dark", "for": "${id}", "html": "${label}" }
          ]
        },
        {
          "<>": "input", "type": "text", "class": "form-control datepicker pl-3 text-dark ${className}", "id": "${id}", "name": "${name}", "html": "${value}",
          "data-date-format": "${format}", "placeholder": "${format}", "data-date-viewmode": "${view_mode}", "data-date-minviewmode": "${min_view_mode}"
        },
        { "<>": "div", "class": "invalid-tooltip ml-dash", "html": "${invalid_feedback}" },
      ]
    },
    "select": [{
      "<>": "div", "class": "input-group  mb-1 flex-nowrap  ", "html": [
        {
          "<>": "div", "class": "input-group-prepend", "html": [
            { "<>": "label", "class": "input-group-text text-dark", "for": "${id}", "html": "${label}" }
          ]
        },
        {
          "<>": "select", "class": "form-control text-dark ${className}", "id": "${id}", "name": "${name}", "html": function ({ options }) {
            return $.json2html(options, transform.options);
          }
        }
      ], "onchange": select_change
    },
    { "<>": "div", "class": "invalid-tooltip ml-dash", "html": "${invalid_feedback}" },
    ],
    "options": { "<>": "option", "value": "${value}", "html": "${label}" }
  };



  postJson(controller, {}, function (triggers) {
    $(container_id).html('');
    $(container_id).json2html(triggers, transform.card);
    $(container_id + " .datepicker").datepicker();
    $(container_id + " select").change();
    $(document).on('keyup', function (e) {
      if (e.key == "Escape") $(container_id + " .datepicker").datepicker('hide');
    });
    // refresh();
  });
}


