$(document).ready(function () {
    display_loader('#content');
    var reload = setTimeout(function () { location.reload(true); }, 90 * 1000);

    const StageParams = JSON.parse(document.getElementById('stage-params').getAttribute('data-url'));
    const getConflictsUrl = document.getElementById('get-conflicts-url').getAttribute('data-url');
    const conflictsUrl = document.getElementById('conflicts-url').getAttribute('data-url');


    postJson(getConflictsUrl, StageParams, function (data) {
        clearTimeout(reload);
        display_timelines('#content', data, conflictsUrl);
    });

});