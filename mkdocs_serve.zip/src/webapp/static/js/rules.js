$(document).ready(function () {
    $("#fixed_prop_variable").change(renderFixedProportion);
});

function renderFixedProportion() {

    function unhide_regular() {
        // unhide regular fields
        elements = document.getElementsByClassName("input-group mb1 flex-nowrap")
        for (let i = 0; i < elements.length; i++) {
            label = elements[i].getElementsByClassName("input-group-text text-dark")[0].innerText
            if (!(label.toLowerCase().trim().includes("proportions"))) {
                elements[i].classList.remove("d-none");
            }
        }

        // hide proportions
        props = document.querySelectorAll('[id$="_proportions-div"]')
        for (let i = 0; i < props.length; i++) {
            props[i].classList.add("d-none");
        }
        // unhide all of the candidate imputation variables
        props = document.querySelectorAll('[id$="_field-div"]')
        for (let i = 0; i < props.length; i++) {
            props[i].classList.remove("d-none");
        }

    }

    function unhide_proportion(val) {
        element = document.getElementById(val + '_proportions-div');
        element.classList.remove("d-none");
    }
    /*
    * Hide the proportion that the fixed rule is being created for.
    */
    function hide_selected_proportion(val) {
        element = document.getElementById(val + "_field-div");
        element.classList.add("d-none");
    }

    /* NOTE - Labels are used to create the unique ID, thus the underscores were replaces
              with spaces. That is the reason for some vals to be hardcoded below.
    */

    let val = document.getElementById("fixed_prop_variable").value.toLowerCase();
    //replaceProportion();
    if (val === "vehicle_type") {
        unhide_regular()
        unhide_proportion(val)
        hide_selected_proportion(val)
    } else if (val == "plate_country") {
        unhide_regular()
        unhide_proportion(val)
        hide_selected_proportion(val)
    } else if (val == "arriving_from") {
        unhide_regular()
        unhide_proportion(val)
        hide_selected_proportion(val)
    } else if (val == "country_of_residence") {
        unhide_regular()
        unhide_proportion(val)
        hide_selected_proportion(val)
    } else if (val == "purpose4") {
        unhide_regular()
        unhide_proportion(val)
        hide_selected_proportion(val)
    } else if (val == "duration2") {
        unhide_regular()
        unhide_proportion(val)
        hide_selected_proportion(val)
    }
}
