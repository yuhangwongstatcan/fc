$(document).ready(function () {
    $("select").change(myFunction);
});

function myFunction() {
    let val = document.getElementById("capture_type").value;
    if (val === "travellers") {
        document.getElementById("number_of_vehicles").classList.add("d-none")
        document.getElementById("arriving_from").classList.remove("d-none")
        document.getElementById("country_of_residence").classList.remove("d-none")
        document.getElementById("trip_purpose_detailed").classList.remove("d-none")
        document.getElementById("trip_purpose").classList.remove("d-none")
        document.getElementById("duration").classList.remove("d-none")
        document.getElementById("number_of_travellers").classList.remove("d-none")

    } else {
        document.getElementById("number_of_vehicles").classList.remove("d-none")
        document.getElementById("arriving_from").classList.add("d-none")
        document.getElementById("country_of_residence").classList.add("d-none")
        document.getElementById("trip_purpose_detailed").classList.add("d-none")
        document.getElementById("trip_purpose").classList.add("d-none")
        document.getElementById("duration").classList.add("d-none")
        document.getElementById("number_of_travellers").classList.add("d-none")
    }
}
