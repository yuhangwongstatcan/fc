$(document).ready(function () {
    display_loader("#runs");
    display_loader("#pipeline")
    //var reload = setTimeout(function () { location.reload(true); }, 90 * 1000);

    // runsUrl and triggersUrl are generated in the associated index.html file
    const runsUrl = document.getElementById('runs-url').getAttribute('data-url');
    const triggersUrl = document.getElementById('triggers-url').getAttribute('data-url');

    function refresh() {
        display_latest_runs(runsUrl, "#runs");
    }
    refresh()
    var interval = setInterval(refresh, 180000);
    display_triggers(triggersUrl, '#pipeline', refresh);
});