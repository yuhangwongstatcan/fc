$(document).ready(function () {
    display_loader('#content');
    // var reload = setTimeout(function(){location.reload(true);}, 90*1000);

    // Parameters
    const DiffParams = JSON.parse(document.getElementById('diff-params').getAttribute('data-url'));
    // URLs
    const rollbackUrl = document.getElementById('rollback-url').getAttribute('data-url');
    const diffUrl = document.getElementById('diff-url').getAttribute('data-url');
    const fileHistoryUrl = document.getElementById('file-history-url').getAttribute('data-url');
    const downloadUrl = document.getElementById('download-url').getAttribute('data-url');
    // Translations
    const rollbackToVersionTranslation = document.getElementById('rollback-to-version-translation').getAttribute('data-url');
    const currentTranslation = document.getElementById('current-translation').getAttribute('data-url');
    const versionTranslation = document.getElementById('version-translation').getAttribute('data-url');

    var DiffControlParams = {
        "basename": '',
        "stage": '',
        "datasource": '',
        "original": '',
        "path": '',
        "org_bucket": '',
        "path_bucket": ''
    }
    function set_opt(obj) {
        DiffControlParams.basename = obj.basename
        DiffControlParams.stage = obj.stage
        DiffControlParams.datasource = obj.datasource
        DiffControlParams.original = obj.original
        DiffControlParams.path = obj.path
        DiffControlParams.org_bucket = obj.org_bucket
        DiffControlParams.path_bucket = obj.path_bucket
    }

    function format_location(str) {
        return str.replace("%24", "$").replace("%7B", "{").replace("%7D", "}")
    }

    function generate_download_url(baseUrl, bucket, path) {
        var bucketFormatted = format_location(bucket)
        var pathFormatted = format_location(path)

        return baseUrl.replace("__BUCKET__", bucketFormatted).replace("__PATH__", pathFormatted)
    }

    const downloadOrigUrl = generate_download_url(downloadUrl, DiffControlParams.org_bucket, DiffControlParams.original)
    const downloadPathUrl = generate_download_url(downloadUrl, DiffControlParams.path_bucket, DiffControlParams.path)

    function rollback(e) {
        set_opt(e.obj);
        postJson(rollbackUrl, DiffControlParams, function (response) {
            // window.location.href = "{{ url_for('index') }}";
            location.reload(true);
        });
    }
    var controls = [
        {
            "<>": "div", "class": "btn-group ", "role": "group", "html": [
                { "<>": "button", "type": "button", "class": "btn btn-outline-primary  ", "html": rollbackToVersionTranslation, "onclick": rollback }
            ]
        },
        {
            "<>": "div", "class": "btn-group ml-3", "role": "group", "html": [
                {
                    "<>": "a", "class": "btn btn btn-outline-primary   ", "role": "button", "html": [
                        { "<>": "i", "class": "fas fa-download fa-sm " },
                        { "<>": "span", "html": currentTranslation }
                    ], "href": downloadOrigUrl
                },
                {
                    "<>": "a", "class": "btn btn-outline-primary  ", "role": "button", "html": [
                        { "<>": "i", "class": "fas fa-download fa-sm " },
                        { "<>": "span", "html": versionTranslation }
                    ], "href": downloadPathUrl
                }
            ]
        }
    ];



    display_diff(diffUrl, DiffParams, '#content', controls);

    postJson(fileHistoryUrl, DiffParams, function (data) {
        $('#history').html(timeline(data).html)
    })
});