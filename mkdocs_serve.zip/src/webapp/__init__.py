#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
from os import environ
from config.env import environ
from flask import Flask
from flask import url_for
from flask_session import Session
# from flask_talisman import Talisman

# WebApp
app = Flask(__name__)

# # Define your restrictive policy (no unsafe-* keywords)
# csp = {
#     'default-src': "'self'",
#     'script-src': "'self'",
#     'style-src': "'self'",
#     'img-src': ["'self'", "data:"]  # Replaces wildcard '*' with 'self'
# }

# # Apply globally to every response
# Talisman(app, content_security_policy=csp)

from webapp import config

# WebApp Session
Session(app)


# Override url_for inside templates to account for kubernetes prefix
def prefix(suffix=""):
    return environ().FLASK_BASE_URL + suffix


def prefix_url_for(*args, **kargs):
    return prefix(url_for(*args, **kargs))


@app.context_processor
def override_url_for():
    return dict(url_for=prefix_url_for)


# Add CSP security headers to every page response
# See https://content-security-policy.com/ for an explanation of why this
# header is necessary.
@app.after_request
def set_response_headers(resp):
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src * data:"
    )
    resp.headers["Cache-Control"] = "no-cache, no-store,  must-revalidate"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = 0
    return resp


# WebApp View routes
from webapp import views

# WebApp Controller routes

from webapp.controllers import ctrl_diff
from webapp.controllers import ctrl_conflicts
from webapp.controllers import ctrl_historical
from webapp.controllers import ctrl_dashboard
