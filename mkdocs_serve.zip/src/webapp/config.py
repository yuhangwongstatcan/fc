#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
from webapp import app
from config.env import environ


app.config["APP_NAME"] = "Frontier Counts"
app.config["LOGOUT_URL"] = environ().LOGOUT_URL
app.config["APP_VERSION"] = environ().APP_VERSION
app.config["DEPLOYMENT"] = environ().DEPLOYMENT
app.config["SECRET_KEY"] = environ().FC_FLASK_SECRET_KEY
app.config["SESSION_TYPE"] = "filesystem"
app.config["COPYRIGHT"] = "Copyright © 2021. All rights reserved"


app.config["MINIO"] = environ().S3PROXY_INGRESS
app.config["ARGO"] = environ().ARGO_INGRESS
# TODO: might eventually put file system location for Power BI files here
app.config["POWERBI"] = "powerbi.microsoft.com/en-au/"
