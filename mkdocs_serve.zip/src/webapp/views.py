#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
import tempfile
from typing import Dict
from datetime import datetime
from os.path import join
from flask import render_template, redirect, session, request
from modules.utils.loaders import Loader
from webapp import app
from webapp import prefix_url_for as url_for
from webapp.models.rules import FixedRules, fixed_rules_table
from webapp.models.session import init_session, clear_session
from flask import send_from_directory, Response
from webapp.models.io import StageParams
from webapp.models.io import DiffParams
from config.api import DataSource, Mode
from webapp.models.translation import tr
from modules.s3client import S3Client
from os.path import basename
from os.path import dirname
from config.api import S3
from config.api import S3Location
from config.api import Stage
from config.env import environ
from webapp.models.session import toggle_session_lang
from webapp.models.capture import DataCapture, data_capture_to_minio
from webapp.models.validation import validate_proportions
from webapp.models.validation import validate_non_proportion_variables

from config.api import AutoEnum

from datasource.common.dim import VEHICLE_TYPE, PLATE_COUNTRY
from datasource.common.labels import (
    MONTH as LABEL_MONTH,
    DAY as LABEL_DAY,
    MODE as LABEL_MODE,
    VEHICLE_TYPE as LABEL_VEHICLE_TYPE,
    PLATE_COUNTRY as LABEL_PLATE_COUNTRY,
    PLATE_REGION as LABEL_PLATE_REGION,
    ARRIVING_FROM as LABEL_ARRIVING_FROM,
    PURPOSE9 as LABEL_PURPOSE9,
    PURPOSE4 as LABEL_PURPOSE4,
    DURATION2 as LABEL_DURATION2,
    DURATION3 as LABEL_DURATION3,
    DURATION5 as LABEL_DURATION5,
    TRAVELLER_TYPE as LABEL_TRAVELLER_TYPE,
    DATA_SOURCE as LABEL_DATA_SOURCE,
)
from datasource.travellers.dim import ARRIVING_FROM, PURPOSE4, DURATION2


def navigation():
    return [
        {"type": "divider", "class": "sidebar-divider"},
        {
            "type": "item",
            "url": url_for("index"),
            "id": "index",
            "class": "fas fa-fw fa-tachometer-alt",
            "label": tr("Dashboard"),
            "aria-label": tr("Dashboard"),
        },
        {"type": "divider", "class": "sidebar-divider"},
        {
            "type": "group",
            "url": "",
            "id": "conflicts",
            "class": "fas fa-fw fa-folder",
            "label": tr("Conflicts"),
            "links": [
                {
                    "type": "item",
                    "url": url_for("conflicts", stage=Stage.REFERENCE.name),
                    "id": "conflicts_REFERENCE",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.REFERENCE.name),
                },
                {
                    "type": "item",
                    "url": url_for("conflicts", stage=Stage.RAW.name),
                    "id": "conflicts_RAW",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.RAW.name),
                    "aria_label": f"Conflicts: {tr(Stage.RAW.name)}",
                },
                {
                    "type": "item",
                    "url": url_for("conflicts", stage=Stage.CLEAN.name),
                    "id": "conflicts_CLEAN",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.CLEAN.name),
                    "aria_label": f"Conflicts: {tr(Stage.CLEAN.name)}",
                },
                {
                    "type": "item",
                    "url": url_for("conflicts", stage=Stage.TRANSFORMED.name),
                    "id": "conflicts_TRANSFORMED",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.TRANSFORMED.name),
                    "aria_label": f"Conflicts: {tr(Stage.TRANSFORMED.name)}",
                },
                {
                    "type": "item",
                    "url": url_for("conflicts", stage=Stage.AGGREGATED.name),
                    "id": "conflicts_AGGREGATED",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.AGGREGATED.name),
                    "aria_label": f"Conflicts: {tr(Stage.AGGREGATED.name)}",
                },
            ],
        },
        {"type": "divider", "class": "sidebar-divider"},
        {
            "type": "group",
            "url": "",
            "id": "historical",
            "class": "fas fa-fw fa-calendar-alt",
            "label": tr("Historical"),
            "links": [
                {
                    "type": "item",
                    "url": url_for("historical", stage=Stage.REFERENCE.name),
                    "id": "historical_REFERENCE",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.REFERENCE.name),
                    "aria_label": f"Historical: {tr(Stage.REFERENCE.name)}",
                },
                {
                    "type": "item",
                    "url": url_for("historical", stage=Stage.RAW.name),
                    "id": "historical_RAW",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.RAW.name),
                    "aria_label": f"Historical: {tr(Stage.RAW.name)}",
                },
                {
                    "type": "item",
                    "url": url_for("historical", stage=Stage.CLEAN.name),
                    "id": "historical_CLEAN",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.CLEAN.name),
                    "aria_label": f"Historical: {tr(Stage.CLEAN.name)}",
                },
                {
                    "type": "item",
                    "url": url_for("historical", stage=Stage.TRANSFORMED.name),
                    "id": "historical_TRANSFORMED",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.TRANSFORMED.name),
                    "aria_label": f"Historical: {tr(Stage.TRANSFORMED.name)}",
                },
                {
                    "type": "item",
                    "url": url_for("historical", stage=Stage.AGGREGATED.name),
                    "id": "historical_AGGREATED",
                    "class": "fas fa-fw ",
                    "label": tr(Stage.AGGREGATED.name),
                    "aria_label": f"Historical: {tr(Stage.AGGREGATED.name)}",
                },
            ],
        },
        {"type": "divider", "class": "sidebar-divider"},
        {
            "type": "group",
            "url": "",
            "id": "manual",
            "class": "fas fa-fw fa-edit",
            "label": tr("Manual Entry"),
            "links": [
                {
                    "type": "item",
                    "url": url_for("capture"),
                    "id": "capture",
                    "class": "fas fa-fw text-uppercase",
                    "label": tr("Data Capture"),
                },
                {
                    "type": "item",
                    "url": url_for("rules"),
                    "id": "rules",
                    "class": "fas fa-fw text-uppercase",
                    "label": tr("Fixed Rules"),
                },
            ],
        },
        {"type": "divider", "class": "sidebar-divider"},
    ]


@app.route("/")
@app.route("/index", methods=["GET"])
def index():
    init_session()
    return render_template(
        "index.html",
        config=app.config,
        session=session,
        navigation_menu=navigation(),
        tr=tr,
    )


@app.route("/conflicts/<stage>", methods=["GET"])
@app.route("/conflicts/<stage>/<year>", methods=["GET"])
def conflicts(stage: str, year: str = str(datetime.now().year)):
    init_session()
    year = str(datetime.now().year) if not year.isnumeric() else year
    return render_template(
        "conflicts.html",
        config=app.config,
        session=session,
        params=StageParams(stage, year),
        navigation_menu=navigation(),
        tr=tr,
    )


@app.route("/conflict/<stage>/<datasource>/<basename>", methods=["GET"])
def conflict(stage, datasource, basename):
    init_session()
    params = DiffParams(
        mode=Mode.conflicts.value,
        version="",
        stage=stage,
        datasource=datasource,
        basename=basename,
        page=1,
        filters=[],
    )

    return render_template(
        "conflict.html",
        config=app.config,
        session=session,
        params=params,
        navigation_menu=navigation(),
        tr=tr,
    )


@app.route("/historical/<stage>", methods=["GET"])
@app.route("/historical/<stage>/<year>", methods=["GET"])
def historical(stage: str, year: str = str(datetime.now().year)):
    init_session()
    year = str(datetime.now().year) if not year.isnumeric() else year
    return render_template(
        "historical.html",
        config=app.config,
        session=session,
        params=StageParams(stage, year),
        navigation_menu=navigation(),
        tr=tr,
    )


@app.route("/history/<stage>/<datasource>/<basename>", methods=["GET"])
@app.route("/history/<stage>/<datasource>/<basename>/<version>", methods=["GET"])
def history(stage, datasource, basename, version=""):
    init_session()
    params = DiffParams(
        mode=Mode.historical.value,
        stage=stage,
        version=version,
        datasource=datasource,
        basename=basename,
        page=1,
        filters=[],
    )
    return render_template(
        "history.html",
        config=app.config,
        session=session,
        params=params,
        navigation_menu=navigation(),
        tr=tr,
    )


@app.route("/capture", methods=["GET", "POST"])
def capture():
    init_session()
    form = DataCapture(meta={"csrf": False})
    if form.validate_on_submit():
        data_capture_to_minio(form)
        return redirect(url_for("capture"))
    return render_template(
        "capture.html",
        config=app.config,
        session=session,
        navigation_menu=navigation(),
        tr=tr,
        form=form,
    )


def _populate_countries() -> dict:
    tmp = [
        {"proportion_label": r, "select": 0}
        for r in Loader.get(Stage.REFERENCE, DataSource.countries, None).country_name_en
    ]
    return {"country_of_residence_proportions": tmp}


def _populate_proportions(proportion: str, dimension: Dict) -> dict:
    tmp = [{"proportion_label": r, "select": 0} for r in dimension.values()]
    return {proportion: tmp}


def _populate_data() -> dict:
    data = {}
    data.update(_populate_proportions("vehicle_type_proportions", LABEL_VEHICLE_TYPE))
    data.update(_populate_proportions("plate_country_proportions", LABEL_PLATE_COUNTRY))
    data.update(_populate_proportions("arriving_from_proportions", LABEL_ARRIVING_FROM))
    data.update(_populate_countries())
    data.update(_populate_proportions("purpose4_proportions", LABEL_PURPOSE4))
    data.update(_populate_proportions("duration2_proportions", LABEL_DURATION2))

    return data


@app.route("/rules", methods=["GET", "POST"])
def rules():
    init_session()
    if request.method == "GET":
        data = _populate_data()
        form = FixedRules(data=data, meta={"csrf": False})
    else:
        form = FixedRules(request.form, meta={"csrf": False})
        if (
            form.validate_on_submit()
            and validate_proportions(form)
            and validate_non_proportion_variables(form)
        ):
            # fixed_rules_table() uploads and overwrites the rules table in MinIO, but
            # only if the new entry does not conflict with existing rules. If there is
            # a conflict, fixed_rules_table() returns False and subscribes an appropriate
            # error message to the form, which gets rendered in the render_template() portion
            # of this function.
            if fixed_rules_table(form):
                return redirect(url_for("rules"))

    return render_template(
        "rules.html",
        config=app.config,
        session=session,
        navigation_menu=navigation(),
        tr=tr,
        form=form,
    )


@app.route("/toggle_lang", methods=["GET"])
def toggle_lang():
    init_session()
    toggle_session_lang()
    if request.referrer:
        return redirect(request.referrer)
    else:
        return redirect(environ().FLASK_BASE_URL)


@app.route("/download/<bucket>/<path:path>", methods=["GET"])
def download(bucket, path):
    init_session()
    client = S3Client.get_client()
    dirpath = tempfile.mkdtemp()
    localname = join(dirpath, basename(path))
    location = S3Location(bucket, dirname(path), basename(path))
    client.fget_object(location.bucket, S3.loc_to_obj(location), localname)
    return send_from_directory(directory=dirpath, filename=basename(path))


@app.route("/favicon.ico", methods=["GET"])
def favicon():
    return send_from_directory(
        join(
            app.root_path,
            "static",
            "imgs",
        ),
        "favicon.ico",
        mimetype="image/vnd.microsoft.icon",
    )


@app.route("/healthz", methods=["GET"])
def healthz():
    """
    Healthcheck endpoint for kubernetes.
    """
    return Response("{'status': 'OK'}", status=200, mimetype="application/json")


@app.route("/readyz", methods=["GET"])
def readyz():
    """
    Healthcheck endpoint for kubernetes.
    """
    return Response("{'status': 'OK'}", status=200, mimetype="application/json")


@app.route("/livez", methods=["GET"])
def livez():
    """
    Healthcheck endpoint for kubernetes.
    """
    return Response("{'status': 'OK'}", status=200, mimetype="application/json")
