"""
    Program: schema.py

    Author: Nicole Vingerhoeds, nicole.vingerhoeds@statcan.gc.ca
            Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW and
        CLEAN data for the e62 data source.
"""
import pandera as pa
from pandera.typing import Series

from typing import Optional

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.e63.dim import DURATION2, FROM, MODE, TRANS_TYPE, TRAV_CHAR

from datasource.common.types import (
    SafeIntToStringType,
    Padded2ZeroStringType,
    CapitalXOrNullType,
)


# Define pandera fields for reusability
DURATION2_FIELD = pa.Field(
    description="Trip duration of travellers, either same day or overnight",
    isin=DURATION2.list(),
    coerce=True,
    raise_warning=True,
)
DATE_FIELD = pa.Field(
    description="Date of arrival in Canada",
    # Date should be in the format YYYY-MM-DD
    str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
    coerce=True,
)
PORT_FIELD = pa.Field(
    description="Port of entry into Canada (common to all entries in the same E63 form)",
    coerce=True,
    nullable=True,
)
MODE_FIELD = pa.Field(
    description="Mode of transportation, air or marine (common to all entries in the same E63 form)",
    isin=MODE.list(),
    coerce=True,
    raise_warning=True,
    nullable=True,
)
TRANS_TYPE_FIELD = pa.Field(
    description="Type of transportation, either commercial, private or military",
    isin=TRANS_TYPE.list(),
    coerce=True,
    raise_warning=True,
)
CARGO_FIELD = pa.Field(
    description="Indicator of whether the movement is primarily a cargo (aircraft or ship) or courier movement (either X or [blank])",
    str_matches="X",
    coerce=True,
    nullable=True,
)


# Define schemas
class RawSchema(FCSchemaModel):
    """
    Schema for e63 RAW data
    """

    port: Series[Padded2ZeroStringType] = PORT_FIELD

    mode: Series[pa.String] = MODE_FIELD

    date: Series[pa.String] = DATE_FIELD

    time: Series[pa.String] = pa.Field(
        description="Time of clearance by Canada Border Services Agency (can be blank)",
        coerce=True,
        nullable=True,
    )

    report_number: Series[pa.String] = pa.Field(
        description="Identification number for the movement such as a flight number or a vessel name (can be blank)",
        coerce=True,
        nullable=True,
    )

    from_: Series[pa.String] = pa.Field(
        description="Where the movement is arriving from, either Canada, U.S., another country direct or another country via the U.S.",
        isin=FROM.list(),
        coerce=True,
        alias="from",
        raise_warning=True,
    )

    trans_type: Series[pa.String] = TRANS_TYPE_FIELD

    cargo: Series[CapitalXOrNullType] = CARGO_FIELD

    trc: Series[CapitalXOrNullType] = pa.Field(
        description="Indicator of whether the movement was also processed through the TRC or CANPASS systems (either X or [blank])",
        str_matches="X",
        coerce=True,
        nullable=True,
    )

    coasting: Series[CapitalXOrNullType] = pa.Field(
        description="Indicator of whether the movement is considered coasting, high seas or fishing grounds (either X or [blank])",
        str_matches="X",
        coerce=True,
        nullable=True,
    )

    ambulance: Series[CapitalXOrNullType] = pa.Field(
        description="Indicator of whether the movement is considered an air ambulance, a Medevac flight or an Air Med flight (either X or [blank])",
        str_matches="X",
        coerce=True,
        nullable=True,
    )

    tech_stop: Series[CapitalXOrNullType] = pa.Field(
        description="Indicator of whether the movement is considered a technical stopover, a fuel stop or a stop for repairs (either X or [blank])",
        str_matches="X",
        coerce=True,
        nullable=True,
    )

    notes: Series[pa.String] = pa.Field(
        description="Additional notes or comments about the movement provided by CBSA",
        nullable=True,
        coerce=True,
    )

    country_of_residence: Series[SafeIntToStringType] = pa.Field(
        description="Country code for the country of residence of the passengers or crew",
        coerce=True,
    )

    trav_char: Series[pa.String] = pa.Field(
        description="Traveller characteristics",
        isin=TRAV_CHAR.list(),
        coerce=True,
        raise_warning=True,
    )

    count: Series[pa.Int] = pa.Field(
        description="Count of arrivals",
        ge=0,
        coerce=True,
    )

    duration2: Optional[Series[SafeIntToStringType]] = DURATION2_FIELD

    @staticmethod
    def get_keys():
        return [
            RawSchema.port,
            RawSchema.mode,
            RawSchema.date,
            RawSchema.time,
            RawSchema.report_number,
            RawSchema.from_,
            RawSchema.trans_type,
            RawSchema.cargo,
            RawSchema.trc,
            RawSchema.coasting,
            RawSchema.ambulance,
            RawSchema.tech_stop,
            RawSchema.notes,
            RawSchema.country_of_residence,
            RawSchema.trav_char,
        ]


class CleanSchema(RawSchema):
    """
    Schema for e63 CLEAN data
    """

    duration2: Series[pa.String] = DURATION2_FIELD


class ValidationSchema(pa.DataFrameModel):
    """
    Schema for variables appearing in validation output but not in RAW or CLEAN
    e63 data
    """

    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of an E63 dimension variable with unexpected values.",
        coerce=True,
    )

    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value observed in an E63 dimension variable.",
        coerce=True,
        nullable=True,
    )

    date: Optional[Series[pa.String]] = DATE_FIELD

    location: Optional[Series[pa.String]] = pa.Field(
        description="Geographical location where an unexpected dimension variable occurred.",
        coerce=True,
    )

    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences of a particular validation case.",
        ge=0,
        coerce=True,
    )

    action: Optional[Series[pa.String]] = pa.Field(
        description="Action column",
        coerce=True,
    )

    removal_reason: Optional[Series[pa.String]] = pa.Field(
        description="Reason for removal from processed df to be fed into validation df",
        isin=[
            "TRC/CANPASS",
            "Coasting/High Seas",
            "Domestic Flights",
            "Technical/Repair/Fuel Stops",
        ],
        coerce=True,
    )

    port: Optional[Series[Padded2ZeroStringType]] = PORT_FIELD

    mode: Optional[Series[pa.String]] = MODE_FIELD

    trans_type: Optional[Series[pa.String]] = TRANS_TYPE_FIELD

    cargo: Optional[Series[CapitalXOrNullType]] = CARGO_FIELD


# Define columns for subsetting dataframes when temporary columns are used
RAWSCHEMA_COLUMNS = [
    col
    for col in RawSchema.to_schema().columns.keys()
    if RawSchema.to_schema().columns[col].required
]
E_63_040_GROUPBY_COLUMNS = [col for col in RAWSCHEMA_COLUMNS if col != "count"]
CLEANSCHEMA_COLUMNS = list(CleanSchema.to_schema().columns.keys())

E63_V000_COLUMNS = [
    ValidationSchema.variable,
    ValidationSchema.unexpected_value,
    ValidationSchema.date,
    ValidationSchema.location,
    ValidationSchema.count,
]
E63_V010_COLUMNS = [
    ValidationSchema.date,
    ValidationSchema.port,
    ValidationSchema.mode,
    ValidationSchema.trans_type,
    ValidationSchema.cargo,
    ValidationSchema.action,
    ValidationSchema.count,
]
E63_V020_COLUMNS = [
    ValidationSchema.removal_reason,
    ValidationSchema.date,
    ValidationSchema.port,
    ValidationSchema.count,
]
