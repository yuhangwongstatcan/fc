import pandas as pd

from datasource.ipil_hwy.schema import RawSchema
from datasource.ipil_hwy.dim import PROVINCE, COUNTRY


def ipil_hwy_070(df: pd.DataFrame) -> pd.DataFrame:
    """
    Codes the province/state of licence plate variable as Mexico in the case
    where the licence plate country is "MX" and the province/state is missing
    or set as "XX".

    Also code the country of licence plate variable as Puerto Rico in the case
    where the licence plate region is "PR".

    Args:
        df:
            A pandas dataframe where the country license plate is "MX" but the
            province/state is not equal to "MX" (e.g. missing or "XX"), and/or
            the province/state = "PR" but country does not
    Returns:
        df:

            A pandas dataframe where province/state is set to "MX" if country
            license plate is "MX", and where the country is set to "PR" if the
            province/state is "PR"
    """

    mask_mx = (df[RawSchema.country] == COUNTRY.mexico.value) & (
        df[RawSchema.province] != PROVINCE.MX.value
    )
    df.loc[mask_mx, RawSchema.province] = PROVINCE.MX.value

    mask_pr = df[RawSchema.province] == PROVINCE.PR.value
    df.loc[mask_pr, RawSchema.country] = COUNTRY.puerto_rico.value

    return df
