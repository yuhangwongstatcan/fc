import pandas as pd

from modules.utils.data_manipulation import explode

from datasource.ipil_hwy.utils import unix_timestamp_from_sin_and_date, split_buses

from config.api import Stage, DataSource, Mapping
from modules.utils.loaders import Loader

from datasource.ipil_hwy.schema import CleanSchema
from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
    TRAVELLERS_COLUMNS,
)

from datasource.ipil_hwy.dim import COUNTRY, VEHI, WATER_FLAG
from datasource.travellers.dim import (
    ARRIVING_FROM,
    COUNTRY_OF_RESIDENCE,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    DATA_SOURCE,
)
from datasource.common.dim import MODE, VEHICLE_TYPE, PLATE_COUNTRY, PLATE_REGION

from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema
from datasource.mapping.schema import ReferenceSchema as MappingSchema


def ipil_hwy_170(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Collin Brown - `collin.brown@canada.ca`

    **Created On:** December, 2020

    **Description:**

    Performs the business logic that transforms cleaned IPIL_HWY data into IPIL_HWY's contribution
    to the travellers table.

    Args:
        df: pd.DataFrame
            The IPIL_HWY clean table for the current month.

    Returns:
        travellers: pd.DataFrame
            A pandas dataframe containing IPIL_HWY's contribution to the travellers table.
    """
    work_locations = Loader.get(Stage.REFERENCE, DataSource.work_locations, None)
    work_locations = WorkLocationsSchema(work_locations)

    # MAPPINGS
    ipil_vehicle_mapping = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__ipil_hwy__clean__vehi__travellers__transformed__vehicle_type,
    )
    ipil_vehicle_mapping = MappingSchema(ipil_vehicle_mapping)

    ipil_plate_country_mapping = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__ipil_hwy__clean__country__travellers__transformed__plate_country,
    )
    ipil_plate_country_mapping = MappingSchema(ipil_plate_country_mapping)

    # Note: Since this is a large "business rule", it might make sense to break
    # it into smaller components and test the collective functionality in an
    # integration test or similar.

    # 1. Add a data source column and set it to IPIL-HWY
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.IPIL_Highway.value

    # 2. Parse %Y/%m/%d string of schema.date.name column into three columns: 'year',
    # 'month', 'day'
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        CleanSchema.date
    ].str.split("/", expand=True)
    df.loc[:, TransformedSchema.month] = df.loc[:, TransformedSchema.month].replace(
        {r"0(\d)": r"\1"}, regex=True
    )
    df.loc[:, TransformedSchema.day] = (
        df.loc[:, TransformedSchema.day]
        .replace({r"0(\d)": r"\1"}, regex=True)
        .astype("float")
        .astype("Int64")
    )
    # 3. Create location variables: port and work_location
    df = pd.merge(
        df,
        work_locations[
            [
                WorkLocationsSchema.work_location,
            ]
        ],
        left_on=CleanSchema.cport,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )

    # 4. Create mode of transportation field.
    # Use the 'water_flag' variable to assign "LAND" or "WATER"
    df.loc[
        df[CleanSchema.water_flag].isnull(), TransformedSchema.mode
    ] = MODE.land.value
    df.loc[
        ~df[CleanSchema.water_flag].isnull(), TransformedSchema.mode
    ] = MODE.water.value

    # 5. Create vehicle type field
    ipil_vehicle_mapping = ipil_vehicle_mapping.rename(
        columns={
            MappingSchema.key: CleanSchema.vehi,
            MappingSchema.value: TransformedSchema.vehicle_type,
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)
    df = pd.merge(df, ipil_vehicle_mapping, on=[CleanSchema.vehi], how="left")

    # Case: mode is WATER
    df.loc[
        (df[CleanSchema.water_flag] == WATER_FLAG.ferry.value)
        & (
            df[CleanSchema.vehi].isin(
                [
                    VEHI.car.value,
                    VEHI.bus.value,
                    VEHI.truck.value,
                    VEHI.other_land_vehicle.value,
                    VEHI.motorcycle.value,
                ]
            )
        ),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.ferry_private_vehicle.value

    df.loc[
        (df[CleanSchema.water_flag] == WATER_FLAG.ferry.value)
        & (df[CleanSchema.vehi] == VEHI.pedestrian.value),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.ferry_pedestrian.value

    # If record was identified as a private boat (water flag == private watercraft), then vehicle
    # type is 321
    df.loc[
        (df[CleanSchema.water_flag] == WATER_FLAG.private_boat.value),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.private_boat.value

    # 6. Create plate country and region
    ipil_plate_country_mapping = ipil_plate_country_mapping.rename(
        columns={
            MappingSchema.key: CleanSchema.country,
            MappingSchema.value: TransformedSchema.plate_country,
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)
    df = pd.merge(df, ipil_plate_country_mapping, on=[CleanSchema.country], how="left")

    # Additionally, if vehi == "P" or water_flag == "private_watercraft"
    # then plate_country = 9 (N/A) and plate_region = "NA"
    df.loc[
        (df[CleanSchema.vehi] == VEHI.pedestrian.value)
        | (df[CleanSchema.water_flag] == WATER_FLAG.private_boat.value),
        [TransformedSchema.plate_country, CleanSchema.province],
    ] = df.loc[
        (df[CleanSchema.vehi] == VEHI.pedestrian.value)
        | (df[CleanSchema.water_flag] == WATER_FLAG.private_boat.value),
        [TransformedSchema.plate_country, CleanSchema.province],
    ] = [
        PLATE_COUNTRY.not_available.value,
        PLATE_REGION.NA.value,
    ]

    df = df.rename(columns={CleanSchema.province: TransformedSchema.plate_region})

    # Need to split into multiple rows based on which of CS*D, US*D,
    # or O*D are present.
    traveller_cols = [
        CleanSchema.cdsd,
        CleanSchema.cd1d,
        CleanSchema.cd2d,
        CleanSchema.ussd,
        CleanSchema.us1d,
        CleanSchema.us2d,
        CleanSchema.osd,
        CleanSchema.o1d,
        CleanSchema.o2d,
    ]
    # Get unpivot id columns
    id_cols = [
        CleanSchema.vehi,
        CleanSchema.country,
        CleanSchema.date,
        CleanSchema.sin,
        CleanSchema.sout,
        CleanSchema.lane,
        CleanSchema.cport,
        CleanSchema.canpass1,
        CleanSchema.canpass2,
        CleanSchema.water_flag,
        TransformedSchema.data_source,
        TransformedSchema.year,
        TransformedSchema.month,
        TransformedSchema.day,
        TransformedSchema.port,
        TransformedSchema.work_location,
        TransformedSchema.mode,
        TransformedSchema.vehicle_type,
        TransformedSchema.plate_country,
        TransformedSchema.plate_region,
        TransformedSchema.country_of_residence,
    ]
    # Use pandas melt() method to unpivot on the traveller columns
    df = pd.melt(
        df,
        id_vars=id_cols,
        value_vars=traveller_cols,
        var_name="traveller_col",
        value_name="passengers_total",
    ).sort_values(id_cols)
    # Keep only passengers > 0
    df = df[df["passengers_total"] > 0]
    ###
    # 7. Logic to create arriving_from column
    ###
    # Note that arriving_from should be coded *after* we unpivot the ipil_hwy table.
    # this is because there could be a vehicle with multiple types of travellers, and
    # we may need to code `arriving_from` differently depending on the case we are in.
    ARRIVING_FROM_CONDITION_1 = (
        (
            df["traveller_col"].isin(
                [
                    CleanSchema.cdsd,
                    CleanSchema.cd1d,
                    CleanSchema.cd2d,
                    CleanSchema.ussd,
                    CleanSchema.us1d,
                    CleanSchema.us2d,
                ]
            )
        )
        & (df[CleanSchema.country] != COUNTRY.mexico.value)
        & (df[CleanSchema.country] != COUNTRY.puerto_rico.value)
    )
    df.loc[
        ARRIVING_FROM_CONDITION_1, TransformedSchema.arriving_from
    ] = ARRIVING_FROM.us_only.value
    ARRIVING_FROM_CONDITION_2 = (
        df["traveller_col"].isin(
            [
                CleanSchema.cdsd,
                CleanSchema.cd1d,
                CleanSchema.cd2d,
                CleanSchema.ussd,
                CleanSchema.us1d,
                CleanSchema.us2d,
            ]
        )
    ) & (
        (df[CleanSchema.country] == COUNTRY.mexico.value)
        | (df[CleanSchema.country] == COUNTRY.puerto_rico.value)
    )
    df.loc[
        ARRIVING_FROM_CONDITION_2, TransformedSchema.arriving_from
    ] = ARRIVING_FROM.ovs_via_us.value
    ARRIVING_FROM_CONDITION_3 = df["traveller_col"].isin(
        [
            CleanSchema.osd,
            CleanSchema.o1d,
            CleanSchema.o2d,
        ]
    )
    df.loc[
        ARRIVING_FROM_CONDITION_3, TransformedSchema.arriving_from
    ] = ARRIVING_FROM.ovs_via_us.value

    # Assign priority to break ties - note that the sort above correctly orders
    # the observations to break ties from left to right (see ipil_hwy_160test
    # for more information about this requirement). By creating a column that
    # preserves the order of each row within a group, we can ensure we
    # correctly break ties.
    df.loc[:, "bus_order"] = df.index.size - df.reset_index().index.values
    # Create UNIX timestamp column to sort on
    if "unix_timestamp" not in df:
        df.loc[:, "unix_timestamp"] = df.apply(
            lambda row: unix_timestamp_from_sin_and_date(
                row[CleanSchema.sin], row[CleanSchema.date]
            ),
            axis=1,
        )
    # Sort on cbsa work location, lane, and timestamp
    df = df.sort_values(
        by=[
            CleanSchema.cport,
            CleanSchema.lane,
            "unix_timestamp",
            "passengers_total",
            "bus_order",
        ]
    )

    # 8. Country of Residence
    df.loc[
        df["traveller_col"].isin(
            [CleanSchema.cdsd, CleanSchema.cd1d, CleanSchema.cd2d]
        ),
        TransformedSchema.country_of_residence,
    ] = COUNTRY_OF_RESIDENCE.canada.value
    df.loc[
        df["traveller_col"].isin(
            [CleanSchema.ussd, CleanSchema.us1d, CleanSchema.us2d]
        ),
        TransformedSchema.country_of_residence,
    ] = COUNTRY_OF_RESIDENCE.united_states.value

    # 9. Duration of Trip

    # duration2
    df.loc[
        df["traveller_col"].isin([CleanSchema.cdsd, CleanSchema.ussd, CleanSchema.osd]),
        TransformedSchema.duration2,
    ] = DURATION2.same_day.value
    df.loc[
        ~df["traveller_col"].isin(
            [CleanSchema.cdsd, CleanSchema.ussd, CleanSchema.osd]
        ),
        TransformedSchema.duration2,
    ] = DURATION2.overnight.value

    # duration3
    df.loc[
        df["traveller_col"].isin([CleanSchema.cdsd, CleanSchema.ussd, CleanSchema.osd]),
        TransformedSchema.duration3,
    ] = DURATION3.same_day.value
    df.loc[
        df["traveller_col"].isin([CleanSchema.cd1d, CleanSchema.us1d, CleanSchema.o1d]),
        TransformedSchema.duration3,
    ] = DURATION3.one_night.value
    df.loc[
        df["traveller_col"].isin([CleanSchema.cd2d, CleanSchema.us2d, CleanSchema.o2d]),
        TransformedSchema.duration3,
    ] = DURATION3.two_or_more_nights.value

    # duration5
    df.loc[:, TransformedSchema.duration5] = DURATION5.not_available.value

    # 10. Trip Purpose
    df.loc[
        :, TransformedSchema.purpose9
    ] = PURPOSE9.visit.value  # Purpose9 (Visit, not otherwise specified by default)
    df.loc[
        :, TransformedSchema.purpose4
    ] = PURPOSE4.visit.value  # Purpose4 (VISIT by default)

    # If vehicle type is TRUCK, both purposes are CREW
    df.loc[
        df[TransformedSchema.vehicle_type] == VEHICLE_TYPE.truck.value,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [PURPOSE9.crew.value, PURPOSE4.crew.value]

    # If vehicle type is BUS, need to recode one member to crew. One traveller
    # is recoded as CREW and CREW, either from the maximum of the nine
    # residency-duration variables or, in the event of a tie, between multiple
    # variables, from the left-most group. Since columns are already sorted,
    # the donor of the CREW member is the top record for each unique bus.
    df.loc[:, "UID"] = df.index
    bus_donors = (
        df[df[TransformedSchema.vehicle_type] == VEHICLE_TYPE.bus.value]
        .groupby([CleanSchema.cport, CleanSchema.lane, "unix_timestamp"])
        .last()
    )
    # Only need to worry about handling bus donors if this case is present
    if len(bus_donors):
        bus_donors.loc[:, "bus_split_indicator"] = 1
        # Merge bus_donor values back to original dataframe and
        df = pd.merge(
            df, bus_donors[["UID", "bus_split_indicator"]], on="UID", how="left"
        )
        # Need to split the appropriate bus row into CREW and VISIT
        bus_donors = bus_donors.apply(split_buses, axis=1)
        # Explode again so each becomes its own row
        bus_donors = explode(
            bus_donors,
            [
                "passengers_total",
                TransformedSchema.purpose9,
                TransformedSchema.purpose4,
            ],
        )
        # Need to recode purpose9 to pd.NA when it gets cast to None in explode() (This is the edge
        # case where purpose9 already had None values)
        bus_donors.loc[
            bus_donors[TransformedSchema.purpose9].isna(), TransformedSchema.purpose9
        ] = PURPOSE9.visit.value
        # Drop rows flagged with bus split, and then concatenate bus_donors to input
        df = df[df["bus_split_indicator"] != 1]
        df = pd.concat([df, bus_donors])

    # If license plate is XX and is a non-pedestrian, code purpose9/purpose4
    # respectively as N/A and OTHER NON-TOURISM.
    mask = (
        (df[CleanSchema.country] == COUNTRY.XX.value)
        & (df[TransformedSchema.plate_region] == PLATE_REGION.XX.value)
        & (~df[TransformedSchema.vehicle_type].isin([VEHICLE_TYPE.pedestrian.value]))
    )
    df.loc[mask, [TransformedSchema.purpose9, TransformedSchema.purpose4]] = [
        PURPOSE9.other_purpose.value,
        PURPOSE4.other_purpose.value,
    ]

    # Apply series of logic to assign traveller type
    # By default traveller_type is "TOURIST"
    df.loc[:, TransformedSchema.traveller_type] = TRAVELLER_TYPE.tourist.value
    # If duration2 is "same day" they are "EXCURSIONIST"
    df.loc[
        df[TransformedSchema.duration2] == DURATION2.same_day.value,
        TransformedSchema.traveller_type,
    ] = TRAVELLER_TYPE.excursionist.value
    # If (country == other AND province == XX AND vehicle type != pedestrian)
    # OR (purpose4 == "CREW") --> traveller_type = OTHER TRAVELLER
    mask = (
        (df[CleanSchema.country] == COUNTRY.XX.value)
        & (df[TransformedSchema.plate_region] == PLATE_REGION.XX.value)
        & (df[TransformedSchema.vehicle_type] != VEHICLE_TYPE.pedestrian.value)
    )
    df.loc[
        mask, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.other_traveller.value
    # Case 1: purpose is CREW --> traveller_type is "OTHER TRAVELLER"
    df.loc[
        df[TransformedSchema.purpose4] == PURPOSE4.crew.value,
        TransformedSchema.traveller_type,
    ] = TRAVELLER_TYPE.other_traveller.value

    # Last step: Count of entries
    # Select all columns we want to keep for the final table
    KEEP_COLUMNS = TRANSFORMED_GROUPBY.copy()
    KEEP_COLUMNS.append("passengers_total")
    df = df[KEEP_COLUMNS]

    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = (
        df.groupby(
            by=TRANSFORMED_GROUPBY,
            dropna=False,
        )
        .sum()
        .reset_index()
    ).astype({"passengers_total": "Int64"})

    df = df.rename(columns={"passengers_total": TransformedSchema.count_of_entries})

    # Include only columns for the final transformed output
    df = df[TRANSFORMED_COLUMNS]

    df = TransformedSchema(df)
    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]
    # Sort entries from left to right
    travellers = df.sort_values(
        [
            TransformedSchema.data_source,
            TransformedSchema.year,
            TransformedSchema.month,
            TransformedSchema.day,
            TransformedSchema.port,
            TransformedSchema.work_location,
            TransformedSchema.mode,
            TransformedSchema.vehicle_type,
            TransformedSchema.plate_country,
            TransformedSchema.plate_region,
            TransformedSchema.arriving_from,
            TransformedSchema.country_of_residence,
            TransformedSchema.purpose9,
            TransformedSchema.purpose4,
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
            TransformedSchema.traveller_type,
            TransformedSchema.count_of_entries,
        ],
        ascending=True,
    )
    return travellers
