"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        PORTS reference file.
"""

import pandera as pa
from pandera.typing import Series

from datasource.ports.dim import SGC_CODE, TYPE


class ReferenceSchema(pa.DataFrameModel):
    """
    Schema for the PORTS reference file.
    """

    sgc_code: Series[pa.String] = pa.Field(
        description="Province or territory of entry", isin=SGC_CODE.list(), coerce=True,
    )
    port: Series[pa.String] = pa.Field(
        description="Port of entry", str_matches=r"\d{5}", coerce=True,
    )
    port_name_en: Series[pa.String] = pa.Field(
        description="Name of port of entry in English", coerce=True,
    )
    port_name_fr: Series[pa.String] = pa.Field(
        description="Name of port of entry in French", coerce=True,
    )
    port_start: Series[pa.String] = pa.Field(
        description="Date the port started existing in our data",
        str_matches=r"\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
    )
    port_end: Series[pa.String] = pa.Field(
        description="Date the port ceased to exist in our data",
        str_matches=r"\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
        nullable=True,
    )
    port_area: Series[pa.String] = pa.Field(
        description="Four-digit code which groups ports within a province into zones",
        str_matches=r"\d{4}",
        coerce=True,
    )
    type: Series[pa.String] = pa.Field(
        description="Categorical combinations of Air, Land, Water modes",
        isin=TYPE.list(),
        coerce=True,
        nullable=True,
    )
    us_state: Series[pa.String] = pa.Field(
        description="A StatCan numerical code that represents the U.S. state",
        coerce=True,
        nullable=True,
    )
    us_port_name: Series[pa.String] = pa.Field(
        description="The name of the bordering U.S. port", coerce=True, nullable=True,
    )
    port_coordinates: Series[pa.String] = pa.Field(
        description="Geographical coordinates", coerce=True,
    )
    notes_en: Series[pa.String] = pa.Field(
        description="Notes about the port for external users, in English",
        coerce=True,
        nullable=True,
    )
    notes_fr: Series[pa.String] = pa.Field(
        description="Notes about the port for external users, in French",
        coerce=True,
        nullable=True,
    )
    comments: Series[pa.String] = pa.Field(
        description="Notes about the port for internal users",
        coerce=True,
        nullable=True,
    )
    published_port: Series[pa.String] = pa.Field(
        description="Roll up of ports to a level that can be published to respect confidentiality",
        str_matches=r"\d{5}",
        coerce=True,
    )
    published_port_name_en: Series[pa.String] = pa.Field(
        description="Name of published port of entry in English", coerce=True,
    )
    published_port_name_fr: Series[pa.String] = pa.Field(
        description="Name of published port of entry in French", coerce=True,
    )
    table_24100055: Series[pa.String] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100055",
        coerce=True,
        nullable=True,
    )
    table_24100056: Series[pa.String] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100056",
        coerce=True,
        nullable=True,
    )
    table_24100057: Series[pa.String] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100057",
        coerce=True,
        nullable=True,
    )
    table_24100058: Series[pa.String] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100058",
        coerce=True,
        nullable=True,
    )
    table_24100059: Series[pa.String] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100059",
        coerce=True,
        nullable=True,
    )
    published_port_notes_en: Series[pa.String] = pa.Field(
        description="Notes about the published port for external users, in English",
        coerce=True,
        nullable=True,
    )
    published_port_comments: Series[pa.String] = pa.Field(
        description="Notes about the published port for internal users",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [
            ReferenceSchema.port
        ]