"""
CLI script to "bulk prepare" ndm outputs into the /outbox location
"""
import datetime
import io
from dateutil.relativedelta import relativedelta
from argparse import ArgumentParser

import pandas as pd
from modules.s3client import S3Client
from modules.utils.loaders import Loader

from config.api import S3, S3Location, DataSource, Stage, Mode

from datasource.common.schema import NDMOutputCommonSchema as NDMSchema

# Seasonally Adjusted and non-seasonally adjusted data sources to prepare.
SEASONALLY_ADJUSTED = [DataSource.ndm_24100051, DataSource.ndm_24100054]

NON_ADJUSTED = [
    DataSource.ndm_24100050,
    DataSource.ndm_24100052,
    DataSource.ndm_24100053,
    DataSource.ndm_24100055,
]


def get_parser():
    """
    Sets up argo helper CLI
    """
    parser = ArgumentParser(
        prog="ndm_prepare_outbox",
        description="Command line tool to prepare ndm outputs for a given month.",
    )
    # Start date (set by default to January 1 2000 but can change in the future)
    parser.add_argument(
        "-d",
        "--date",
        # Default to the current year and month
        default=f"{datetime.datetime.strftime(datetime.datetime.today(), '%Y-%m')}-01",
        type=datetime.date.fromisoformat,
        help="""
        The month that is being processed.
        """,
    )
    # Parameters for number of periods
    parser.add_argument(
        "-p",
        "--periods",
        default="12",
        type=int,
        help="Number of months that the seasonal adjustment team will produce estimates for.",
    )
    return parser


def fetch_cumulative_tables(
    datasource: DataSource, periods: int, date: datetime.datetime
) -> pd.DataFrame:
    # Infer start date from date and periods
    # Note that the interpretation of periods is *excluding* the current production
    # month, so if periods = 18 this means "the current month plus 18 previous months".
    start_date = date - relativedelta(months=periods - 1)

    # Get MinIO client
    client = S3Client.get_client()
    # Generate a S3Location for each year between start_date.year and date.year (inclusive)
    locs = [
        S3.prefix(Stage.AGGREGATED, Mode.file, datasource, year=year)
        for year in range(start_date.year, date.year + 1)
    ]
    # Get all datasource tables for time range specified
    dfs = pd.concat([client.get_CSVs(loc) for loc in locs], ignore_index=True)
    # Keep only the months requested
    dfs = dfs[
        (
            pd.to_datetime(dfs[NDMSchema.ReferencePeriod], format="%Y%m%d")
            >= pd.to_datetime(start_date)
        )
        & (
            pd.to_datetime(dfs[NDMSchema.ReferencePeriod], format="%Y%m%d")
            <= pd.to_datetime(date)
        )
    ]
    return dfs


def fetch_non_cumulative_tables(
    datasource: DataSource, date: datetime.datetime
) -> pd.DataFrame:
    basename = S3.get_s3_basename(
        Stage.AGGREGATED, datasource, date.year, date.month, date.day
    )
    return Loader.get(Stage.AGGREGATED, datasource, basename)


def table_to_outbox(df: pd.DataFrame, datasource: DataSource) -> bool:
    """
    Exports data to a known location on MinIO.
    """
    client = S3Client.get_client()
    # Note that the requirements for ndm tables is that they follow the naming
    # convention <Table #>_data.csv
    basename = f"{datasource.value.replace('ndm_', '')}_data.csv"
    df_loc = S3Location(Stage.OUTBOX.value.bucket, Stage.OUTBOX.value.prefix, basename)

    # If the table file exists, remove it before uploading the new file. 
    exists = client.stat_loc(df_loc)
    if exists:
        client.remove_object(Stage.OUTBOX.value.bucket,S3.loc_to_obj(df_loc))

    df_bytes = df.to_csv(index=False).encode("utf-8")
    df_buffer = io.BytesIO(df_bytes)

    print(f"Uploading {df_loc.basename} to {df_loc.prefix}.")
    client.put_loc(df_loc, df_buffer, len(df_bytes), content_type="application/csv")
    return True


def main(periods: int, date: datetime.datetime):
    """Prepares the number of periods for ndm adjusted data that need to be overwritten.

    Args:
        periods (int): number of periods in months
        date (datetime.datetime): date (%Y-%m-01) of the year/month we are preparing NDM data for.
    """
    # List that will hold the dataframes that need to be exported to outbox
    OUTBOUND_TABLES = []
    # For the non-seasonal NDM tables, simply load one month of them.
    for datasource in NON_ADJUSTED:
        OUTBOUND_TABLES.append(
            {
                "datasource": datasource,
                "df": fetch_non_cumulative_tables(datasource, date),
            }
        )
    # For the seasonally adjusted NDM tables, use fetch_cumulative_tables to get
    # `periods` number of months.
    for datasource in SEASONALLY_ADJUSTED:
        OUTBOUND_TABLES.append(
            {
                "datasource": datasource,
                "df": fetch_cumulative_tables(datasource, periods, date),
            }
        )
    # Export OUTBOUND_TABLES to /outbox
    for obj in OUTBOUND_TABLES:
        table_to_outbox(obj["df"], obj["datasource"])


if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()
    periods = args.periods
    date = args.date
    main(periods, date)
    print("NDM Outputs saved to outbox.")
