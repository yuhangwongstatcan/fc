"""
CLI program to produce SA_IN and SA_PARAMETERS files from ndm_unadjusted files for a given month.

E.g.
```
python sa_in.py --date 2000-01-01 --num-periods 156 [--force]
```
"""
import io
import datetime
from argparse import ArgumentParser

import pandas as pd

from modules.s3client import S3Client

from config.api import S3, S3Location
from config.api import DataSource
from config.api import OutputFile
from config.api import Stage
from config.api import Mode
from config.constants import SA_IN_START_DATE

from datasource.sa_in.schema import AggregatedSchema as SASchema
from datasource.sa_parameters.schema import ReferenceSchema as ParametersSchema


def get_parser():
    """
    Sets up argo helper CLI
    """
    parser = ArgumentParser(
        prog="sa_in",
        description="Command line tool to produce SA_IN and SA_PARAMETERS files",
    )
    # Start date (set by default to January 1 2000 but can change in the future)
    parser.add_argument(
        "-d",
        "--date",
        default="2000-01-01",
        type=datetime.date.fromisoformat,
        help="""
        The start date of data that the seasonal adjustment will get.
        Date is of the form YYYY-MM-DD (e.g. 2020-12-22)
        """,
    )
    # Parameters for number of periods and force
    parser.add_argument(
        "-n",
        "--num-periods",
        default="240",
        type=int,
        help="Number of months that the seasonal adjustment team will produce estimates for.",
    )
    # Argument to list workflows in argo
    parser.add_argument(
        "--force",
        choices=["YES", "NO"],
        help="""Sets the 'force' option for seasonal adjustment (specified by end user)""",
    )
    return parser


def get_cumulative_sa_in(
    start_date: datetime.date, end_date: datetime.date
) -> pd.DataFrame:
    """
    **Description:**

    Gets all SA_IN files in the date range requested. At the time of writing this, MinIO doesn't
    seem to support seraching prefix patterns with regular expressions. As such, the implementation
    is as follows:

        1. Construct the prefix pattern for all years between start_date and end_date (inclusive).
        2. Use S3Client.get_CSVs to get all SA_IN tables for that year.
        3. If there are any extra months in the start year or end year, exclude them from the
           final result.
        4. Return the concatenation of the SA_IN tables.

    Args:
        start_date: datetime.date
            [description]. Valid Values are [values]
        end_date: datetime.date
            [description]. Valid Values are [values]

    Returns:
        pd.DataFrame:
            [description]. Valid Values are [values]
    """

    # Get MinIO client
    client = S3Client.get_client()
    # Generate a S3Location for each year between start_date.year and end_date.year (inclusive)
    locs = [
        S3.prefix(Stage.AGGREGATED, Mode.file, DataSource.sa_in, year=year)
        for year in range(start_date.year, end_date.year + 1)
    ]
    # Get all SA_IN tables for time range specified
    dfs = pd.concat([client.get_CSVs(loc) for loc in locs], ignore_index=True)
    # Keep only the months requested
    dfs = dfs[
        (
            pd.to_datetime(dfs[SASchema.DATE], format="%Y%m")
            >= pd.to_datetime(start_date)
        )
        & (
            pd.to_datetime(dfs[SASchema.DATE], format="%Y%m")
            <= pd.to_datetime(end_date)
        )
    ]
    return dfs


def main(num_periods: int, force: bool, date: datetime.date):
    # Get SA_IN table for time range requested
    # Note: By default, we always consider SA_IN production relative to a fixed start
    # date; this is distinct from the num_periods parameter which is simply passed as
    # a parameter to the seasonal adjustment team.
    sa_in = get_cumulative_sa_in(SA_IN_START_DATE, date)

    # Get SA_PARAMETERS table
    sa_parameters = pd.DataFrame(
        {
            ParametersSchema.YEAR: [date.year],
            ParametersSchema.MONTH: [date.month],
            ParametersSchema.NUM_PERIODS: [num_periods],
            ParametersSchema.FORCE: [force],
        }
    )
    # Use S3Client to upload sa_in and sa_parameters to appropriate S3location
    client = S3Client.get_client()

    # Get bytes of dataframes
    sa_in_bytes = sa_in.to_csv(index=False).encode("utf-8")
    sa_in_buffer = io.BytesIO(sa_in_bytes)
    sa_parameters_bytes = sa_parameters.to_csv(index=False).encode("utf-8")
    sa_parameters_buffer = io.BytesIO(sa_parameters_bytes)

    # Construct S3Location for sa_in and sa_parameters
    sa_in_loc = S3Location(
        Stage.OUTBOX.value.bucket, Stage.OUTBOX.value.prefix, OutputFile.sa_in.value
    )
    sa_params_loc = S3Location(
        Stage.OUTBOX.value.bucket,
        Stage.OUTBOX.value.prefix,
        OutputFile.sa_parameters.value,
    )
    # Put each file in the outbox location
    print(f"Uploading {sa_in_loc.basename} to {sa_in_loc.prefix}.")
    client.put_loc(
        sa_in_loc, sa_in_buffer, len(sa_in_bytes), content_type="application/csv"
    )
    print(f"Uploading {sa_params_loc.basename} to {sa_params_loc.prefix}.")
    client.put_loc(
        sa_params_loc,
        sa_parameters_buffer,
        len(sa_parameters_bytes),
        content_type="application/csv",
    )


if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()
    num_periods = args.num_periods
    force = args.force
    date = args.date
    main(num_periods, force, date)
