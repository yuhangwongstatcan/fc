from __future__ import annotations
import importlib
import json
import os
import datetime
from pathlib import Path

from typing import Dict, Optional, Callable, List

from pytest_cases import parametrize
from pandas.testing import assert_frame_equal

from pydantic import BaseModel
from pydantic.types import FilePath
from pydantic.types import DirectoryPath

# When invoking a specific test with the VSCode testing GUI, the CWD defaults
# to the project root. In all cases, we want to make sure the test runner is invoked
# from the src folder.
test_cwd = Path(os.getcwd())
if "src" not in test_cwd.parts:
    os.chdir(Path(test_cwd, "src"))

from modules.utils.loaders import Loader

# Any custom modules need to be imported after we are certain the test runner is
# running from cwd = src
from config.api import DataSource

from modules.utils.schema import load_datasource_schema

datasource_path = Path(__file__).parent / "datasource"


class FCIntegrationConfig(BaseModel):
    """
    A pydantic model for the FC Test configuration.
    """

    datasource: str
    test_name: str
    test_folder_path: DirectoryPath
    pipeline: Callable
    date: datetime.datetime
    outputs: List[Dict[str, str]]
    reference_year: Optional[str]


def integration_test_generator(datasource_path: Path):
    """
    Generates integration test configs for all of the tests defined at a given path

    Args:
        datasource_path (Path): A path to a valid datasource
    """
    for path in datasource_path.rglob("integration.config.json"):
        # Test config path
        integration_config_path = FilePath.validate(value=path)
        # Test folder path
        test_folder_path = DirectoryPath.validate(integration_config_path.parent)
        # Test name
        test_name = integration_config_path.parent.stem
        # Load the test config into a dictionary
        integration_config: Dict[str, str] = json.loads(
            Path(integration_config_path).read_text()
        )

        # Extract date as a datetime
        date = datetime.datetime.strptime(integration_config["date"], "%Y-%m-%d")

        # Get datasource name
        datasource = test_folder_path.parent.parent.stem

        # Pipeline class
        # The integration tests use two underscores in the naming convention so we can extract the class out this way
        pipeline_class = test_folder_path.stem.split("__")[1]

        # Get the pipeline module and pipeline itself
        pipeline_module_parts = ["datasource", datasource, "pipeline"]
        pipeline_module_str = ".".join(pipeline_module_parts)
        pipeline_module = importlib.import_module(pipeline_module_str)
        Pipeline = getattr(pipeline_module, pipeline_class)

        # Get all of the data associated with the test case in question.
        yield FCIntegrationConfig(
            datasource=datasource,
            test_name=test_name,
            test_folder_path=test_folder_path,
            pipeline=Pipeline,
            date=date,
            outputs=integration_config["outputs"],
            reference_year=integration_config.get("reference_year"),
        )


def run_test_pipeline(integration_test_instance):
    # Define pipeline and run it to generate the outputs
    pipeline = integration_test_instance.pipeline(
        DataSource[integration_test_instance.datasource],
        integration_test_instance.date,
        integration_test_instance.reference_year,
    )
    pipeline.run()

    # for output in integration_test_instance.outputs:
    for output in pipeline.outputs.values():
        # Load expected dataframe from mock MinIO
        TestSchema = load_datasource_schema(
            output.datasource,
            output.stage,
        )
        expected_df = Loader.get(
            stage=output.stage,
            datasource=output.datasource,
            basename=output.basename,
        )
        expected_df = TestSchema(expected_df)

        # Load actual dataframe from outputs
        actual_df = output.data

        # Cast all columns of both dataframes to string type as we only care about comparing their values.
        actual_df = (
            actual_df.astype(str)
            .sort_values(list(actual_df.columns))
            .reset_index(drop=True)
        )
        expected_df = (
            expected_df.astype(str)
            .sort_values(list(expected_df.columns))
            .reset_index(drop=True)
        )
        assert_frame_equal(actual_df, expected_df, check_dtype=False)


# Define tests to be run
@parametrize(
    test_case_instance=integration_test_generator(Path(datasource_path, "e63"))
)
def test_integration_e63(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(Path(datasource_path, "e63_1"))
)
def test_integration_e63_1(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(Path(datasource_path, "e311"))
)
def test_integration_e311(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(
        Path(datasource_path, "ipil_hwy")
    )
)
def test_integration_ipil_hwy(test_case_instance):
    run_test_pipeline(test_case_instance)

@parametrize(
    test_case_instance=integration_test_generator(
        Path(datasource_path, "ipil_air")
    )
)
def test_integration_ipil_air(test_case_instance):
    run_test_pipeline(test_case_instance)

@parametrize(
    test_case_instance=integration_test_generator(
        Path(datasource_path, "nghh")
    )
)
def test_integration_nghh(test_case_instance):
    run_test_pipeline(test_case_instance)

@parametrize(
    test_case_instance=integration_test_generator(
        Path(datasource_path, "manual_entry_travellers")
    )
)
def test_integration_manual_entry_travellers(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(
        Path(datasource_path, "manual_entry_vehicles")
    )
)
def test_integration_manual_entry_vehicles(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(Path(datasource_path, "nexus_hwy"))
)
def test_integration_nexus_hwy(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(Path(datasource_path, "pik"))
)
def test_integration_pik(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(Path(datasource_path, "trc"))
)
def test_integration_trc(test_case_instance):
    run_test_pipeline(test_case_instance)


@parametrize(
    test_case_instance=integration_test_generator(Path(datasource_path, "nexus_air"))
)
def test_integration_nexus_air(test_case_instance):
    run_test_pipeline(test_case_instance)