"""
A simple CLI that allows execution of pipelines
"""
import time
from config.api import DataSource

from modules.cli import get_parser
from modules.pipeline import get_pipeline

if __name__ == "__main__":
    data_sources = DataSource.aslist()
    # Get configured pipeline arg parser
    pipeline_parser = get_parser(data_sources)
    # Get command line arguments passed
    args = pipeline_parser.parse_args()
    # Get the correct Enum class given the arguments provided
    datasource = DataSource[args.data_source]
    # Get the appropriate Pipeline class
    Pipeline = get_pipeline(datasource, args.pipeline_class)
    # Create pipeline instance
    pipeline = Pipeline(datasource, args.date, args.reference_year, True)#args.force)
    # Run the pipeline
    pipeline.run()
