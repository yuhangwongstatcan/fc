#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This module provides a CLI for staging data and setting up demos.
@author: collin brown (collin.brown@canada.ca)
@created_at: March 4, 2021
"""
import re
import os
import glob
from typing import Union
from os.path import basename
from os.path import join
import argparse

import minio

from modules.s3client import S3Client

from config.api import Stage
from config.api import S3Location
from config.api import DEFAULT_BUCKET


options = {
    "reference": {
        "loc": "tests/mock_minio/reference/*/*.csv",
        "description": "Stage all references from mock minio.",
    },
    "validation": {
        "loc": "tests/mock_minio/validation/*/*.csv",
        "description": "Stage all validation data from mock minio.",
    },
}

vehicles_main = {
    f"vehicles_main_{ix:02d}": {
        "loc": S3Location(DEFAULT_BUCKET, f"staging/vehicles_main/{ix:04d}/"),
        "description": f"Stage vehicles_main for {ix:04d}.",
    }
    for ix in range(1972, 2022)
}

travellers_main = {
    f"travellers_main_{ix:04d}": {
        "loc": S3Location(DEFAULT_BUCKET, f"staging/travellers_main/{ix:04d}/"),
        "description": f"Stage travellers_main for {ix:04d}.",
    }
    for ix in range(1972, 2022)
}
# Merge dictionaries together
options = {**options, **vehicles_main, **travellers_main}

groups = {
    "initialize": {
        "loc": ["reference", "validation"],
        "description": "Initialize all of the non-time based data sources.",
    },
    "vehicles_travellers_main": {
        "loc": [f"vehicles_main_{ix:04d}" for ix in range(1972, 2022)]
        + [f"travellers_main_{ix:04d}" for ix in range(1972, 2022)],
        "description": "All of the vehicles_main and travellers_main dependencies for ndm tables.",
    },
    "ndm_historical_validation": {
        "loc": [
            "ndm_24100050_old_data",
            "ndm_24100052_old_data",
            "ndm_24100053_old_data",
        ],
        "description": "Stages all of the artifacts to perform the historical validation of NDM data.",
    },
}


def glob_regex(regex: str, root_path="tests/mock_minio"):
    """
    A more flexible glob file expansion using regular expressions.
    Allows to do things such as:
        List all the files except the index file
        'tests/mock_minio/reference/mapping/map__.*(?!(index)).csv'

    """
    matches = []
    for folder, _, files in os.walk(root_path):
        extended = [os.path.join(folder, f) for f in files] if files else []
        for ex in extended:
            if re.match(regex, ex):
                matches.append(ex)
    return matches


def clean_minio(client: S3Client):
    for staged in Stage:
        if staged != Stage.DATA and staged != Stage.STAGING:
            client.rm(staged.value.bucket, staged.value.prefix, True)
    for staged in Stage:
        client.mkdir(staged.value.bucket, staged.value.prefix)


def stage_data(
    client: S3Client,
    src: Union[S3Location, str],
    dst: S3Location = Stage.INBOX.value,
    recursive: bool = False,
) -> None:
    if isinstance(src, S3Location):
        for obj in client.ls_objs(
            bucket=src.bucket,
            prefix=src.prefix,
            recursive=recursive,
            default_folder_file=False,
            only_files=True,
        ):
            try:
                client.cp_obj(
                    src.bucket,
                    obj.object_name,
                    join(Stage.INBOX.value.prefix, basename(obj.object_name)),
                    Stage.INBOX.value.bucket,
                )
                print("successfully moved ", obj.object_name)
            except minio.error.NoSuchKey:
                print("failed to move ", obj.object_name)
    elif isinstance(src, str):
        for filename in glob.glob(src):
            full_dst = S3Location(dst.bucket, dst.prefix, os.path.basename(filename))
            client.fput_loc(full_dst, filename)
            print(f"successfully moved: {filename} to Stage.INBOX")
    else:
        raise Exception("Must pass S3Location or string (file path)")


if __name__ == "__main__":
    """"""
    sclient = S3Client.get_client()
    parser = argparse.ArgumentParser(description="Demo CLI")

    for key, val in options.items():
        parser.add_argument(f"--{key}", action="store_true", help=val["description"])

    for key, val in groups.items():
        parser.add_argument(f"--{key}", action="store_true", help=val["description"])

    parser.add_argument(
        "--clean-minio", action="store_true", help="Clean out contents of MinIO"
    )

    parser.add_argument(
        "--s3",
        nargs="?",
        default=None,
        help="Stage a prefix under the Stage.STAGING folder",
    )

    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Indicates whether a recursive copy should be performed",
    )

    args = parser.parse_args()

    for key, val in options.items():
        if hasattr(args, key) and getattr(args, key) is True:
            stage_data(sclient, val["loc"])

    if not args.s3 is None:
        prefix_loc = S3Location(
            Stage.STAGING.value.bucket,
            join(Stage.STAGING.value.prefix, args.s3, ""),
            "",
        )
        stage_data(sclient, prefix_loc, recursive=args.recursive)

    for key, val in groups.items():
        if hasattr(args, key) and getattr(args, key) is True:
            for k in val["loc"]:
                loc = options[k]["loc"]
                stage_data(sclient, loc)

    if args.clean_minio:
        clean_minio(sclient)
