"""
Author(s):

- Collin Brown (collin.brown@statcan.gc.ca)

Date Created: December 13, 2021

The purpose of this short CLI script is to automatically reconcile the state
of "live minio" with "mock minio". Reasons to do this:

1. As configuration changes, it is desirable to synchronize dimension changes
   with the source code.

2. If you change configuration files, unit/integration tests that previously
   passed could fail, and you want to know if this happens.

3. You have extra redundancy - if your production data gets lost/corrupted,
   you can automatically restore from backup with the staging.py script (e.g.
   `python staging.py --reference`)

This script recursively copies the contents of the `/reference` s3 prefix
to the `src/tests/mock_minio/reference` filesystem location of this git
repository.

Importantly, this allows you to use Git diff tools to see any differences between
production MinIO and Mock MinIO reference files.

This script contains some "edge case" logic to handle the treatment of different
file names that contain certain prefixes/suffixes.

To run this script, simply do `python reconcile_mock_minio.py` from inside of the
`src` directory while in the `frontier-counts` conda environment.
"""
import csv
import os

from modules.utils.loaders import Loader
from modules.s3client import S3Client
from config.api import (
    S3,
    DataSource,
    Stage,
    Mapping,
    WorkLocationsAction,
    WorkLocationsTransAction,
    WorkLocationsTransportation,
)

MOCK_MINIO_PREFIX = os.path.join("tests", "mock_minio")


if __name__ == "__main__":
    client = S3Client.get_client()

    for obj in client.ls_objs(bucket="fc-bucket", prefix="reference", recursive=True):
        loc = S3.obj_to_loc(obj.bucket_name, obj.object_name)
        # Skip historical reference data since we do not want to move it
        # to mock_minio.
        if "/historical/" in loc.prefix:
            continue
        # Note that REFERENCE stage data sources always follow the naming
        # convention of <datasource name>.csv, so we can safely assume that
        # every obj listed will have a name that is a valid key for DataSource.
        basename = loc.basename.replace(".csv", "")

        # There are a set of reference files that need to be reviewed manually
        # (i.e. too complicated to change in this script), these should not be
        # automatically included to avoid tedious manual changes.
        if basename in ["ndm_vectors", "ndm_sa", "ndm_integrity_config"]:
            continue

        # There are special cases for dimensions and map types which need to
        # be loaded differently.
        try:
            if basename.startswith("map__") and not basename.endswith(
                "__reference__index"
            ):
                df = Loader.get_map_df(Mapping[basename])
            elif basename.startswith(
                "work_locations_action__"
            ) and not basename.endswith("__reference__index"):
                df = Loader.get(
                    Stage.REFERENCE,
                    DataSource.work_locations_action,
                    WorkLocationsAction[basename],
                )
            elif basename.startswith(
                "work_locations_trans__"
            ) and not basename.endswith("__reference__index"):
                df = Loader.get(
                    Stage.REFERENCE,
                    DataSource.work_locations_trans,
                    WorkLocationsTransportation[basename],
                )
            elif basename.startswith("work_locations__") and not basename.endswith(
                "__reference__index"
            ):
                df = Loader.get(
                    Stage.REFERENCE,
                    DataSource.work_locations_trans_action,
                    WorkLocationsTransAction[basename],
                )
            elif not basename.endswith("__reference__index"):
                datasource = DataSource[basename]
                df = Loader.get(Stage.REFERENCE, datasource, None)
            else:
                print(f"Skipping index file:    {basename}")
                continue
        except Exception:
            tmp = 1
        OUT_PATH = os.path.join(MOCK_MINIO_PREFIX, loc.prefix, loc.basename)
        if datasource.value == "ndm_vectors":
            df.to_csv(
                OUT_PATH, index=False, encoding="utf-8", quoting=csv.QUOTE_NONNUMERIC
            )
        else:
            df.to_csv(OUT_PATH, index=False, encoding="utf-8")
        print(f"Successfully wrote:    {OUT_PATH}    to mock_minio")
