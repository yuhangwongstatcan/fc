"""

"""
import datetime
import io
from argparse import ArgumentParser

from config.api import S3, S3Location, Mode, Stage, DataSource

from modules.s3client import S3Client

from modules.utils.data_integrity_report import time_based_validations
from modules.utils.data_integrity_report import geographical_based_validations
from modules.utils.data_integrity_report import type_based_validations, misc_validations
from modules.utils.data_integrity_report import vehicles_geographical_based_validations
from modules.utils.data_integrity_report import vehicles_type_misc_based_validations

from modules.utils.loaders import Loader

from datasource.travellers.schema import TransformedSchema as TravellersSchema
from datasource.vehicles.schema import TransformedSchema as VehiclesSchema


def get_parser():
    """
    Sets up argo helper CLI
    """
    parser = ArgumentParser(
        prog="downstream_parser",
        description="Command line tool to produce database integrity files",
    )
    # Start date (set by default to January 1 2000 but can change in the future)
    parser.add_argument(
        "-y",
        "--year",
        type=int,
        help="""
        the filter year.
        """,
    )
    # Current date (i.e. date for the data being run)
    parser.add_argument(
        "-m",
        "--month",
        type=int,
        help="""
        the filter month.
        """,
    )
    return parser


def entrypoint(date: datetime.datetime):
    month = date.month
    month = f"{month:02d}"
    basename = f"{date.year}{month}.csv"

    travellers = Loader.get(Stage.AGGREGATED, DataSource.travellers, basename)
    travellers = TravellersSchema(travellers)
    vehicles = Loader.get(Stage.AGGREGATED, DataSource.vehicles, basename)
    vehicles = VehiclesSchema(vehicles)

    ##########################################
    # Travellers Data Integrity Validations
    ##########################################

    time_based = time_based_validations(travellers)

    geographical_based = geographical_based_validations(travellers)

    type_based = type_based_validations(travellers)

    miscellaneous = misc_validations(travellers)

    travellers_integrity = time_based.append(
        [geographical_based, type_based, miscellaneous]
    )

    s3client = S3Client.get_client()
    CSV_bytes = travellers_integrity.to_csv(index=False).encode("utf-8")
    CSV_buffer = io.BytesIO(CSV_bytes)
    integrity_loc = S3Location(
        Stage.VALIDATION.value.bucket,
        S3.prefix(
            Stage.VALIDATION,
            Mode.file,
            DataSource.travellers,
            year=date.year,
            month=month,
        ).prefix,
        f"{year}{month}-integrity.csv",
    )
    s3client.put_loc(
        integrity_loc, CSV_buffer, len(CSV_bytes), content_type="application/csv"
    )

    ##########################################
    # Vehicles Data Integrity Validations
    ##########################################

    time_based_vehicles = time_based_validations(vehicles)

    geographical_based_vehicles = vehicles_geographical_based_validations(vehicles)

    miscellaneous_vehicles = vehicles_type_misc_based_validations(vehicles)

    vehicles_integrity = time_based.append(
        [time_based_vehicles, geographical_based_vehicles, miscellaneous_vehicles]
    )

    CSV_bytes = vehicles_integrity.to_csv(index=False).encode("utf-8")
    CSV_buffer = io.BytesIO(CSV_bytes)
    integrity_loc = S3Location(
        Stage.VALIDATION.value.bucket,
        S3.prefix(
            Stage.VALIDATION,
            Mode.file,
            DataSource.vehicles,
            year=date.year,
            month=month,
        ).prefix,
        f"{year}{month}-integrity.csv",
    )
    s3client.put_loc(
        integrity_loc, CSV_buffer, len(CSV_bytes), content_type="application/csv"
    )


if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()
    year = args.year
    month = args.month
    date = datetime.datetime(year, month, 1)
    entrypoint(date)
