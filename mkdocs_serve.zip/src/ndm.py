#
# Created: December 2022
# Last update: January 31, 2023
#
# Authors: Jacob Doering - jacob.doering@statcan.gc.ca
#          Collin Brown - collin.brown@statcan.gc.ca
#
# Purpose: Perform task related to the Frontier Counts NDM/CODR unadjusted tables:
# - Generate the Leading Indicator tables (56, 57, 58 and 59)
# - Generate the unadjusted tables for the main release (50, 52, 53 and 55)
# - Generate the SA_IN unadjusted feeder table for the seasonal adjustment process
# - Validate the Leading Indicator tables
# - Validate the tables for the main release

import pandas as pd
import typer

import os
import pathlib
from pathlib import Path

from datetime import datetime

from typing import List, Set, Dict
from itertools import product

import logging
import glob
import itertools
import re

app = typer.Typer()

pd.options.display.max_colwidth = 200

#  _                                       _   _
# | |_ _   _ _ __   ___ _ __    ___  _ __ | |_(_) ___  _ __  ___
# | __| | | | '_ \ / _ \ '__|  / _ \| '_ \| __| |/ _ \| '_ \/ __|
# | |_| |_| | |_) |  __/ |    | (_) | |_) | |_| | (_) | | | \__ \
#  \__|\__, | .__/ \___|_|     \___/| .__/ \__|_|\___/|_| |_|___/
#      |___/|_|                     |_|

YEAR_OPTION: int = typer.Option(
    ..., help="The year of NDM data being generated",
)
MONTH_OPTION: int = typer.Option(
    ..., help="The month of NDM data being generated",
)
TABLE_OPTION: str = typer.Option(
    ..., help="The NDM table to be generated",
)
RELEASE_OPTION: str = typer.Option(
    default="main",
    help="The release whose tables are being validated, either leading or main.",
)
CURRENT_PARTITION_OPTION: str = typer.Option(
    ..., help="The current partition for parallel procesing."
)
NDM_QUERY_PATH_OPTION: Path = typer.Option(
    ...,
    help="The path to the file containing the configuration data used to generate the NDM data.",
)
PORTS_PATH_OPTION: Path = typer.Option(
    ..., help="The path to the ports reference file, including the port area column."
)
TRAVELLERS_PATH_OPTION: Path = typer.Option(
    default="/tmp/travellers_main/travellers_main.csv",
    help="The path to the file containing the travellers_main table.",
)
VEHICLES_PATH_OPTION: Path = typer.Option(
    default="/tmp/vehicles_main/vehicles_main.csv",
    help="The path to the file containing the vehicles_main table.",
)
OUTPUT_PATH_OPTION: Path = typer.Option(
    ..., help="The output file path for the NDM table being generated."
)
ARTIFACT_PATH_OPTION: Path = typer.Option(
    ..., help="The directory of artifacts run in parallel.",
)
NDM_SA_PATH_OPTION: Path = typer.Option(
    default="/tmp/ndm_sa/ndm_sa.csv",
    help="The path to the reference file defining queries to generate SA series.",
)
NDM_INTEGRITY_CONFIG_PATH_OPTION: Path = typer.Option(
    default="/tmp/ndm_integrity_config/ndm_integrity_config.csv",
    help="The reference file showing the intratable integrity checks to be done.",
)
NDM_BETWEEN_CONFIG_PATH_OPTION: Path = typer.Option(
    default="/tmp/ndm_integrity_between_tables/ndm_integrity_between_tables.csv",
    help="The reference file showing the intertable integrity checks to be done.",
)
NDM_INPUTS_PATH_OPTION: Path = typer.Option(
    default="/tmp/ndm_inputs/",
    help="A directory containing all of the ndm inputs for the month.",
)
OUTPUT_PATH_INTRATABLE_OPTION: Path = typer.Option(
    ..., help="The path to the intra-table validation output location.",
)
OUTPUT_PATH_INTERTABLE_OPTION: Path = typer.Option(
    ..., help="The path to the inter-table validation output location.",
)

#  _          _                    __                  _   _
# | |__   ___| |_ __   ___ _ __   / _|_   _ _ __   ___| |_(_) ___  _ __  ___
# | '_ \ / _ \ | '_ \ / _ \ '__| | |_| | | | '_ \ / __| __| |/ _ \| '_ \/ __|
# | | | |  __/ | |_) |  __/ |    |  _| |_| | | | | (__| |_| | (_) | | | \__ \
# |_| |_|\___|_| .__/ \___|_|    |_|  \__,_|_| |_|\___|\__|_|\___/|_| |_|___/
#              |_|


def safe_write_to_csv(df: pd.DataFrame, save_path: str):
    """
    Write a file to csv, but first make sure the set of directories that is
    indicated in save_path exist before attempting to write the CSV file.
    """
    as_path = Path(save_path)

    if not os.path.exists(as_path.parent):
        logging.info(f"Directory {as_path.parent} doesn't exist. Creating it now.")
        os.mkdir(as_path.parent)
    df.to_csv(as_path, index=False)
    logging.info(f"Successfully wrote DataFrame to {as_path}")


def prepare_config_file(
    config_file_path: Path, table: str, current_partition: str
) -> pd.DataFrame:
    """
    Reads in and formats the reference file containing the database
    queries for each table dimension.
    """
    config_file = pd.read_csv(config_file_path)

    # Since Table 55 and 57 are so large, it is partitioned at runtime to a single
    # combination of dims 3-4-5, so reduce the query file to just these cases
    if table == "55" or table == "57":

        current_values = current_partition.split(".")
        DIM3_EXCLUSION_MASK = (config_file["dim"] == 3) & (
            config_file["member"] != int(current_values[0])
        )
        DIM4_EXCLUSION_MASK = (config_file["dim"] == 4) & (
            config_file["member"] != int(current_values[1])
        )
        DIM5_EXCLUSION_MASK = (config_file["dim"] == 5) & (
            config_file["member"] != int(current_values[2])
        )

        config_file = config_file[
            ~(DIM3_EXCLUSION_MASK | DIM4_EXCLUSION_MASK | DIM5_EXCLUSION_MASK)
        ]
    # Fuse each NDM member and its corresponding query together so that they
    # can be passed as a unit through the program.
    config_file["member_w_query"] = list(
        zip(config_file["member"], config_file["query"])
    )
    return config_file


def prepare_ports_file(ports_path: Path) -> pd.DataFrame:
    """
    Reads in and formats the ports reference file
    """
    ports = pd.read_csv(ports_path)
    ports = ports.drop_duplicates(subset=["published_port"], keep="first")
    ports = ports[["published_port", "port_area"]]
    ports.rename(columns={"published_port": "port"}, inplace=True)

    return ports


def prepare_data_file(
    table: str, ports_file: pd.DataFrame, travellers_path: Path, vehicles_path: Path
) -> pd.DataFrame:
    """
    Reads in and formats the appropriate aggregate database files
    depending on which NDM table is being generated.
    """
    TRAVELLERS_ONLY_VARIABLE_LIST = [
        "arriving_from",
        "country_of_residence",
        "purpose9",
        "purpose4",
        "duration2",
        "duration3",
        "duration5",
        "traveller_type",
    ]
    travellers = pd.read_csv(travellers_path)
    vehicles = pd.read_csv(vehicles_path)
    # Table 58 uses only the vehicles_leading aggregate file
    if table in ["52", "58"]:
        data_file = vehicles
        data_file["table"] = "VL"
    # Table 59 uses both the travellers_leading and vehicles_leading aggregate files
    # Since the vehicles_leading table has a subset of the variables that the
    # travellers_leading does, the append requires some additional processing to avoid
    # ending up with float values in the NaN vehicles_leading columns
    elif table == "59":
        travellers["table"] = "TL"
        vehicles["table"] = "VL"
        data_file = travellers.append(vehicles, ignore_index=True).fillna(0)
        data_file[TRAVELLERS_ONLY_VARIABLE_LIST] = data_file[
            TRAVELLERS_ONLY_VARIABLE_LIST
        ].astype(pd.Int64Dtype())
    else:
        data_file = travellers
        data_file["table"] = "TL"

    # Merge with ports file to get the port_area
    data_file = pd.merge(data_file, ports_file, how="left", on=["port"])
    # data_file["port_area"] = data_file["port_area"].astype(int)

    return data_file


def dim_metrics(config_file: pd.DataFrame):
    max_dim: int = max(config_file["dim"])
    dim0: str = config_file[config_file["dim"] == 0]["query"].to_string(index=False)
    return max_dim, dim0


def determine_max_dim(df: pd.DataFrame) -> int:
    """"
    Determine the maximum dimension based on the column names in the dataframe.
    """
    numeric_component = [re.findall("\d+", f) for f in df.columns]
    flat_list = list(itertools.chain(*numeric_component))
    max_dim = max(flat_list)
    max_dim = int(max_dim)
    return max_dim


def get_dim_list(config_file: pd.DataFrame, max_dim: int) -> List[Set]:
    """
    For each dimension in the NDM table being generated, determines the list
    of members and their associated queries.
    """
    dim_list = []
    for idx in range(1, max_dim + 1):
        dim_list.append(set(config_file[config_file["dim"] == idx]["member_w_query"]))
    return dim_list


def ndm_from_queries(
    table: str, data_file: pd.DataFrame, dims: List[Set], max_dim: int, dim0: str
) -> pd.DataFrame:
    """
    Generates the count of entries from the database for every combination of NDM
    dimension members, based on the queries associated with these dimension members.
    """

    df = pd.DataFrame()

    # Take the cross-product of all dimension-member-query combinations, to effectively
    # generate every possible table cell and its associated query.
    for cp in product(*dims):
        list_of_dims, list_of_queries = new_ndm_row(
            cp, max_dim
        )  # Separate members from queries
        addon_df = query_data_for_value(
            table, data_file, list_of_dims, list_of_queries, max_dim, dim0
        )
        if not addon_df.empty:
            df = pd.concat([df, addon_df])

    # For Table 53, even though it is possible to have tourist and excursionist counts
    # for all international travellers, they are not published because it is conceptually
    # invalid for the other travellers
    if table == "53":
        REMOVAL_MASK = (df["dim2"] == 1) & ((df["dim3"] == 2) | (df["dim3"] == 3))
        df = df[~(REMOVAL_MASK)]
    return df


def new_ndm_row(cp: List[Set], max_dim: int) -> List:
    """
    Generates separate lists of dimension members and queries from the original sets.
    """
    list_of_dims = []
    list_of_queries = []
    for idx in range(0, max_dim):
        list_of_dims.append(
            cp[idx][0]
        )  # Extract member as the first element of the set
        list_of_queries.append(
            cp[idx][1]
        )  # Extract query as the second element of the set
    return list_of_dims, list_of_queries


def query_data_for_value(
    table: str,
    data_file: pd.DataFrame,
    list_of_dims: List,
    list_of_queries: List,
    max_dim: int,
    dim0: str,
) -> pd.DataFrame:
    """
    Queries the database file to return a sum of count of entries based on the
    established query for each NDM table dimension-member combination.
    """

    sum_df = pd.DataFrame()

    # Build the main query as a concatenation of components based on the dimensions
    # in the NDM table. The dim0 is a query component that applies to all elements in the table
    #
    # For example, coordinate 1.2.3.4.5 is made up of dim = 1, dim2 = 2, dim3 = 3, ...
    # dim0 may mean VEHICLE_TYPE = 1, dim1 = 1 may mean PORT = ABC, dim2 = 2 may mean COUNTRY = 34567, ...
    # So the ACTIVE_QUERY would end up as  VEHICLE_TYPE = 1 & PORT = ABC & COUNTRY = 34567 & ...
    ACTIVE_QUERY = dim0 + " & " + " & ".join(list_of_queries)

    # If a Leading table is being generated, group for daily totals, whereas if a Main
    # table is being generated, group for monthly totals
    if table in ["56", "57", "58", "59"]:
        GROUP_BY_VARIABLE = ["year", "month", "day"]
    else:
        GROUP_BY_VARIABLE = ["year", "month"]

    # Return all records from the database file matching the query.
    filtered_df = data_file.query(ACTIVE_QUERY)
    # Calculate a sum of count_of_entries for the data subset by date.
    sum_df = filtered_df.groupby(GROUP_BY_VARIABLE, as_index=False)[
        "count_of_entries"
    ].sum()
    sum_df.rename(columns={"count_of_entries": "Value"}, inplace=True)

    # If some values are returned, include the dimensions on the output table.
    # Otherwise, return an empty dataframe.
    if not sum_df.empty:
        sum_df["dims"] = ".".join([str(dim) for dim in list_of_dims])
        sum_df = unpack_dims(sum_df, max_dim)
        sum_df = sum_df.drop(["dims"], axis=1)
    return sum_df


def unpack_dims(sum_df: pd.DataFrame, max_dim: int) -> pd.DataFrame:
    """
    Creates an NDM coordinate variable of the form X.X.X.X... based on the table dimensions.
    """
    for idx in range(0, max_dim):
        col_name = "dim" + str(idx + 1)
        sum_df[col_name] = int((sum_df["dims"].str.split(".")[0][idx]))
    return sum_df


def format_ndm_file(
    table: str,
    ndm_df: pd.DataFrame,
    max_dim: int,
    ndm_columns_except_dim: List[str],
    ndm_sort_except_dim: List[str],
) -> pd.DataFrame:
    """
    Formats the output dataframe to adhere to some NDM conventions.
    """
    # If a leading table is being generated, include a dynamic day value
    # based on the date of the crossing. Otherwise set a 01
    if table in ["56", "57", "58", "59"]:
        ndm_df["ReferencePeriod"] = (
            ndm_df["year"].astype(str)
            + ndm_df["month"].astype(str).str.zfill(2)
            + ndm_df["day"].astype(str).str.zfill(2)
        ).astype(int)
    else:
        ndm_df["ReferencePeriod"] = (
            ndm_df["year"].astype(str) + ndm_df["month"].astype(str).str.zfill(2) + "01"
        ).astype(int)

    # Several other required NDM columns are constants for the Leading tables
    ndm_df[["ReferencePeriod2", "Symbol", "Status", "SecurityLevel"]] = [
        "",
        0,
        0,
        0,
    ]

    ndm_df = ndm_df[get_column_list(max_dim, ndm_columns_except_dim)]
    return ndm_df.sort_values(get_sort_list(max_dim, ndm_sort_except_dim))


def get_column_list(max_dim: int, ndm_columns_except_dim: List[str]) -> List[str]:
    """
    Dynamically generates a list of columns based on the number of
    dimensions in the table currently being created.
    """
    return ndm_columns_except_dim + [f"dim{idx}" for idx in range(1, max_dim + 1)]


def get_sort_list(max_dim: int, ndm_sort_except_dim: List[str]) -> List[str]:
    """
    Dynamically generates a list of sort variables based on the number
    of dimensions in the table currently being created.
    """
    return ndm_sort_except_dim + [f"dim{idx}" for idx in range(1, max_dim + 1)]


def read_artifacts(artifact_path: Path) -> pd.DataFrame:
    """
    Read all CSV parallel run artifacts from a directory and append to
    a single dataframe.
    """
    all_artifacts = glob.glob(os.path.join(artifact_path, "*.csv"))
    df = pd.concat(
        (pd.read_csv(artifact) for artifact in all_artifacts), ignore_index=True
    )
    return df


def create_sa_in(
    ndm_sa: pd.DataFrame, travellers_main: pd.DataFrame, current_period: str,
) -> pd.DataFrame:
    """
    For every NDM -> Seasonal Adjustment mapping, create the corresponding sa_in row
    based on the database query from the reference file
    """
    # Create empty dataframe to hold the sa_in values.
    sa_in = pd.DataFrame()

    for idx, row in ndm_sa.iterrows():
        # If vectors_in column is empty, we do not provide an SA_IN value, but we receive an SA_OUT
        # value. In this case, just skip to the next row.
        if pd.isna(row["query_in"]):
            continue
        # Evaluate the query that corresponds to the current row
        QUERY_IN_MASK = travellers_main.eval(row["query_in"])
        # Aggregate the input values as appropriate to create the corresponding sa_in values.
        sa_in_value = travellers_main[QUERY_IN_MASK]["count_of_entries"].sum()
        sa_in = sa_in.append(
            {"DATE": current_period, "SERIES": row["series"], "VALUE": sa_in_value,},
            ignore_index=True,
        )
    return sa_in


def ndm_validation(
    year: str,
    month: str,
    release: str,
    ndm_integrity_config: pd.DataFrame,
    ndm_between_config: pd.DataFrame,
    ndm_inputs_path: Path,
    table_to_dim: Dict[str, List],
    output_path_intratable: Path,
    output_path_intertable: Path,
):
    """
    Main driver for validation of the NDM tables, running intratable
    and/or intertable validations for all applicable tables depending
    if the release is leading or main.
    """
    for table_number in ndm_integrity_config["table_number"].unique():
        mistakes = pd.DataFrame()

        path_backend = (
            "ndm_241000"
            + str(table_number)
            + "/"
            + year
            + "/"
            + month
            + "/"
            + year
            + month
            + ".csv"
        )

        table_path = os.path.join(ndm_inputs_path, path_backend)
        ndm_table = pd.read_csv(table_path, dtype=str)

        # Drop rows where Value is NaN (this would indicate a missing value)
        ndm_table = ndm_table.dropna(subset=["Value"])
        table_dims = table_to_dim[table_number]
        print(f"About to process {table_number}")
        for idx, row in ndm_integrity_config[
            ndm_integrity_config["table_number"] == table_number
        ].iterrows():
            temp = table_dims.copy()
            compliment_dims = temp
            compliment_dims.remove(row["dim_number"])
            if len(compliment_dims) == 2:
                # There are two special cases: one for NDM 24100053 and one for NDM 24100054.
                # NDM 24100053 special case:
                # When we are checking dim3, don't consider the case where dim2 == 1,74,75,76,81,86
                if table_number == "53" and row["dim_number"] == "dim3":
                    DIM1 = ndm_table[compliment_dims[0]].unique().tolist()
                    exclude_range = ["1"] + [str(i) for i in range(74, 92)]
                    DIM2 = list(
                        set(ndm_table[compliment_dims[1]].unique().tolist())
                        - set(exclude_range)
                    )
                    enumerations = list(product(DIM1, DIM2))
                # Additional exclusion: When looking at dim2=1, exclude when dim3 = 2 or 3
                # (only possible when dim2 = 1).
                elif (
                    table_number == "53"
                    and row["dim_number"] == "dim2"
                    and row["corresponding_value"] == "1"
                ):
                    DIM1 = ndm_table[compliment_dims[0]].unique().tolist()
                    DIM3 = list(
                        set(ndm_table[compliment_dims[1]].unique().tolist())
                        - set(["2", "3"])
                    )
                    enumerations = list(product(DIM1, DIM3))
                # NDM 24100054 special case:
                # When we are checking dim3, don't consider the case where dim2 == 1,17
                elif table_number == "54" and row["dim_number"] == "dim3":
                    DIM1 = ndm_table[compliment_dims[0]].unique().tolist()
                    DIM2 = list(
                        set(ndm_table[compliment_dims[1]].unique().tolist())
                        - set(["1", "17"])
                    )
                    enumerations = list(product(DIM1, DIM2))
                # When looking at dim2=1, exclude when dim3 = 2 OR 3 (only verify when dim3=1)
                elif (
                    table_number == "54"
                    and row["dim_number"] == "dim2"
                    and row["corresponding_value"] == "1"
                ):
                    DIM1 = ndm_table[compliment_dims[0]].unique().tolist()
                    DIM3 = list(
                        set(ndm_table[compliment_dims[1]].unique().tolist())
                        - set(["2", "3"])
                    )
                    enumerations = list(product(DIM1, DIM3))
                else:
                    enumerations = list(
                        product(
                            ndm_table[compliment_dims[0]].unique(),
                            ndm_table[compliment_dims[1]].unique(),
                        )
                    )
            else:
                # There is one special case with NDM table 24100051 where we exclude
                # cases where dim1 = 2,3,4,5 if we are checking dim2.
                # Special case for exclusion on dim2: it should be "Only enumerate
                # dim2 = 4, 23, 53 OR 63 for the case where dim1 == 1." i.e. Do not
                # enumerate dim2 = 23 if dim1 == 2 or 3 or 4 or 5. Enumerate dim2 = 1
                # when dim1 = 1, 2, 3, 4 OR 5.
                if (
                    table_number == "51"
                    and row["dim_number"] == "dim2"
                    and row["corresponding_value"] in ["4", "23", "53", "63"]
                ):
                    enumerations = list(
                        set(ndm_table[compliment_dims[0]].unique().tolist())
                        - set(["2", "3", "4", "5"])
                    )
                # When looking at dim1, exclude when dim2 = 5-22, 24-52, 54-62, 64-85 and 87-89
                # (it should only be looked at when dim2 = 1, 2, 3, 4, 23, 53, 63 and 86).
                elif table_number == "51" and row["dim_number"] == "dim1":
                    range1 = [str(i) for i in range(5, 23)]
                    range2 = [str(i) for i in range(24, 53)]
                    range3 = [str(i) for i in range(54, 63)]
                    range4 = [str(i) for i in range(64, 86)]
                    range5 = [str(i) for i in range(87, 90)]
                    exclude_range = range1 + range2 + range3 + range4 + range5
                    enumerations = list(
                        set(ndm_table[compliment_dims[0]].unique().tolist())
                        - set(exclude_range)
                    )
                else:
                    enumerations = ndm_table[compliment_dims[0]].unique().tolist()
            for grp in enumerations:
                # (assume dim_number = "dim1", then using grp, get the subset of rows where dim2 == 1 and dim3 == 4
                if len(compliment_dims) == 2:
                    GRP_MASK = (ndm_table[compliment_dims[0]] == grp[0]) & (
                        ndm_table[compliment_dims[1]] == grp[1]
                    )
                else:
                    GRP_MASK = ndm_table[compliment_dims[0]] == grp
                # This comes from the fourth column of ndm_integrtiy_config (which is `row` on the current iteration)
                # e.g. for dim1, SHOULD_EQUAL_MASK = (ndm_table["dim1"] == 3) | (ndm_table["dim1"] == 6) | ... | (ndm_table["dim1"] == 14)
                should_equal_query = generate_should_equal_query(row)
                SHOULD_EQUAL_MASK = ndm_table.eval(should_equal_query)
                # E.g. (ndm_table["dim1"] == 2)
                CORRESPONDING_VALUE_MASK = (
                    ndm_table[row["dim_number"]] == row["corresponding_value"]
                )
                if (
                    ndm_table.loc[GRP_MASK & SHOULD_EQUAL_MASK, "Value"]
                    .convert_dtypes()
                    .astype(int)
                    .sum()
                    != ndm_table.loc[GRP_MASK & CORRESPONDING_VALUE_MASK, "Value"]
                    .convert_dtypes()
                    .astype(int)
                    .sum()
                ):
                    mistakes_temp = pd.DataFrame()
                    mistakes_temp = mistakes_temp.append(row)
                    mistakes_temp["compliment_dims"] = "0"
                    mistakes_temp["compliment_dims"] = (
                        mistakes_temp["compliment_dims"]
                        .convert_dtypes()
                        .astype("object")
                    )
                    mistakes_temp.at[
                        mistakes_temp.index.tolist()[-1], "compliment_dims"
                    ] = compliment_dims
                    mistakes_temp["compliment_dims_values_at_mistake"] = "0"
                    mistakes_temp["compliment_dims_values_at_mistake"] = (
                        mistakes_temp["compliment_dims_values_at_mistake"]
                        .convert_dtypes()
                        .astype("object")
                    )
                    mistakes_temp.at[
                        mistakes_temp.index.tolist()[-1],
                        "compliment_dims_values_at_mistake",
                    ] = grp
                    # Get the value of the dim we are looking at
                    mistakes_temp["dim_value"] = mistakes_temp["corresponding_value"]
                    # Get actual vs expected
                    mistakes_temp["should_equal"] = (
                        ndm_table.loc[GRP_MASK & SHOULD_EQUAL_MASK, "Value"]
                        .convert_dtypes()
                        .astype(int)
                        .sum()
                    )
                    mistakes_temp["corresponding_value"] = (
                        ndm_table.loc[GRP_MASK & CORRESPONDING_VALUE_MASK, "Value"]
                        .convert_dtypes()
                        .astype(int)
                        .sum()
                    )
                    mistakes_temp["actual_vs_expected"] = (
                        mistakes_temp["should_equal"]
                        - mistakes_temp["corresponding_value"]
                    )
                    mistakes = mistakes.append(mistakes_temp)
        # Order the columns so the output is easier to read
        if not mistakes.empty:
            mistakes = mistakes[
                [
                    "table_number",
                    "dim_number",
                    "dim_value",
                    "compliment_dims",
                    "compliment_dims_values_at_mistake",
                    "corresponding_value",
                    "should_equal",
                    "actual_vs_expected",
                ]
            ]
        # Write the intratable integrity validation to Azure
        output_path_backend = (
            year
            + "/"
            + month
            + "/ndm_241000"
            + str(table_number)
            + "/"
            + year
            + "-"
            + month
            + "-ndm_integrity-"
            + datetime.now().strftime("%d-%m-%Y %H-%M-%S")
            + ".csv"
        )
        full_output_path = os.path.join(output_path_intratable, output_path_backend)
        safe_write_to_csv(mistakes, full_output_path)

    # ###########################
    # Do the between table validations
    # ###########################

    # There are no between table validations for the Leading release
    if release == "main":
        mistakes_50_53 = between_table_validations(
            year,
            month,
            ndm_between_config,
            ndm_inputs_path,
            "ndm_24100050",
            "ndm_24100053",
        )
        mistakes_50_55 = between_table_validations(
            year,
            month,
            ndm_between_config,
            ndm_inputs_path,
            "ndm_24100050",
            "ndm_24100055",
        )
        mistakes_51_54 = between_table_validations(
            year,
            month,
            ndm_between_config,
            ndm_inputs_path,
            "ndm_24100051",
            "ndm_24100054",
        )
        mistakes_53_55 = between_table_validations(
            year,
            month,
            ndm_between_config,
            ndm_inputs_path,
            "ndm_24100053",
            "ndm_24100055",
        )
        mistakes_between = pd.concat(
            [mistakes_50_53, mistakes_50_55, mistakes_51_54, mistakes_53_55]
        )

        # Write the intertable integrity validation to Azure
        output_path_bt_backend = (
            year
            + "/"
            + month
            + "/"
            + year
            + "-"
            + month
            + "-between-tables-"
            + datetime.now().strftime("%d-%m-%Y %H-%M-%S")
            + ".csv"
        )
        full_output_path_bt = os.path.join(
            output_path_intertable, output_path_bt_backend
        )
        safe_write_to_csv(mistakes_between, full_output_path_bt)


def generate_should_equal_query(row: pd.Series) -> str:
    """
    Generate a query based on the sub-categories for what the
    total category should be equal to.
    """
    return "|".join(
        f"({row['dim_number']} == '{i}')" for i in row["should_equal"].split(",")
    )


def between_table_validations(
    year: str,
    month: str,
    ndm_between_config: pd.DataFrame,
    ndm_inputs_path: Path,
    table1: str,
    table2: str,
) -> pd.DataFrame:
    """
    Produces between-tables validations for NDM tables.

    Args:
        table1 (DataSource): _description_
        table2 (DataSource): _description_
        date (datetime.datetime): _description_

    Returns:
        pd.DataFrame: _description_
    """

    def parse_coords(coords: str) -> List[Dict[str, str]]:
        """
        Parses a string of period delimited coordinates
        into key-value pairs of dimensions.
        """
        # If a comma separated list of coordinates is passed,
        # return a list of dimension key-value pairs.
        if "," in coords:
            coord_list = [coord for coord in coords.split(",")]
        else:
            coord_list = [coords]
        return [
            {
                "dim1": coord.split(".")[0] if len(coord.split(".")) >= 1 else None,
                "dim2": coord.split(".")[1] if len(coord.split(".")) >= 2 else None,
                "dim3": coord.split(".")[2] if len(coord.split(".")) >= 3 else None,
                "dim4": coord.split(".")[3] if len(coord.split(".")) >= 4 else None,
                "dim5": coord.split(".")[4] if len(coord.split(".")) >= 5 else None,
            }
            for coord in coord_list
        ]

    def get_table_value_at_condition(
        table: pd.DataFrame, table_dims: List[Dict[str, str]]
    ) -> int:
        """
        Gets the value evaluated at a condition that is derrived from
        the table_dims list that is passed to this function.
        """
        # If table_dims has only one coordinate, just create the condition
        # directly. Otherwise need to generate the condition based on N coordinates.
        if len(table_dims) == 1:
            TABLE_DIM1_COND = (
                (table["dim1"] == table_dims[0]["dim1"])
                if table_dims[0]["dim1"]
                else pd.Series([True] * len(table))
            )
            TABLE_DIM2_COND = (
                (table["dim2"] == table_dims[0]["dim2"])
                if table_dims[0]["dim2"]
                else pd.Series([True] * len(table))
            )
            TABLE_DIM3_COND = (
                (table["dim3"] == table_dims[0]["dim3"])
                if table_dims[0]["dim3"]
                else pd.Series([True] * len(table))
            )
            TABLE_DIM4_COND = (
                (table["dim4"] == table_dims[0]["dim4"])
                if table_dims[0]["dim4"]
                else pd.Series([True] * len(table))
            )
            TABLE_DIM5_COND = (
                (table["dim5"] == table_dims[0]["dim5"])
                if table_dims[0]["dim5"]
                else pd.Series([True] * len(table))
            )
            CONDITION = (
                TABLE_DIM1_COND
                & TABLE_DIM2_COND
                & TABLE_DIM3_COND
                & TABLE_DIM4_COND
                & TABLE_DIM5_COND
            )
        else:
            # Note that we only need to check table_dims[0]["dim<dim number>"]
            # since the schema of the table will be the same for every condition.
            CONDITIONS = []
            for obj in table_dims:
                CONDITIONS.append(
                    (
                        (
                            table["dim1"] == obj["dim1"]
                            if obj["dim1"]
                            else pd.Series([True] * len(table))
                        )
                        & (
                            table["dim2"] == obj["dim2"]
                            if obj["dim2"]
                            else pd.Series([True] * len(table))
                        )
                        & (
                            table["dim3"] == obj["dim3"]
                            if obj["dim3"]
                            else pd.Series([True] * len(table))
                        )
                        & (
                            table["dim4"] == obj["dim4"]
                            if obj["dim4"]
                            else pd.Series([True] * len(table))
                        )
                        & (
                            table["dim5"] == obj["dim5"]
                            if obj["dim5"]
                            else pd.Series([True] * len(table))
                        )
                    )
                )
            CONDITION = pd.Series([False] * len(table))
            for condition in CONDITIONS:
                CONDITION = CONDITION | condition
        return pd.to_numeric(table[CONDITION]["Value"]).sum()

    mistakes = pd.DataFrame()
    # Load the two data sources being compared
    TABLE1_NAME = table1
    TABLE2_NAME = table2

    path_backend1 = table1 + "/" + year + "/" + month + "/" + year + month + ".csv"
    path_backend2 = table2 + "/" + year + "/" + month + "/" + year + month + ".csv"

    table1_path = os.path.join(ndm_inputs_path, path_backend1)
    table2_path = os.path.join(ndm_inputs_path, path_backend2)

    table1 = pd.read_csv(os.path.join(ndm_inputs_path, table1_path), dtype=str)
    table2 = pd.read_csv(os.path.join(ndm_inputs_path, table2_path), dtype=str)

    for idx, row in ndm_between_config.iterrows():
        if row["table1"] != TABLE1_NAME or row["table2"] != TABLE2_NAME:
            continue
        table1_dims = parse_coords(row["table1_coords"])
        table2_dims = parse_coords(row["table2_coords"])
        table1_value = get_table_value_at_condition(table1, table1_dims)
        table2_value = get_table_value_at_condition(table2, table2_dims)
        if table1_value != table2_value:
            tmp = pd.DataFrame()
            tmp = tmp.append(row)
            tmp["table1_value"] = table1_value
            tmp["table2_value"] = table2_value
            tmp["difference"] = tmp["table1_value"] - tmp["table2_value"]
            mistakes = mistakes.append(tmp)
    return mistakes


#   ____ _     ___                                                 _
#  / ___| |   |_ _|   ___ ___  _ __ ___  _ __ ___   __ _ _ __   __| |___
# | |   | |    | |   / __/ _ \| '_ ` _ \| '_ ` _ \ / _` | '_ \ / _` / __|
# | |___| |___ | |  | (_| (_) | | | | | | | | | | | (_| | | | | (_| \__ \
#  \____|_____|___|  \___\___/|_| |_| |_|_| |_| |_|\__,_|_| |_|\__,_|___/


@app.command()
def unadjusted_tables(
    year: int = YEAR_OPTION,
    month: int = MONTH_OPTION,
    table: str = TABLE_OPTION,
    current_partition: str = CURRENT_PARTITION_OPTION,
    ndm_query_path: Path = NDM_QUERY_PATH_OPTION,
    ports_path: Path = PORTS_PATH_OPTION,
    travellers_path: Path = TRAVELLERS_PATH_OPTION,
    vehicles_path: Path = VEHICLES_PATH_OPTION,
    output_path: Path = OUTPUT_PATH_OPTION,
):
    config_file = prepare_config_file(ndm_query_path, table, current_partition)
    ports_file = prepare_ports_file(ports_path)
    data_file = prepare_data_file(table, ports_file, travellers_path, vehicles_path)

    # Determine how many dimensions are in the table being validated and the query
    # conditions that apply to the whole table
    max_dim, dim0 = dim_metrics(config_file)

    dim_list = get_dim_list(config_file, max_dim)

    ndm_df = ndm_from_queries(table, data_file, dim_list, max_dim, dim0)

    ndm_columns_except_dim = [
        "ReferencePeriod",
        "ReferencePeriod2",
        "Value",
        "Symbol",
        "Status",
        "SecurityLevel",
    ]
    ndm_sort_except_dim = ["ReferencePeriod"]

    if not ndm_df.empty:

        output_df = format_ndm_file(
            table, ndm_df, max_dim, ndm_columns_except_dim, ndm_sort_except_dim
        )

    else:
        output_df = pd.DataFrame(
            columns=get_column_list(max_dim, ndm_columns_except_dim)
        )

    output_df.to_csv(output_path, index=False)


@app.command()
def append(
    artifact_path: Path = ARTIFACT_PATH_OPTION, output_path: Path = OUTPUT_PATH_OPTION,
):

    df = read_artifacts(artifact_path)

    max_dim = determine_max_dim(df)
    ndm_sort_except_dim = ["ReferencePeriod"]

    output_df = df.sort_values(get_sort_list(max_dim, ndm_sort_except_dim))
    output_df.to_csv(output_path, index=False)


@app.command()
def sa_in(
    year: str = YEAR_OPTION,
    month: str = MONTH_OPTION,
    ndm_sa_path: Path = NDM_SA_PATH_OPTION,
    travellers_path: Path = TRAVELLERS_PATH_OPTION,
    output_path: Path = OUTPUT_PATH_OPTION,
):
    # Get ndm_sa table which contains the mappings between the Seasonally Adjusted series
    # and database queries / output NDM vectors
    ndm_sa = pd.read_csv(ndm_sa_path)

    # Read in the travellers main database file
    travellers_main = pd.read_csv(travellers_path)

    # Create string for the current period (note that date is already a timestamp).
    current_period = year + month

    sa_in_df = create_sa_in(ndm_sa, travellers_main, current_period)

    sa_in_df.to_csv(output_path, index=False)


@app.command()
def validate_ndm(
    year: str = YEAR_OPTION,
    month: str = MONTH_OPTION,
    release: str = RELEASE_OPTION,
    ndm_integrity_config_path: Path = NDM_INTEGRITY_CONFIG_PATH_OPTION,
    ndm_between_config_path: Path = NDM_BETWEEN_CONFIG_PATH_OPTION,
    ndm_inputs_path: Path = NDM_INPUTS_PATH_OPTION,
    output_path_intratable: Path = OUTPUT_PATH_INTRATABLE_OPTION,
    output_path_intertable: Path = OUTPUT_PATH_INTERTABLE_OPTION,
):

    ndm_integrity_config = pd.read_csv(ndm_integrity_config_path, dtype=str)
    ndm_between_config = pd.read_csv(ndm_between_config_path, dtype=str)

    # Load ndm integrity configuration from reference files depending on release
    # being validated - either leading or main
    if release == "main":

        table_to_dim = {
            "50": ["dim1", "dim2"],
            "51": ["dim1", "dim2"],
            "52": ["dim1", "dim2", "dim3"],
            "53": ["dim1", "dim2", "dim3"],
            "54": ["dim1", "dim2", "dim3"],
            "55": ["dim1", "dim2", "dim3", "dim4", "dim5"],
        }

    else:

        table_to_dim = {
            "56": ["dim1", "dim2", "dim3"],
            "57": ["dim1", "dim2", "dim3", "dim4", "dim5"],
            "58": ["dim1", "dim2", "dim3"],
            "59": ["dim1", "dim2", "dim3"],
        }

    ndm_validation(
        year,
        month,
        release,
        ndm_integrity_config,
        ndm_between_config,
        ndm_inputs_path,
        table_to_dim,
        output_path_intratable,
        output_path_intertable,
    )


if __name__ == "__main__":
    app()
