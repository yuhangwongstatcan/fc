"""

    Program: pik_report.py

    Author: Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

    Last Update: February 2025

    Purpose: Transcode Generate Demography PIK Program in Python

"""

import pandas as pd
import datetime

import io
from argparse import ArgumentParser
from config.api import S3, S3Location, Mode, Stage, DataSource, DEFAULT_BUCKET
from modules.s3client import S3Client
from modules.utils.loaders import Loader

from datasource.pik.schema import RawSchema
from datasource.pik_airports.schema import ReferenceSchema as APSchema

def get_parser():
    """
    Sets up argo helper CLI
    """
    parser = ArgumentParser(
        prog="downstream_parser",
        description="Command line tool to produce PIK demography reports",
    )
    parser.add_argument(
        "-d",
        "--date",
        default="2000-01-01",
        type=datetime.date.fromisoformat,
        help="""
        The start date of data that the seasonal adjustment will get.
        Date is of the form YYYY-MM-DD (e.g. 2020-12-22)
        """,
    )
    return parser

def entrypoint(date: datetime.date):
    mm = date.month
    yyyy = date.year

    # Deriving previous month and year
    prev_month = (datetime.datetime(yyyy, mm, 1) - datetime.timedelta(days=1)).month
    prev_year = (datetime.datetime(yyyy, mm, 1) - datetime.timedelta(days=1)).year

    # Convert numeric month to short name (e.g., Dec, Nov)
    mmm = datetime.datetime(yyyy, mm, 1).strftime('%b').upper()
    filemmm = datetime.datetime(prev_year, prev_month, 1).strftime('%b').upper()

    # Convert month to full name (e.g., December)
    month = datetime.datetime(yyyy, mm, 1).strftime('%B')
    filemonth = datetime.datetime(prev_year, prev_month, 1).strftime('%B')

    # Get MinIO client
    client = S3Client.get_client()
    # Generate a S3Location for year yyyy and month mm
    locs = S3.prefix(Stage.RAW, Mode.file, datasource=DataSource.pik, year=yyyy, month=mm)
    
    # Get all datasource tables for time range specified
    pik_raw = client.get_CSVs(locs)
    pik_raw = RawSchema(pik_raw)

    # Remove records that have missing key information
    pik_raw = pik_raw[
    ~((pik_raw["arrivingfrom"].isna()) | (pik_raw["arrivingfrom"] == 0) | (pik_raw["rescntry"] == ""))
    ]

    # Fetch and merge with the reference table
    airport_ref = Loader.get(Stage.REFERENCE, DataSource.pik_airports, None)
    airport_ref = APSchema(airport_ref)
    pik_airports = pik_raw.merge(airport_ref, how="left", left_on="wloc", right_on="WLOC")

    # Classify travellers
    pik_airports["cancz_return"] = (pik_airports["rescntry"] != "CAN") & (pik_airports["travellercitizenship"] == "CAN")
    pik_airports["cancz_usa"] = (pik_airports["cancz_return"]) & (pik_airports["rescntry"] == "USA")
    pik_airports["foreign_res"] = (pik_airports["rescntry"] != "CAN")
    pik_airports["can_res_cz"] = (pik_airports["rescntry"] == "CAN") & (pik_airports["travellercitizenship"] == "CAN")
    pik_airports["non_cz_res"] = (pik_airports["rescntry"] == "CAN") & (pik_airports["travellercitizenship"] != "CAN")

    # Convert boolean (True/False) to integer (1/0)
    classification_columns = ["cancz_return", "cancz_usa", "foreign_res", "can_res_cz", "non_cz_res"]
    pik_airports[classification_columns] = pik_airports[classification_columns].astype(int)

    # Aggregate data
    agg_columns = ['cancz_return', 'cancz_usa', 'foreign_res', 'can_res_cz', 'non_cz_res']
    agg_data = pik_airports.groupby(['Airport_Name', 'Province'])[agg_columns].sum().reset_index()
    agg_data.rename(columns={'Airport_Name': 'Airport'}, inplace=True)

    pik_can_ret = merge_with_previous(f"PIK Returning Canadians JAN2018 to {filemmm}{prev_year}.csv", agg_data[['Airport', 'Province', 'cancz_return']], prev_month, prev_year)
    pik_can_ret = pik_can_ret.rename(columns={"cancz_return": f"{mmm}{yyyy}"})
    pik_can_ret_usa = merge_with_previous(f"PIK Returning Canadians from USA JAN2018 to {filemmm}{prev_year}.csv", agg_data[['Airport', 'Province', 'cancz_usa']], prev_month, prev_year)
    pik_can_ret_usa = pik_can_ret_usa.rename(columns={"cancz_usa": f"{mmm}{yyyy}"})
    pik_foreign_res = merge_with_previous(f"PIK Foreign Residents JAN2018 to {filemmm}{prev_year}.csv", agg_data[['Airport', 'Province', 'foreign_res']], prev_month, prev_year)
    pik_foreign_res = pik_foreign_res.rename(columns={"foreign_res": f"{mmm}{yyyy}"})
    pik_can_rescz = merge_with_previous(f"PIK Canadian Resident Citizens JAN2018 to {filemmm}{prev_year}.csv", agg_data[['Airport', 'Province', 'can_res_cz']], prev_month, prev_year)
    pik_can_rescz = pik_can_rescz.rename(columns={"can_res_cz": f"{mmm}{yyyy}"})
    pik_noncz_res = merge_with_previous(f"PIK Non-Citizen Residents JAN2018 to {filemmm}{prev_year}.csv", agg_data[['Airport', 'Province', 'non_cz_res']], prev_month, prev_year)
    pik_noncz_res = pik_noncz_res.rename(columns={"non_cz_res": f"{mmm}{yyyy}"})

    update_report(f"PIK Returning Canadians JAN2018 to {mmm}{yyyy}.csv", pik_can_ret, mm, yyyy)
    update_report(f"PIK Returning Canadians from USA JAN2018 to {mmm}{yyyy}.csv", pik_can_ret_usa, mm, yyyy)
    update_report(f"PIK Foreign Residents JAN2018 to {mmm}{yyyy}.csv", pik_foreign_res, mm, yyyy)
    update_report(f"PIK Canadian Resident Citizens JAN2018 to {mmm}{yyyy}.csv", pik_can_rescz, mm, yyyy)
    update_report(f"PIK Non-Citizen Residents JAN2018 to {mmm}{yyyy}.csv", pik_noncz_res, mm, yyyy)
    return True
    
def merge_with_previous(basename: str , new_data: pd.DataFrame, prev_month, prev_year) -> pd.DataFrame:
    client = S3Client.get_client()
    # Generate a S3Location for year yyyy and month mm
    loc = S3.prefix(Stage.PRE_RELEASE, Mode.file, datasource=DataSource.pik_report, year=prev_year, month=prev_month, basename=basename)
    # Get the table for time range specified
    prev_data = client.get_CSV(loc)
    merged_data = pd.merge(prev_data, new_data, on=['Airport', 'Province'], how='outer').fillna(0)
    return merged_data   

def update_report(basename: str, new_report, month, year):
    s3client = S3Client.get_client()
    CSV_bytes = new_report.to_csv(index=False).encode("utf-8")
    CSV_buffer = io.BytesIO(CSV_bytes)
    report_loc = S3Location(
        #Stage.PRE_RELEASE.value.bucket,
        DEFAULT_BUCKET,
        S3.prefix(
            Stage.PRE_RELEASE,
            Mode.file,
            DataSource.pik_report,
            year=year,
            month=month
        ).prefix,
        basename
    )
    s3client.put_loc(
        report_loc, CSV_buffer, len(CSV_bytes), content_type="application/csv"
    )
    return True


if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()
    date = args.date
    entrypoint(date)


