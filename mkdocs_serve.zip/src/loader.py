#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
from datetime import datetime
import re
import argparse
import importlib
from os.path import basename

import pandas as pd
from config.argo import ArgoStatusCodes

from modules.s3client import S3Client
from config.api import S3, Stage
from config.api import DataSource, S3Location
from config.api import AutoEnum
from modules.logger import MinIOLogger
from config.env import StatusCodeConfig
from enum import auto
from dataclasses import dataclass, asdict
from config.api import PatternRule
from config.api import LoadingRules


class Index(AutoEnum):
    loader = auto()


class Status(AutoEnum):
    archived = auto()
    error = auto()
    unknown = auto()
    matched = auto()


@dataclass
class FileEvent:
    status: Status = None
    src: S3Location = None
    dst: S3Location = None
    rule: PatternRule = None


from modules.utils.loaders import Uploader


def upload_filebased(loc: S3Location, stage: Stage, datasource: DataSource) -> bool:
    try:
        files = Uploader.copy_dir(loc, stage, datasource, fallback_on_historical=True)
        return True
    except:
        return False


def check_inbox(client: S3Client, loading_rule_matches: LoadingRules) -> None:
    """"""
    # List all the objects from the Stage.INBOX location
    objs = client.ls_objs(
        Stage.INBOX.value.bucket,
        recursive=True,
        prefix=Stage.INBOX.value.prefix,
        only_files=True,
        default_folder_file=False,
    )
    # Create a file event for every obj found in Stage.INBOX
    # By default their status is unknown and their dst is *error
    unmatched = []
    for obj in objs:
        status = Status.unknown.value
        src = S3.obj_to_loc(Stage.INBOX.value.bucket, obj.object_name)
        dst = S3.get_error_location(DataSource.unknown, basename(obj.object_name))
        rule = None
        unmatched.append(FileEvent(status=status, src=src, dst=dst, rule=rule))

    # Identify which files match each existing rule_matches.
    # Multiple files can match a rule, a file will only be assigned to a rule
    # the first one that it matches.
    rule_matches = {}
    rules = {}
    for idx, rule in enumerate(loading_rule_matches.get()):
        pattern = re.compile(rule.pattern)
        matches, nmatches = [], []
        for file in unmatched:
            if pattern.match(file.src.basename):
                file.status = Status.matched.value
                file.rule = rule
                matches.append(file)
            else:
                nmatches.append(file)
        unmatched = nmatches
        rule_matches[idx] = matches
        rules[idx] = rule

    # Iterate over all rule_matches and matches
    timebased = DataSource.timebased()
    for idx, matches in rule_matches.items():
        rule = rules[idx]
        # don't process rule_matches without matches or disabled
        if not matches or not rule.enabled:
            continue
        print("-" * 100)
        print("-" * 100)
        print(f"Rule: {rule}")
        datasource = DataSource[rule.datasource]
        tmp = S3.get_processing_location(datasource, "temp")
        print(f"\tCreating temp S3Location:\n\t\t{tmp.bucket}/{tmp.prefix}")
        print(f"\tCopying:")
        for file in matches:
            file.dst = S3Location(tmp.bucket, tmp.prefix, file.src.basename)
            client.cp_loc(file.src, file.dst)
            print(f"\t\t{file.src.basename}")
        if datasource in timebased and rule.entrypoint:
            module_path = f"datasource.{rule.datasource}.loader"
            module = importlib.import_module(module_path)
            print(f"\tExecuting Loader entrypoint:\n\t\t{matches[0].dst}")
            success = getattr(module, rule.entrypoint)(
                client, Stage[rule.stage], matches[0].dst
            )
        else:
            print(f"\tLoading File-Based Data Source : \n\t\t{datasource}")
            success = upload_filebased(matches[0].dst, Stage[rule.stage], datasource)
        print(f"\tRemoving temp S3Location:\n\t\t{tmp.bucket}/{tmp.prefix}*")
        client.rm(tmp.bucket, tmp.prefix, remove_dir=True)

        for file in matches:
            ERROR_PROCESSING_FILE = False
            if success:
                file.dst = S3.get_archive_location(datasource, file.src.basename)
                file.status = Status.archived.value
            else:
                file.dst = S3.get_error_location(datasource, file.src.basename)
                file.status = Status.error.value
                print(
                    f"\tError encountered with datasource {datasource.name} file {file.src.basename}, moving to error location."
                )
                ERROR_PROCESSING_FILE = True
            client.mv_loc(file.src, file.dst)
            print(f"\t\t{file.src.basename}")
            if ERROR_PROCESSING_FILE:
                print(f"exit on error: {file.src.basename}")
                ArgoStatusCodes.exit_error_location()

        # If there is conflict, for example, 55 e63 reports, we move all the reports to archive folder, since
        #   all files has been parsed correctly. Now we can exit with conflict code.
        if StatusCodeConfig().CONFLICT_LOCATION:
            print(f"exit on conflicts: {file.src.basename}")
            ArgoStatusCodes.exit_conflict()

    minio_logger = MinIOLogger.get_logger()
    files = [file for _, matches in rule_matches.items() for file in matches]
    files.extend(unmatched)
    print("\tLogging events to minio")
    unknown_dfs = []
    for file in files:
        # Display the file containing the error
        print(f"\t\t{file.src.basename}: {file.status}")
        # Move the error file from /inbox to the appropriate error location if it
        # is an unmatched file. Note that mv_loc will fail if we encounter a file
        # that is already matched. Note that we remove the files from unmatched once
        # it's moved out of the inbox.
        if any(x.src.basename == file.src.basename for x in unmatched):
            print(f"Moving unmatched file {file.src.basename} to {file.dst.prefix}")
            client.mv_loc(file.src, file.dst)
            unmatched.remove(file)
            # Log the unknown file to MinIO
            file.src = file.src._asdict()
            file.dst = file.dst._asdict()
            # Keep track of all unknown files that arrive in inbox
            unknown_dfs.append(pd.json_normalize(asdict(file)))
    # Log unknown files to MinIO to be validated
    if unknown_dfs:
        unknown_dfs = pd.concat(unknown_dfs)
        minio_logger.log_pandas(
            unknown_dfs, DataSource.check_inbox, "unknown_inbox_files", datetime.today()
        )
    client.mkdir(Stage.INBOX.value.bucket, Stage.INBOX.value.prefix)
    # If there was at least one file with an unknown name, exit with code 5.
    if isinstance(unknown_dfs, pd.DataFrame) and not unknown_dfs.empty:
        ArgoStatusCodes.exit_unknown_location()


if __name__ == "__main__":
    """
    --clean clears the cache/archived/error from the S3 storage
    """

    sclient = S3Client.get_client()

    parser = argparse.ArgumentParser(description="Loading")
    parser.add_argument(
        "--check-inbox",
        help="Indicate that you want to run check_inbox",
        action="store_true",
    )

    args = parser.parse_args()

    if args.check_inbox:
        check_inbox(sclient, LoadingRules.load())
