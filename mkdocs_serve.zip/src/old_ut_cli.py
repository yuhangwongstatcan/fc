#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from config.api import TestType
from config.api import DataSource
from tests.api import FCIntegrationTestSuite, FCUnitTestSuite


class CliTestRunner:
    TEST_API_ARGS = ["datasource", "name"]
    TEST_TYPES = {
        TestType.unit: FCUnitTestSuite,
        TestType.integration: FCIntegrationTestSuite,
    }

    def parse_args(self):
        parser = argparse.ArgumentParser()
        parser.add_argument(
            "-t",
            "--type",
            help="Test Type",
            type=str,
            choices=[t.value for t in TestType],
            required=True,
        )
        parser.add_argument(
            "-d",
            "--datasource",
            help="Data Source",
            type=str,
            choices=[t.value for t in DataSource],
        )
        parser.add_argument("-n", "--name", help="Test Name", type=str)
        parser.add_argument(
            "-v", "--verbose", help="Verbose Mode", type=bool, default=False
        )
        parser.add_argument(
            "-r",
            "--raise-exception",
            help="Raises an exception if any tests fail or encounter errors. Intended for use in CI pipeline.",
            action="store_true",
            default=False,
        )
        return parser.parse_args()

    @property
    def unit(self):
        return FCUnitTestSuite()

    @property
    def integration(self):
        return FCIntegrationTestSuite()

    def run(self):
        args = self.parse_args()

        test_suite = CliTestRunner.TEST_TYPES[TestType[args.type]]()

        args_dict = vars(args)
        api_args = {
            key: args_dict[key]
            for key in args_dict
            if key in CliTestRunner.TEST_API_ARGS
        }
        results = test_suite.run(**api_args)
        stats = results.test_stats

        print("Tests Run: ", stats.run_count)
        print("Successes: ", stats.successes)
        print("Failures: ", stats.failures)
        print("Errors: ", stats.errors)
        print("Skipped: ", stats.skipped)

        if args.verbose:
            print("-" * 80)
            for case_result in results.test_cases:
                print(case_result.status, case_result.message)
                print("-" * 80)

        if args.raise_exception:
            if stats.failures or stats.errors:
                print("\n" * 2, "\t" * 4, "FAILED TEST CASES", "\n" * 2)
                for case in results.test_cases:
                    if case.message != "":
                        print(
                            f"{case.name} finished with status {case.status.value.upper()}.\n\n"
                        )
                        print(case.message, "\n" * 5)
                raise Exception("At least one test did not pass.")


if __name__ == "__main__":
    test_runner = CliTestRunner()
    test_runner.run()
