from __future__ import annotations
import importlib
import json
import os
import datetime
from pathlib import Path
import pandas as pd
import numpy as np

from typing import Dict, Optional, Callable, List

from pytest_cases import parametrize
from pandas.testing import assert_frame_equal
from numpy.testing import assert_array_equal

from pydantic import BaseModel
from pydantic.types import FilePath
from pydantic.types import DirectoryPath

# When invoking a specific test with the VSCode testing GUI, the CWD defaults
# to the project root. In all cases, we want to make sure the test runner is invoked
# from the src folder.
test_cwd = Path(os.getcwd())
if "src" not in test_cwd.parts:
    os.chdir(Path(test_cwd, "src"))

from modules.utils.loaders import Loader

# Any custom modules need to be imported after we are certain the test runner is
# running from cwd = src
from config.api import Stage, DataSource

from datasource.travellers.schema import TransformedSchema

analysis_reports_path = Path(__file__).parent / "analysis_reports"


class FCAnalysisTestConfig(BaseModel):
    """
    A pydantic model for the FC analysis reports test configuration.
    """

    test_name: str
    test_folder_path: DirectoryPath
    reference_periods: List[str]
    stage: str
    datasource: str
    report: str
    test_function: Callable
    output: List[str]
    parameters: Optional[List[int]]


def unit_test_generator(datasource_path: Path):
    """
    Generates cases for all of the unit tests at a given path.
    """
    for path in datasource_path.rglob("fctest.config.json"):
        # Test config path
        fc_test_config_path = FilePath.validate(value=path)
        # Test folder path
        test_folder_path = DirectoryPath.validate(fc_test_config_path.parent)
        # Test name
        test_name = fc_test_config_path.parent.stem
        # Load the test config into a dictionary
        fc_test_config: Dict[str, str] = json.loads(
            Path(fc_test_config_path).read_text()
        )

        test_function_module_parts = [
            "analysis_reports",
            "data_processing",
            fc_test_config["report"],
        ]

        test_function_module_str = ".".join(test_function_module_parts)
        test_function_module = importlib.import_module(test_function_module_str)

        # Get the function under test
        test_function = getattr(test_function_module, fc_test_config["test_function"])

        fc_test_config["test_function"] = test_function

        yield FCAnalysisTestConfig(
            test_name=test_name, test_folder_path=test_folder_path, **fc_test_config
        )


def run_test_case(test_case_instance):
    df_list = []

    for reference_period in test_case_instance.reference_periods:
        df_list.append(
            Loader.query(
                stage=Stage[test_case_instance.stage],
                datasource=DataSource[test_case_instance.datasource],
                year=int(reference_period[:4]),
                month=int(reference_period[4:]),
            )
        )

    input_df = TransformedSchema(pd.concat(df_list))

    # Handle extra parameters being passed to the function
    if test_case_instance.parameters is not None:
        function_output = test_case_instance.test_function(
            input_df, *test_case_instance.parameters
        )
    else:
        function_output = test_case_instance.test_function(input_df)

    # We can flatten the output dictionary because order doesn't matter here
    report_rows = function_output.reports
    reports = [report for d in report_rows for report in d.values()]

    for i, actual_output in enumerate(reports):
        # # For generating test data
        # actual_output = actual_output.astype(str)

        # actual_output.to_csv(
        #     Path(test_case_instance.test_folder_path, test_case_instance.output[i]),
        #     index=True,
        # )

        # For evaluating tests
        actual_output = (actual_output.fillna(-1).astype(str).reset_index()).values

        # To be implemented when actually testing
        expected_output = pd.read_csv(
            Path(test_case_instance.test_folder_path, test_case_instance.output[i]),
            index_col=0,
            dtype=str,
        )


        expected_output = (expected_output.fillna(-1).astype(str).reset_index()).values
        assert_array_equal(actual_output, expected_output)


@parametrize(test_case_instance=unit_test_generator(Path(analysis_reports_path)))
def test_cad_reports(test_case_instance):
    run_test_case(test_case_instance)
