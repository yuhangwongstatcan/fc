"""

    Program: prune_leading_ndm_files.py

    Author: Jacob Doering (jacob.doering@statcan.gc.ca)

    Last Update: April 2023

    Purpose: Single-use program to prune the NDM loading files for the Leading tables.
    As part of the NDM refactor, aggregate series are added to the Leading tables
    57, 58 and 59, but the rerun of the historical data included all series.

    This program is used to remove any vectors that are not touched by the new series.

"""

import pandas as pd

from dotenv import load_dotenv
import os

load_dotenv()

ACCOUNT_NAME = os.environ.get("ACCOUNT_NAME")
ACCOUNT_KEY = os.environ.get("ACCOUNT_KEY")
storage_options = {"account_name": ACCOUNT_NAME, "account_key": ACCOUNT_KEY}

TABLE = "57"

AFFECTED_MONTHS = [
    "201701",
    "201702",
    "201703",
    "201704",
    "201705",
    "201706",
    "201707",
    "201708",
    "201709",
    "201710",
    "201711",
    "201712",
    "201801",
    "201802",
    "201803",
    "201804",
    "201805",
    "201806",
    "201807",
    "201808",
    "201809",
    "201810",
    "201811",
    "201812",
    "201901",
    "201902",
    "201903",
    "201904",
    "201905",
    "201906",
    "201907",
    "201908",
    "201909",
    "201910",
    "201911",
    "201912",
    "202001",
    "202002",
    "202003",
    "202004",
    "202005",
    "202006",
    "202007",
    "202008",
    "202009",
    "202010",
    "202011",
    "202012",
    "202101",
    "202102",
    "202103",
    "202104",
    "202105",
    "202106",
    "202107",
    "202108",
    "202109",
    "202110",
    "202111",
    "202112",
]

for item in AFFECTED_MONTHS:
    YEAR = int(item[0:4])
    MONTH = item[4:6]

    df = pd.read_csv(
        f"az://fc-bucket/z_ndm_refactor/aggregated/ndm_241000{TABLE}/{YEAR}/{MONTH}/{YEAR}{MONTH}.csv",
        storage_options=storage_options,
        keep_default_na=False,
        na_values="",
    )

    # Exclusion conditions
    if TABLE == "57":
        EXCLUSION_CONDITION = ~(
            (df["dim3"] != 4) & (df["dim4"] != 4) & (df["dim5"] != 3)
        )
    if TABLE == "58":
        EXCLUSION_CONDITION = ~(
            (df["dim1"] < 125) & (df["dim2"] < 65) & (df["dim3"] != 4)
        )
    if TABLE == "59":
        EXCLUSION_CONDITION = ~((df["dim1"] < 119) & (df["dim2"] < 65))

    df = df[EXCLUSION_CONDITION]

    df.to_csv(
        f"az://fc-bucket/z_ndm_refactor/FOR_PROD/aggregated/ndm_241000{TABLE}/{YEAR}/{MONTH}/{YEAR}{MONTH}.csv",
        storage_options=storage_options,
        index=False,
    )
