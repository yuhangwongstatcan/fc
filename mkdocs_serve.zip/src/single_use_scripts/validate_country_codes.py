"""

    Program: change_country_codes.py

    Author: Jacob Doering (jacob.doering@statcan.gc.ca)

    Last Update: April 2023

    Purpose: Single-use program to update erroneous country codes in various
    historical data files. Countries were originally classified in the incorrect
    continent or region.

"""

import pandas as pd

from dotenv import load_dotenv
import os

load_dotenv()

ACCOUNT_NAME = os.environ.get("ACCOUNT_NAME")
ACCOUNT_KEY = os.environ.get("ACCOUNT_KEY")
storage_options = {"account_name": ACCOUNT_NAME, "account_key": ACCOUNT_KEY}

STAGE = "clean"
DATASOURCE = "e311"

if STAGE == "aggregated" or STAGE == "transformed":
    AFFECTED_MONTHS = [
        "201801",
        "201802",
        "201803",
        "201804",
        "201805",
        "201807",
        "201809",
        "201902",
        "201906",
        "201907",
        "201908",
        "201910",
        "202003",
        "202004",
        "202010",
        "202011",
        "202203",
        "202204",
        "202205",
        "202206",
        "202208",
        "202210",
    ]
else:
    AFFECTED_MONTHS = [
        "202203",
        "202204",
        "202205",
        "202206",
        "202208",
        "202210",
    ]

for item in AFFECTED_MONTHS:

    YEAR = int(item[0:4])
    MONTH = item[4:6]

    if STAGE == "aggregated":
        try:
            prev_df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values="",
            )
            current_df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/FOR_PROD/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values="",
            )
        except FileNotFoundError:
            continue
    elif STAGE == "transformed":
        try:
            prev_df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/{STAGE}/travellers/{YEAR}/{MONTH}/{YEAR}{MONTH}01.{DATASOURCE}.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values="",
            )
            current_df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/FOR_PROD/{STAGE}/travellers/{YEAR}/{MONTH}/{YEAR}{MONTH}01.{DATASOURCE}.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values="",
            )
        except FileNotFoundError:
            continue
    else:
        try:
            prev_df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}01.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values=".",
            )
            current_df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/FOR_PROD/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}01.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values=".",
            )
        except FileNotFoundError:
            continue

    prev_df = prev_df.astype(str)
    current_df = current_df.astype(str)

    print(prev_df.compare(current_df))
