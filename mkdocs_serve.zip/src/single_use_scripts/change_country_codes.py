"""

    Program: change_country_codes.py

    Author: Jacob Doering (jacob.doering@statcan.gc.ca)

    Last Update: April 2023

    Purpose: Single-use program to update erroneous country codes in various
    historical data files. Countries were originally classified in the incorrect
    continent or region.

"""

import pandas as pd

from dotenv import load_dotenv
import os

load_dotenv()

ACCOUNT_NAME = os.environ.get("ACCOUNT_NAME")
ACCOUNT_KEY = os.environ.get("ACCOUNT_KEY")
storage_options = {"account_name": ACCOUNT_NAME, "account_key": ACCOUNT_KEY}

STAGE = "transformed"
DATASOURCE = "e63"

if STAGE == "aggregated" or STAGE == "transformed":
    AFFECTED_MONTHS = [
        "201801",
        "201802",
        "201803",
        "201804",
        "201805",
        "201807",
        "201809",
        "201902",
        "201906",
        "201907",
        "201908",
        "201910",
        "202003",
        "202004",
        "202010",
        "202011",
        "202203",
        "202204",
        "202205",
        "202206",
        "202208",
        "202210",
        "202211",
        "202212",
        "202301",
        "202302",
    ]
else:
    AFFECTED_MONTHS = [
        "202203",
        "202204",
        "202205",
        "202206",
        "202208",
        "202210",
        "202211",
        "202212",
        "202301",
        "202302",
    ]

for item in AFFECTED_MONTHS:

    YEAR = int(item[0:4])
    MONTH = item[4:6]

    if STAGE == "aggregated":
        try:
            df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values="",
            )
        except FileNotFoundError:
            continue

    elif STAGE == "transformed":
        try:
            df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/{STAGE}/travellers/{YEAR}/{MONTH}/{YEAR}{MONTH}01.{DATASOURCE}.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values="",
            )
        except FileNotFoundError:
            continue
    else:
        try:
            df = pd.read_csv(
                f"az://fc-bucket/z_ndm_refactor/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}01.csv",
                storage_options=storage_options,
                keep_default_na=False,
                na_values=".",
            )
        except FileNotFoundError:
            continue

    if STAGE == "aggregated" or STAGE == "transformed":
        df = df.astype(str).astype({"count_of_entries": "Int64"})

    if STAGE == "clean" and DATASOURCE == "e311":

        df["country_code"] = df["country_code"].replace(
            ["44086", "51162", "51166", "51574"], ["32086", "53162", "53166", "52574"],
        )

    else:

        df["country_of_residence"] = df["country_of_residence"].replace(
            ["44086", "51162", "51166", "51574"], ["32086", "53162", "53166", "52574"],
        )

    if STAGE == "aggregated":
        df.to_csv(
            f"az://fc-bucket/z_ndm_refactor/FOR_PROD/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}.csv",
            storage_options=storage_options,
            index=False,
        )
    elif STAGE == "transformed":
        df.to_csv(
            f"az://fc-bucket/z_ndm_refactor/FOR_PROD/{STAGE}/travellers/{YEAR}/{MONTH}/{YEAR}{MONTH}01.{DATASOURCE}.csv",
            storage_options=storage_options,
            index=False,
        )
    else:
        df.to_csv(
            f"az://fc-bucket/z_ndm_refactor/FOR_PROD/{STAGE}/{DATASOURCE}/{YEAR}/{MONTH}/{YEAR}{MONTH}01.csv",
            storage_options=storage_options,
            index=False,
        )
