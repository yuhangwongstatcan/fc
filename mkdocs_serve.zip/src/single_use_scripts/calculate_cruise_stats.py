"""
RUN FROM src/

To fill custom request:

1). We don’t seem to have cruise-specific data for April to September 2019 in table 53, apparently only mode ‘water.’  
Is there a way to get this level of detail?  I am looking specifically for percentages of the total cruise arrivals on 
the west coast, east coast, and Arctic cost POEs (I think ‘Arctic’ just refers to Pond Inlet and Iqaluit) into Canada.  
Totals are fine (doesn’t need to be split between US / OVS / CAN res).  West coast SHOULD be something like 90% of all 
arrivals but again, I can’t seem to find this info for 2019.
"""

import os
import pandas as pd
from dotenv import load_dotenv
from openpyxl import Workbook

from modules.utils.loaders import Loader
from config.api import DataSource, Stage
from datasource.travellers.schema import TransformedSchema
from datasource.provinces_and_territories.schema import ReferenceSchema as PTSchema


#  ____                                _
# |  _ \ __ _ _ __ __ _ _ __ ___   ___| |_ ___ _ __ ___
# | |_) / _` | '__/ _` | '_ ` _ \ / _ \ __/ _ \ '__/ __|
# |  __/ (_| | | | (_| | | | | | |  __/ ||  __/ |  \__ \
# |_|   \__,_|_|  \__,_|_| |_| |_|\___|\__\___|_|  |___/

load_dotenv()

year = "2019"

months = [
    "04",
    "05",
    "06",
    "07",
    "08",
    "09",
]

grouping_1 = {
    "East": [
        "Newfoundland and Labrador",
        "Prince Edward Island",
        "Nova Scotia",
        "New Brunswick",
        "Quebec",
    ],
    "West": ["British Columbia"],
    "North": ["Yukon", "Northwest Territories", "Nunavut"],
    "Interior": ["Ontario", "Manitoba", "Saskatchewan", "Alberta"],
}


grouping_2 = {
    "East": [
        "Newfoundland and Labrador",
        "Prince Edward Island",
        "Nova Scotia",
        "New Brunswick",
        "Quebec",
        "Ontario",
    ],
    "West": ["British Columbia", "Manitoba", "Saskatchewan", "Alberta"],
    "North": ["Yukon", "Northwest Territories", "Nunavut"],
}


#   ____      _            _       _   _
#  / ___|__ _| | ___ _   _| | __ _| |_(_) ___  _ __  ___
# | |   / _` | |/ __| | | | |/ _` | __| |/ _ \| '_ \/ __|
# | |__| (_| | | (__| |_| | | (_| | |_| | (_) | | | \__ \
#  \____\__,_|_|\___|\__,_|_|\__,_|\__|_|\___/|_| |_|___/


output_store = {}

provinces = Loader.get(Stage.REFERENCE, DataSource.provinces_and_territories, None)
provinces = PTSchema(provinces)


for ref_month in months:
    data = Loader.query(
        Stage.AGGREGATED, datasource=DataSource.travellers, year=year, month=ref_month
    )
    data = TransformedSchema(data)

    vehicle_filter = data[TransformedSchema.vehicle_type] == "311"  # Cruise ship
    traveller_filter = data[TransformedSchema.traveller_type].isin(
        ["1", "2"]
    )  # Exclude other travellers

    data = data[vehicle_filter & traveller_filter]

    necessary_cols = [
        TransformedSchema.year,
        TransformedSchema.month,
        TransformedSchema.port,
        TransformedSchema.count_of_entries,
    ]  # Only keep necessary cols

    data = data[necessary_cols]

    data["sgc_code"] = data[TransformedSchema.port].str[:2]

    data = pd.merge(data, provinces, on="sgc_code")

    data = data[["count_of_entries", "province_territory_en"]]

    output = data.groupby("province_territory_en").sum().reset_index()

    output_store[ref_month] = output.copy()


#  _____                          _   _   _                               _
# |  ___|__  _ __ _ __ ___   __ _| |_| |_(_)_ __   __ _    __ _ _ __   __| |
# | |_ / _ \| '__| '_ ` _ \ / _` | __| __| | '_ \ / _` |  / _` | '_ \ / _` |
# |  _| (_) | |  | | | | | | (_| | |_| |_| | | | | (_| | | (_| | | | | (_| |
# |_|  \___/|_|  |_| |_| |_|\__,_|\__|\__|_|_| |_|\__, |  \__,_|_| |_|\__,_|
#                                                 |___/
#  _____              _
# | ____|_  _____ ___| |
# |  _| \ \/ / __/ _ \ |
# | |___ >  < (_|  __/ |
# |_____/_/\_\___\___|_|

output_flat = (
    pd.concat(output_store)
    .reset_index()
    .drop("level_1", axis=1)
    .rename(
        {
            "level_0": "Month",
            "province_territory_en": "Geography",
            "count_of_entries": "Count of Entries",
        },
        axis=1,
    )
)

ungrouped_output = output_flat.pivot(
    columns="Month", index="Geography", values="Count of Entries"
)
ungrouped_output.to_csv("ungrouped.csv", index=True)

reverse_group_1 = {value: key for key, values in grouping_1.items() for value in values}
output_flat["Geography 1"] = output_flat["Geography"].replace(reverse_group_1)
group_1_output = (
    output_flat[["Month", "Geography 1", "Count of Entries"]]
    .groupby(["Month", "Geography 1"])
    .sum()
    .reset_index()
    .pivot(columns="Month", index="Geography 1", values="Count of Entries")
)
group_1_output.to_csv("grouping_1.csv")

reverse_group_2 = {value: key for key, values in grouping_2.items() for value in values}
output_flat["Geography 2"] = output_flat["Geography"].replace(reverse_group_2)
group_2_output = (
    output_flat[["Month", "Geography 2", "Count of Entries"]]
    .groupby(["Month", "Geography 2"])
    .sum()
    .reset_index()
    .pivot(columns="Month", index="Geography 2", values="Count of Entries")
)
group_2_output.to_csv("grouping_2.csv")


print("All done")
