"""
RUN FROM src/

To fill custom request:

2). In which year did total cruise arrivals into Canada first surpass 1 million? I have no idea how to find this one if we even have it.
"""

import os
import pandas as pd
from dotenv import load_dotenv
from openpyxl import Workbook

from modules.utils.loaders import Loader
from config.api import DataSource, Stage
from datasource.travellers.schema import TransformedSchema
from datasource.provinces_and_territories.schema import ReferenceSchema as PTSchema


#  ____                                _
# |  _ \ __ _ _ __ __ _ _ __ ___   ___| |_ ___ _ __ ___
# | |_) / _` | '__/ _` | '_ ` _ \ / _ \ __/ _ \ '__/ __|
# |  __/ (_| | | | (_| | | | | | |  __/ ||  __/ |  \__ \
# |_|   \__,_|_|  \__,_|_| |_| |_|\___|\__\___|_|  |___/

load_dotenv()

years = range(2000, 2023)

all_months = [
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "08",
    "09",
    "10",
    "11",
    "12",
]

season_months = [
    "04",
    "05",
    "06",
    "07",
    "08",
    "09",
]


#   ____      _            _       _   _
#  / ___|__ _| | ___ _   _| | __ _| |_(_) ___  _ __  ___
# | |   / _` | |/ __| | | | |/ _` | __| |/ _ \| '_ \/ __|
# | |__| (_| | | (__| |_| | | (_| | |_| | (_) | | | \__ \
#  \____\__,_|_|\___|\__,_|_|\__,_|\__|_|\___/|_| |_|___/


output_store = {}

provinces = Loader.get(Stage.REFERENCE, DataSource.provinces_and_territories, None)
provinces = PTSchema(provinces)

all_data = {}

for year in years:
    year_data = {}
    for month in all_months:
        data = Loader.query(
            Stage.AGGREGATED, datasource=DataSource.travellers, year=year, month=month
        )
        try:
            data = TransformedSchema(data)
        except Exception:
            # Adding an exception for bad dates in 2022
            data = data[data["country_of_residence"].astype(str).str.len() == 5]
            data = TransformedSchema(data)

        vehicle_filter = data[TransformedSchema.vehicle_type] == "311"  # Cruise ship
        traveller_filter = data[TransformedSchema.traveller_type].isin(
            ["1", "2"]
        )  # Exclude other travellers

        data = data[vehicle_filter & traveller_filter]

        necessary_cols = [
            TransformedSchema.year,
            TransformedSchema.month,
            TransformedSchema.port,
            TransformedSchema.count_of_entries,
        ]  # Only keep necessary cols

        data = data[necessary_cols]

        year_data[month] = int(data[TransformedSchema.count_of_entries].sum())

    all_data[str(year)] = year_data.copy()

data_list = [
    {"year": year, "month": month, "count": count}
    for year, months in all_data.items()
    for month, count in (
        months.items() if isinstance(months, dict) else [(None, months)]
    )
]

# Create a DataFrame from the list of dictionaries
df = pd.DataFrame(data_list)

df.to_csv("monthly_cruise_counts.csv", index=False)
df.groupby("year").sum().to_csv("yearly_cruise_counts.csv")
df[df["month"].isin(season_months)].groupby("year").sum().to_csv(
    "yearly_cruise_counts_in_season.csv"
)
