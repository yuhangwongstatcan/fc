import os
import pandas as pd
import hashlib
from dotenv import load_dotenv
from azure.storage.blob import ContainerClient
from azure.core.credentials import AzureNamedKeyCredential

load_dotenv()

ALPHA_ACCOUNT_NAME = os.getenv("ALPHA_ACCOUNT_NAME")
ALPHA_ACCOUNT_KEY = os.getenv("ALPHA_ACCOUNT_KEY")

PROD_ACCOUNT_NAME = os.getenv("PROD_ACCOUNT_NAME")
PROD_ACCOUNT_KEY = os.getenv("PROD_ACCOUNT_KEY")

alpha_credential = AzureNamedKeyCredential(
    name=ALPHA_ACCOUNT_NAME, key=ALPHA_ACCOUNT_KEY
)
prod_credential = AzureNamedKeyCredential(name=PROD_ACCOUNT_NAME, key=PROD_ACCOUNT_KEY)

alpha_options = {"account_name": ALPHA_ACCOUNT_NAME, "account_key": ALPHA_ACCOUNT_KEY}
prod_options = {"account_name": PROD_ACCOUNT_NAME, "account_key": PROD_ACCOUNT_KEY}

alpha_client = ContainerClient(
    credential=alpha_credential,
    account_url=f"https://{ALPHA_ACCOUNT_NAME}.blob.core.windows.net",
    container_name="fc-bucket",
)

prod_client = ContainerClient(
    credential=prod_credential,
    account_url=f"https://{PROD_ACCOUNT_NAME}.blob.core.windows.net",
    container_name="fc-bucket",
)


with open("azure_list.txt", "r") as f:
    for line in f:
        alpha_iterlist = {
            blob.name: blob.content_settings.content_md5
            for blob in alpha_client.list_blobs(line.strip())
            if blob.content_settings.content_md5
        }
        alpha_bigfiles = [
            blob.name
            for blob in alpha_client.list_blobs(line.strip())
            if not (blob.content_settings.content_md5)
            and blob.content_settings.content_type
        ]
        prod_iterlist = {
            blob.name: blob.content_settings.content_md5
            for blob in prod_client.list_blobs(line.strip())
            if blob.content_settings.content_md5
        }
        prod_bigfiles = [
            blob.name
            for blob in prod_client.list_blobs(line.strip())
            if not (blob.content_settings.content_md5)
            and blob.content_settings.content_type
        ]
        for k, _ in alpha_iterlist.items():
            if k not in alpha_iterlist.keys() or k not in prod_iterlist.keys():
                with open("key_not_in_alpha_or_prod.txt", "a") as f:
                    f.write(f"{k}\n")
            elif alpha_iterlist[k] == prod_iterlist[k]:
                with open("same_checksum.txt", "a") as f:
                    f.write(f"{k}\n")
            else:
                with open("different_checksum.txt", "a") as f:
                    f.write(f"{k}\n")
        for l, _ in prod_iterlist.items():
            if l not in alpha_iterlist.keys():
                with open("key_not_in_alpha_or_prod.txt", "a") as f:
                    f.write(f"{l}\n")
        for m in alpha_bigfiles:
            if m not in prod_bigfiles:
                with open("key_not_in_alpha_or_prod.txt", "a") as f:
                    f.write(f"{m}\n")
            else:
                alpha = pd.read_csv(
                    f"az://fc-bucket/{m}", storage_options=alpha_options
                )
                alpha_cksum = hashlib.sha1(
                    pd.util.hash_pandas_object(alpha).values
                ).hexdigest()
                prod = pd.read_csv(f"az://fc-bucket/{m}", storage_options=prod_options)
                prod_cksum = hashlib.sha1(
                    pd.util.hash_pandas_object(prod).values
                ).hexdigest()
                if alpha_cksum == prod_cksum:
                    with open("same_checksum.txt", "a") as f:
                        f.write(f"{m}\n")
                else:
                    with open("different_checksum.txt", "a") as f:
                        f.write(f"{m}\n")
