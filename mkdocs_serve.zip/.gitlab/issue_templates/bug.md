## Summary

(Summarize the bug encountered concisely)

## Steps to reproduce

(How one can reproduce the issue - this is **very** important - please include information like which environment the bug occurred in, under what circumstances did the error occur (e.g. data source, pipeline stage, year, month, etc.), etc.)

## What is the current bug behavior?

(What actually happens)

## What is the expected correct behavior?

(What you should see instead)

## Relevant logs and/or screenshots

(Paste any relevant logs - please use code blocks (```) to format console output, logs, and code, as it's very hard to read otherwise.)

## Possible fixes

(If you can, link to the line(s) of code that might be responsible for the problem)
