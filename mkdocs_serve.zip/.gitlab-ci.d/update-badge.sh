#!/bin/bash


jq --version || apk add --no-cache jq
if ! jq --version; then
    apt-get update && apt-get install -y jq
fi

curl --version || apk add --no-cache curl
if ! curl --version; then
    apt-get update && apt-get install -y curl
fi

BADGE_ARG=$1

set -e

# Make sure the env vars are visible.
if test -z "$CI_REPOSITORY_URL"; then  
    echo "Variables not set" 
    exit 1
fi

BASE="$CI_PROJECT_URL"
BADGE="$BASE/-/jobs/$CI_JOB_ID/artifacts/raw/public"
API=$CI_API_V4_URL/projects/$CI_PROJECT_ID/badges

get_badge_id () {
    curl -X GET --form "token=$TOKEN" "$API" |
        tee /dev/stderr |
        jq --arg BADGE_ARG "$BADGE_ARG" '.[] | select(.image_url | contains($BADGE_ARG)) | .id' |
        sed '1q'
}

badge_id=$(get_badge_id "$BADGE_ARG")
test -z "$badge_id" && METHOD=POST || METHOD=PUT

echo
echo "ENDPOINT: $API/$badge_id"
echo

curl -X $METHOD \
    --header "PRIVATE-TOKEN: $TOKEN" \
    --data "image_url=$BADGE/$BADGE_ARG/$BADGE_ARG.svg&link_url=$BADGE/$BADGE_ARG/$BADGE_ARG.log" \
    "$API/$badge_id"

