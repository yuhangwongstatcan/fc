# Pydantic will fail automatically if these environment variables aren't declared.
# They neeed not hold the real values, but they must be defined in the process.
export $(grep -v '^#' src/default.env | xargs echo)
# This is a fake token that has the value "TEST".
export WEBAPP_SERVICE_ACCOUNT_JWT="$(pwd)/src/config/token"
# Run mkdocs serve to build the docs site + run the development server.
mkdocs serve
