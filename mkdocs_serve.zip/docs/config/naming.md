# Naming Conventions

!!! abstract
    The purpose of this page is to identify certain naming conventions we use throughout the project. Various parts of the system rely on following certain naming conventions, so it is important to consult them as needed.

## General Decisions

1. For data source naming, we will include the underscore in the name.

__Examples:__

the IPIL HWY is named `ipil_hwy` and ENTRY EXIT is named `entry_exit`


2. For the business rules, validations, or anything that is numbered, we will separate by a single underscore between the name and the number. Examples:

`ipil_hwy_001` or `ipil_hwy_008v`

| Data Source Name | As a Business Rule | As a Validation | As a Unit Test                            | As an Integration Test            |
| ---------------- | ------------------ | --------------- | ----------------------------------------- | --------------------------------- |
| `ipil_hwy`       | `ipil_hwy_010`     | `ipil_hwy_v010` | `ipil_hwy_010__u01`  `ipil_hwy_v010__u01` | `ipil_hwy__PipelineRawClean__i01` |

**rule:** whenever we make an enumerator for file names, by default we do **not** include an extension (i.e. it is up to the programmer to add the extension to the string returned by the enumerator.

**rule** Module namespaces should be singular always. Examples:

`/datasource/ipil_hwy/business_rule` not `/datasources/ipil_hwy/business_rules/`

## For column names

Everything will be snake case + alphanumeric characters only.
Any discrepancies between the schema of the incoming data and what we expect will be resolved at load time (i.e. in the loader.py module of the given data source.
If there is a discrepancy between the two, we can fail and indicate the difference in column naming. There will be some indication provided to the production user and a person will investigate further to resolve the issue.


## Tabular Data in Azure using .csv

As part of naming conventions, all the tabular data stored in Azure will be using the .csv extension instead of .dat. There is no semantic difference, it was more of a legacy naming convention that can be removed for easy access and unifying all data sources storage.

## Dimensions

Common dimension files can be found in `src/datasource/common/dim.py` while datasource-specific dimension files can be found in `src/datasource/{datasource}/dim.py`.

## Mappings

See [mapping reference file]({{fc_baseurl.doc}}/reference/mapping) documentation for information about this reference file.

The naming convention for mapping files is the following: `map__<data source 1>__<stage 1>__<column 1>__<data source 2>__<stage 2>__<column 2>.csv`, where the data source may either be time-based or a reference file.
