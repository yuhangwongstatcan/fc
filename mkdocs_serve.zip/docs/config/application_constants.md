# Constants

In an attempt to split up the main application configuration, a separate module in `src/config` exists for the purpose of storing constants.

::: config.constants