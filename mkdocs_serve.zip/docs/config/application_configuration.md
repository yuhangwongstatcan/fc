# Main Application Configuration

The module `config/api.py` contains enumerators, factories, and proxy classes that relate to application-level configuration details.

::: config.api.DEFAULT_BUCKET

::: config.api.DATE_FORMAT

::: config.api.DATETIME_STR_FORMAT

::: config.api.TIME_BASE_DATASOURCE_PATTERN

::: config.api.CURRENT_YEAR_THRESHOLD

::: config.api.PREV_YEAR_THRESHOLD

::: config.api.AutoEnum

::: config.api.ConfigFile

::: config.api.NDMValidations

::: config.api.Stage

::: config.api.DataSource

::: config.api.OutputFile

::: config.api.Mapping

::: config.api.WorkLocationsTransportation

::: config.api.WorkLocationsAction

::: config.api.WorkLocationsTransAction

::: config.api.GroupByAggTypes

::: config.api.OutputType

::: config.api.FixedProportionVars

::: config.api.RuleOutput

::: config.api.S3