The clients are able to access data from the Network A file share servers via network attached storage through the cloud workstations.

To access the file share server, open the Windows File explorer and enter the following in the search bar: `\\fld<#>filer.statcan.ca\`, where `<#>` is the number of the file share server you need access to.

You will then be prompted to enter your Network A credentials. In the username field, put `STATCAN\<7 character user name>` (e.g. `smitjoh` instead of `john.smith`), and for the password put your **Network A password**.