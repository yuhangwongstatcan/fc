# Documentation Site

## Running locally for development
Run `bash mkdocs_serve.sh` at the project root - this will build the docs site and run it with the development server. There are a few environment variables that must be set in order for Pydantic to not throw runtime errors. This shell script hides these details from the developer.

## Add a new page
- Create a markdown document in the `docs` folder.
- Add the path to this document to `mkdocs.yml` in the project root under the `nav` heading.
- The website index follows the hierarchical structure specified under `nav`.

## Docstring Generation

Throughout this project, we use the [audoDocstring - Python Docstring Generator](https://marketplace.visualstudio.com/items?itemName=njpwerner.autodocstring) extension.

![Docstring Generation GIF](../img/gif/docstring.gif)
