!!! Out of date
    Unfortunately, this article has become out of date and refers to the pre-2022 schema refactor system. The new system should be much easier to configure, but the general overview of how a datasource fits into the system in this article is still good.  
    Refer to the existing data sources for examples of how things should be organised as well as the testing documentation, and you should be in a good spot to add a new datasource to the system. 


> **author(s):** collin brown - collin.brown@canada.ca

> **created on:** April 7, 2021

# Adding a New Data Source

This section of documentation reviews all of the steps required to add a new data source.

## High Level Overview

The diagram below outlines how a data source moves through the system.

![Pipeline Context Diagram](../../img/pipeline-context-diagram.svg)

First, the data source arrives in an `inbox` location in object storage. At some point, a script is called that checks the inbox for files with names that match certain patterns.

If a file is matched, there is a loader script specific to that data source that specifies how the data should be processed and the location to which the incoming data should be triaged.

Once the data file is triaged, a series of pipelines operate on the data and move it between 3 stages of processing: a `PipelineRawClean` pipeline moves the data from the `RAW` stage to the `CLEAN` stage, and a `PipelineCleanTransformed` pipeline moves the data from the `CLEAN` stage to the `TRANSFORMED` stage. Once the data source has moved to the `TRANSFORMED` stage, it will be aggregated along with the remaining data sources.

## Create the prerequisite files for your data source

The code and configuration for every data source is specified under `src/datasource`. To add a new data source, first create a new folder under `src/datasource` named after the new data source.

An example of the directory structure for a new data source is as follows (from the `ipil_hwy` data source):

```bash
datasource/ipil_hwy
├── __init__.py
├── business_rule
├── clean.schema.json
├── loader.py
├── pipeline.py
├── pipelinecleantransformed.config.json
├── pipelinerawclean.config.json
├── raw.schema.json
├── utils.py
└── validation
```

- `__init__.py` indicates that all python files under this folder should be treated as Python modules.
- `business_rule` is a directory that contains all of the files with **code that mutates data** (i.e. the data processing logic).
- `validation` is a directory that contains all of the files with **code that produces validation logs** (i.e. the validation logic).
- `raw.schema.json` contains a JSON file with the schema of the raw data source input.
- `clean.schema.json` contains the JSON file with the schema of the data in its clean state.
- `pipelinerawclean.config.json` is a JSON file with the pipeline configuration for the pipeline that moves data between the `RAW` and `CLEAN` stage (i.e. `PipelineRawClean`).
- `pipelinecleantransformed.config.json` is a JSON file with the pipeline configuration for the pipeline that moves data between the `CLEAN` and `TRANSFORMED` stage (i.e. `PipelineCleanTransformed`).
- `loader.py` contains the code that is used by the loaderscript to load and triage the data.
- `pipeline.py` contains all of the pipeline class definitions.
- `utils.py` contains any utility/helper functions that are specific to this data source.

Each of these components is elaborated upon in further detail below.

## Create the Code Boilerplate

Much of the code for these files follows a fairly standard boilerplate (except, of course, for the specific data processing/validation logic unique to this data source). This boilerplate is outlined in the sections below.

### Pipelines

In the `pipeline.py` file described above, we create two classes for the new datasource: `PipelineRawClean` and `PipelineCleanTransformed`. Below is some boilerplate to start this file:

```python
"""
**Author(s)**

- [Maintainer(s) Name] - `[Maintainer(s) email]`

**Created On:** [date]

**Description:**

[Short description of what the module does]
"""
from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

# Import all of your validation here

from modules.pipeline import validation_wrapper  # Wrapper to contain validation functions when piping dataframe through operations.
from modules.utils.uid import PipelineUID  # Singleton class that generates the pipeline UID (used in logging)

from config.api import Stage  # Enumerator for each stage.
from config.api import DataSource  # Enumerator for each data source.
from config.api import S3  # Proxy class for generating locations in S3 object storage


class PipelineRawClean(BasePipeline):
    
    def pipeline(self):
        raise NotImplementedError


class PipelineCleanTransformed(BasePipeline):

    def pipeline(self):
        raise NotImplementedError
```

The `BasePipeline` class takes care of much of the repeated logic involved with pipelines. Typically, the maintainer should only need to override the `pipeline` method (this is where the code that is specific to this pipeline/data source goes). Any modification to the imported items are detailed below.

There is a `DataSource` enumerator class in the `config.api` module. This enumerator can be used to indicate the value of a particular data source. When a new data source is added, it should be added to this enumerator. A snippet below shows an example of a custom data source (`my_custom_datasource`) being added.

```python
class DataSource(AutoEnum):
    # ...
    my_custom_datasource = "my_custom_datasource"
    # ...
```

Now, whenever you need to refer to your new datasource you can use the enumerator rather than hard-coding the name of the data source. E.g. use `DataSource.my_custom_datasource` instead of `"my_custom_datasource"`.

### Business Rules

The `business_rule` folder, is structured as follows:

```
datasource/<your new data source>/business_rule
├── __init__.py
├── new_data_source_1
│   ├── __init__.py
│   ├── business_rule.py
│   ├── input_schema.json
│   └── output_schema.json
├── ...
├── new_data_source_N
│   ├── __init__.py
│   ├── business_rule.py
│   ├── input_schema.json
│   └── output_schema.json
```

The idea here is to break each piece of data processing logic into its own modular unit of modest size. Each "business rule" should contain one logical piece of data processing logic. The motivation for this organization is to avoid creating one giant monolithic data processing script for each data source (this would be very hard to debug and unit test).

- `__init__.py` indicates that this business rule is a python module.
- `business_rule.py` contains the implementation of a particular business rule.
- `input_schema.json` contains the expected schema of the input data.
- `output_schema.json` contains the expected schema of the output data.

**Note:** the reason for specifying `input_schema.json` and `output_schema.json` is that the data processing logic may change the schema (e.g. may add or remove a column).

Below is some boilerplate for each of the files above.

**`business_rule.py`**

```python
"""
**Author(s)**

- [Maintainer(s) Name] - `[Maintainer(s) Email]`

**Created On:** [date]

**Description:**

[Short description of what the module does.]
"""
import pandas as pd  # Everything is done with pandas dataframes

from config.api import DataSource  # Data source enumerator
from config.api import RuleOutput  # Wrapper for output(s) of the business rule
from config.api import ConfigFile  # Enumerator for names of configuration files

from schema.api import Schema
from schema.api import FuncParams  # helper function to load data source schemas

from tests.decorators import test_function  # decorator to associate this function with a unit test


@test_function
def <name of your unit test>(input: pd.DataFrame) -> RuleOutput:
    """
    **Author(s)**

    - [Maintainer(s) Name] - `[Maintainer(s) Email]`

    **Created On:** [date]

    **Description:**

    [description]

    Examples:
        
        [description]

    Args:
        input: pd.DataFrame
            [description]. Valid Values are [values]

    Returns:
        RuleOutput:
            [description]. Valid Values are [values]
    """
    # Get input schema for this validation
    schema = Schema.load_rule_schema(ipil_hwy00[i].__name__,FuncParams.input)
    # Your specific data processing logic goes here, E.g.
    input.loc[input[schema.country.name] == "CA", schema.country.name] = "CD"
    # Return the output as an instance of the RuleOutput dataclass
    return RuleOutput(output=input, datasource=DataSource.[your_new_datasource])
```

Note that `Schema.load_rule_schema()` expects (1) a data source enumerator (2) an integer indicating the number of the business rule and (3) a name from the `ConfigFile` enumerator indicating the name of the schema file. This information is required to dynamically import the schema at runtime.

Also note that the way we associated a function with a unit test is by adding a decorator with the name of the test. When tests are run, any function that has the `test_function` decorator is added to a dictionary that maps functions to test names. How the test runner works and how to add a test is outlined in more detail in the [unit test framework]({{fc_baseurl.doc}}/test/unit_test_framework.md) documentation.

The format of `input_schema.json` and `output_schema.json` looks as follows (example taken from the `ipil_hwy` data source):

```json
{
	"name": "ipil_hwy_002_input",
	"columns": [
		["vehi", "object"],
		["cdsd", "float64"],
		["cd1d", "float64"],
		["cd2d", "float64"],
		["ussd", "float64"],
		["us1d", "float64"],
		["us2d", "float64"],
		["osd", "float64"],
		["o1d", "float64"],
		["o2d", "float64"],
		["country", "object"],
		["date", "object"],
		["sin", "float64"],
		["sout", "float64"],
		["lane", "object"],
		["cport", "float64"],
		["province", "object"],
		["canpass1", "object"],
		["canpass2", "object"],
		["water_flag", "object"]
	],
	"keys": [
		"date",
		"sin" ,
		"cport",
		"lane"
	]
}
```

The `"name"` key indicates the name for this schema (naming convention is **"data source" + number of business rule + [input/output]**).

The `"columns"` key indicates the columns and types for each column. Note that this is implemented as an array of length-2 arrays - the first element contains the column name and the second element contains the column type (this refers to the name of the pandas `dtype` that this column will be stored as).

The `"keys"` key indicates the primary key(s) for this data source. The idea is that the combination of keys should uniquely identify each record (row) of the data source.

Output schema follows the same format, except the `"name"` should now contain the suffix `_output` to indicate that this is the output of a business rule rather than the input.

### validation

The `validation` folder is structured as follows:

```
datasource/<your new data source>/validation
├── __init__.py
├── new_data_source_v_1
│   ├── __init__.py
│   ├── input_schema.json
│   ├── output_schema.json
│   └── validation.py
├── ...
└── new_data_source_v_N
    ├── __init__.py
    ├── input_schema.json
    ├── output_schema.json
    └── validation.py
```

The files `input_schema.json` and `output_schema.json` follow the same format as described above. These schemas specify the schema of the input to the validation function and the schema of the output of the validation function, respectively.

**Note:** By design, a validation wraps a business rule (i.e. every business rule is called inside of a validation). The reason for this is that validation can produce logs about the data or about a particular data processing job. By wrapping the business rule, the validation can make use of the input/output of the business rule, and compare them where required. For example, if a validation requires reporting how many duplicates got removed by a business rule, the validation would need to look at the difference between the input and output dataframes to inspect how many duplicates were removed.

Below is some boilerplate for the `validation.py` file. Note that a small amount of business logic with `province_list` and `state_list` is included for illustrative purposes; of course, these arguments need not be present for every validation. However, an example may make the validation implementation more concrete/clear.

```python
import pandas as pd

from datasource.[new_data_source].business_rule import new_data_source_i as br  # Import the business rule that this validation wraps

from schema.api import Schema
from schema.api import FuncParams  # Helper to dynamically load schemas for validation

from config.api import DataSource  # Enumerator for data source
from config.api import RuleOutput  # Wrapper for outputs from validation/business rules

from config.api import ConfigFile  # Enumerator for configuration file names

from tests.decorators import test_function  # decorator to associate this function with a unit test


@test_function
def <your test name here>(
    input: pd.DataFrame, province_list: pd.DataFrame, state_list: pd.DataFrame
) -> RuleOutput:
    """
    **Author(s)**

    - [Maintainer(s) Name] - `[Maintainer(s) Email]`

    **Created On:** [date]

    **Description:**

    [description]

    Examples:
        [examples here]

    Args:
        input: pd.DataFrame
            [description]. Valid Values are [values]
        province_list: pd.DataFrame
            [description]. Valid Values are [values]
        state_list: pd.DataFrame
            [description]. Valid Values are [values]

    Returns:
        RuleOutput:
            [description]. Valid Values are [values]
    """
    # Convert tables to native python data structures where required.
    # TODO: update me
    # Get input schema for this validation
    schema = Schema.load_rule_schema("ipil_hwy_v002", FuncParams.input)
    # Include any validation logic before the business rule gets called. Assume that multiple
    # dataframes were created for validation purposes.
    # ...
    # Convention is to include all rows that are to be logged as validation as a dataframe named
    # groupby_df.
    groupby_df = pd.concat(
        [unexpected_vehi_df, unexpected_country_df, unexpected_province_df]
    )
    # Perform an aggregation + group by on the groupby_df. In this example, taking the COUNT
    # aggregation and grouping by several columns
    groupby_df = groupby_df.groupby(
        by=[
            "invalid_column",
            "date",
            "province",
            "vehi",
            "country",
            schema.cport.name,
            "unexpected_value",
        ],
        dropna=False,
        as_index=False,
    ).count()
    # Run the business rule and capture the output
    node_output = br(input)
    output = node_output.output
    # Store the output dataframe and the validation dataframe in an instance of RuleOutput and return
    return RuleOutput(
        output=output, validation=groupby_df, datasource=DataSource.ipil_hwy
    )

```

validation were designed to be quite flexible. You can add arbitrary validation logic before or after the business rule is called.

### Loaders

When the end users check the inbox, they trigger a loader script that inspects each file in the inbox (see `src/loader.py` for implementation details). When the loader identifies a file as belonging to a particular data source, it expects to find a callback function defined in `src/datasource/[data source name]/loader.py` (If such a function is found, it is dynamically imported by `src/loader.py` at runtime). Boilerplate for each datasource's loader function looks as follows:

**`src/datasource/[data source name]/loader.py`**

```python
from modules.s3client import S3Client  # Custom wrapper that extends the MinIO python client
from config.api import S3Location  # S3Location named tuple (this is how we represent S3 object storage locations)
from config.api import DataSource  # DataSource enumerator
from config.api import Stage  # Stage enumerator


def new_data_source_loader(
    minio_client: S3Client, location: S3Location
) -> bool:
    """
    **Author(s)**

    - [Maintainer(s) Name] - `[Maintainer(s) Email]`

    **Created On:** [date]

    **Description:**

    [description]

    Examples:

    Args:
        minio_client: S3Client
            [description]. Valid Values are [values]
        location: S3Location
            [description]. Valid Values are [values]

    Returns:
        bool:
            [description]. Valid Values are [values]
    """
    try:
        loc = minio_client.cp_loc_to_stage(
            location,
            Stage.RAW,
            DataSource.port_list_recode_mapping,
            basename=location.basename,
            fallback_on_conflicts=True,
        )
        print("DATA SOURCE SPECIFIC LOADER: ---------------------------------")
        print(f"moved: {location}")
        print(f"to: {loc}")
        return True
    except:
        return False

```

The loaders are intended to be very flexible. They can be simple (e.g. simply copy data from inbox to a specific destination S3 location) or complicated with custom logic for that data source (e.g. load the data into memory, sort on a column, and partition into `N` new files - see `src/datasource/ipil_hwy/loader.py` for a more complicated example).

Note that loaders are always called by passing an instance of `minio_client` and `location`, and are expected to return `True` or `False` - this means that the loader itself must implement any try-catch logic if there is a possibility that the loader will throw an exception (e.g. if the specified S3Location doesn't actually exist).

### Utilities and Helpers

For any logic that is reusable within a data source (but not reusable across data sources), the intended place to put such code is in `src/datasource/[new data source]/utils.py`. The idea is to avoid duplicating any logic that can be shared across code within a data source (e.g. 3 business rules may use the same helper method).

### Pipeline Configurations

There are two kinds of configuration files specified at the pipeline level: (1) pipeline dependency configurations (e.g. `pipelinerawclean.config.json`) and (2) input schema at the beginning of the pipeline (this indicates the expected schema that the data should have at the beginning of that stage of processing).

#### Pipeline Dependency Configurations

This is just a JSON file that follows the naming scheme **`pipeline{from stage}{to stage}.config.json`**. The purpose of this file is to indicate all of the dependencies for that pipeline along with metadata about where those dependencies can be found. Below is an example from the `ipil_hwy` data source.

```json
{
    "inputs": [
        {
            "stage": "raw",
            "datasource": "ipil_hwy"
        }
    ]
}
```

The **file_type** field indicates whether the data source is `time_based` (is it produced at a regular interval) or `file_based` (it can change over time, but it is not produced on a regular interval). The **stage** field indicates the stage of processing that each source can be found in (one of `raw`, `clean`, `transformed`, or `aggregated`). The **basename** field indicates the name of the file as it is stored in MinIO. Finally, the **datasource** field indicates the data source that the file belongs to.

From the fields specified above, there is enough information to automatically generate the `S3Location` where these data can be found. This means that once the configuration is provided, these `S3Location`s can be generated programmatically and the datasource can be loaded automatically from MinIO.

#### Pipeline Stage Schema Configuration

The format of these schema files are identical to the format of `input_schema.json` and `output_schema.json` described earlier in this document. The only difference is that the schemas at the pipeline level (e.g. `raw.schema.json`, `clean.schema.json`, etc.) indicate the expected schema at the beginning of that stage of processing.

## Putting it all together

Once you have written all of the validation, business rules, utilities, and the loader, you are ready to assemble all of these components together into a pipeline. The general pattern we follow for the pipelines is the following:

![Pipeline Overview Diagram](../../img/pipeline-diagram-1.svg)

The code organization is detailed in other parts of the documentation **(TODO: link these pages when they are ready)**, but there are a few details to point out here for clarity:

1. Every validation wraps a business rule. In other words, whenever a validation is run, it is assumed that the business rule that it wraps is also run. The reason for this is that these two pieces of logic are tightly coupled (a validation often operates on data before and after the business rule is run).

2. Business rule functions and validation functions themselves are **stateless** (they depend only on their arguments in a deterministic way). `validation_wrapper`, however, logs the validation data produced by the validation function to an Elasticsearch database.

3. The pipeline instance itself is stateful (it is an instance of a class that extends `src.modules.pipeline.BasePipeline` and it depends on configuration data). This implies that the business rule and validation functions can be easily unit tested (see [unit test framework]({{fc_baseurl.doc}}/test/unit_test_framework.md) documentation), while integration tests (i.e. tests for the entire pipeline) require mocking some context as well as an instance of Elasticsearch that can catch logs as the pipeline runs for the test.

4. `validation_wrapper` does two things: (1) it passes along the modified data produced by the business rule (2) it uses a custom Elasticsearch python client to write the validation data to the Elasticsearch database (see `src.modules.logger.ElasticLogger` for implementation).

5. The `BasePipeline` class (see `src.modules.pipeline` for implementation) handles the logic for fetching all of the input dependencies from MinIO and writing the output of the pipeline to MinIO. The inputs are specified by a configuration file (e.g. `pipelinerawclean.config.json` or `pipelinecleantransformed.config.json`). Since outputs are different for each pipeline (the point of implementing a pipeline is to detail the processing logic specific to that stage and that data source), the output(s) produced (and their destination in MinIO) can be specified directly in the body of the `pipeline` method of your pipeline class.

The code snippet below depicts an example of a pipeline implementation (this was borrowed partially from `src.datasource.ipil_hwy.pipeline.PipelineRawClean` for the `ipil_hwy` data source).

```python
class PipelineRawClean(BasePipeline):
    """
    Overrides pipeline method for ipil_hwy raw -> clean pipeline.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()  # This sets a timestamp at the time the pipeline run initiates
        # Get the initial pandas data frame
        df = self.dependencies[DataSource.ipil_hwy.value].data
        # Perform all edits and imputations
        df = (
            .pipe(
                validation_wrapper,  # The validation wrapper is what calls the validation function
                ipil_hwy_v_1,  # This is the validation function we want to apply to the data
                DataSource.ipil_hwy,  # Identify which data source we are applying the processing to
                self.date,  # The date that applies to the data processing
            )
            .pipe(
                validation_wrapper,
                ipil_hwy_v_2,
                DataSource.ipil_hwy,
                self.date
            )
            # ...
            .pipe(
                validation_wrapper,
                ipil_hwy_v_14,
                DataSource.ipil_hwy,
                self.date
            )
        )
        # Save outputs to outputs dictionary
        ipil_hwy_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=DataSource.ipil_hwy,
            basename=S3.get_s3_basename(
                Stage.CLEAN, DataSource.ipil_hwy, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.ipil_hwy] = ipil_hwy_clean
```