Whether the task is to debug an issue or develop a new feature, in the majority of cases, setting up the appropriate debug settings and launching the VSCode debugger is an efficient way to address the majority of application-side concerns. This section briefly details the recommended steps for solving client issues.

# Prerequisite Documentation
- [Setup Frontier Counts Development Environment]({{fc_baseurl.doc}}/development/../../../development/development_environment.md) - the documentation on this page assumes the user has already set up their development environment on their cloud workstation.

# Case 1: Bug in a Program

In this case, some of the application code (e.g. data processing logic) does not behave as expected. We have asked our clients to report such issues in [Gitlab](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline), indicate the priority with which they need a resolution by (e.g. within 24 hours, within 72 hours, etc.), and include information to help debug (e.g. a screenshot/link to the Argo Workflow logs).

Specifically, there is a Bug Report Template that the users should be following.

