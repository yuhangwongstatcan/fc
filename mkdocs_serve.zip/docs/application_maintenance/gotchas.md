The purpose of this page is to highlight issues that have caused significant confusion throughout the project. Hopefully this prevents future developers/maintainers from incurring the same confusion/cost of debugging that we did.

# Unexpected test passing due to precision limit of 5 digits
This is a known bug where tests that should otherwise fail could pass due to the default precision limit in the `assert_frame_equal` function of `pandas`.

The default precision limit for comparison within `assert_frame_equal` is 5 digits. An example of where this could erroneously cause a test to pass is when 2 high precision timestamps have a difference smaller than 5 digit precision. The test suite will fail to detect this difference.

If precise comparisons are necessary, the solution is to set the `check_exact` keyword parameter on `assert_frame_equal` to `True`.

This known potential bug is currently left unfixed because it is not causing any problems.

# Flask Session + Localization
The web application uses flask session to track the user's locale parameter. If any development work is done that affects the localization code, it may be necessary to delete the `flask_session` folder on your local filesystem and let the web app re-create this folder.

In other words, if you encounter an error related to the flask session while developing locally, this is a good first test while debugging.

# The order that unit/integration tests are run in *can* matter
This "gotcha" relates to an issue that was already resolved, but is worth noting the debugging process as it took many hours to figure out what was happening. This relates to this [gitlab issue](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/issues/427) that was addressed in this [merge request](https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/merge_requests/275).

This issue was noteworthy for the following reasons:

1. I fixed the occurrences *that I found*, but a similar error could exist elsewhere in the application.
2. A future developer/maintainer might not be aware of this issue, and might accidentally make the same mistake.
2. There is an important design lesson here that is worth sharing for anyone who happens to read the docs.

**Description**

When I refactored the `gitlab-ci.yml` to include jobs for running the unit/integration tests, I noticed that there were a small number of tests that were failing on the CI runner, but were passing locally. It turns out a few things were happening.

1. Test discovery is done through `os.walk` which lists files/directories **in an arbitrary order** (see [os.listdir docs](https://docs.python.org/3/library/os.html#os.listdir)). Also when there is more than one input file for a pipeline (e.g. in a `RawClean` pipeline for an integration test), the implementation of our `TestLoader` uses python's `glob` module, which also returns results **in an arbitrary order** (see [glob docs](https://docs.python.org/3/library/glob.html)). Without sorting, there is no guarantee that the files/directories will appear in a given order when run on two different machines.

2. One of the business rules - `trc_020.py` - modified the `countries` dataframe as part of its business logic. Normally this is fine, but the test runner implements file caching in the `TestLoader` to prevent redundant disk I/O at test time. This means that once the test for `trc_020.py` is run, `countries` continues to have the mutation (in this case it was capitalizing country names). On my local machine, it just happened to be the case that `trc_020.py` ran **after** another business rule that depended on `countries` being unaltered. On the CI runner, however, this was not true, and another business rule (`manual_entry_travellers_030`) failed because it expected to find an entry where `country_name_en == 'Overseas'`, but the same entry had already been modified to contain the value `'OVERSEAS'` (i.e. all caps).

3. Another test (`e311__PipelineRawClean__i01`) that called `Loader.query` uses `glob.glob` to get many files in the `mock_minio` folder. Since the file retrieval was not sorted, files were loaded in an order that did not match the order on my local machine. Two of the pipeline steps involve doing a "nearest neighbour" imputation using the **position of the record in the file**. This test, of course, failed on the Gitlab CI runner since the input files were loaded in a different order.

**Summary:**

- This took several hours to debug (and the debug cycle is slow because I had to do many iterations of the CI pipeline to see what was going wrong in our CI runner). Issues like the above are not immediately obvious and require significant debugging effort to find the underlying issue.

- Ideally, no part of the correctness of a test suite should depend on the order of execution. If this is unavoidable (e.g. random number generator, walking a file system), then steps should be taken to ensure the order is perfectly reproducible no matter what machine the code is running on (e.g. seeding a PRNG, sorting the order that the filesystem walk happens in).

# Related to the above issue - test runner caching

When debugging https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/merge_requests/275/pipelines#75142c7938eed1bb294117c443d12fe2273c6a45, the source of the error was that one of the business rules (trc_020) mutated one of the reference files. Normally this would be fine as this mutation is ephemeral (it doesn't last outside of the function that performed the mutation).

However, the test runner caches all reference file loads to minimize disk I/O during test time (e.g. see https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/blob/master/src/modules/utils/loaders.py#L332-335). What was causing the tests to fail in the CI was that the `countries` reference file was mutated in `trc_020`, then instead of loading a fresh copy, the runner already cached the file and used the cached (mutated) copy, which led to a test error.

How to handle this going forward is up to future maintainers, but I recommend one of two policies:

1. Never mutate reference files (e.g. make a local copy and mutate the copy instead). This requires developers to be aware of the test runner's caching.

2. Remove caching from the test runner and accept that the running time will be several seconds slower due to the increased repetitive disk I/O. The upside of this approach is that the developers need not be aware of test runner caching (and hence never have to spend hours debugging issues like https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/merge_requests/275/pipelines#75142c7938eed1bb294117c443d12fe2273c6a45).
