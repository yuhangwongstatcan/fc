# E63 Data Source

### E63 Forms
The "E63" form was originally a Canada Customs and Revenue Agency form designed to report commercial and private arrivals by the air and marine
modes. A new template of the form was developed for the Frontier Counts redesign in order to allow for simpler and more comprehensive data
collection of the elements that are essential for the Frontier Counts program. The general format of the previous iteraion of the form was 
however maintained, since CBSA officers are already familiar with its structure and content.

An example of the template for the E63 form is stored as [sample E63](sample_e63.xlsx)

### Data Reception
E63 forms are received by email (or in some cases, fax) from individual ports of entry. A single E63 form always contains data for only one port of
entry and one mode (air or marine), but can contain one or many "movements" (flights or ship arrivals), and the information for the travellers 
(passengers and crew) onboard these movements. The reception of files varies depending on the volume of arrivals at each individual port and the
preference of the border officers who work there.

**Note: In order to avoid difficulties processing the forms if they are filled out incorrectly, the Frontier Counts production team will review any forms
received in Excel and transcribe any received in PDF (or in previous Excel templates) into the correct template.**

The parameters of the received files are as follows:
> - File type: .xlsx (Excel)
> - Naming conventions:
>>  - File name of the form: E63 *Port Number Date Range*.xlsx
>>>   - Note: To identify E63 files, can use the pattern: E63(*space*)*.xlsx
>>>   - **It is important to include the *space* in the file name pattern in order to differentiate from E63-1 forms, which have the pattern 
>       "E63-1...xlsx"**
>>>   - The tab containing the data is "E63"
> - Timeliness: Reception of files varies depending on the volume of arrivals at individual ports of entry
> - Granularity: Daily
> - Date Variable: DATE
> - Format: 
>>  - YYYY-MM-DD

### E63 Loader Function
To create the e63 raw data with the loader function, the following steps needs to be done with the data from the "E63" tab:
> - Extract the following information from the top portion of the E63 form, which are applicable to **all records from the same E63 form** and 
> apply to reach record from the form:
>>  - Port Name / Nom du port (Cells E5:V5 from the Excel file)
>>  - Mode of Transport / Mode de transport (Cells E9:V9)
> - Fill down and extract the information for each "movement" reported on the E63 file
>>  - Recall that a single E63 form can report one or multiple "movements" (flights or arriving vessels)
>>  - Movements can span multiple rows of the Excel template in order to correctly report all types of travellers, however the "movement"-level 
>   variables may not be repeated for each row that applies to them, so they need to be filled down to the start of the next reported movement
>>  - The following variables should be filled down when blank (if applicable, see next point):
>>>   - DATE, from Column B (Cells B15:B1000)
>>>   - TIME HEURE, from Column C (Cells C15:C1000)
>>>   - REPORT NUMBER NUMÉRO DU RAPPORT, from Column D (Cells D15:D1000)
>>>   - FROM / DE, from Column E (Cells E15:E1000)
>>>   - PRIVATE / PRIVÉ (P) COMM. (C) MILITARY / MILITAIRE (M), from Column P (Cells P15:P1000)
>>>   - CARGO COURIER, from Column Q (Cells Q15:Q1000)
>>>   - TRC CANPASS, from Column R (Cells R15:R1000)
>>>   - HIGH SEAS COASTING, from Column S (Cells S15:S1000)
>>>   - AMBULANCE MEDEVAC AIR MED, from Column T (Cells T15:T1000)
>>>   - FUEL/TECH STOP/REPAIR, from Column U (Cells U15:U1000)
>>>   - OTHER NOTES AUTRES NOTES, from Column V (Cells V15:V1000)
>>  - **Note: Be careful when filling down the variables. Some of the above-noted variables can be blank by design (i.e. blank has meaning), so use
>   the approach of filling down DATE and FROM / DE (which should always be populated) first, and then filling down the other variables noted above
>   across the same range of rows**
>>  - For example, if the movement-level variables are filled out in row 20, and then again in row 23, but are left blank in rows 21 & 22, copy the
>   values for all above-noted variables from row 20 into rows 21 & 22. If CARGO COURIER is then blank in row 23, do not fill in it, since it is
>   applicable to a different movement, and was purposefully left blank
> - Generate a record in the raw data for each of the following, coding the country of residence and the traveller characteristics as specified, and
> copying the form-level variables and movement-level variables, as described in the points above, for all generated records:
>>  - Any non-zero/non-missing values from Column F (Cells F15:F1000) (United States resident crew) as *count*, setting *country_of_residence* = 
>   11840 and *trav_char* = "crew"
>>  - Any non-zero/non-missing values from Column G (Cells G15:G1000) (United States same-day passengers) as *count*, setting 
>   *country_of_residence* = 11840 and *trav_char* = "passenger_sdy"
>>  - Any non-zero/non-missing values from Column H (Cells H15: H1000) (United States overnight passengers) as *count*, setting 
>   *country_of_residence* = 11840 and *trav_char* = "passenger_ovn"
>>  - Any non-zero/non-missing values from Column J (Cells J15:J1000) (Crew members resident of other countries) as *count*, setting 
>   *country_of_residence* equal to the *numeric* portion of the corresponding Column I value from the same row, and setting *trav_char* = "crew"
>>>   - Note: If Column I = "Other" (no country provided), then set *country_of_residence* = 99998
>>  - Any non-zero/non-missing values from Column L (Cells L15:L1000) (Passengers resident of other countries) as *count*, setting 
>   *country_of_residence* equal to the *numeric* portion of the corresponding Column K value from the same row, and setting *trav_char* = 
>   "passenger"
>>>   - Note: If Column K = "Other" (no country provided), then set *country_of_residence* = 99998
>>  - Any non-zero/non-missing values from Column M (Cells M15:M1000) (Canadian resident crew) as *count*, setting *country_of_residence* = 11124 
>   and *trav_char* = "crew"
>>  - Any non-zero/non-missing values from Column N (Cells N15:N1000) (Canadian passengers returning from U.S.) as *count*, setting 
>   *country_of_residence* = 11124 and *trav_char* = "passenger_usa"
>>  - Any non-zero/non-missing values from Column O (Cells O15:O1000) (Canadian passengers returning from other countries) as *count*, setting 
>   *country_of_residence* = 11124 and *trav_char* = "passenger_ovs"

**Note**: Since it is very common for E63 forms to be received in various files and frequently throughout the month, the default behaviour for a
file received where a raw file already exists, should be to **append**. It should **not** be to generate a conflict.
For example, if an E63 file is received in inbox with records for January 1, 2018, and there is already a raw file 20180101.csv in 
raw/e63/2018/01, just append the records to 20180101.csv - do not create a conflict that needs to be resolved.

### Variables in the Raw Data
To create the e63 raw data, combine the extracted data as follows:
> - port: numeric portion *only* from "Port Name / Nom du port" (form-level information in the top portion of the E63 form)
> - mode: from "Mode of Transport / Mode de transport" (form-level information)
> - date: from "DATE" (movement-level information)
> - time: from "TIME HEURE" (movement-level information) (Note: can be blank)
> - report_number: from "REPORT NUMBER NUMÉRO DU RAPPORT" (movement-level information) (Note: can be blank)
> - from: from "FROM / DE" (movement-level information)
> - trans_type: from "PRIVATE / PRIVÉ (P) COMM. (C) MILITARY / MILITAIRE (M)" (movement-level information)
> - cargo: from "CARGO COURIER" (movement-level information) (Note: can be blank)
> - trc: from "TRC CANPASS" (movement-level information) (Note: can be blank)
> - coasting: from "HIGH SEAS COASTING" (movement-level information) (Note: can be blank)
> - ambulance: from "AMBULANCE MEDEVAC AIR MED" (movement-level information) (Note: can be blank)
> - tech_stop: from "FUEL/TECH STOP/REPAIR" (movement-level information) (Note: can be blank)
> - notes: from "OTHER NOTES AUTRES NOTES" (movement-level information) (Note: can be blank)
> - country_of_residence: coded as described in the previous section based on which column in the E63 Excel file the *count* comes from
> - trav_char: coded as described in the previous section based on which column in the E63 Excel file the *count* comes from
> - count: extracted as described in the previous section from Columns F, G, H, J, L, M, N and O
