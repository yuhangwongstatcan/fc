# Documentation for Validation pik_v000

### ID
pik_v000

### Related Business Rule
None (pik_000 is an empty business rule)

### Name
Summary of Unexpected Values - PIK

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected values for certain discrete variables in PIK.

### Additional Details

##### Variable Values
The system is only expecting to see certain values in each discrete variable, as specified in the dimension files **dim__pik__...**. The valid
values are based on the PIK data dictionary provided by CBSA. The Production Team needs to be aware of unexpected values, because the system may
not be able to handle them, or they could indicate invalid records from PIK raw data.

Specifically, the following variables should have their values validated:
> - *arrivingfrom* in (1,2,3)
> - *arvby* in ('Air')
> - *crew* in ('N','Y')
> - *doctype* in (13,29,40)
> - *durofabsn* in (1,2,3,4,[blank])
> - *gender* in (1,2,3,4)
> - *numtrvlr* in (1,2,3,4,5,6)
> - *purpimm* in (0,1)
> - *purpstudy* in (0,1)
> - *purpvisit* in (0,1)
> - *purpwork* in (0,1)
> - *rescntry* in list of three-letter codes from the dimension file
> - *travellercitizenship* in list of three-letter codes from the dimension file

##### Dashboard Display
Any invalid values are displayed in a bar chart grouping invalid codes by variable name.  

This graphic can be filtered dynamically by month and year, and by airport (*wloc*).

### Validity
March 2017 - present

### Required Auxiliary Inputs
The dimension files for the pik data source are required.

### Related Pages
None
