# Documentation for Validation pik_v010

### ID
pik_v010

### Related Business Rule
pik_010

### Name
Summary of Unexpected PIK Work Locations

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected work locations from PIK.

### Additional Details

##### Unexpected Work Locations
This validation is produced for the Production Team to examine records that could not be matched to the PIK work location reference file, either 
because the work location code from the raw data is not present in the reference file, or because the work location does not have a corresponding
*transportation_type* of pik__111 (for commercial aircraft; all PIK data is considered commercial aircraft).

Since PIK is only anticipated to be installed at 11 airports, these unexpected work locations could indicate unexpected Kiosk installations, or 
data errors, both of which need to be investigated.

##### Dashboard Display
The count of records by unexpected airport (unmatched *wloc*) is summarized in a table with a filters for month, year and date.

### Validity
March 2017 - present

### Required Auxiliary Inputs
The PIK work location reference file is required.

### Related Pages
[Documentation for pik_010]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_010)
