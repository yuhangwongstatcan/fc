This page details the requirements of the so-called Data Integrity Report that is generated every month.

# Purpose

The program `data_integrity.py` programatically verifies a number of geography, time, type, and miscellaneous properties of the data that should hold true. The script uses the same logging mechanism as pipeline validations (see [pipeline docs]({{fc_baseurl.doc}}/pipeline/overview) for more information about how these validations are written). The output files from this validation report can be found at one of the following S3 locations:

- `/validation/travellers/<geographical_based_validations>/<year>/<month>/<timestamp>.csv`
- `/validation/travellers/<misc_validations>/<year>/<month>/<timestamp>.csv`
- `/validation/travellers/<time_based_validations>/<year>/<month>/<timestamp>.csv`
- `/validation/travellers/<type_based_validations>/<year>/<month>/<timestamp>.csv`

The input data to this program is the `travellers` and `vehicles` tables produced by the system.

The output data from these files are used in PowerBI visualizations that are maintained by the clients.

The program `data_integrity.py` is a simple CLI program that can be invoked manually, or by the web app as an Argo Workflow. This program is expected to need minimal maintenance/changes.

# Specs

This section details the clients' requirements for this report.

> Within a section, the order of the conditions could change. If it is preferable to group them in categories (ex: always filled), it is up to you.

> We would like to have an indicator next to every condition met.

> We would like to have an indicator next to every condition not met. Conditions not met should be displayed first on the page or be easily identifiable. If a condition is not met, we would like to display Data_Source in order to facilitate the investigation.

## Travellers

- **Year**: always filled, numeric only, value from 1972 to 2050
- **Month**: always filled, numeric only, value from 1 to 12
- **Day**: always filled, numeric only, value from (1 to 31) OR 99
- **Invalid combination**: Month = 2 AND Day = 30
- **Invalid combination**: Month = 2 AND Day = 31
- **Invalid combination**: Month = 4 AND Day = 31
- **Invalid combination**: Month = 6 AND Day = 31
- **Invalid combination**: Month = 9 AND Day = 31
- **Invalid combination**: Month = 11 AND Day = 31
- **Port**: always filled, numeric only, value from ports.csv
- Make sure we are not using terminated ports (port_end is not null)
- **Mode**: always filled, numeric only, value from 1 to 3, make sure value 9 is never used
- **Vehicle_type**: always filled, numeric only, make sure values (199 OR 299 OR 399 OR 999) are never used
- If Mode = 1, value for Vehicle_Type (111 OR 112 OR 121)
- If Mode = 2, value for Vehicle_Type (211 OR 212 OR 213 OR 214 OR 215 OR 216 OR 217)
- If Mode = 3, value for Vehicle_Type (311 OR 312 OR 313 OR 314 OR 315 OR 321)
- **Plate_country**: always filled, numeric only
- If vehicle_type in (211 OR 212 OR 213 OR 214) AND data_source = 11, then plate_country in (1 OR 2 OR 3 OR 8)
- If vehicle_type in (211 OR 212 OR 213 OR 214) AND data_source != 11, then plate_country in (1 OR 2)
- If vehicle_type in (215 OR 313 OR 315), then plate_country in (1 OR 2 OR 3 OR 8 OR 9)
- If vehicle_type in (111 OR 112 OR 121 OR 216 OR 217 OR 311 OR 312 OR 314 OR 321), then plate_country = 9
- **Plate_region**: always filled
- If Plate_Country = 1, value for Plate_Region (NL, PE, NS, NB, QC, ON, MB, SK, AB, BC, YT, NT, NU, NA)
- If Plate_Country = 2, value for Plate_Region (AL, AK, AZ, AR, CA, CO, CT, DE, DC, FL, GA, HI, ID, IL, IN, IA, KS, KY, LA, ME, MD, MA, MI, MN, MS, MO, MT, NE, NV, NH, NJ, NM, NY, NC, ND, OH, OK, OR, PA, RI, SC, SD, TN, TX, UT, VT, VA, WA, WV, WI, WY, NA)
- If Plate_Country = 3, value for Plate_Region = MX
- If Plate_Country = 8, value for Plate_Region = XX
- If Plate_Country = 9, value for Plate_Region = NA
- **Arriving_from**: always filled, numeric only, value from 1 to 3, make sure value 9 is never used
- If (Country_of_Residence = 11840 OR 11124) and Mode = 2, Arriving_From in (1 OR 3)
- If (Country_of_Residence is not 11124 nor 11840) AND Mode = 2, Arriving_From = 3
- If (Country_of_Residence is not 11124 nor 11840) AND (Mode = 1 OR 3), Arriving_From (2 OR 3)
- **Country_of_Residence**: always filled, numeric only, make sure value 99998 is never used
- Make sure we are not using terminated countries (country_end is not null)
- If Purpose9 = 41, Country_of_Residence = 99999
- If Purpose9 = all except 41, value for Country_of_Residence is from countries.csv (but not 99998, nor 99999)
- **Purpose9**: always filled, numeric only, value (11, 12, 13, 19, 21, 31, 41, 42, 43)
- **Purpose4**: always filled, numeric only, value (1, 2, 3, 4), make sure value 9 is never used
- If Purpose9 (11, 12, 13, 19), Purpose4 = 1
- If Purpose 9 = 21, Purpose4 = 2
- If Purpose9 = 31, Purpose4 = 3
- If Purpose9 (41, 42, 43), Purpose4 = 4
- **Duration5**: always filled, numeric only, value (11, 21, 22, 23, 24, 99)
- **Duration3**: always filled, numeric only, value (11, 21, 22, 99)
- **Duration2**: always filled, numeric only, value in (1, 2, 9)
- If Purpose9 = 41, Duration2 = 9
- If Duration5 = 11, Duration2 = 1
- If Duration3 = 11, Duration2 = 1
- If Duration5 (21, 22, 23, 24), Duration2 = 2
- If Duration3 (21, 22), Duration2 = 2
- **Traveller_Type**: always filled, numeric only, make sure value 9 is never used
- If (Purpose9 = 11, 12, 13, 19) AND (Duration2 = 1), Traveller_Type = 1
- If (Purpose9 = 21) AND (Vehicle_Type = 121, 321) AND (Duration2 = 1), Traveller_Type = 1
- If Duration5 = 24, Traveller_Type = 3
- If (Purpose9 = 11, 12, 13, 19) AND (Duration2 = 2) AND Duration5 is not 24, Traveller_Type = 2
- If (Purpose9 = 21) AND (Vehicle_Type = 121, 321) AND (Duration2 = 2) AND Duration5 is not 24, Traveller_Type = 2
- If (Purpose9 = 21) AND (Vehicle_Type is not 121 nor 321), Traveller_Type = 3
- If (Purpose9 = 31, 41, 42, 43), Traveller_Type = 3
- If Vehicle_Type (112 OR 214 OR 312), Traveller_Type = 3
- **Counts**: all counts are positive integer numbers

## Vehicles

- **Year**: always filled, numeric only, value from 1972 to 2050
- **Month**: always filled, numeric only, value from 1 to 12
- **Day**: always filled, numeric only, value from (1 to 31) OR 99
- **Invalid combination**: Month = 2 AND Day = 30
- **Invalid combination**: Month = 2 AND Day = 31
- **Invalid combination**: Month = 4 AND Day = 31
- **Invalid combination**: Month = 6 AND Day = 31
- **Invalid combination**: Month = 9 AND Day = 31
- **Invalid combination**: Month = 11 AND Day = 31
- **Port**: always filled, numeric only, value from ports.csv
- Make sure we are not using terminated ports (port_end is not null)
- **Mode**: always filled, numeric only, value = 2 OR 3, make sure values 1 OR 9 are never used
- **Vehicle_Type**: always filled, numeric only, make sure value 999 is never used
- If Mode = 2, value for Vehicle_Type (211, 212, 213, 214, 215)
- If Mode = 3, value for Vehicle_Type (313)
- **Plate_Country**: always filled, numeric only
- If vehicle_type in (211 OR 212 OR 213 OR 214) AND data_source = 11, then plate_country in (1 OR 2 OR 3 OR 8)
- If vehicle_type in (211 OR 212 OR 213 OR 214) AND data_source != 11, then plate_country in (1 OR 2)
- If vehicle_type in (215 OR 313), then plate_country in (1 OR 2 OR 3 OR 8 OR 9)
- **Plate_Region**: always filled
- If Plate_Country = 1, value for Plate_Region (NL, PE, NS, NB, QC, ON, MB, SK, AB, BC, YT, NT, NU, NA)
- If Plate_Country = 2, value for Plate_Region (AL, AK, AZ, AR, CA, CO, CT, DE, DC, FL, GA, HI, ID, IL, IN, IA, KS, KY, LA, ME, MD, MA, MI, MN, MS, MO, MT, NE, NV, NH, NJ, NM, NY, NC, ND, OH, OK, OR, PA, RI, SC, SD, TN, TX, UT, VT, VA, WA, WV, WI, WY, NA)
- If Plate_Country = 3, value for Plate_Region = MX
- If Plate_Country = 8, value for Plate_Region = XX
- If Plate_Country = 9, value for Plate_Region = NA
- **Counts**: all counts are positive integer numbers
