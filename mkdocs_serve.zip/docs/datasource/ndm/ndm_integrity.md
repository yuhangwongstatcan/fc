# Related Documentation
- [NDM Tables]({{fc_baseurl.doc}}/datasource/ndm/overview) - this page will make little sense if the reader has not already looked at the NDM documentation.


The purpose of this CLI tool is to programmatically compare a large number of NDM table values that should equal eachother. This serves as a quality assurance check to see if any NDM tables produce values that are inconsistent with eachother.

# Original Client Specs

For context, this section details the original specifications for what the NDM Integrity report needs to generate.

> After the data is signed off and loaded in the NDM tables, the Production team needs to verify that the data is disseminated correctly. The script should run all dimensions against each other, unless there is a note for an exception. We would like to have an indicator next to every condition met.
We would like to have an indicator next to every condition not met. Conditions not met should be easily identifiable. If a condition is not met, we would like to display for which combinations it doesn’t balance in order to facilitate the investigation. Ex: Europe doesn’t balance at the Ontario level.

The original specs were provided to us in a Microsoft Word document. I show examples below of the original specs and how they are translated into configuraiton files that the clients can edit. The system generates the various reports based on the configuration.

# Within-Table NDM Validations

These validations ensure that certain combinations (sums) of ndm records equal other ndm records. This is needed because NDM contains aggregations in the data itself. For example, the sum of records 1,2,3,4 may be stored in record 5 as its own entry in the data. The partial table below is taken from the clients original documentation, and it is contrasted with the corresponding configuration file entry.

| Title                                                                          | Corresponding Value | Should equal to                     |
| ------------------------------------------------------------------------------ | ------------------- | ----------------------------------- |
| Non-resident visitors entering Canada                                          | Value 1 of dim2     | Values 2+3 of dim2                  |
| Residents of countries other than the United States of America entering Canada | Value 3 of dim2     | Values 4+65+141+204+254+288 of dim2 |
| ...                                                                            | ...                 | ...                                 |

The clients requested that we provide the configuration in `csv` format so that they could easily edit the configuration themselves without involving IT for maintenance. Below is the entry from the corresponding configuration.

{{ read_csv('src/tests/mock_minio/reference/ndm_integrity_config/ndm_integrity_config.csv', nrows=5) }}

The first column indicates the NDM Table Number. This refers to which NDM table the validation applies to (e.g. `table_number = 50` implies that the validation is for NDM table `24100050`).

The second column indicates which dimension the validation applies to.

The third column indicates the value associated with that dimension.

Finally, the fourth column indicates a list of `dim2` values that, when the corresponding values are summed together, should equal the value associated with the `corresponding_value` of `dim_number`. For example, in plain language, the second row of the table above can be interpretted as follows:

> "For NDM Table 24100050, the value of the row where `dim2` equals `1` should equal to the sum of values where `dim2` equals `2` or `3`.

!!! note

    Each row of these validations are applied against **every combination of other dimension values**, unless there are any exceptions provided, in which case the exceptions are omitted.

!!! example

    For the validation in the first row, we want to check that the value of the row where `dim2` equals `1` is the same as the sum of values of the two rows where `dim2` equals `2` and `dim2` equals `3`. We want to do this check **for every value that `dim1` can take on**. In this case, there are 14 iterations (the cardinality of `dim1` for table `24100050`).

!!! warning

    There are several edge cases specified by the clients. These are commented where they occur in the actual functions in `ndm_integrity.py`. That being said, the code looks quite messy/complicated as there are a small number of edge cases that just needed to be coded directly. These are not expected to change often, so we opted to simply hard-code them rather than come up wtih some configuration system for specifying them.

# Between-Tables Validations

The so-called between-tables validations ensures that specific rows between two given NDM tables are equal. Additionally, there are cases where one table will have that a sum of values is expected to equal another value. The table below shows some of the original specifications, followed by the corresponding configuration we created to automate the creation of this report.

| Title                                 | Corresponding value 24-10-0051 | Corresponding value 24-10-0054                                                     |
| ------------------------------------- | ------------------------------ | ---------------------------------------------------------------------------------- |
| Non-resident visitors entering Canada | 1.1                            | 1.2.1                                                                              |
| ...                                   | ...                            | ...                                                                                |
| Non-resident visitors entering Canada | 5.1                            | =2.2.1 + 3.2.1 + 4.2.1 + 5.2.1 + 8.2.1 + 9.2.1 + 10.2.1 + 12.2.1 + 13.2.1 + 14.2.1 |
| ...                                   | ...                            | ...                                                                                |


For the same reason as for the within-tables validation, the clients requested that the configuration be provided in `csv` format.

{{ read_csv('src/tests/mock_minio/reference/ndm_integrity_between_tables/ndm_integrity_between_tables.csv', nrows=3) }}
{{ read_csv('src/tests/mock_minio/reference/ndm_integrity_between_tables/ndm_integrity_between_tables.csv', skiprows=50, nrows=3) }}

The first column is the first table used in the between-tables validation.

The second column contains the so-called "coordinates" that identify a record(s) in `table1`. See [NDM Tables]({{fc_baseurl.doc}}/datasource/ndm/overview) for the definition of coordinates.

The third column is the second NDM table in the between-tables validation.

The fourth column has the coordiantes to identify a record(s) in `table2`.

If more than one coordinate is listed, this means that we need to take the sum of those coordinates.


# Outputs

The files output by the `ndm_integrity.py` script have the following prefix:

```
/validation/ndm_241000<table number>/year/month/<year>-<month>-ndm_integrity-<timestamp>.csv
```

The clients will either view these files directly through the MinIO browser, or create a PowerBI visualization that accesses directly this location via the Azure Storage account that is backing MinIO. In either case, what comes after the generation of the NDM Integrity report is not the responsibility of IT.

# Source Code

The source code for this CLI program is found in `src/ndm_integrity.py`. This file should require little maintenance as the requirements are not expected to change often.