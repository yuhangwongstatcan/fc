The output medium for data produced by the Frontier Counts system is the so-called New Dissemination Model (NDM). As such, a series of NDM tables are produced by the Frontier Counts progra. This page details the key information around the NDM tables.

!!! tip
    The contents of this page may be more clear if you first visit the [end-to-end data flow diagram]({{fc_baseurl.doc}}/datasource/data_diagrams/end_to_end_data_flow).

# NDM Unadjusted and Seasonal Adjustment Input

Once the [travellers_main]({{fc_baseurl.doc}}/datasource/travellers) and [vehicles_main]({{fc_baseurl.doc}}/datasource/vehicles) tables are produced, the `ndm_unadjusted` pipeline can be run to produce the `ndm_unadjusted` and `sa_in` tables for a given year and month.

Each row of the **NDM Unadjusted** table represents a single value produced by a given SUM aggregation where a number of conditions are met. Each such record represents a single observation in a monthly time series.

The queries are not simply an enumeration of certain variable combinations. Instead, they are specific queries corresponding to specific NDM vectors.

The pipeline that produces the NDM Unadjusted table makes use of the `ndm_vectors` and the [`ndm_sa`]({{fc_baseurl.doc}}/reference/ndm_sa/) reference files.

The `ndm_unadjusted` pipeline can be run with the `run_pipeline.py` CLI program by doing `python run_pipeline.py --pipeline-class PipelineAggregated --data-source ndm_unadjusted --date YYYY-MM-DD`, or it can be run directly through the webapp.

The outputs of the `ndm_unadjusted` pipeline are written to locations matching the pattern `/aggregated/ndm_unadjusted/year/month/YYYYMM.csv` and `/aggregated/sa_in/year/month/YYYYMM.csv`

# NDM Adjusted

Once the `ndm_unadjusted` and `sa_in` tables are produced for the current month, the `sa_in.py` CLI program under the `src` folder can be used to concatenate a number of `sa_in` tables and place them in the `/outbox` location. The two output files from this process are (1) `SA_IN.csv` which contains a user-defined number of months of historical data to include, and a table called `SA_PARAMETERS.csv` which are needed by the seasonal adjustment team that use the `SA_IN.csv` file as input to a seasonal adjustment process.

The seasonal adjustment team has a process outside of the Frontier Counts system for performing seasonal adjustment on time series data, so the two files mentioned above are placed in `/outbox` so they can be moved to a Network A location, processed by the seasonal adjustment team, and moved back to the `/inbox` location in MinIO to be ingested by the system.

Once the seasonal adjustment team finishes their workflow, they provide the Frontier Counts system with a file called `SA_RK_OUT.csv` that is placed in the `/inbox` location in MinIO. There is a loader function in `src/datasource/ndm_adjusted/loader.py` that specifies how to merge `SA_RK_OUT.csv` with the `ndm_sa.csv` table to create the various months of `ndm_adjusted` data that are stored in the Frontier Counts system.

Note that for every month of processing, the seasonal adjustment process returns many revised months of seasonally adjusted data. This is because the new data received affects the seasonal adjustment process retroactively, so the most up-to-date estimates need to be reflected in the system. The behaviour of the loader mentioned above is to automatically overwrite the previous data that was present under the given year/month combinations in `ndm_adjusted`.

# NDM Output Tables

At the time of writing this documentation, the following NDM tables are produced by the Frontier Counts system.

| NDM Table Number | Description | Seasonally Adjusted | Language Implemented |
| ---------------- | ----------- | ------------------- | -------------------- |
| 24100050         | TODO        | no                  | Python               |
| 24100051         | TODO        | yes                 | Python               |
| 24100052         | TODO        | no                  | Python               |
| 24100053         | TODO        | no                  | Python               |
| 24100054         | TODO        | yes                 | Python               |
| 24100055         | TODO        | no                  | Python               |
| 24100056         | TODO        | no                  | Python               |
| 24100057         | TODO        | no                  | Python               |
| 24100058         | TODO        | no                  | Python               |
| 24100059         | TODO        | no                  | Python               |