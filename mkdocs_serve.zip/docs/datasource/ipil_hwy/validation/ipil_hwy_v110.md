# Documentation for Validation ipil_hwy_v110

### ID
ipil_hwy_v110

### Related Business Rule
ipil_hwy_110

### Name
Summary of IPIL-Hwy Removed Records (Duplicates)

### Type
Validation

### Purpose
Contribute to a visualization that shows end users a summary of records removed from IPIL-Hwy and the reason for their removal.

### Additional Details
This validation contributes to the dashboard showing the Production Team a summary of records removed from IPIL-Hwy according to their reason of
removal. This dashboard is summarized by month and work location.

This validation is logged from the edit ipil_hwy_110, and contributes the records removed due to duplication. A duplicate in IPIL-Hwy is defined as
duplication of the variables *cport* (work location), *lane*, *date* and *sin* (time in).

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_110]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_110)
