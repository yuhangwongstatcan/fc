# Documentation for Validation ipil_hwy_v000

### ID
ipil_hwy_v000

### Related Business Rule
None (ipil_hwy_000 is an empty rule)

### Name
Validation of Discrete Variable Values - IPIL-Hwy

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected values for certain discrete variables in IPIL-Hwy.

### Additional Details

##### Variable Values
The system is only expecting to see certain values in each discrete variable, as specified in the dimension files **dim__ipil_hwy__...**. The 
valid values are based on the IPIL-Hwy data dictionary received from CBSA. The Production Team needs to be aware of unexpected values, because 
the system may not be able to handle them, or they could indicate invalid records from IPIL-Hwy raw data.

Specifically, the following variables should have their values validated:
> - *vehi* in ("A","B","C","M","O","P")
> - *country* in ("CA","CD","US","MX","PR","XX")
> - *province* in (10 provinces,3 territories,50 states,"DC","MX","MXC","PR","XX" or [blank])

##### Dashboard Display
Any invalid values are displayed in a bar chart grouping invalid codes by variable name. The measurement variable of the grouped graphic is 
*count* (count of travellers with the unexpected variable value).

This graphic can be filtered dynamically by year and month.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The dimension files for the ipil_hwy data source are required.

### Related Pages
None
