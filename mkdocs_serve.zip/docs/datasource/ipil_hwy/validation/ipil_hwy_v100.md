# Documentation for Validation ipil_hwy_v100

### ID
ipil_hwy_v100

### Related Business Rule
ipil_hwy_100

### Name
Summary of IPIL-Hwy Removed Records (Zero Travellers)

### Type
Validation

### Purpose
Contribute to a visualization that shows end users a summary of records removed from IPIL-Hwy and the reason for their removal.

### Additional Details
This validation contributes to the dashboard showing the Production Team a summary of records removed from IPIL-Hwy according to their reason of
removal. This dashboard is summarized by month and work location.

This validation is logged from the edit ipil_hwy_100, and contributes the records removed due to having zero total travellers, or a missing number 
of travellers. CBSA has previously confirmed that these types of records would typically represent trailers or towed vehicles, and these types of
vehicles are not in scope for the Frontier Counts program.

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_100]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_100)
