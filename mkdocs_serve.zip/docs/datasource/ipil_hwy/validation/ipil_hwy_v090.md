# Documentation for Validation ipil_hwy_v090

### ID
ipil_hwy_v090

### Related Business Rule
ipil_hwy_090

### Name
Summary of IPIL-Hwy Removed Records (Invalid Province)

### Type
Validation

### Purpose
Contribute to a visualization that shows end users a summary of records removed from IPIL-Hwy and the reason for their removal.

### Additional Details
This validation contributes to the dashboard showing the Production Team a summary of records removed from IPIL-Hwy according to their reason of
removal. This dashboard is summarized by month and work location.

This validation is logged from the edit ipil_hwy_090, and contributes the records removed due to an invalid province value (either blank or not
among the list of valid values after all edit logic has been applied). CBSA has previously confirmed that these types of records do not represent
valid border crossing records.

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_090]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_090)
