# Documentation for Validation ipil_hwy_v30

### ID
ipil_hwy_v030

### Related Business Rule
None

### Name
Daily Volume of Vehicles - IPIL-Hwy

### Type
Validation

### Purpose
Provide a visualization for end users to analyze the volume of vehicles in IPIL-Hwy by day.

### Additional Details

##### Abnormalities in Daily Volume
The purpose is for the Production Team to be able to identify abnormally high or low values in daily IPIL-Hwy traffic, and determine the cause 
(explainable reason vs. system outage or processing error). The typical workflow would be to examine the Canada-level and province-level daily 
volume distributions. If abnormalities are identified, then the Production Team can drill down to the work location level to isolate the issue.

##### Dashboard Display
This validation presents a daily count of vehicles (records) overall, by province and by work location. The volume summary is presented in a 
dashboard with a line graph showing the daily count. The graph can be dynamically filtered by time period, province, vehicle type and work location.

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
None
