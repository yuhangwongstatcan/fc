# Documentation for Validation ipil_hwy_v080

### ID
ipil_hwy_v080

### Related Business Rule
ipil_hwy_080

### Name
Summary of Automobiles Recoded as Buses in IPIL-Hwy

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of overfull automobiles changed to buses in IPIL-Hwy.

### Additional Details

##### Overfull Automobiles
This validation is produced for the Production Team to examine the number of automobiles recoded as buses based on the Frontier Counts (UNWTO) rule
that an automobile can only have a maximum of eight passengers. 

##### Dashboard Display
The validation is presented as a summary by work location and time period (year and month) showing the number of automobiles changed to buses, 
as well as the number of buses and automobiles not affected by the changes, and the number of automobiles changed as a percentage of the 
unaffected automobiles and as a percentage of the unaffected buses.

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_080]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_080)
