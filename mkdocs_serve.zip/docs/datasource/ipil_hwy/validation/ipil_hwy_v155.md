# Documentation for Validation ipil_hwy_v155

### ID
ipil_hwy_v155

### Related Business Rule
ipil_hwy_v155

### Name
Summary of IPIL-Hwy Overseas Country Imputation

### Type
Validation

### Purpose
Provide a visualization for end users to view a breakdown of countries of residence for overseas travellers in IPIL-Hwy following imputation.

### Additional Details

##### Imputation Method
The dashboard displays a count of travellers (sum(*osd*,*o1d*,*o2d*)) assigned to each country of residence during the imputation. The dashboard
summarizes by province of entry (extracted from the first two digits of *port*) and mode of transportation (*vehi*), as well as by the 
imputation method used (either "Manual Entry" or "PIK").

The imputation method used is logged as *imputation_method*, and set to "Manual Entry" if the manual_entry country distribution was used, and
to "PIK" if the pik country distribution was used.

##### Dashboard Display
The dashboard displays two pie charts, one for "Manual Entry" and one for "PIK" (*imputation_method* from the output), where each pie chart is 
divided into wedges for the count of travellers from each country of residence (i.e. the percentage that each country of residence represents among
all overseas travellers who had their country of residence imputed). Only **overseas** travellers are shown.

Filters are provided for year, month, province of entry and mode of transportation.

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation on ipil_hwy_155]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_155)
