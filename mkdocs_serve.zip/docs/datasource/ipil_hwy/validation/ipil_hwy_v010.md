# Documentation for Validation ipil_hwy_v010

### ID
ipil_hwy_v010

### Related Business Rule
ipil_hwy_010

### Name
Summary of Recoded Vehicles and Unexpected Data - IPIL-Hwy

### Type
Validation

### Purpose
Provide a dashboard with two visuals for end users to view edits done to IPIL-Hwy data based on work locations.

### Additional Details

##### Summary of Recoded Vehicles
This validation is produced for the Production Team to examine the number of records that were recoded from one vehicle type to another 
because the original vehicle type was not permitted at the work location (*cport*; based on the work location reference file).

##### Dashboard Display for Recoded Vehicles
The count of recoded vehicles is displayed in a table with the "from" vehicle types as columns and the "to" vehicle types as rows. The table
can be filtered by year, month and work location.

##### Summary of Unexpected IPIL-Hwy Data
This validation is produced for the Production Team to examine records that could not be matched to the work location reference file based on work
location and transportation type (*cport* and *vehi* from the raw data), indicating that they are not accepted for IPIL-Hwy processing by default. 

##### Dashboard Display for Unexpected Data
The count of records by unexpected work location and transportation type (unmatched *cport* and/or *vehi*) is summarized in a simple table with filters for year and month.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The work location reference file is required.

### Related Pages
[Documentation for ipil_hwy_010]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_010)
