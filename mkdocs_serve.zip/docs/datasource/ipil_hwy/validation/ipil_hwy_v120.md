# Documentation for Validation ipil_hwy_v120

### ID
ipil_hwy_v120

### Related Business Rule
ipil_hwy_120

### Name
Summary of IPIL-Hwy Removed Records (Missing Date)

### Type
Validation

### Purpose
Contribute to a visualization that shows end users a summary of records removed from IPIL-Hwy and the reason for their removal.

### Additional Details
This validation contributes to the dashboard showing the Production Team a summary of records removed from IPIL-Hwy according to their reason of
removal. This dashboard is summarized by month and work location.

This validation is logged from the edit ipil_hwy_120, and contributes the records removed due to a missing date (blank *date* variable). The
Frontier Counts program needs to be able to confidently assign records to a month since the program releases monthly official statistics, so if
the date field is blank, a record cannot be accurately assigned.

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_120]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_120)
