# Documentation for Validation ipil_hwy_v130

### ID
ipil_hwy_v130

### Related Business Rule
ipil_hwy_130

### Name
Imputation Summary of Overfull Vehicles (Trucks)

### Type
Validation

### Purpose
Contribute to a visualization that shows end users an imputation summary for overfull vehicles.

### Additional Details
This validation is produced for the Production Team to examine the number of records imputed due to an overfull truck (more than 4 passengers).
It is presented alongside imputation summaries for overfull buses and motorcycles in a simple dashboard of card visuals.

Due to the relative rarity of needing to impute for these types of overfull vehicles, the validation is only presented at the overall (Canada) 
level.

### Validity
January 2022 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_130]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_130)
