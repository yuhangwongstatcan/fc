# Documentation for Business Rule ipil_hwy_090

### ID
ipil_hwy_090

### Name
Remove records with no valid province or state code in IPIL-Hwy

### Type
Edit

### Purpose
Remove any records in IPIL-Hwy raw data where the *province* variable is not among the list of valid codes.

### Additional Details
These types of records have been confirmed by CBSA to not represent valid border crossings.

The list of valid codes for the *province* variable includes the 50 American state two-letter codes (see ipil_hwy_050), the 13 Canadian
province and territory two-letter codes (see ipil_hwy_060), "DC" (District of Columbia), "MX" (Mexico), "MXC" (Mexico City), "PR" (Puerto Rico)
and "XX" (Other). 

If the *province* variable indicates any other code or is missing, the record should be removed.  
**Exception: if the *country* variable is "MX" (Mexico), and the *province* variable is missing, then the record is not removed, as those records
often have a missing province, which is coded to "MX" based on the country (see ipil_hwy_070).**

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_050]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_050)  
[Documentation for ipil_hwy_060]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_060)  
[Documentation for ipil_hwy_070]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_070)
