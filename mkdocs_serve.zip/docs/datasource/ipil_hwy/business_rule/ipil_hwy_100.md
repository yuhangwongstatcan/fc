# Documentation for Business Rule ipil_hwy_100

### ID
ipil_hwy_100

### Name
Remove empty vehicles in IPIL-Hwy

### Type
Edit

### Purpose
Remove any records in IPIL-Hwy raw data where the sum of passengers in the vehicle is either zero or missing.

### Additional Details
If the sum of variables *cdsd*, *cd1d*, *cd2d*, *ussd*, *us1d*, *us2d*, *osd*, *o1d* and *o2d* is either zero or missing, then the record should
be deleted.

CBSA has confirmed that records of this type typically represent trailers or towed vehicles, which are out of scope for Frontier Counts as the
program only enumerates driven vehicles.

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
None
