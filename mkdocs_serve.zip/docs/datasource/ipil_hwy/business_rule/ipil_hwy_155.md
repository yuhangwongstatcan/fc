# Documentation for Business Rule ipil_hwy_155

### ID
ipil_hwy_155

### Name
Impute country of residence for IPIL-Hwy overseas travellers

### Type
Imputation

### Purpose
Impute a country of residence for any overseas travellers in IPIL-Hwy using the best available auxiliary information.

### Additional Details
Overseas travellers in IPIL-Hwy are enumerated by the variables *osd* (same-day), *o1d* (one night) and *o2d* (two or more nights), but their 
specific country of residence is not available in the raw data from CBSA. Since country of residence is a critical variable for Frontier Counts, the
country of residence needs to be imputed for these travellers using the best available auxiliary information.

##### Setting up the Imputation
Each record in the ipil_hwy raw data will have the following variables added in support of the imputation:

> - *random_number*: A random number on the uniform (0,1) distribution, generated from Python's numpy package with a seed based on the year and 
> month in production (e.g. seed = 202001 for January 2020 production). The number of random numbers to generate is equivalent to the number of 
> records in the ipil_hwy raw data (e.g. the first row receives the first random number generated and so on)
>   - Note: *random_number* is only a temporary variable to aid in processing and does not need to be maintained beyond this business rule
> - *port*: Since some of the reference distributions will be at the port level, and IPIL-Hwy data is at the work location level, it will facilitate
> the task to add the corresponding port to each record by extracting *port* from the **work_locations.csv** reference file, linking on *cport* from
> the raw IPIL-Hwy data and *work_location* from the reference file
> - *country_of_residence*: A placeholder where the imputed country of residence code will be added for each record

Note: Only records with at least one overseas traveller (sum(osd,o1d,o2d) >= 1) need to have an imputation done for country of residence. For any
IPIL-Hwy records where sum(osd,o1d,o2d) = 0, their *country_of_residence* can be set as 99999 (Not applicable), and they do
not need to pass through any of the subsequently described imputation steps.

Note: In order to simplify the assignment process in IPIL-Hwy, randomly assign a country of residence to the **vehicle** (the IPIL-Hwy record), and all 
overseas travellers riding in the same vehicle can be assigned to the same country of residence. In the long-term over a large number of vehicles 
the effect will be the same as assigning countries of residence individually, but the structure of the file will be MUCH simpler, as the variable 
*country_of_residence* can simply be added to each line of the IPIL-Hwy CLEAN data, and the data can be kept at the level of the microdata from 
CBSA (the vehicle).

##### Using Overseas Reports from the Manual Entry for Imputation
There are a few ports of entry where a report on overseas travellers with a good quality country distribution is received, so these are the best
auxiliary source if they are received. 

The first step therefore for each IPIL-Hwy record requiring imputation is to check if there are any corresponding overseas traveller records in the 
transformed manual_entry TRAVELLERS table for the production year and month, at the same port of entry and vehicle type.

The corresponding vehicle type is determined as follows:
> - If *water_flag* = 'private watercraft', then search for *vehicle_type* = 321 (Private boat) in the TRAVELLERS table
> - Else if *water_flag* = 'ferry' and *vehi* = 'P', then search for *vehicle_type* = 314 (Ferry (Pedestrian)) in the TRAVELLERS table
> - Else if *water_flag* = 'ferry', then search for *vehicle_type* = 313 (Ferry (Private vehicle)) in the TRAVELLERS table
> - Else if *vehi* = 'A', then search for *vehicle_type* = 211 (Automobile) in the TRAVELLERS table
> - Else if *vehi* = 'M', then search for *vehicle_type* = 212 (Motorcycle) in the TRAVELLERS table
> - Else if *vehi* = 'O', then search for *vehicle_type* = 213 (Other land vehicle) in the TRAVELLERS table
> - Else if *vehi* = 'C', then search for *vehicle_type* = 214 (Truck) in the TRAVELLERS table
> - Else if *vehi* = 'B', then search for *vehicle_type* = 215 (Bus) in the TRAVELLERS table
> - Else if *vehi* = 'P', then search for *vehicle_type* = 217 (Pedestrian) in the TRAVELLERS table

If there are any records in the manual_entry TRAVELLERS table where 
> - *year* = year(*date*) from the IPIL-Hwy raw data
> - *month* = month(*date*) from the IPIL-Hwy raw data
> - *port* = *port* from the IPIL-Hwy data, linked through *cport* as described above
> - *vehicle_type* matches *water_flag* and *vehi* as described in the previous section

AND where there is a least one entry for overseas travellers (*country_of_residence* not in (11124,11840,99998,99999)), then the country 
distribution from the manual_entry TRAVELLERS table will be used to impute country of residence for this ipil_hwy record.

The imputed country of residence is then determined as follows:
> - For all applicable **overseas** travellers in the manual_entry TRAVELLERS table (i.e. with the correct year, month, port and vehicle type),
> determine a country breakdown (e.g. 50% U.K., 30% France, 10% Germany, 10% China for BUS travellers at Port 35427 in June 2020) based on traveller
> volume (sum of *count_of_entries*)
> - Order the countries based on their *country_of_residence* code (e.g. 21250-France, 21280-Germany, 23826-U.K., 42156-China)
> - Set each country on the (0,1) range based on their prevalence (e.g. France in [0.0,0.3], Germany in [0.3,0.4], U.K. in [0.4,0.9], China in [0.9, 1.0])
> - Assign the *country_of_residence* to the ipil_hwy record based on which range the *random_number* falls in (e.g. if *random_number* = 0.3866612
> then assign 21280 (i.e. Germany) to this record)

##### Using PIK Data for Imputation
In the case where there are no corresponding overseas records in the manual_entry TRAVELLERS table (which will typically be the case), PIK 
TRAVELLERS data will be used for the overseas country imputation, because it is timely, detailed and accurate.

Since the PIK data are for air travellers and the IPIL-Hwy data are for land travellers, there is no overlap between the ports, so the applicable
country distribution is selected regionally as follows:
> - IPIL-Hwy ports in British Columbia (59XXX) and Yukon (60XXX) use PIK data from Vancouver Airport (*work_location* = 8212)
> - IPIL-Hwy ports in Alberta (48XXX) use PIK data from Calgary and Edmonton Airports (*work_location* in (7011,7023))
> - IPIL-Hwy ports in Saskatchewan (47XXX) and Manitoba (46XXX) use PIK data from Winnipeg Airport (*work_location* = 5102)
> - IPIL-Hwy ports in Ontario (35XXX) use PIK data from Ottawa, Toronto Pearson T1, Toronto Pearson T3 and Billy Bishop airports (*work_location* 
> in (4312,4971,4974,4952))
> - IPIL-Hwy ports in Quebec (24XXX) use PIK data from Quebec City and Montreal Trudeau airports (*work_location* in (3123,3961))
> - IPIL-Hwy ports in New Brunswick (13XXX) and Nova Scotia (12XXX) use PIK data from Halifax airport (*work_location* = 7593)

The distribution should be determined considering only those travelling for tourism-related purposes (*traveller_type* in (1,2)) and only overseas 
travellers (*country_of_residence* not in (11124,11840,99998,99999)). Any travellers with *traveller_type* = 3 ("other travellers") or travellers
not from overseas countries can be ignored.

The imputed country of residence is then determined as follows:
> - For all applicable overseas travellers in the PIK TRAVELLERS table (i.e. from the region corresponding to the IPIL-Hwy port of entry),
> determine a country breakdown, as above
> - Order the countries based on their *country_of_residence* code, as above
> - Set each country on the (0,1) range based on their prevalence, as above
> - Assign the *country_of_residence* to the ipil_hwy record based on which range the *random_number* falls in, as above

Note: If for some reason there is no PIK data available in the system for the production month and year, use the PIK TRAVELLERS file from the same
month of the previous year (e.g. the PIK TRAVELLERS file for January 2019 if a January 2020 file is required, but not available).

Note: If there are no travellers from the correct region for either of these files, use the distribution for Canada (all work locations).

### Validity
January 2018 - present

### Required Auxiliary Inputs
The work location reference file is required.  
The transformed pik TRAVELLERS table for the production month is required.  
The transformed manual_entry TRAVELLERS table for the production month is required.

### Related Pages
None
