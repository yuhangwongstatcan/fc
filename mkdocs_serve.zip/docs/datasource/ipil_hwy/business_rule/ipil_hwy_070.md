# Documentation for Business Rule ipil_hwy_070

### ID
ipil_hwy_070

### Name
Recode the province of Mexican vehicle records based on licence plate country in IPIL-Hwy, and the country of Puerto Rican vehicle
records based on licence plate region in IPIL-Hwy.

### Type
Edit

### Purpose
Recode the *province* to "MX" of any records where the *country* variable in the raw data indicates Mexico and *province* is missing.
Recode the *country* to "PR" of any records where the *province* variable = "PR".

### Recoding Mexico
This is done in order to have consistency in the file, with country and province/state of licence plate populated everywhere, where possible.

It is necessary to have this step since the province/state variable is not typically populated for Mexican plates.

We do not need to recode if the *province* variable indicates a valid Canadian province or territory or a valid American state because those cases
have already had their countries recoded to US or Canada, as applicable (see rules ipil_hwy_050 and ipil_hwy_060).

We will not recode if *province* = "XX", as these cases are military or diplomatic vehicles, and should be specially coded as non-visitors / 
non-tourists.

### Recoding Puerto Rico
This is done in order to have consistency between the *country* and *province* variables in the case of Puerto Rican vehicles, so that they can
be accurately coded in the transformed data.

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for ipil_hwy_050]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_050)  
[Documentation for ipil_hwy_060]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_060)
