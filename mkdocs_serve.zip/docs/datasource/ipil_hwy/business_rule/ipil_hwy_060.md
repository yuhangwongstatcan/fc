# Documentation for Business Rule ipil_hwy_060

### ID
ipil_hwy_060

### Name
Recode Canadian vehicle records based on licence plate in IPIL-Hwy

### Type
Edit

### Purpose
Recode the country to "CD" of any records where the *province* variable in the raw data indicates a valid Canadian province or territory.

### Additional Details
Although it is rare to have this inconsistency, it is possible.

The *province* variable is automatically populated by a computer and verified by a border services officer, whereas the *country* variable is only 
coded by the officer, so the *province* variable is believed to be more reliable in the case of a disagreement between the two.

If the *province* variable indicates any of (AB,BC,MB,NB,NL,NS,NT,NU,ON,QC,PE,SK,YT), then the *country* variable should be recoded as "CD" (Canada).

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
None
