# Documentation for Business Rule ipil_hwy_160

### ID
ipil_hwy_160

### Name
IPIL-Hwy transformation to vehicles table

### Type
Transformation

### Purpose
Generate the IPIL-Hwy contribution to the vehicles table in the correct schema.

### Additional Details
Since the IPIL-Hwy data is at the level of the vehicle (individual vehicles crossing the border), all of the columns for the vehicles table can
be coded directly from the IPIL-Hwy clean data.

IPIL-Hwy data is transformed as follows:  

The *year* column is extracted from the *date* variable.  

The *month* column is extracted from the *date* variable.  

The *day* column is extracted from the *date* variable.  

The *port* column is copied from the *port* variable.

The *mode* column is coded as 2 ("Land"), in all cases, except where the *cport* is identified by the work location reference file as a ferry
port or marina (*water_flag* in ('ferry','private watercraft')), in which case the column is coded as 3 ("Water"). See ipil_hwy_010 for details.  

The *vehicle_type* column is coded based on the *vehi* variable, as follows:
> - If *vehi* = "A" then *vehicle_type* = 211 ("Automobile")
> - If *vehi* = "M" then *vehicle_type* = 212 ("Motorcycle")
> - If *vehi* = "O" then *vehicle_type* = 213 ("Other land vehicle")
> - If *vehi* = "C" then *vehicle_type* = 214 ("Truck")
> - If *vehi* = "B" then *vehicle_type* = 215 ("Bus")

If the record was also identified as a ferry (*water_flag* = 'ferry'), then the following vehicle types will supersede the above:
> - If *vehi* in ("A","M","O","C","B") then *vehicle_type* = 313 ("Ferry (private vehicle)")

**Note: Records with *vehi* = "P", whether aboard a ferry or not, and records identified as private boats (*water_flag* = 'private watercraft') are 
EXCLUDED from the vehicles table as the measure is not applicable for pedestrians and Frontier Counts does not record the number of private boats.**

The *plate_country* column is coded based on the *country* variable, as follows:
> - If *country* = "CD" then *plate_country* = 1 ("Canada")
> - If *country* = "US" then *plate_country* = 2 ("United States of America")
> - If *country* = "MX" then *plate_country* = 3 ("Mexico")
> - If *country* = "PR" then *plate_country* = 4 ("Puerto Rico")
> - If *country* = "XX" then *plate_country* = 8 ("Other")

The *plate_region* column is coded using the same two-letter codes in IPIL-Hwy clean data, as one of the 10 province codes, 3 territory codes,
50 state codes, "DC" (Washington D.C.), "MX" (Mexico), "PR" (Puerto Rico) or "XX" (Other).

The *work_location* column is coded from the *cport* variable.

The *data_source* column is coded as 11 ("IPIL Highway") in all cases for this data source.

Once all columns are coded, the *count_of_entries* is determined by taking the count of records grouped across all transformed variables.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The work location reference file is required.

### Related Pages
[Documentation for ipil_hwy_010]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_010)
