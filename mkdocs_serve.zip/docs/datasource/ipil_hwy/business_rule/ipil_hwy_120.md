# Documentation for Business Rule ipil_hwy_120

### ID
ipil_hwy_120

### Name
Remove records with missing dates in IPIL-Hwy

### Type
Edit

### Purpose
Remove any record from the IPIL-Hwy raw data where the date is missing.

### Additional Details
If the variable *date* is blank or so incomplete that it is not possible to determine the month of the border crossing, then the record should be
deleted, since we do not know what month to assign the border crossing to for publication.

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
None
