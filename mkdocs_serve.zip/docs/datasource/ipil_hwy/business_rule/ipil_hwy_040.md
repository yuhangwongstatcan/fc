# Documentation for Business Rule ipil_hwy_040

### ID
ipil_hwy_040

### Name
Recode Canadian records to CD in IPIL-Hwy

### Type
Edit

### Purpose
Ensure that any records having *country* = CA are recoded to *country* = CD.

### Additional Details
Sometimes the IPIL-Hwy raw files encode Canadian-plated vehicles as "CA", and sometimes as "CD". In order to avoid confusion in the tabulation of 
data, we unify the Canadian-plated records by coding all as "CD".

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
None
