# Documentation for Business Rule ipil_hwy_010

### ID
ipil_hwy_010

### Name
Edit IPIL-Hwy data based on work locations

### Type
Edit

### Purpose
This rule uses the ipil_hwy work locations reference file to perform three actions:
> - Recode vehicle types that are not permitted at certain work locations
> - Remove records with unexpected work locations or unexpected work location/transportation types, until they can be verified
> - Remove test ports

### Additional Details

##### Matching to the ipil_hwy Work Location Reference File

This edit is the first done after the raw files are read in. Each record in the raw file needs to be matched to the appropriate row of the
**work_locations__ipil_hwy.csv** reference file to determine the appropriate action. The match should be done on work location (*cport* from the
raw data) and transportation type.

The applicable codes for matching on transportation type are:
>- *ipil_hwy__211* for *vehi* = "A" from the raw data
>- *ipil_hwy__212* for *vehi* = "M" from the raw data
>- *ipil_hwy__213* for *vehi* = "O" from the raw data
>- *ipil_hwy__214* for *vehi* = "C" from the raw data
>- *ipil_hwy__215* for *vehi* = "B" from the raw data
>- *ipil_hwy__217* for *vehi* = "P" from the raw data

The corresponding *action* value then determines how each record should be processed for this edit.

Code "A" (accept) indicates to process the data without modification.

##### Recode Vehicle Types
There are some work locations in Canada where certain vehicle types are not permitted, so they are recoded with the
assumption that they were miscoded by a CBSA officer, and some other cases where the work location only accommodates water traffic or ferry traffic, so although
the vehicles are labelled as land vehicles in IPIL-Hwy, they are known to be water or ferry traffic.

All of these recoding cases have an *action* code which is prefixed by "R", and the suffix matches the vehicle type codeset from the main database.

The following cases need to be recoded:

>- Code "R211" - Recode to automobile (*vehi* = A)
>- Code "R212" - Recode to motorcycle (*vehi* = M)
>- Code "R213" - Recode to other land vehicle (*vehi* = O)
>- Code "R214" - Recode to truck (*vehi* = C)
>- Code "R215" - Recode to bus (*vehi* = B)
>- Code "R217" - Recode to pedestrian (*vehi* = P)
>- Code "R315" - Recode to ferry. This is done by adding an additional indicator variable (*water_flag* = 'ferry'), rather than recoding *vehi* raw
> variable
>- Code "R321" - Recode to private watercraft. This is done by adding an additional indicator variable (*water_flag* = 'private watercraft'),
> rather than recoding *vehi* raw variable

##### Unexpected Data Based on Work Location
The absence of a work location or work location-transportation type combination in the reference file indicates that the records **are not accepted
by default** and need to be validated first.

Therefore, if either:
> - The work location cannot be matched to the ipil_hwy work location reference file at all OR
> - The combination of work location and transportation type (*cport* and *vehi* from the raw data) is not present in the ipil_hwy work location
reference file

This indicates that vehicles of this type are not currently accepted from IPIL-Hwy, either because they were not previously expected to arrive
there, or because another source is used for them, so to use both would result in double counting. These records should also be removed until the
data has been validated and the work location list potentially updated.

##### Test Ports
Some pre-defined work location codes are used when testing the IPIL-Hwy system. Since these do not represent real border crossings, they need to
be removed from the raw data.

These are  identified by *action* = "T" in the work location reference file.

Currently known values of *cport* which indicate test ports are 1001, 1036, 1050, 1054 and 2060.

### Validity
January 2016 - present

### Required Auxiliary Inputs
The work location reference file for ipil_hwy is required.

### Related Pages
[Documentation on Work Locations]({{fc_baseurl.doc}}/reference/work_locations)
