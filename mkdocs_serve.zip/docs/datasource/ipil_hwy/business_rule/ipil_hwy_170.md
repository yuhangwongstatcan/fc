# Documentation for Business Rule ipil_hwy_170

### ID
ipil_hwy_170

### Name
IPIL-Hwy transformation to travellers table

### Type
Transformation

### Purpose
Generate the IPIL-Hwy contribution to the travellers table in the correct schema.

### Additional Details
Since the IPIL-Hwy data is at the level of the vehicle (individual vehicles crossing the border) and shows all travellers in the vehicle, a single 
record from the clean data can sometimes generate multiple entries in the travellers table depending on the travellers' characteristics.

The variables *cdsd, cd1d, cd2d, ussd, us1d, us2d, osd, o1d* and *o2d* enumerate the number of travellers of various types in each vehicle. In order
to summarize the data at the traveller level, these will need to be broken into multiple entries. The easiest way is likely to take them from a wide
format to a long format and then encode the variables at the traveller level.

In an attempt to make this simpler, the transformations have been separated into two sub-sections below, the first which shows the transformations
that can happen at the record level (and apply to all travellers in the record), and the second which shows transformations that require the record
to be split depending on the values of the above-noted traveller enumeration variables.

IPIL-Hwy data is transformed as follows:  

##### Vehicle (Record) Level Transformations

The *year* column is extracted from the *date* variable.  

The *month* column is extracted from the *date* variable.  

The *day* column is extracted from the *date* variable.  

The *port* column is copied from the *port* variable.

The *mode* column is coded as 2 ("Land"), in all cases, except where the *cport* is identified by the work location reference file as a ferry
port or marina (*water_flag* in ('ferry','private watercraft')), in which case the column is coded as 3 ("Water"). See ipil_hwy_010 for details.  

The *vehicle_type* column is coded based on the *vehi* variable, as follows:
> - If *vehi* = "A" then *vehicle_type* = 211 ("Automobile")
> - If *vehi* = "M" then *vehicle_type* = 212 ("Motorcycle")
> - If *vehi* = "O" then *vehicle_type* = 213 ("Other land vehicle")
> - If *vehi* = "C" then *vehicle_type* = 214 ("Truck")
> - If *vehi* = "B" then *vehicle_type* = 215 ("Bus")
> - If *vehi* = "P" then *vehicle_type* = 217 ("Pedestrian")

If the record was also identified as a ferry (*water_flag* = 'ferry'), then the following vehicle types will supersede the above:
> - If *vehi* in ("A","M","O","C","B") then *vehicle_type* = 313 ("Ferry (Private vehicle)")
> - If *vehi* = "P" then *vehicle_type* = 314 ("Ferry (Pedestrian)")

If the record was identified as a private boat (*water_flag* = 'private watercraft'), then *vehicle_type* = 321 ("Private boat"), which also 
supersedes the *vehi* value.

The *plate_country* column is coded based on the *country* variable, as follows:
> - If *country* = "CD" then *plate_country* = 1 ("Canada")
> - If *country* = "US" then *plate_country* = 2 ("United States of America")
> - If *country* = "MX" then *plate_country* = 3 ("Mexico")
> - If *country* = "PR" then *plate_country* = 4 ("Puerto Rico")
> - If *country* = "XX" then *plate_country* = 8 ("Other")

**Note: In the case of pedestrians (*vehi* = "P") or private boat (*water_flag* = 'private watercraft'), *plate_country* = 9 ("Not applicable"),
which supersedes the above logic based on *country***.

The *plate_region* column is coded using the same two-letter codes in IPIL-Hwy clean data (*province*), as one of the 10 province codes, 3 
territory codes, 50 state codes, "DC" (Washington D.C.), "MX" (Mexico), "PR" (Puerto Rico) or "XX" (Other).  
**Note: In the case of pedestrians (*vehi* = "P") or private boat (*water_flag* = 'private watercraft'), *plate_region* is coded as "NA" (Not 
applicable), which supersedes the above logic based on *province*.**

The *work_location* column is coded from the *cport* variable.

The *data_source* column is coded as 11 ("IPIL Highway") in all cases for this data source.


##### Traveller (Sub-record) Level Transformations

The *arriving_from* column is coded as follows:
> - If Canadian or American residents (i.e. cdsd, cd1d, cd2d, ussd, us1d or us2d) and *country* not in ("MX","PR") then *arriving_from* = 1 ("United States only")
> - If Canadian or American residents (i.e. cdsd, cd1d, cd2d, ussd, us1d or us2d) and *country* in ("MX","PR") then *arriving_from* = 3 ("Other country via 
the United States")
> - If overseas residents (i.e. osd, o1d, o2d), then *arriving_from* = 3 ("Other country via the United States")

The *country_of_residence* column is coded as:
> - 11124 for Canadian residents (cdsd, cd1d, cd2d)
> - 11840 for American residents (ussd, us1d, us2d)
> - The imputed *country_of_residence* for overseas residents (osd,o1d,o2d)

The trip purpose columns should be coded as *purpose9* = 19 ("Visit, not otherwise specified") and *purpose4* = 1 ("Visit"), except in the
following cases:
> - If *vehicle_type* = 214 ("Truck"), then *purpose9* = 21 ("Crew") and *purpose4* = 2 ("Crew")
> - If *vehicle_type* = 215 ("Bus"), then **one** traveller should be coded as *purpose9* = 21 ("Crew") and *purpose4* = 2 ("Crew"). The crew can
be taken from the maximum of the 9 traveller variables. If there is a tie for the maximum, take from the left-most variable. For the rest of the
passengers in the bus, the above rule applies for trip purpose columns.
> - If *plate_country* = "XX" and *vehicle_type* != 217 ("Pedestrian"), then *purpose9* = 43 ("Other purpose") and *purpose4* = 4 ("Other non-tourism")

The trip duration columns are coded as follows:
> - If a same-day traveller (i.e. cdsd, ussd or osd), then *duration2* = 1 ("Same day") and *duration3* = 11 ("Same day")
> - If a one-night traveller (i.e. cd1d, us1d or o1d), then *duration2* = 2 ("Overnight") and *duration3* = 21 ("One night")
> - If a two-or-more-nights travellers (i.e. cd2d, us2d or o2d), then *duration2* = 2 ("Overnight") and *duration3* = 22 ("Two or more nights")  

*duration5* is coded as 99 ("Not available") in all cases for IPIL Highway.

The *traveller_type* column is derived from other columns in the travellers table as follows:
> - If *purpose4* != 1 ("Visit"), then *traveller_type* = 3 ("Other traveller")
> - If *purpose4* = 1 ("Visit") and *duration2* = 1 ("Same day"), then *traveller_type* = 1 ("Excursionist")
> - If *purpose4* = 1 ("Visit") and *duration2* = 2 ("Overnight"), then *traveller_type* = 2 ("Tourist")

Once all columns are coded, the *count_of_entries* (count of travellers) is determined by taking the sum of travellers grouped across all 
transformed variables.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The work location reference file is required.

### Related Pages
[Documentation for ipil_hwy_010]({{fc_baseurl.doc}}/datasource/ipil_hwy/business_rule/ipil_hwy_010)
