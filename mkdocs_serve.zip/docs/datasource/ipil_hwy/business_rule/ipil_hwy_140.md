# Documentation for Business Rule ipil_hwy_140

### ID
ipil_hwy_140

### Name
Impute overfull bus records in IPIL-Hwy

### Type
Imputation

### Purpose
Impute the number of passengers in a bus in IPIL-Hwy if it is overfull.

### Additional Details
An overfull bus is defined as having more than 99 (100+) passengers. In other words, the sum of the variables *cdsd, cd1d, cd2d, ussd, us1d,
us2d, osd, o1d* and *o2d* being greater than 99 when *vehi* = "B".

In this case, a donor is selected as the nearest neighbour by **absolute** difference between date and time in (*date* and *sin*), matching on
vehicle type (*vehi*), work location (*cport*) and country of licence plate (*country*). 

If an appropriate donor cannot be found based on all criteria, match only on *vehi* and *country*, searching within province for a donor. The 
corresponding province for a *cport* can be determined by linking to the work location reference file, and using the first two digits of the 
corresponding port of entry (standard StatCan province code makes up the first two digits of this *port*).

If still an appropriate donor cannot be found, match only on *vehi*.

If the nearest neighbour found also violates the rule and needs to be imputed, continue searching to the nth nearest neighbour. Multiple candidate 
records for imputation can have the same donor.

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
None
