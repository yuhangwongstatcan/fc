# Documentation for Business Rule ipil_hwy_110

### ID
ipil_hwy_110

### Name
Remove duplicates in IPIL-Hwy

### Type
Edit

### Purpose
Retain only one record for each set of duplicate rows in the IPIL-Hwy raw data.

### Additional Details
In IPIL-Hwy, a duplicate is defined as having the same work location (*cport*), lane (*lane*), date (*date*) and time in (*sin*). For cases where
two or more records have duplication of these four key values, retain the first record in the file by default and delete the rest of the duplicate
rows.

Duplicate records typically happen either due to system glitches or two vehicles passing in tandem, one of which should not be counted, such as
a trailer or towed vehicle.

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
None
