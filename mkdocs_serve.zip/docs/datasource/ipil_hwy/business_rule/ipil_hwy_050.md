# Documentation for Business Rule ipil_hwy_050

### ID
ipil_hwy_050

### Name
Recode American vehicle records based on licence plate in IPIL-Hwy

### Type
Edit

### Purpose
Recode the country to "US" of any records where the *province* variable in the raw data indicates a valid U.S. state.

### Additional Details
Although it is rare to have this inconsistency, it is possible.

The *province* variable (which also indicates state of licence plate if applicable) is automatically populated by a computer and verified by a 
border services officer, whereas the *country* variable is only coded by the officer, so the province/state variable is believed to be more 
reliable in the case of a disagreement between the two.

If the *province* variable indicates any of (AK,AL,AR,AZ,CA,CO,CT,DC,DE,FL,GA,HI,IA,ID,IL,IN,KS,KY,LA,MA,MD,ME,MI,MN,MO,MS,MT,NC,ND,NE,NH,NJ,NM,NV,
NY,OH,OK,OR,PA,RI,SC,SD,TN,TX,UT,VA,VT,WA,WI,WV,WY), then the *country* variable should be recoded as "US".

### Validity
January 2016 - present

### Required Auxiliary Inputs
None

### Related Pages
None
