# Documentation for Business Rule ipil_hwy_080

### ID
ipil_hwy_080

### Name
Recode overfull automobiles to buses in IPIL-Hwy

### Type
Edit

### Purpose
Recode any automobile records that have more than eight passengers as buses.

### Additional Details
Any automobile records (*vehi* = "A") with nine or more total passengers (sum of *cdsd, cd1d, cd2d, ussd, us1d, us2d, osd, o1d, o2d*) are 
recoded as buses (*vehi* = "B"), in order to align with the adopted United Nations World Tourism Organization (UNWTO) tourism standard where a 
private automobile is defined to include up to eight passengers.

The assumption is that anything with over eight passengers is a small bus, or was miscoded by an officer.

### Validity
January 2022 - present

Note: Prior to the Frontier Counts system redesign, the threshold for recoding was more than 10 passengers to align with a Transport Canada
definition, but one of the objectives of the redesigned system is to align more closely with UNWTO definitions and recommendations.

### Required Auxiliary Inputs
None

### Related Pages
None
