# IPIL Highway Data Source

### Data Reception
The IPIL (Integrated Primary Inspection Line) Highway system is the main source of data that the Frontier Counts program uses for automobile, 
motorcycle, truck, bus, pedestrian and other land vehicle arrivals.

The IPIL Highway data are microdata at the level of the vehicle crossing the border. They contain information about the vehicle itself, as well
as information about the occupants.

The parameters of the received files are as follows:
> - File type: .dat (flat files), either individual files or zipped together
> - Naming conventions:
>   - Individual files are named as STATSCAN_YYYY-MM-DD-HH.MM.SS.SSS.dat, where YYYY, MM, DD, HH, SS and SSS represent the date and time that the
>   process was run to create the file.
>       - Note: To identify IPIL-Hwy files, can use the pattern STATSCAN_####-##-##-##.##.###.dat
>       - Note: The date in the file name does not necessarily equate to the dates of the border crossings in the raw data
>   - Zip files are named as YYYYMMDD_######_YYY2-M2 #of#.zip, where YYYY, MM and DD represent the date that the process was run, and YYY2 and M2
>   represent the reference period
>       - Note: To identify IPIL-Hwy zip folders (which should be unpacked to access the .dat files), can use the pattern YYYYMMDD_######_####-##*.zip
> - Timeliness: All files for a month received within a couple of days of the end of the reference month
>   - For example, files for May received around June 1 - 3
> - Granularity: Daily, although sub-daily granularity to the second is available as well
> - Date Variable: "date"
> - Format YYYY/MM/DD

### Process
The IPIL Highway system is installed at most land points of entry in Canada. When a vehicle passes into the border checkpoint area, a camera
takes a photo of the licence plate, which populates the *province* and *country* variables below. If the system cannot determine the location of
the plate, a border officer corrects the information in the system.

The officer then manually enters the vehicle type, and the count of occupants according to residency and duration of stay, based on questions
asked of the travellers.

The rest of the variables are populated automatically for each border crossing based on system parameters (e.g. location of installation, date and
time of crossing, etc.)

### Variables
The variables provided are the following:

> - vehi: Vehicle type, either automobile, motorcycle, commercial truck, bus, pedestrian or other land vehicle
> - cdsd: Number of same-day Canadian resident travellers in the vehicle
> - cd1d: Number of one-night Canadian resident travellers in the vehicle
> - cd2d: Number of two-or-more-night Canadian resident travellers in the vehicle
> - ussd: Number of same-day American resident travellers in the vehicle
> - us1d: Number of one-night American resident travellers in the vehicle
> - us2d: Number of two-or-more-night American resident travellers in the vehicle
> - osd: Number of same-day overseas resident travellers in the vehicle
> - o1d: Number of one-night overseas resident travellers in the vehicle
> - o2d: Number of two-or-more-night overseas resident travellers in the vehicle
> - country: Country of the licence plate of the vehicle, either Canada, United States, Mexico or Other (XX)
> - date: Date that the vehicle crossed the border
> - sin: Time the vehicle crossed into the border checkpoint
> - sout: Time the vehicle passed out of the border checkpoint
> - lane: Lane which the vehicle passed through the port of entry, or mobile device identification that was used to process the vehicle
> - cport: Code for the CBSA work location that the vehicle passed through
> - province: Region (province or state) of the licence plate of the vehicle
> - canpass1: Indicator variable for if the travellers are members of the CANPASS program
> - canpass2: Indicator variable for if the vehicle passed through a CANPASS lane

For more information, refer to the dimension and index reference files for the *ipil_hwy* data source.
