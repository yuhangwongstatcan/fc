# Manual Entry Data Source

### Purpose
The “manual entry component” of the redesigned Frontier Counts system serves as the catchall entry point for data which cannot be processed through one of the dedicated pipelines (e.g. IPIL-Hwy, NEXUS, etc.), either because the data has a non-standard input format, the data reception is too irregular to justify the creation of a dedicated pipeline, or significant human interaction or judgement is required at the data ingestion phase.

### Sources
The data sources to be processed through the manual entry component currently comprise, but are not limited in the future to:
> -	E62 (green) tally sheets
> -	E62B (red) bus tally sheets
> - E63 or E63-1 “residual” data which cannot be processed through the regular pipeline
> - Overseas summary reports
> - Passport counts
> - Emails, faxes or other ad hoc data additions, including cases where data should have been received, but CBSA was not able to provide a total (“Nothing Received”)
> - Imputed data to fill outage gaps or other gaps in electronic data sources such as IPIL-Hwy, NEXUS, PIK, TRC, etc.
> - Corrections (negatives)

### Data Capture
Data is entered by the Frontier Counts Production Team in the manual entry capture application. The data for a month may be entered in one batch, or in several batches throughout the month before passing through the data processing pipelines.

The fields to be completed correspond to variables from the VEHICLES and TRAVELLERS database tables, namely (for TRAVELLERS):
> - DATA SOURCE (required; dropdown, limited selection)
> - YEAR (required)
> - MONTH (required)
> - DAY
> - PORT (required; dropdown, limited selection based on port list)
> - VEHICLE TYPE (dropdown, limited selection from valid values in database)
> - PLATE COUNTRY (dropdown, limited selection from valid values in database; not applicable for many vehicle types)
> - ARRIVING FROM (dropdown, limited selection from valid values in database)
> - COUNTRY OF RESIDENCE (dropdown, limited selection based on country list)
> - TRIP PURPOSE (DETAILED) (dropdown, limited selection from valid values of the Purpose9 variable in the database)
> - TRIP PURPOSE (dropdown, limited selection from valid values of the Purpose4 variable in the database - VISIT, WORK, CREW or OTHER NON-TOURISM; even if not explicitly available, can be assumed as VISIT in many cases by the Production Team)
> - DURATION (dropdown, limited selection from valid values of the Duration2 variable in the database - SAME-DAY or OVERNIGHT)
> - NUMBER OF TRAVELLERS

Note: Fields are "optional" and entered only if provided by CBSA unless marked as "required" above.

The fields to be made available for capture in the VEHICLES template are: DATA SOURCE, YEAR, MONTH, DAY, PORT, VEHICLE TYPE, PLATE COUNTRY and NUMBER OF VEHICLES

The fields which are included in the TRAVELLERS table of the database but excluded from the manual entry capture are MODE, PLATE REGION (LICENCE PLATE), DURATION3, DURATION5, TRAVELLER TYPE and WORK LOCATION, either because they are almost never available from the sources which would typically be captured in the manual entry component, they are a rollup of another variable captured or they are derived from a combination of the captured variables.

### Imputation

If any of the critical Frontier Counts variables are not available from a given data entry, the Production Team enters them as "Not available" or "Not applicable", and the data processing pipeline will impute the variable breakdowns based on auxiliary data. The variables which are considered critical for Frontier Counts and which will pass through imputation if they are not available are VEHICLE TYPE, PLATE COUNTRY, ARRIVING FROM, COUNTRY OF RESIDENCE, TRIP PURPOSE and DURATION.

If NUMBER OF TRAVELLERS or NUMBER OF VEHICLES is left blank, this indicates a case of “Nothing Received”, and the total will be imputed as well as any applicable missing breakdowns. In the case of a correction, a negative number is entered in the NUMBER OF TRAVELLERS or NUMBER OF VEHICLES (as applicable) field.
