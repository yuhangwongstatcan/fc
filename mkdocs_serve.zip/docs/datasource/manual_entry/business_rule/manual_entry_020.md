# Documentation for Business Rule manual_entry_020

### ID
manual_entry_020

### Name
Imputation for unknown variable breakdowns using fixed rules

### Type
Imputation

### Purpose
Impute the breakdown for variables where it was unknown from the manual entry capture, in the case where predefined fixed rules are available.

### Additional Details

##### Imputation Using Fixed Rules
In some cases, some of the variable breakdown details required for Frontier Counts are known at the time of data entry, and in some cases they are not. 

Since Frontier Counts has an obligation to publish detail on certain characteristics (vehicle type, plate country [if applicable], arriving from, country of residence, basic trip purpose, basic trip duration), if these details are not known for some of the manual entries, they are imputed using auxiliary data.

For some of these unknown breakdowns, there are precise distributions that are to be used. This is often because a CBSA representative was able to confirm separately an appropriate breakdown, yet they do not provide the detailed statistics in their reports. Before progressing to the use of auxiliary data for imputation of variable breakdowns, this business rule ensures that any applicable fixed rules are applied.

##### Definition of Fixed Rules
Fixed rules are defined by the Production Team for a specific port, data source (individual or all) and time period. They can also be defined to apply to specific categories of other variables.

All of these rules are defined in the FIXED RULES module of the web application, and they are stored in:
> - **fixed_proportion_rules.csv** to list the rules
> - **fixed_proportions.csv** to define the specific proportions for each rule

Examples:
> - For all Canadian travellers at Port ABC, 90% are same-day and 10% are overnight
> - For train crew reported on E62 forms at Port DEF, 60% are Canadian residents, 35% are American residents and 5% are Mexican residents

### Validity
January 2022 - present

### Required Auxiliary Inputs
The **fixed_proportion_rules.csv** and **fixed_proportions.csv** reference files are required to verify if there are any applicable fixed rules for each manual entry.

### Related Pages
None
