# Documentation for Business Rule manual_entry_030

### ID
manual_entry_030

### Name
Imputation for unknown variable breakdowns using historical data from previous years

### Type
Imputation

### Purpose
Impute the breakdown for variables where it was unknown from the manual entry capture, in the case where there are no predefined fixed rules and the imputation is done using historical data from previous years of Frontier Counts.

### Additional Details

##### Using Aggregated Data from the Current Year
If imputation of the breakdown for one or more variables is required in the absence of a predefined fixed rule, the pipeline confirms if a “high proportion” (greater than 50%) of data for the combination of CRITICAL filled fields has already been received for the month compared to the same month from the previous year, before deciding to use the breakdown currently available in the system. The purpose of this check is to ensure that we do not use proportions from the current month which are based only on a tiny number of travellers to impute a high number of travellers captured in the manual entry component. 

Concretely, the check is: For the combination of all filled CRITICAL fields, is {sum(Count of Vehicles or Count of Travellers, as applicable, from the current year already in the system) / sum(Count of Vehicles or Counts of Travellers, as applicable, from the same month of YYYY-1) > 50%}?

If the condition is met, then NUMBER OF TRAVELLERS or NUMBER OF VEHICLES will be broken down based on the applicable distributions from the VEHICLES or TRAVELLERS table from the current year and month, already in the system. If not, then the pipeline moves to the next step.

For example, if we need to impute the TRIP DURATION breakdown of 1,000 VISITing Canadian BUS travellers at Port ABC from an E62B file for July 2020, with N/A licence plates, arriving from U.S. ONLY, the system looks to the TRAVELLERS table of the database and sees that there are 20 travellers from these categories from IPIL-Hwy already in the database for the current year and month; however in July 2019, there were 975. The check (20/975 > 50%) fails, so the module moves to the next condition.

##### Using Aggregated Data from a Previous Year
If the breakdown imputation is still not resolved, the pipeline confirms if the NUMBER OF TRAVELLERS for which the breakdown needs to be imputed is significantly higher across the combination of filled CRITICAL fields than it was in the same month of YYYY-X from the VEHICLES or TRAVELLERS table of the database. The purpose of this check is to ensure that a small amount of data from the same month of the previous year is not used to impute a large amount of data entered in the manual entry batch.

Concretely, the check is: For the combination of all filled CRITICAL fields, is {sum(Count of Vehicles or Count of Travellers, as applicable, from the same month of YYYY-X) / NUMBER OF VEHICLES or NUMBER OF TRAVELLERS, as applicable > 50%}? The value X is passed as a parameter *reference_year* at runtime by the user.

If the condition is met, then NUMBER OF TRAVELLERS or NUMBER OF VEHICLES will be broken down based on the applicable distributions from the VEHICLES or TRAVELLERS table from the same month of YYYY-X. If not, then the pipeline moves to the next step.

For example, continuing the previous example, if we need to impute the TRIP DURATION breakdown of 1,000 VISITing Canadian BUS travellers at Port ABC from an E62B file for July 2020, with N/A licence plates, arriving from U.S. ONLY, the system looks to the corresponding rows of the TRAVELLERS table for July 2019 and there were 975 travellers. The check (975/1000 > 50%) passes, so the imputation is done using the breakdown of the 975 travellers, and this manual entry row does not need to proceed to the next step in the pipeline.

##### Remedial Steps
If the above conditions are not met and breakdown imputation is therefore still not resolved, the steps to attempt imputation using data from the current year or the same month of a previous year are repeated, but using data from all ports in the appropriate province from the VEHICLES or TRAVELLERS table. 

If the breakdown imputation is still not resolved, the steps are repeated using data from all ports in Canada. 

### Validity
January 2022 - present

### Required Auxiliary Inputs
The TRAVELLERS and VEHICLES tables from the current year and the specified previous year (*reference_year*) are required to do the imputation.

### Related Pages
None
