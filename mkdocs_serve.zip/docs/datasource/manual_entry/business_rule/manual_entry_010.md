# Documentation for Business Rule manual_entry_010

### ID
manual_entry_010

### Name
Imputation for unknown number of travellers or number of vehicles

### Type
Imputation

### Purpose
Impute a count of travellers or count of vehicles (depending on the capture form) when the count is unknown (entered as a blank in the data capture form).

### Additional Details
In some cases, it is known that certain types of travellers or certain types of vehicles crossed the border, however CBSA is not able to provide a precise count (or even an estimate) of the exact number. For example, it might be known that American train crew crossed at Port XYZ, but CBSA cannot provide a count of crew members.

Since there is no basis to record the number of travellers or number of vehicles in these cases except historical data, cases of "nothing received" (where the "Number of Travellers" or "Number of Vehicles" [*count_of_entries* in the data] is left blank during capture) are imputed using counts from the a past year in the VEHICLES or TRAVELLERS table, as applicable. 

The past year to be used is specified by the user at runtime as *reference_year* as it may not always be desirable to use the year directly preceding the current one (for example, during COVID-19).

### Validity
January 2022 - present

### Required Auxiliary Inputs
The VEHICLES or TRAVELLERS aggregated files are required to do the imputation.

### Related Pages
None
