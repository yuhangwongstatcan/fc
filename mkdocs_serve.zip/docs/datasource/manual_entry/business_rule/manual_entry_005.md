# Documentation for Business Rule manual_entry_005

This is an empty business rule which only runs the identity function.

It exists only to provide a function to couple to the manual_entry_v005 validation, as per the following document:  
[Business Rule and Validation Organization]({{fc_baseurl.doc}}/architecture/business_rule_validation_organization) 