# Documentation for Validation manual_entry_v005

### ID
manual_entry_v005

### Related Business Rule
manual_entry_005

### Name
Manual Entry Tracker - Unexpected Manual Entry Data

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of manual entry records that did not have a corresponding entry in the Manual Entry Tracker.

### Additional Details

##### Flagged Records
This validation logs manual entries that are not "expected" in a given month, meaning that they are not present in the Manual Entry Tracker (**manual_entry_tracker_vehicles.csv** or **manual_entry_tracker_travellers.csv**) files which enumerate the types of manual entry data that are expected to be received from CBSA each month.

##### Dashboard Display
The dashboard displays a table visual showing a list of the manual entries which were not present in the Manual Entry Tracker.

This graphic can be filtered dynamically by year and month.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The Manual Entry Tracker files **manual_entry_tracker_vehicles.csv** and **manual_entry_tracker_travellers.csv** are required.

### Related Pages
[Documentation for manual_entry_005]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_005)
