# Documentation for Validation manual_entry_v007

### ID
manual_entry_v007

### Related Business Rule
manual_entry_007

### Name
Manual Entry Tracker - Manual Entry Data Not Received

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of manual entry data that was not received.

### Additional Details

##### Flagged Records
This validation logs entries from the Manual Entry Tracker (**manual_entry_tracker_vehicles.csv** and **manual_entry_tracker_travellers.csv**) files that do not have a corresponding data entry from the manual entry component for a given month. This indicates that these types of data were expected to be received from CBSA each month, but either are not available or have not been received yet in the month.

##### Dashboard Display
The dashboard displays a table visual showing a list of Manual Entry Tracker entries which are not present in the manual entry capture data.

This graphic can be filtered dynamically by year and month.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The Manual Entry Tracker files **manual_entry_tracker_vehicles.csv** and **manual_entry_tracker_travellers.csv** are required.

### Related Pages
[Documentation for manual_entry_007]({{fc_baseurl.doc}}/datasource/manual_entry/business_rule/manual_entry_007)
