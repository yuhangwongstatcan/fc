# Documentation for Validation nexus_air_v010

### ID
nexus_air_v010

### Related Business Rule
nexus_air_010

### Name
Summary of NEXUS Air Work Location Issues

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected work locations from NEXUS Air, and a summary of expected NEXUS Air locations
which were not received or had zero travellers.

### Additional Details

##### Unexpected Work Locations
This portion of the validation is produced for the Production Team to examine records that could not be matched to the nexus_air work location 
reference file, either because the work location code from the raw data is not present in the reference file, or because the work location does not 
have a corresponding *transportation_type* of nexus_air__111 (for commercial aircraft; all NEXUS Air data is considered commercial air traffic).

Since NEXUS Air processing capacity only exists at a limited number of airports, these unexpected work locations could indicate airports that have 
added a NEXUS processing area or could indicate data errors, both of which need to be investigated.

These cases are flagged in the validation file as *work_location_issue_type* = "Unexpected Work Locations".

##### Missing Work Locations
This portion of the validation is produced for the Production Team to examine work locations that were expected to have NEXUS Air data (i.e. 
they had a corresponding record in the nexus_air work location reference file), but no raw data was received for the month.

It is expected that all NEXUS Air work locations will be reported from CBSA each month, so if an expected location is missing, CBSA needs to
be contacted to see if the location is closed (temporarily or permanently), or was omitted in error.

These cases are flagged in the validation file as *work_location_issue_type* = "Missing Work Locations".

##### Work Locations with Zero NEXUS Travellers
This portion of the validation is produced for the Production Team to examine work locations that were expected to have NEXUS Air data, and for
which raw data was received, but the total numbers of travellers is zero.

It is expected that an open NEXUS Air processing area will have at least some travellers each month, so if an expected location has zero 
travellers, CBSA needs to be contacted to see if the processing area is closed, if the total is a true zero, or if the data was dropped in error.

These cases are flagged in the validation file as *work_location_issue_type* = "Zero NEXUS Travellers".

##### Dashboard Display
The dashboard displays a filterable table with the various *work_location_issue_type* issues. 

Filters are available by year and month, as well as an auxiliary filter by work location issue type.

### Validity
March 2017 - present

### Required Auxiliary Inputs
The NEXUS Air work location reference file is required.

### Related Pages
[Documentation for nexus_air_010]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_010)
