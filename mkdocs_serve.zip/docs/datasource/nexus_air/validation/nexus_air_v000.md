# Documentation for Validation nexus_air_v000

### ID
nexus_air_v000

### Related Business Rule
None (nexus_air_000 is an empty business rule)

### Name
Summary of Unexpected Values - NEXUS Air

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected values for discrete variables in NEXUS Air.

### Additional Details

##### Variable Values
The system is only expecting to see certain values in each discrete variable, as specified in the dimension files **dim__nexus_air__...**. The valid
values are based on the Excel files received historically from CBSA. The Production Team needs to be aware of unexpected values, because the system 
may not be able to handle them, or they could indicate invalid records from NEXUS raw data.

Specifically, the following variables should have their values validated:
> - *citizenship* in ("Canada","United States","Other")

##### Dashboard Display
Any invalid values are displayed in a bar chart grouping invalid codes by variable name.  

This graphic can be filtered dynamically by month and year.

### Validity
March 2017 - present

### Required Auxiliary Inputs
The dimension files for the nexus_air data source are required.

### Related Pages
None
