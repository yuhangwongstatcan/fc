# Documentation for Business Rule nexus_air_040

### ID
nexus_air_040

### Name
NEXUS Air transformation to travellers table

### Type
Transformation

### Purpose
Generate the NEXUS Air contribution to the travellers table in the correct schema.

### Additional Details
To generate the NEXUS Air contribution to the aggregate TRAVELLERS table, code the columns of the TRAVELLERS table as follows:

The *year* column is extracted from the *date* variable.  

The *month* column is extracted from the *date* variable.  

The *day* column is coded as 99 ("Not available") in all cases.  

The *port* column is coded based on linking *work_location* to the work location reference file and extracting the corresponding port value.

The *mode* column is coded as 1 ("Air") in all cases.  

The *vehicle_type* column is coded as 111 ("Commercial aircraft") in all cases.

The *plate_country* and *plate_region* columns are coded as 9 ("Not applicable) and NA ("Not applicable) respectively.

The *arriving_from* column is coded as 1 ("United States only") in all cases.

The *country_of_residence* column is coded based on the *citizenship* variable as:
> - If *citizenship* = "Canada" then *country_of_residence* = 11124
> - Else if *citizenship* = "United States" then *country_of_residence* = 11840

The *purpose9* and *purpose4* columns are coded as 19 ("Visit, not otherwise specified") and 1 ("Visit") respectively.

The *duration2* column is copied from the imputed *duration2* variable.

The *duration3* and *duration5* columns are coded as 99 ("Not available") and 99 ("Not available") respectively.

The *traveller_type* column is derived from other columns in the travellers table as follows:
> - If *duration2* = 1 ("Same day") then *traveller_type* = 1 ("Excursionist")
> - Else if *duration2* = 2 ("Overnight"), then *traveller_type* = 2 ("Tourist")
Note: There are no "Other travellers" in NEXUS Air; all are considered visitors or returning visitors.

The *work_location* column is copied from the *work_location* variable.

The *data_source* column is coded as 15 ("NEXUS Air") in all cases for this data source.

Once all columns are coded, the *count_of_entries* is determined by taking the sum of *count* grouped across all transformed variables.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The work location reference file is required.

### Related Pages
None
