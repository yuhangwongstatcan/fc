# Documentation for Business Rule nexus_air_010

### ID
nexus_air_010

### Name
Remove NEXUS Air records with unexpected work locations

### Type
Edit

### Purpose
Remove records from the NEXUS Air raw data that cannot be matched to the work location reference file, or for which the file indicates that they are
not accepted, until they can be reviewed.

### Additional Details
The NEXUS program is only available (meaning a NEXUS cardholder can pass through a specialized kiosk or processing area) at a limited number of 
airports and the Production Team needs to be aware of any unexpected work locations as this could represent a new NEXUS Air location (in which case 
the **work_locations__nexus_air.csv** reference file needs to be updated) or an indication of erroneous or invalid data (in which case the records 
should be removed).

The NEXUS Air raw data should be joined with the **work_locations__nexus_air.csv** reference file on work location (*work_location* variable from 
the NEXUS Air data, as coded from the business rule nexus_air_005) and *transportation_type* = "nexus_air__111" (since all NEXUS Air data 
are considered commercial aircraft).

If the corrseponding action is "A" (accept) in the work location reference file, the record should be maintained.

A record should be removed in the following cases:
> - The *work_location* code cannot be matched to the work location reference file
> - The *work_location* can be matched, but there is no corresponding "nexus_air__111" entry for *transportation_type*
> - The *work_location* variable is blank

These removed records will be examined as part of the nexus_air_v010 validation.

### Validity
January 2017 - present

### Required Auxiliary Inputs
The nexus_air work location reference file is required.

### Related Pages
[Documentation on Work Locations]({{fc_baseurl.doc}}/reference/work_locations) 
[Documentation for nexus_air_005]({{fc_baseurl.doc}}/datasource/nexus_air/business_rule/nexus_air_005) 
