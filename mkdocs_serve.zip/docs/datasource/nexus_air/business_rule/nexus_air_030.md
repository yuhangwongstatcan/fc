# Documentation for Business Rule nexus_air_030

### ID
nexus_air_030

### Name
Impute trip duration for NEXUS Air travellers

### Type
Imputation

### Purpose
Assign a trip duration of same day or overnight to travellers in NEXUS Air.

### Additional Details
There is no trip duration available from the NEXUS Air summary file that we currently receive, but this is a required element (at a minimum
same day and overnight) for Frontier Counts, so an imputation is required.

The best auxiliary data source that we have available to impute NEXUS Air trip durations is PIK because Kiosks are installed at (mostly) the same
airports that have NEXUS traveller processing available. As such, the NEXUS travellers (who are not required to make a declaration at a PIK Kiosk)
likely arrived on the same flights as the PIK travellers. PIK also has very reliable trip duration information, so although the travel patterns of 
NEXUS Air travellers may be somewhat different from the travellers declaring at a PIK Kiosk, this is the best auxiliary source that we have.

To generate the required reference distributions, read in the transformed PIK file (**travellers.csv.pik**) from the same month as the NEXUS 
data being processed and calculate the proportion of same day travellers (excursionists) for both Canadian and American residents by work 
location.

Concretely, for each PIK *work_location*, calculate:
> - (sum(*count_of_entries*) where *traveller_type* = 1 / sum(*count_of_entries*) where *traveller_type* in (1,2)) having 
*country_of_residence* = 11124 as the same day proportion for Canadian residents
> - (sum(*count_of_entries*) where *traveller_type* = 1 / sum(*count_of_entries*) where *traveller_type* in (1,2)) having
 *country_of_residence* = 11840 as the same day proportion for American residents

The easiest way to add this to the dataframe is to use the *duration2* variable from the TRAVELLERS table, which will be encoded shortly. After
applying the appropriate proportion to the *count* of travellers by *work_location* and *citizenship*, we code the resultant *count* of same-day 
travellers as *duration2* = 1 and the resultant count of overnight travellers as *duration2* = 2. In this case, use the calculated PIK proportion
for Canadian resident travellers when *citizenship* = "Canada", and use the calculated PIK proportion for American resident travellers when
*citizenship* = "United States".

For example, if there are 1000 same-day Canadian travellers (excursionists) from PIK in January 2020 at Montreal (3961) and 3000 overnight 
travellers (tourists), then the same-day proportion for Canadian travellers at this work location is 25%. If there are 200 NEXUS Air travellers at 
Montreal in January 2020 where *citizenship* = "Canada", then code 50 as *duration2* = 1 and 150 as *duration2* = 2.

If there is no PIK data available at the same work location for the month being processed, the national (all PIK airports) proportion can be used.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The PIK transformed data for the same month being processed for NEXUS Air is required.

### Related Pages
[Documentation for PIK transformed data]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_110)
