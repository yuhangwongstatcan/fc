# Documentation for Business Rule nexus_air_000

This is an empty business rule which only runs the identity function.

It exists only to provide a function to couple to the nexus_air_v000 validation, as per the following document:  
[Business Rule and Validation Organization]({{fc_baseurl.doc}}/architecture/business_rule_validation_organization) 
