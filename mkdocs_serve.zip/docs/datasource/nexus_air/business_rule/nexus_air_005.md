# Documentation for Business Rule nexus_air_005

### ID
nexus_air_005

### Name
Add work location code to NEXUS Air data.

### Type
Edit

### Purpose
Add the four digit CBSA work location code to the NEXUS Air input data, which will be used with the nexus_air work location reference file to 
determine which data is accepted.

### Additional Details
NEXUS Air data is received in Excel file format with string (text) names for each NEXUS airport. In order to avoid the difficulties of working with 
string values, and to be consistent with other data sources, we will use a mapping file to convert the string names provided by CBSA in the raw 
NEXUS Air data into the corresponding work location codes.

The corresponding work location code can be obtained from the string value using the nexus_air work location mapping file 
(**map__nexus_air__raw__wloc__nexus_air__clean__work_location.csv**) by matching the *wloc* variable coded during the NEXUS Loader function.

This variable can be added to the nexus_air data as *work_location*, which will later be inserted into the travellers table.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The nexus_air work location mapping file is required.

### Related Pages
[Documentation on NEXUS Air, including Loader function]({{fc_baseurl.doc}}/datasource/nexus_air/overview)
