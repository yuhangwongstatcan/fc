# NEXUS Air Data Source

### NEXUS Program
The NEXUS program is a trusted traveller program which allows pre-approved travellers to pass between Canada and the United States with minimal
interaction with border authorities (CBSA or U.S. Customs and Border Protection).

Since air travellers using the NEXUS program have specific lanes, there is no overlap between NEXUS and other data sources. For example, NEXUS 
travellers by air do not need to make a declaration at a PIK Kiosk, or to submit an E311 declaration card.

### Data Reception
Note: NEXUS Air data and NEXUS Highway data are received in the same file each month, so this section is duplicated in the documentation of NEXUS
Air and NEXUS Highway since they will be processed by the same loader function.

NEXUS Air data is received (with NEXUS Highway data) in a single Excel file each month. The file provides an aggregate monthly total by port of
entry and, in some tabs of the Excel file, by citizenship.

The parameters of the received files are as follows:
> - File type: .xlsx (Excel)
> - Naming conventions:
>>  - File name of the form: Month YYYY - STAT CAN Monthly Nexus Report.xlsx
>>>>   - Note: To identify NEXUS files, can use the pattern: *STAT CAN Monthly Nexus Report.xlsx
>>   - There are three tabs in the Excel file:
>>>    - NEXUS vs all Conveyances: Showing NEXUS Highway vehicle traffic
>>>    - NEXUS Land Citizenship: Showing NEXUS Highway travellers
>>>    - NEXUS Air Citizenship: Showing NEXUS Air travellers
> - Timeliness: One file is received monthly near the middle of the following month
>>  - For example, file for February received in mid-March
> - Granularity: Monthly
> - Date Variable: N/A; year needs to be extracted from YYYY of the file name, and month from the "Month" of the file name
> - Format: 
>>  - YYYY is a four-digit year
>>  - Month can be three (e.g. "Mar") or four (e.g. "Sept") characters, or the whole month name (e.g. "January")

### NEXUS Loader Function
As noted, since there is one file which contains data for both NEXUS Air and NEXUS Highway, there is only one loader function for both.

To create the nexus_air raw data with the loader function, the following steps needs to be done:
> - Extract the date from the file name as YYYY-MM-DD, where YYYY is extracted from the YYYY of the file name, MM is extracted from "Month" of
> the file name and DD = 01. Since the length of "Month" can vary, the easiest way is to take the first three characters and base MM on those
>   - Copy this *date* to every record in the raw data

> - From the tab "NEXUS Air Citizenship", keep the columns B ("Airport"), C ("Citizenship") and the appropriate data column (one from D-O)
>>  - Columns are named for months, from April to March. Keep the column that corresponds to the month from the file name
> - Drop the rest of the columns
> - From the tab "NEXUS Air Citizenship", remove all summary rows where "Airport" (Column B) contains "ROLL-UP" or "Citizenship" (Column C) = "Total"
> - Remove the header and footnote rows (if applicable) by keeping only non-blank "Citizenship" values
> - Remove any comments from the port names: in "Airport" by removing anything in parentheses, including the parentheses themselves

### Variables in the Raw Data
To create the nexus_air raw data, code the variables as follows:
>   - *date* (format YYYY-MM-DD), as extracted from the file name
>   - *wloc* from "Airport"
>   - *citizenship* from "Citizenship"
>   - *count*, as the value from the appropriate month column
