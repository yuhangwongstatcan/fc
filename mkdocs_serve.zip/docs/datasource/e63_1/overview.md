# E63-1 Data Source

### E63-1 Forms
The form "E63-1" was designed by Statistics Canada as a tool for CBSA officers to report detailed information on cruise arrivals at their port of
entry. The form was slightly reorganized for the Frontier Counts redesign (version E63-1 (2021-01)) in order to allow for simpler and more accurate 
processing, but the general format was maintained since officers are familiar with it.

In some cases, CBSA border officers will fill out the forms themselves, and in some cases they will give them to employees of the cruise line who
will fill out the information based on the passenger manifest.

An example of a blank E63-1 form is available to be downloaded by clicking on [this link](sample_e63_1.xlsx)

### Data Reception
E63-1 forms are received by email (or in some cases, fax) from individual ports of entry. Each E63-1 corresponds to **one** cruise ship arrival.
The forms can be received either in Excel or in PDF.
**Note: In order to avoid difficulties processing the forms if they are filled out incorrectly, the Frontier Counts production team will review any forms
received in Excel and transcribe any received in PDF into the correct template.**

The parameters of the received files are as follows:
> - File type: .xlsx (Excel)
> - Naming conventions:
>>  - File name of the form: E63-1 *Port Number Name of Ship Date*.xlsx
>>>   - Note: To identify E63-1 files, can use the pattern: E63-1*.xlsx
>>  - There are three tabs in the Excel file:
>>>   - Instructions-Procédures: Instructions for completing the form; not used in Frontier Counts data processing.
>>>   - Passengers-Passagers: Summary of passengers aboard the cruise ship
>>>   - Crew-Équipage: Summary of crew members aboard the cruise ship
> - Timeliness: One file is received for each cruise ship arrival during the reference month or in the month following
>>  - For example, files for cruise arrivals in July 2019 are received in July 2019 and August 2019
> - Granularity: Specific cruise ship arrival (Arrival date available)
> - Date Variable: Arrival Date (Cells E4:G4 of the Excel file)
> - Format: 
>>  - DD/MM/YYYY

### E63-1 Loader Function
Recall that there is one E63-1 form per cruise ship arrival, and each contains the arrival date for the ship at its first Canadian port of call.
The loader function triages each E63-1 form into raw data based on *date_of_arrival*. Every ship that arrives on the same date can be stored in
the same raw file. Raw data is not organized in separate files by cruise ship, even though it is received this way.

To create the e63_1 raw data with the loader function, the following steps needs to be done:
> - Extract the following information from the "Passengers-Passagers" tab, that is applicable to **all records from the E63-1 form** and apply it
>   to each record from the E63-1 form:
>>  - Arrival Port (Cells A4:C4)
>>  - Name of Ship (Cells A9:C9)
>>  - Date of Arrival (DD/MM/YYYY) (Cells E4:G4)
>>  - Date of Departure from Canada (DD/MM/YYYY) (Cells E6:G7)
>>  - Itinerary - United States (Cell J5)
>>  - Itinerary - Canada (Cell J6)
>>  - Itinerary - Another Country (Cell J7)
>>  - Note: Since the form is at the level of the cruise ship, all the general information about the ship and the itinerary applies to **all**
>   passengers and crew onboard
> - Extract the following from the "Passengers-Passagers" tab, setting *passenger_type* = "passenger":
>>  - Canadian passengers, setting *country_of_residence* = 11124 (Cell G8)
>>  - United States passengers, setting *country_of_residence* = 11840 (Cell G9)
>>  - Passengers from other countries, setting *country_of_residence* based on B12:B95,F12:F95,I12:I92 (Cells C12:C95,G12:G95,J12:J92)
>>  - Passengers of unknown residency, setting *country_of_residence* = 99998 (Cells J93:95)
> - Extract the following from the "Crew-Équipage" tab, setting *passenger_type* = "crew":
>>  - Canadian crew, setting *country_of_residence* = 11124 (Cell G8)
>>  - United States crew, setting *country_of_residence* = 11840 (Cell G9)
>>  - Crew from other countries, setting *country_of_residence* based on B12:B95,F12:F95,I12:I92 (Cells C12:C95,G12:G95,J12:J92)
>>  - Crew of unknown residency, setting *country_of_residence* = 99998 (Cells J93:95)

**Note**: Since it is very common for E63-1 forms to be received in various files and frequently throughout the month, the default behaviour for a
file received where a raw file already exists, should be to **append**. It should **not** be to generate a conflict.
For example, if an E63-1 file is received in inbox with records for January 1, 2018, and there is already a raw file 20180101.csv in 
raw/e63-1/2018/01, just append the records to 20180101.csv - do not create a conflict that needs to be resolved.

### Variables in the Raw Data
To create the e63_1 raw data, combine the extracted data as follows:
> - date_of_arrival, converted to YYYY-MM-DD format from "Date of Arrival"
> - port, numeric portion **only** of "Arrival Port"
> - ship, from "Name of Ship"
> - date_of_departure, converted to YYYY-MM-DD format from "Date of Departure from Canada"
> - itinerary_usa, from "Itinerary - United States"
> - itinerary_can, from "Itinerary - Canada"
> - itinerary_ovs, from "Itinerary - Another Country"
> - passenger_type, as above, based on the Excel file tab that the traveller counts are extracted from
> - country_of_residence, as above, from "Canadian passengers", "United States passengers", "Passengers from other countries", "Passengers of
> unknown residency", "Canadian crew", "United States crew", "Crew from other countries", "Crew of unknown residency"
> - count, traveller count as extracted from Cells G8, G9, C12:C95, G12:G95, J12:J92, J93:J95
