# Documentation for Validation nghh_v005

### ID
nghh_v005

### Related Business Rule
nghh_005

### Name
Summary of NGHH Mode of Transportation Imputation

### Type
Validation

### Purpose
Provide a visualization for end users to view a breakdown of modes of transportation in NGHH that were imputed for records where
the `mode` variable is blank.

### Additional Details

##### Validation Output
The output from the validation is a summary table by date (*date*), work location (*wloc*) and work location name (*wloc_name*) with 
the count of travellers imputed to each *mode*.

The validation will also output any cases where imputation could not be completed because there was no reference data available 
(data from the same work location in the current file). These cases are dropped from the pipeline until they can be addressed. For
any such cases appearing the validation output, it will be necessary to manually update the Excel files coming from CBSA with an
appropriate mode of transportation or, if the issue becomes systematic, to make an update to the pipeline.

##### Dashboard Display
The dashboard displays a bar chart with the bars representing the number of travellers imputed for each mode of transportation and 
work location.

Filters are provided for year and month.

### Validity
January 2026 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation on nghh_005]({{fc_baseurl.doc}}/datasource/nghh/business_rule/nghh_005)
