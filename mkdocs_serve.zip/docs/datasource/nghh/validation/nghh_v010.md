# Documentation for Validation nghh_v010

### ID
nghh_v010

### Related Business Rule
nghh_010

### Name
Summary of NGHH Work Location Issues

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected data (work location and/or transportation type) received in 
NGHH and a summary of data that was received but rejected.

### Additional Details

##### Unexpected Work Locations or Transportation Types
This validation is produced for the Production Team to examine records that could not be matched to the `nghh` work location 
reference file based on work location and transportation type (*wloc* and *mode* from the raw data), indicating that the the work 
location-transportation type has not previously been encountered.

These cases could indicate work locations that were not previously in NGHH or work locations that are accepting a new mode of 
transportation. In both instances, the new data need to be checked to see if they will be accepted or rejected from NGHH.

These cases are flagged in the validation output file as *work_location_issue_type* = "Unexpected WLOC or Mode".

##### Rejected Data
Certain work locations and/or transportation types are not accepted from NGHH since they continue to be sourced from a different 
data source (mainly IPIL Highway data "MOB" lanes, but also some E63 reports or other manual sources), and these are identified in 
the `nghh` work location reference file with an action of "X", meaning to reject the data.

Although these cases have been specifically labelled as "X" (reject), so they don't have an unknown status, it is still beneficial 
for the Production Team to be able to review the rejected data on a monthly basis to assess the volumes, especially for the work
locations that are rejected because the travellers are ostensibly already recorded in IPIL Highway "MOB" lanes, to see if NGHH
volumes are starting to become higher and we should consider accepting NGHH data from this work location.

These cases are flagged in the validation file as *work_location_issue_type* = "Rejected Data".

##### Adding IPIL Highway "MOB" Lane Volumes
The IPIL Highway `clean` data file from the same month being processed is read in to establish as the sum of travellers passing 
through IPIL Highway lanes designated as mobile, by work location, as:

> - SUM(*cdsd*,*cd1d*,*cd2d*,*ussd*,*us1d*,*us2d*,*osd*,*o1d*,*o2d*) = *ipil_mob_count* where the first three digits of *lane* are 
"MOB", by *cport*

Add *ipil_mob_count* to the output file so that the Production Team can assess if it still makes sense to reject the NGHH data or 
whether it should be considered in addition to the IPIL Highway "MOB" lane data. In the case of previously unobserved data, it will
assist the Production Team with determining whether the NGHH data should be accepted or not.

For *wloc* where there is either no IPIL Highway "MOB" lane data or no IPIL Highway data at all, the *ipil_mob_count* can be recorded
as zero.

This IPIL Highway `clean` data for "MOB" lanes is also used in `nghh_020` to adjust the NGHH volumes of accepted work location data.

##### Output File and Dashboard Display
The output file from the validation contains a count of travellers for each *work_location_issue_type*, grouped by *date*, *wloc*, 
*wloc_name* and *mode*. The *ipil_mob_count* is also included, where applicable and set to zero if there is no IPIL Highway "MOB"
lane data for the work location.

The dashboard displays a filterable table with the various *work_location_issue_type* issues. 

Filters are available by year and month, as well as an auxiliary filter by work location issue type.

### Validity
January 2026 - present

### Required Auxiliary Inputs
The NGHH work location reference file is required.
The IPIL Highway `clean` data from the same month and year being processed is required.

### Related Pages
[Documentation for nghh_010]({{fc_baseurl.doc}}/datasource/nghh/business_rule/nghh_010)
[Documentation for nghh_020]({{fc_baseurl.doc}}/datasource/nghh/business_rule/nghh_020)
