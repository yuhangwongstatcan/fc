# NGHH Data Source

### Data Reception
The reception of NGHH data from CBSA was established in 2024 as part of an amendment to the data-sharing MOU between CBSA and 
StatCan, and integration into the FC system was completed in January 2026 jointly with the second phase of IPIL Air, both to fill 
existing data gaps and to replace other data sources which are less efficient or more expensive to process (e.g., E311 declaration 
cards and E62 reports).

The NGHH data are received jointly with daily Nexus and IPIL Air data. **The NGHH data is ingested at the same time as IPIL Air,
using the IPIL Air `loader.py` file**.

The parameters of the received files are as follows:
> - File type: Excel (.xlsx)
> - Naming conventions: 
>   - The files collectively containing the NGHH, daily Nexus and IPIL Air data are named **Daily StatsCan Report (YYYY-MM-DD).xlsx** 
>     for files with a single day of data or **Daily StatsCan Report (YYYY1-MM1-DD1 to YYYY2-MM2-DD2).xlsx** for files with multiple days of data.
>   - We can use the pattern **Daily StatsCan Report (####-##-##\*).xlsx** to identify files for NGHH
>   - The Excel workbook tab containing the NGHH data is called "NGHH"
> - Timeliness: Files are received daily with a three-day lag.
>   - For example, the NGHH file for February 22 crossings would be received on February 25
> - Granularity: Daily counts of travellers broken down by the other variables provided (see below)
> - Date Variable: "Date of Entry"
> - Date Format: YYYY-MM-DD

### Process
The NGHH (Next Generation Handhelds) are used by Canada Border Services Agency as a complementary tool to process travellers 
alongside other automated systems such as Primary Inspection Kiosks, IPIL Highway, IPIL Air and NEXUS. The NGHH are also referred
to as "Mobile IPIL".

The system automatically populates the required variables based on information from the traveller's passport and the entry location.

### Variables
The variables provided are the following. The name in brackets indicates the variable name to be used after data ingestion.

> - "Port of Entry" (port_of_entry): CBSA work location where the crossing occurred, including four-digit code and WLOC name
> - "Date of Entry" (date_of_entry): Date that the crossing occurred
> - "Citizenship" (citizenship): Traveller citizenship from the passport
> - "Gender" (gender): Traveller gender from the passport
> - "Count of Travellers" (count_of_travellers): Count of travellers for each grouping of the other variables provided on the file
> - "Data Source" (data_source): CBSA primary system that was used to process the traveller crossing. This should be "Mobile IPIL - 
>      NGHH" for all NGHH data.
> - "Mode" (mode): Mode of transportation, either Air, Land, Rail or Marine
