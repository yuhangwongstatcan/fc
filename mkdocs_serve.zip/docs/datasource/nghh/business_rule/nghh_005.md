# Documentation for Business Rule nghh_005

### ID
nghh_005

### Name
Impute mode of transportation for NGHH travellers with unknown mode

### Type
Imputation

### Purpose
Impute a mode of transportation for travellers where the mode variable is blank, using the most common mode for the work location
where the traveller crossed the border.

### Additional Details

##### Determine most common mode of transportation for each work location
Most (if not all) work locations in NGHH have only a single mode of transportation (either Air, Land, Rail or Marine) that is 
permitted, so we can deterministically (or pseudo-deterministically) impute a mode of transportation for cases where the *mode* 
variable is blank by determining the most common *mode* in each *wloc*.

Concretely, calculate the sum of *count_of_travellers* by *wloc* and *mode* for the entire month of data being processed, and for
each *wloc*, retain the *mode* with the maximum *count_of_travellers*.

##### Imputation
For each record where the *mode* variable is missing, attribute the most common mode of transportation for its *wloc*, as determined
in the previous step.

##### Cases that cannot be imputed
In rare cases, there may be no reference data available (no other records from the same work location in the current file). Such 
cases are dropped from the pipeline temporarily and flagged in the `nghh_v005` validation output as a blank *mode* column. These
should be addressed, either by manually updating the Excel file received from CBSA or, if the issue becomes systematic, adding
additional code to the pipeline to address them.

### Validity
January 2026 - present

### Required Auxiliary Inputs
None

### Related Pages
None
