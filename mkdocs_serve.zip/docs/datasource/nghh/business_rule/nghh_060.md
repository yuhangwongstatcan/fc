# Documentation for Business Rule nghh_060

### ID
nghh_060

### Name
Impute number of vehicles in NGHH

### Type
Imputation

### Purpose
Determine number of vehicles in NGHH, as well as the licence plate country for the imputed vehicles.

### Additional Details

##### Background
The NGHH raw data does not provide any counts of vehicles (only counts of travellers by certain characteristics), however Frontier 
Counts needs to publish the number of land vehicles (automobiles, trucks, motorcycles and other land vehicles), so a count of 
vehicles from NGHH needs to be imputed, since some of the NGHH travellers are imputed as automobile, truck, motorcycle or other 
land vehicle for *vehicle_type*. 

Additionally, the country of the licence plate (at a minimum, Canada vs. United States) is a required element for Frontier Counts 
and needs to be imputed.

Since Frontier Counts only needs to publish a count of **land** vehicles, this imputation only applies to NGHH records where 
*vehicle_type* was imputed as 211 ("Automobile"), 212 ("Motorcycle"), 213 ("Other Land Vehicle") or 214 ("Truck") in `nghh_050`.
The best auxiliary data source that we have available to impute the number of vehicles based on the number of travellers is 
IPIL Highway, so the `ipil_hwy` records data from the same month will be extracted from the aggregated `vehicles` and `travellers` files.

##### Impute Number of Vehicles
For each work location in the NGHH raw data where there are *vehicle_type* in (211,212,213,214) (i.e. where there are travellers 
arriving by these vehicle types at a certain NGHH work location), a count of vehicles needs to be imputed. This will be done using 
the proportion of vehicles to travellers from the auxiliary data source (IPIL Highway) from the same reference month as the NGHH 
data, and the total number of NGHH travellers arriving at the work location.

If no proportion is available from the same work location in IPIL Highway, use the same province (first two digits of the port).
Otherwise, use the Canada proportion.

Concretely, determine the proportion as:
> - sum(*count_of_entries*) from the `vehicles` file / sum(*count_of_entries*) from the `travellers` file from the same month and 
year being processed for NGHH and *data_source* = 11 ("IPIL Highway") and with the correct *work_location* and *vehicle_type*

Then calculate for each applicable *vehicle_type* at the *wloc*, the number of vehicles as (ceiling is used to avoid having zero 
vehicles if there is a lower ratio and a low number of NGHH travellers):
> - Ceiling (**Proportion of vehicles from IPIL Highway** x total number of travellers of that vehicle type at NGHH work location)

For example, if there is NGHH data for *wloc* = 7054 (Chief Mountain) with imputed *vehicle_type* = 211 ("Automobile"), broken down 
as 10 same-day U.S. travellers, 20 overnight U.S. travellers, 49 Canadian same-day travellers and 1 same-day Belgian traveller (80 
total), we know that we need to impute a number of automobiles at this work location (a number of cars for these 80 reported 
travellers). If we look to the `travellers` **automobile** data for the same *month* and *work_location*, and see that there are 
1,500 travellers from IPIL Highway (sum(*count_of_entries*) where *work_location* = 7054 & *vehicle_type* = 211 & *data_source* 
= 11) and 1,000 vehicles from the same month in the `vehicles` data (sum(*count_of_entries*) where *work_location* = 7054 & 
*vehicle_type* = 211 & *data_source* = 11), then the proportion is 1,000 / 1,500 = 0.666667 vehicles / traveller. We apply this 
proportion to the 80 travellers to determine that 54 vehicles should be added.

A second example: if there is NGHH data for *wloc* = 7054 with imputed *vehicle_type* = 213 ("Other Land Vehicle"), and 1 same-day 
U.S.traveller and 2 same-day Canadian travellers (no other travellers) (3 total), we  need to impute a count of other land vehicles
at this work location. If no data is available at the work location level, we look instead to other land vehicles in all of Alberta 
(first two digits of port = "48"), where, say, the proportion is 0.25 vehicles / traveller. We apply this proportion to the 3 
travellers to determine that 1 vehicle should be added (note the ceiling function to avoid imputing zero other land vehicles).

The imputed number of vehicles are added to the existing dataframe by inserting a new row for each *wloc* and *vehicle_type* where a 
number of vehicles is being imputed, copying the *port_of_entry*, *wloc*, *wloc_name*, *port*, *mode*, *vehicle_type* and 
*data_source*, and setting *date_of_entry* as the first of the month being processed and *gender* as "VEHICLE" to distinguish the 
vehicle records. The *count_of_travellers* can be set to the imputed number of vehicles and rest of the variables in the dataframe 
can be set as not applicable, as follows:
> - *citizenship*, *citizenship_code*, *citizenship_country* and *region_of_residence* set as blank
> - *duration2*, *purpose4* and *arriving_from* set as 9

##### Impute Licence Plate Country
Once the number of vehicles has been imputed, we can simply use the proportions of Canadian and American travellers in the same 
vehicle type at the work location to split the vehicles into Canadian and American licence plates (ignoring any residents of other 
countries because licence plates outside of Canada or the United States are so rare, travellers using other vehicle types and 
travellers from other work locations).

From the first Chief Mountain example above, the number of American licence plates is calculated as (30 American travellers / (30
+49) Canadian or American travellers) x 54 vehicles = 20 U.S.-plated vehicles. The Canadian-plated vehicles are then calculated as 
54 - 20 = 34. In the case where there are no Canadian or American travellers (only travellers from other countries) at a given 
work location, divide the imputed vehicles evenly into Canadian and American licence plates, giving an extra to Canada in the case 
of an odd number.

This information can be added to the existing dataframe by using the *country_of_residence* variable and setting as 11124 ("Canada")
for the *count_of_travellers* imputed as Canadian-plated vehicles and 11840 ("United States of America") for the 
*count_of_travellers* imputed as American-plated vehicles.

### Validity
January 2026 - present

### Required Auxiliary Inputs
The aggregated `vehicles` and `travellers` files for the same month and year are required.

### Related Pages
[Documentation for nghh_050]({{fc_baseurl.doc}}/datasource/nghh/business_rule/nghh_050)
