# Documentation for Business Rule nghh_080

### ID
nghh_080

### Name
NGHH transformation to TRAVELLERS table

### Type
Transformation

### Purpose
Generate the NGHH contribution to the travellers table in the correct schema.

### Additional Details
The way in which the intermediate dataframes are created is such that the clean NGHH data has records for vehicles and records for 
travellers. To generate the NGHH contribution to the aggregate `travellers` table, extract the traveller-level records (*gender* != 
"VEHICLE") and code the columns of the `travellers` table as follows:

##### Time and Location Variables
The *year*, *month* and *day* columns are extracted from the *date* variable.  

The *port* column that was created in the `nghh_050` step is carried forward from the `clean nghh` file.

##### Itinerary Variables
The *mode* column is coded based on the *mode* column from the raw NGHH data as:
> - If *mode* in the raw data = "Air" then *mode* = 1 ("Air")
> - Else if *mode* in the raw data = "Land" or "Rail" then *mode* = 2 ("Land")
> - Else if *mode* in the raw data = "Marine" then *mode* = 3 ("Water")

The *vehicle_type* column that was imputed in the `nghh_050` step is carried forward from the `clean nghh` file.

The *plate_country* and *plate_region* columns are coded as 9 ("Not applicable") and "NA" ("Not applicable") respectively.

##### Arriving From
The *arriving_from* that was imputed in step `nghh_050` is carried forward from the `clean nghh` file.
Recall that land, rail and water travellers (*mode* in (2,3)) are coded as *arriving_from* = 1 (U.S. only) or 3 (Other country via
the U.S.) based on the travellers' citizenship. The air travellers (*mode* = 1) are based on the `nghh_050` imputation.

##### Country of Residence
The *country_of_residence* column that was created in the `nghh_030` step, and further adjusted in the `nghh_040` step is 
carried forward from the `clean nghh` file. Recall that stateless travellers or refugees are assumed as immigrants and carry code 
99999.

##### Trip Purpose Variables
The *purpose9* and *purpose4* columns are coded as follows:
> - If *citizenship_code* in ("XA","XXB","XXC") (Stateless traveller or refugee) then set *purpose9* = 41 ("Immigration") and *purpose4* = 4 ("Other non-tourism purpose")
> - Else the *purpose4* that was imputed in step `nghh_050` is carried forward, and *purpose9* is coded based on this *purpose4* as:
>   - If *purpose4* = 1, then *purpose9* = 19 ("Visit, not otherwise specified")
>   - Else if *purpose4* = 2, then *purpose9* = 21 ("Crew")
>   - Else if *purpose4* = 3, then *purpose9* = 31 ("Work")
>   - Else if *purpose4* = 4 and *wloc* in (4490,3010) then *purpose9* = 42 ("Military")
>   - Else if *purpose4* = 4, then *purpose9* = 43 ("Other non-tourism")

##### Trip Duration and Traveller Type Variables
The *duration2* column is copied from the imputed *duration2* variable.  
The *duration3* and *duration5* columns are coded as 99 ("Not available") and 99 ("Not available") respectively.

The *traveller_type* column is derived from other columns in the travellers table as follows:
> - If *purpose4* = 4 ("Other non-tourism") or *purpose4* = 3 ("Work") or (*purpose4* = 2 ("Crew") and *vehicle_type* in 
> (111,112,214,215,216,311,312,313,314,315)) then *traveller_type* = 3 ("Other traveller")
> - Else if *duration2* = 1 ("Same day"), then *traveller_type* = 1 ("Excursionist")
> - Else if *duration2* = 2 ("Overnight"), then *traveller_type* = 2 ("Tourist")

##### Analysis Variables
The *work_location* column is copied from the *wloc* variable.

The *data_source* column is coded as 19 ("NGHH") in all cases for this data source.

Once all columns are coded, the *count_of_entries* is determined by taking the sum of *count_of_travellers* from the `clean nghh` 
file grouped across all transformed variables where where *gender* != "VEHICLE"..

### Validity
January 2026 - present

### Required Auxiliary Inputs
None

### Related Pages
None
