# Documentation for Business Rule nghh_020

### ID
nghh_020

### Name
Adjust NGHH Volumes to Account for IPIL Highway MOB Lanes

### Type
Edit

### Purpose
This rule lowers the NGHH volumes at work locations where some (or all) of the travellers are also recorded in the IPIL Highway
data that is received from CBSA in order to avoid double-counting.

### Additional Details

##### Establishing the Volumes from IPIL Highway MOB Lanes
The IPIL Highway `clean` data file from the same month being processed, that was ingested in the `nghh_v010` validation is used
to establish the IPIL Highway MOB lane volumes. As was done in `nghh_v010`, the volume of travellers in IPIL Highway MOB lanes
is established as the sum of travellers passing through lanes designated as mobile, by work location:

> - SUM(*cdsd*,*cd1d*,*cd2d*,*ussd*,*us1d*,*us2d*,*osd*,*o1d*,*o2d*) = *ipil_mob_count* where the first three digits of *lane* are 
"MOB", by *cport*

##### Compare to NGHH Data to Determine Volume Reduction
The NGHH data file is then merged with the IPIL Highway MOB lane volumes and a volume comparison done by work location (*wloc*
from NGHH compared to *cport* from IPIL Highway MOB).

The difference is established as (*count_of_travellers* - *ipil_mob_count*). 

> - If *ipil_mob_count* is zero, then no adjustment is needed to the NGHH data for this *wloc*
> - If the difference is zero or negative, then all rows for the work location in question can be removed for this month since it is 
assumed that the volume has already been recorded in IPIL Highway in its entirety.
> - If *ipil_mob_count* is non-zero and the the difference is greater than zero, an adjustment is required to the NGHH file

For example, if *wloc* 7054 (Chief Mountain) has 100 travellers in NGHH, but 30 coming from "MOB" lanes in IPIL Highway, the NGHH
volume for Chief Mountain needs to be adjusted down to 70 travellers.

##### Adjustment to NGHH
Since travellers at each *wloc* are split across different characteristics (e.g., gender, citizenship) and there is no reliable
way to establish some of these characteristics from IPIL Highway to know which travellers are being double-counted, the travellers
are removed from NGHH through a random process.

First, explode the NGHH file to establish a row for each individual travellers. For example, if Chief Mountain has a row with
*citizenship* = "Latvia", *gender* = "Female" and *count_of_travellers* = 5, explode this into five lines, each with the same
citizenship and gender, and with a *count_of_travellers* = 1.

Second, generate a *random_number* variable on the uniform (0,1) distribution for each row, generated from Python's numpy package 
with a seed based on the year and month in production (e.g. seed = 202601 for January 2026 production). The count of random numbers 
to generate is equivalent to the number of records in the `nghh` raw data (e.g., the first row receives the first random number, and 
so on)

Third, sort the records by ascending *wloc* and by ascending *random_number*, such that the travellers for each work location are put 
in random order.

Lastly, starting from the beginning of the sorted *wloc* records, remove a number of rows equivalent to the volume of IPIL Highway 
MOB travellers.

##### Reaggregation
After the removal of NGHH travellers to avoid double-counting, the file can be reaggregated across all variables to simplify the 
remaining processing.

### Validity
January 2026 - present

### Required Auxiliary Inputs
The IPIL Highway `clean` data from the same month and year being processed is required.

### Related Pages
None
