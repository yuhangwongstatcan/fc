# Documentation for Business Rule nghh_050

### ID
nghh_050

### Name
Impute vehicle type, trip duration, trip purpose and arriving from for NGHH travellers

### Type
Imputation

### Purpose
Assign a vehicle type, trip duration, trip purpose and arriving from (air only) value to all travellers in NGHH.

### Additional Details
The NGHH data extractions from CBSA do not provide any breakdown by trip duration (same-day or overnight), by trip purpose (visit, 
crew, work or other purpose) or by arriving from (U.S. only, overseas direct, overseas via U.S.), but these are all required 
elements for Frontier Counts, so an imputation is required. The NGHH data extraction does provide a high-level mode of 
transportation ("Air","Land","Rail","Marine"), but not the detailed vehicle type that is required for Frontier Counts, so an 
imputation is required for this data element as well.

##### Imputation Strategy
Imputation of the required variable types is then done in four stages, which are detailed in the next sections. The reference
distributions required for Stage 1 and 2 are from the 2024 and 2025 `travellers` file for the same month as the NGHH data being
processed.

1. Perform an imputation using reference distributions from specific manual sources
2. Perform an imputation using general reference distributions
3. Deterministically overwrite certain characteristics applicable to all work locations
4. Deterministically overwrite certain characteristics for specific work locations

##### Calculating Reference Proportions
To generate the required reference distributions, read in and append the 2024 and 2025 `travellers` file from the same month as the 
NGHH data being processed and calculate the combined proportions of:

> - *vehicle_type*, to split travellers by vehicle type
> - *duration2*, to split travellers in same-day and overnight
> - *purpose4*, to split travellers by trip purpose for visit, crew, work and other purpose
> - *arriving_from*, **for air travellers (*mode* = "Air") only** to split by route of arrival

The joint proportions from 2024 and 2025 are considered. For example, if January 2024 had 100 records for the domain under
consideration and January 2025 had 50 for the given domain, the reference distributions for January 2026 NGHH had would be
based on the characteristics of all 150 records.

The work locations are split into two groups for imputation by reference proportion ("Stage 1 and 2" listed above). Any work
locations from the `nghh_imputation` reference file that have a record with *variable* = "ALL" and a corresponding *source*
fall into Stage 1 and any that do not fall into Stage 2.

The work locations from Stage 1 have their reference proportions based on a restricted list of sources from the *data_source*
column in the `travellers` reference file, which are specified in the *source* column of the `nghh_imputation` reference file, 
whereas the work locations from Stage 2 are based on all records from the `travellers` reference file.

The reference proportions are calculated and applied by *port*, *mode* and *region_of_residence*. To facilitate this, 
*port* and *region_of_residence* can be added to the NGHH data as described in the following two subsections, and *mode* can
be established as described below:

*Port*
A *port* column is created based on linking *work_location* to the work location reference file and extracting the corresponding 
port value associated with each *wloc*.

*Region of Residence*

> - If *country_of_residence* = 11124, then *region_of_residence* = "CAN"
> - If *country_of_residence* = 11840, then *region_of_residence* = "USA"
> - If *country_of_residence* not in (11124, 11840), then *region_of_residence* = "OVS"

Note that *region_of_residence* can also be added to the incoming auxiliary data.

*Mode*

> - If *mode* = "Air", then consider records from the reference `travellers` file where *mode* = 1
> - If *mode* = "Land", then consider records from the reference `travellers` file where *mode* = 2 and *vehicle_type* not 216
> - If *mode* = "Rail", then consider records from the reference `travellers` file where *vehicle_type* = 216
> - If *mode* = "Marine", then consider records from the reference `travellers` file where *mode* = 3

For "Stage 1" work locations, the joint proportions of *vehicle_type*, *duration2*, *purpose4* and *arriving_from* are calculated 
from the `travellers` file using **only** the *data_sources* listed in the `nghh_imputation` reference file and applied to each 
record from the `nghh` data to split each *count_of_travellers* by these four characteristics.

For "Stage 2" work locations, the joint proportions of *vehicle_type*, *duration2*, *purpose4* and *arriving_from* are calculated 
from the `travellers` file using all records and applied to each record from the `nghh` data to split each *count_of_travellers* by 
these four characteristics.

##### Applying the Reference Proportions
Characteristics are imputed by applying the appropriate reference proportions to each record from the `nghh` data within the same 
*port*-*mode*-*region_of_residence* group, and the *count_of_travellers* split across the various values of *vehicle_type*, 
*duration2*, *purpose4* and *arriving_from*. 

For example, from a "Stage 2" work location, all NGHH records within the month linked to *port* = 48701 (Calgary Airport) and having
*mode* = 1 (Air) and *region_of_residence* = "OVS" (overseas) are considered together when applying the reference proportions.

For example, from a "Stage 1" work location, any NGHH records within the month with *wloc* = 4973 (Toronto Pearson Commercial Ops)
are imputed from the `travellers` file using only records with *port* = 35497 (Toronto Pearson Airport) and *data_source* = 51 (E311),
within the appropriate *mode* and *region_of_residence*.

The original *count_of_travellers* should be respected, so the total for the row with maximum count in the split category should 
take the original *count_of_travellers* and subtract the totals from all other split categories to ensure that the original total is 
respected. The other characteristics of each record (e.g., date, gender) should also be respected after applying the proportions.

Note that small counts in the `nghh` data will make it difficult to apply proportions, so any records with *count_of_travellers* <= 
5 should be uniformly coded directly to the most popular category for the *port*, *mode* and *region_of_residence* from the 
`travellers` file.

For example, if there are only 4 travellers from Chief Mountain (*wloc* = 7054, *port* = 48705) in a particular NGHH row, and the
most popular categories from the `travellers` file are *vehicle_type* = 211 ("Car"), *duration2* = 2 ("Overnight") and *purpose4* = 1
("Visit"), all 4 travellers from this NGHH row are coded to those categories, even if there are some other categories present in
the `travellers` file.

If there is no reference data available for the *port*, *mode* and *region_of_residence* combination in NGHH,the national (all 
ports) proportion can be used for the *mode* and *region_of_residence* combination.

##### Deterministically Overwrite Characteristics Relevant to All Work Locations
Certain characteristics can be established deterministically for all work locations, so once the imputations from Stage 1 and 2 are
complated, the following cases can overwrite whatever was imputed for all work locations:

> - If *mode* = "Rail* in NGHH then *vehicle_type* = 216 (Train)
> - The stateless and refugee cases (*country_of_residence* still = 99999 after `nghh_040` and with *citizenship_code* in ("XA",
>   "XXB","XXC")) can be coded directly as:
>   - *duration2* = 9 (Duration not available)
>   - *purpose4* = 4 (Other non-tourism purpose)
> - *arriving_from* = 2 (Direct from another country)
> - For non-air travellers (*mode* = "Land", "Rail" or "Marine"), *arriving_from* can be coded as:
>   - *arriving_from* = 1 (U.S. Only) for Canadian and American travellers (*country_of_residence* in (11124,11840))
>   - *arriving_from* = 3 (Overseas via the U.S.) for overseas travellers (*country_of_residence* not in (11124,11840))

##### Deterministic Imputation For Specific Work Locations
The reference file for NGHH imputation (`nghh_imputation`) contains a list of characteristics that can be deterministically 
established only for certain work locations.

The *value* to be deterministically assigned is recorded for each relevant *wloc* and *variable*, in any rows of the reference file
where *variable* is either "vehicle_type", "purpose4", "duration2" or "arriving_from" (i.e., all rows except *variable* = "ALL").

Any such cases from the `nghh_imputation` file that are present in the current month's NGHH data should have their imputed data
overwritten with the deterministic value for all applicable values listed in `nghh_imputation`.

### Validity
January 2026 - present

### Required Auxiliary Inputs
The work location reference file is required.
The `nghh_imputation` reference file is required to establish imputation rules for each work location.
The aggregated 2024 and 2025 `travellers` data for the same month being processed for NGHH is required.

### Related Pages
None
