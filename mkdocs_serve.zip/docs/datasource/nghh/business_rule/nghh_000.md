# Documentation for Business Rule nghh_000

### ID
nghh_000

### Name
Extract work location and citizenship codes from NGHH data.

### Type
Manipulation

### Purpose
Extract the four digit CBSA work location code from the NGHH input data (based on variable "Port of Entry"), which will be used with 
the NGHH work location reference file to determine which data is accepted, and extract the citizenship country code from the NGHH
data, which will be used to map to Frontier Counts country codes.

### Additional Details
NGHH data is received in an Excel file which has variables for work location and citizenship that contain both the code and a text description.
  
For work location, we need to:
> - Extract the first four digits from raw variable *port_of_entry*, and create a new variable *wloc*
> - Extract the text after " - " in the raw variable *port_of_entry*, and create a new variable *wloc_name*
  
For citizenship country, we need to:
> - Set all cases of *citizenship* that map to a missing value to pd.NA, including:
>   - "" (an empty value, as recoded from the Excel error code "#NAME?" in the IPIL Air `loader.py` program, which also loads the NGHH data)
>   - "Unknown"
>   - "#Name"
>   - "-2 - Unknown"
>   - "-2 - Other"
>   - "-2 - #Name?"
> - For all *citizenship* values that do not map to a missing value:
>   - Extract all text before " - " in the raw variable *citizenship*, and create a new variable *citizenship_code*
>   - Extract all text after " - " in the raw variable *citizenship*, and create a new variable *citizenship_country*

### Validity
January 2026 - present

### Required Auxiliary Inputs
None

### Related Pages
None 
