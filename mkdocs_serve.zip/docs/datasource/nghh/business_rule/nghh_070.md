# Documentation for Business Rule nghh_070

### ID
nghh_070

### Name
NGHH transformation to VEHICLES table

### Type
Transformation

### Purpose
Generate the NGHH contribution to the vehicles table in the correct schema.

### Additional Details
The way in which the intermediate dataframes are created is such that the clean NGHH data has records for vehicles and records for 
travellers. To generate the NGHH contribution to the aggregate `vehicles` table, extract the vehicle-level records (*gender* = 
"VEHICLE") and code the columns of the `vehicles` table as follows:

The *year*, *month* and *day* columns are extracted from the *date* variable.

The *port* column that was created in the `nghh_050` step is carried forward from the `clean nghh` file.

The *mode* column is coded as 2 ("Land") in all cases.

The *vehicle_type* column that was imputed in the `nghh_050` step and propogated to the "VEHICLE" records in the `nghh_060` step is 
carried forward from the `clean nghh` file.

The *plate_country* column is coded based on the imputed values of *country_of_residence* in the "VEHICLE" records as follows:
> - If *country_of_residence* = 11124 then *plate_country* = 1
> - Else if *country_of_residence* = 11840 then *plate_country* = 2

The *plate_region* column is coded as NA ("Not available") in all cases.

The *work_location* column is copied from the *wloc* variable.

The *data_source* column is coded as 19 ("NGHH") in all cases for this data source.

Once all columns are coded, the *count_of_entries* is determined by taking the sum of *count_of_travellers* from the `clean nghh` 
file grouped across all transformed variables where *gender* = "VEHICLE".

### Validity
January 2026 - present

### Required Auxiliary Inputs
None

### Related Pages
None
