# IPIL Air Data Source

### Data Reception
The reception of IPIL Air data from CBSA was established in 2024 as part of an amendment to the data-sharing MOU between CBSA and StatCan, and 
integration into the FC pipelines started in February 2025 both to fill existing data gaps and to replace other data sources which are less 
efficient or more expensive to process (e.g., E311 declaration cards).

The IPIL Air data are received jointly with daily Nexus and NGHH data.

The parameters of the received files are as follows:
> - File type: Excel (.xlsx)
> - Naming conventions: 
>   - The files collectively containing the IPIL Air, daily Nexus and NGHH data are named **Daily StatsCan Report (YYYY-MM-DD).xlsx** for files with
>     a single day of data or **Daily StatsCan Report (YYYY1-MM1-DD1 to YYYY2-MM2-DD2).xlsx** for files with multiple days of data.
>   - We can use the pattern **Daily StatsCan Report (####-##-##\*).xlsx** to identify files for IPIL Air
>   - The Excel workbook tab containing the IPIL Air data is called "IPIL Air"
> - Timeliness: Files are received daily with a three-day lag.
>   - For example, the IPIL Air file for February 22 crossings would be received on February 25
> - Granularity: Daily counts of travellers broken down by the other variables provided (see below)
> - Date Variable: "Date of Entry"
> - Date Format: YYYY-MM-DD

### Process
The IPIL (Integrated Primary Inspection Line) Air system is used by Canada Border Services Agency to process travellers by passport scan through 
commercial air, bus, rail and ferry points of entry, in cases where another automated system such as Primary Inspection Kiosk, IPIL Highway or 
NEXUS is unavailable or not applicable.

The system automatically populates the required variables based on information from the traveller's passport and the entry location.

### Variables
The variables provided are the following. The name in brackets indicates the variable name to be used after data ingestion.

> - "Port of Entry" (port_of_entry): CBSA work location where the crossing occurred, including four-digit code and WLOC named
> - "Date of Entry" (date_of_entry): Date that the crossing occurred
> - "Citizenship" (citizenship): Traveller citizenship from the passport
> - "Gender" (gender): Traveller gender from the passport
> - "Count of Travellers" (count_of_travellers): Count of travellers for each grouping of the other variables provided on the file
> - "Data Source" (data_source): CBSA primary system that was used to process the traveller crossing. This should be "IPIL" for all IPIL Air data.
> - "Mode" (mode): Mode of transportation, either Air, Land, Rail or Marine
