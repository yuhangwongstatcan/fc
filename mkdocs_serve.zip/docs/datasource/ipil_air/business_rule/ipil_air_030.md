# Documentation for Business Rule ipil_air_030

### ID
ipil_air_030

### Name
Impute country of residence for IPIL Air travellers with unknown citizenship

### Type
Imputation

### Purpose
Impute a country of residence for any travellers in IPIL Air who had an unknown or generic citizenship, using the best available auxiliary 
information.

### Additional Details

##### Cases with Unknown or Generic Citizenship
There are a few values of *citizenship_code* that do not permit a country of residence to be easily assigned with `ipil_air_020`. Of 
these, some values require imputation and some can be left assigned to the generic *country_of_residence* value (99999).

**Cases requiring imputation for country of residence**:
> - *citizenship_code* is BLANK: The result of an Excel error code that indicates no citizenship value could be assigned at CBSA
> - *citizenship_code* = "UNA" or "UNO": An agency of the United Nations, without further details provided
> - *citizenship_code* = "XX": A traveller of unspecified or unknown citizenship
> - *citizenship_code* = "EUE": A traveller who is a citizen of the European Union, without further details provided

**Cases that do not require imputation for country of residence**:
- *citizenship_code* = "XA" (Stateless) or "XXB" (Refugee, Article 1) or "XXC" (Refugee, other): These cases will be presumed as 
immigration with the *country_of_residence* variable left as 99999, which is the Frontier Counts standard for immigrating travellers

##### Setting up the Imputation
To facilitate the imputation with random seeds, explode each record requiring imputation (*citizenship_code* in [BLANK,"UNA","UNO","XX",
"EUE"]) into records for individual travellers. For example, if the *count_of_travellers* in a "UNA" record is five, split into five 
records, each with *count_of_travellers* = 1.

Each record in the `ipil_air` raw data will have the following variable added in support of the imputation:

> - *random_number*: A random number on the uniform (0,1) distribution, generated from Python's numpy package with a seed based on the
> year and month in production (e.g. seed = 202501 for January 2025 production). The number of random numbers to generate is equivalent
> to the number of records in the `ipil_air` raw data (e.g. the first row receives the first random number generated and so on)
>   - Note: *random_number* is only a temporary variable to aid in processing and does not need to be maintained beyond this business rule

Note: Only records requiring imputation for *country_of_residence* need to pass through the subsequently described imputation steps.

##### Establishing the Reference Distributions
The reference distribution to be used for imputing *country_of_residence* is the known citizenship/country of residence cases from the
current month's IPIL Air data, i.e. records from the current month with *citizenship_code* not in (BLANK,"UNA","UNO","XX","EUE","XA",
"XXB","XXC"). The reference distribution should be established within the same *wloc* and *mode*.

For all cases requiring imputation except *citizenship_code* = "EUE" (European Union), an overall reference distribution can be 
calculated. For *citizenship_code* = "EUE", a Europe (first digit of *country_of_residence* = 2) reference distribution is calculated 
and used, so that the imputed records are guaranteed to be assigned to a country in Europe.

The imputed country of residence is then determined as follows:
> - From all records with known citizenship/country of residence (as described in the previous paragraph) and within the same *wloc* 
> and *mode*, determine a country breakdown (e.g. 50% U.K., 30% France, 10% Germany, 10% China for LAND travellers at work location 
> 4273 - Queenston in June  2020) based on traveller volume (sum of *count_of_travellers*)
> - Order the countries based on their *country_of_residence* code (e.g. 21250-France, 21280-Germany, 23826-U.K., 42156-China)
> - Set each country on the (0,1) range based on their prevalence (e.g. France in [0.0,0.3], Germany in [0.3,0.4], U.K. in [0.4,0.9], China in [0.9, 1.0])
> - Recode the `ipil_air` record's *country_of_residence* based on which range the *random_number* falls in (e.g. if *random_number* = 0.3866612
> then recode to 21280 (i.e. Germany))

Note: If there are no applicable travellers from the same work location on which to base a reference distribution, use the distribution for 
Canada (all work locations).

##### Reaggregation
After the imputation of country of residence is completed, the file can be reaggregated across all variables to simplify the remaining processing.

### Validity
January 2025 - present

### Required Auxiliary Inputs
None

### Related Pages
None
