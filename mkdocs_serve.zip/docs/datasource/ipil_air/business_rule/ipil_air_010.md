# Documentation for Business Rule ipil_air_010

### ID
ipil_air_010

### Name
Remove IPIL Air records with unexpected or unaccepted work locations

### Type
Edit

### Purpose
This rule uses the `ipil_air` work location reference file to perform three actions:
> - Recode vehicle types if the specific type is not accepted at the work location
> - Remove records with work locations or vehicle types that are not accepted (typically because the data is pulled from a different data source)
> - Remove records with unexpected work locations or unexpected work location/transportation types, until they can be verified

### Additional Details

##### Matching to the `ipil_air` Work Location Reference File

Each record in the raw file needs to be matched to the appropriate row of the **work_locations__ipil_air.csv** reference file to determine the 
appropriate action. The match should be done on work location (*wloc* from the raw data) and transportation type.

The applicable codes for matching on transportation type are defined in the **work_locations_trans__ipil_air.csv** reference file and consist of:
>- *ipil_air__111* for *Mode* = "Air" from the raw data (Commercial aircraft)
>- *ipil_air__215* for *Mode* = "Land" from the raw data (Buses)
>- *ipil_air__216* for *Mode* = "Rail" from the raw data (Trains)
>- *ipil_air__315* for *Mode* = "Marine" from the raw data (Ferries)

The corresponding *action* value then determines how each record should be processed for this edit.  

Code "A" (accept) indicates to process the IPIL Air data without modification.

##### Recode Passage Types

There are some work locations where certain modes of transportation would not make sense, so they are recoded with the assumption that they were 
miscoded by a CBSA officer. 

All of these recoding cases have an *action* code which is prefixed by "R", and the suffix matches the vehicle type codeset from the main database.

The following cases need to be recoded:

>- Code "R111" - Recode to commercial aircraft (*mode* = "Air")
>- Code "R215" - Recode to bus (*mode* = "Land")  
>- Code "R216" - Recode to train (*mode* = "Rail")
>- Code "R315" - Recode to ferry (*mode* = "Marine") 

##### Unexpected or Rejected Data Based on Work Location

The absence of a work location or work location-transportation type combination in the reference file indicates that the records **are not 
accepted by default** and need to be validated first.

Additionally, based on analysis of traveller volumes, the Tourism Statistics Program has confirmed that in some cases IPIL Air data alone does not fully 
represent travellers at a certain work location by a certain mode of transport, so IPIL Air data is not used. Code "X" (reject) indicates to 
remove information from the IPIL Air raw data because it is not used.

Therefore, if either:
> - The work location cannot be matched to the `ipil_air` work location reference file at all OR
> - The combination of work location and transportation type (*wloc* and *mode* from the raw data) is not present in the `ipil_air` work 
> location reference file OR
> - The combination of work location and transportation type is marked as "X" (reject)

This indicates that vehicles of this type are not currently accepted from IPIL Air at this work location, either because they were not previously 
expected to arrive there, or because another source is used for them, so to use both would result in double counting. These records should also
be removed until the data has been validated and the work location reference file potentially updated. This validation will be done in 
`ipil_air_v010`.

### Validity
January 2025 - present

### Required Auxiliary Inputs
The `ipil_air` work location reference files (trans, action and trans_action) are required.

### Related Pages
[Documentation on Work Locations]({{fc_baseurl.doc}}/reference/work_locations)
