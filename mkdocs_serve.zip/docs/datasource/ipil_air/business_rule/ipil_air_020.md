# Documentation for Business Rule ipil_air_020

### ID
ipil_air_020

### Name
Add Frontier Counts country information to IPIL Air data

### Type
Edit

### Purpose
Add the Frontier Counts country code to the IPIL Air clean data and do any necessary editing based on country codes.

### Additional Details

##### Frontier Counts Country Code
The IPIL Air variable *citizenship* contains the ISO two-letter alpha code and the country name, which are split into separate
variables in `ipil_air_000`. In order to be consistent with country of residence classification across all data sources, we need to convert the 
citizenship code (*citizenship_code*) to the Frontier Counts five-digit country of residence code. 

This Frontier Counts country code can be obtained from the `ipil_air` country of residence mapping file 
(**map__ipil_air__raw__citizenship_code__ipil_air__clean__country_of_residence.csv**) by matching *citizenship_code* from the raw data with *key* 
from the reference file, and taking *value* as the FC country code.

This variable is added to the `ipil_air` clean data as *country_of_residence*.

##### Unmatched Countries
If a *citizenship_code* alpha code cannot be matched to the `ipil_air` country of residence mapping file, this could indicate a 
previously unseen citizenship code, a system error or an invalid code for another reason. These cases need to be validated, and the 
country reference file potentially updated before proceeding.

Concretely, if *citizenship_code* cannot be matched to the `ipil_air` country of residence mapping file, remove the record, unless the
*citizenship_code* is BLANK (empty) in which case the record is kept and the citizenship is imputed in step `ipil_air_030`.

### Validity
January 2025 - present

### Required Auxiliary Inputs
The `ipil_air` country of residence mapping file is required.
