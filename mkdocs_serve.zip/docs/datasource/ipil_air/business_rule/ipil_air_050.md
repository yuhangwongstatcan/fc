# Documentation for Business Rule ipil_air_050

### ID
ipil_air_050

### Name
IPIL Air transformation to travellers table

### Type
Transformation

### Purpose
Generate the IPIL Air contribution to the travellers table in the correct schema.

### Additional Details
**NOTE: Since all IPIL Air travellers are from vehicle types where the count of vehicles is not enumerated by Frontier Counts 
(commercial aircraft, bus, train, pedestrain, ferry and private boat) there is no IPIL Air contribution to the `vehicles` table**.

To generate the IPIL Air contribution to the aggregate `travellers` table, code the columns of the `travellers` table as follows:

##### Time and Location Variables
The *year*, *month* and *day* columns are extracted from the *date* variable.  

The *port* column that was created in the `ipil_air_040` step is carried forward from the `clean ipil_air` file.

##### Itinerary Variables
The *mode* column is coded based on the *vehicle_type* column created in the `ipil_air_040` step as:
> - If *vehicle_type* = 111 then *mode* = 1
> - Else if *vehicle_type* in (215,216,217) then *mode* = 2 
> - Else if *vehicle_type* in (315,321) then *mode* = 3

The *vehicle_type* column that was created in the `ipil_air_040` step is carried forward from the `clean ipil_air` file.

The *plate_country* and *plate_region* columns are coded as 9 (Not applicable) and "NA" (Not applicable) respectively.

##### Arriving From

The *arriving_from* that was imputed in step `ipil_air_040` is carried forward from the `clean ipil_air` file.
Recall that bus, train, pedestrian, ferry and private boat travellers (*vehicle_type* in (215,216,217,315,321)) are coded as 
*arriving_from* = 1 (U.S. only) in all cases. The air travellers (*vehicle_type* = 111) are based on the `ipil_air_040` imputation.

If we ended up with an overseas traveller arriving by land, set them to *arriving_from* = 3 since they arrived from their own country first.
> - If *country_of_residence* not in (11124,11840) and *mode* = 2 then *arriving_from* = 3

##### Country of Residence
The *country_of_residence* column that was created in the `ipil_air_020` step, and further adjusted in the `ipil_air_030` step is 
carried forward from the `clean ipil_air` file. Recall that stateless travellers or refugees are assumed as immigrants and carry code 
99999.

##### Trip Purpose Variables
The *purpose9* and *purpose4* columns are coded as follows:
> - If *citizenship_code* in ("XA","XXB","XXC") (Stateless traveller or refugee) then set *purpose9* = 41 (Immigration) and *purpose4* = 4 (Other non-tourism purpose)
> - Else the *purpose4* that was imputed in step `ipil_air_040` is carried forward, and *purpose9* is coded based on this *purpose4* as:
>   - If *purpose4* = 1, then *purpose9* = 19 (Visit, not otherwise specified)
>   - Else if *purpose4* = 2, then *purpose9* = 21 (Crew)
>   - Else if *purpose4* = 3, then *purpose9* = 31 (Work)
>   - Else if *purpose4* = 4, then *purpose9* = 43 (Other non-tourism)

##### Trip Duration and Traveller Type Variables
The *duration2* column is copied from the imputed *duration2* variable.  
The *duration3* and *duration5* columns are coded as 99 (Not available) and 99 (Not available) respectively.

The *traveller_type* column is derived from other columns in the travellers table as follows:
> - If *purpose4* = 4 ("Other non-tourism") or *purpose4* = 3 ("Work") or (*purpose4* = 2 ("Crew") and *vehicle_type* in 
> (111,112,214,215,216,311,312)) then *traveller_type* = 3 ("Other traveller")
> - Else if *duration2* = 1 (Same day), then *traveller_type* = 1 (Excursionist)
> - Else if *duration2* = 2 (Overnight), then *traveller_type* = 2 (Tourist)

##### Analysis Variables
The *work_location* column is copied from the *wloc* variable.

The *data_source* column is coded as 12 (IPIL Air) in all cases for this data source.

Once all columns are coded, the *count_of_entries* is determined by taking the sum of *count_of_travellers* from the `clean ipil_air` 
file grouped across all transformed variables.

### Validity
January 2025 - present

### Required Auxiliary Inputs
None

### Related Pages
None
