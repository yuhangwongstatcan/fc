# Documentation for Business Rule ipil_air_040

### ID
ipil_air_040

### Name
Impute trip duration, trip purpose and arriving from for IPIL Air travellers

### Type
Imputation

### Purpose
Assign a trip duration, trip purpose and arriving from (air only) value to all travellers in IPIL Air.

### Additional Details
The IPIL Air data extractions from CBSA do not provide any breakdown by trip duration (same-day or overnight), by trip purpose (visit, 
crew, work or other purpose) or by arriving from (U.S. only, overseas direct, overseas via U.S.), but these are all required elements 
for Frontier Counts, so an imputation is required.

##### Add the Port of Entry
The imputation will be done at the port of entry level, so first a *port* column is created based on linking *work_location* to the 
work location reference file and extracting the corresponding port value associated with each *wloc*.

##### Reference Data Sources
There are two possible auxiliary data sources for imputing the required variables, each with strengths and weaknesses:

> - Historical data from the same ports of entry, which would be based on previously used data sources
>   - Prior to 2025, travellers captured in IPIL Air were reported through other data sources (e.g., E311 declaration cards, E63 reports), so the
>     historical data comes from the 2024 aggregated `travellers` file from the same month as the IPIL Air data being processed
>   - This data is the only option for non-PIK airports, and for train, bus and ferry travellers, but can become out of date quickly
> - Primary Inspection Kiosk data for airports where both PIK and IPIL Air are used
>   - This data would come from the `transformed pik` file (**travellers.csv.pik**) from the same month as the IPIL Air being 
>     processed, but is only available at airports where PIK is also used
>   - This data provides more current data for reference proportions, but PIK and IPIL Air may cover different types of travellers, so 
>     reference proportions might not be as accurate

##### Calculating Reference Proportions
To generate the required reference distributions, read in the 2024 `travellers` file and the `transformed pik` file (**travellers.csv.pik**) from 
the same month as the IPIL Air data being processed and calculate the proportions of:

> - *duration2*, to split travellers in same-day and overnight
> - *purpose4*, to split travellers by trip purpose for visit, crew, work and other purpose
> - *arriving_from*, **for air travellers (*mode* = "Air") only** to split by route of arrival

The reference proportions are calculated and applied by *port*, *vehicle_type* and *region_of_residence*. To facilitate this, 
*vehicle_type* and *region_of_residence* can be added to the IPIL Air data as described in the following two subsections.

*Vehicle Type*

There are a few points of entry that are special cases for vehicle type, because the methods of conveyance for which they use the
IPIL Air system are not typical of how the system is used at most POE.

> - If *wloc* in (3514,4115) and *mode* = "Marine", then *vehicle_type* = 321. Marine data considered as private boats for the ports of Quai Richelieu and Sandpoint Lake instead of ferry.
> - If *wloc* in (8171,8173) and *mode* = "Land", then *vehicle_type* = 217. Land data considered as pedestrians for the Abbotsford-Huntingdon ports (Commercial and Travellers) instead of bus.

For the Rainbow Bridge POE (4272), the IPIL Air data is a combination of bus travellers and pedestrians, all stored as "Land". Since
we cannot determine the distribution from IPIL Air, we use the proportions from the 2024 aggregated `travellers` data described above.
In other words,
> - If *wloc* = 4272 and *mode* = "Land" then *vehicle_type* is assigned proportionally to 215 and 217 based on the proportion from the 2024 `travellers` data from the same month being processed

Otherwise, the general IPIL Air vehicle types apply. For all *wloc* except 3514, 4115, 4272, 8171 and 8713:
> - If *mode* = "Air", then *vehicle_type* = 111
> - If *mode* = "Land", then *vehicle_type* = 215
> - If *mode* = "Rail", then *vehicle_type* = 216
> - If *mode* = "Marine", then *vehicle_type* = 315

*Region of Residence*

> - If *country_of_residence* = 11124, then *region_of_residence* = "CAN"
> - If *country_of_residence* = 11840, then *region_of_residence* = "USA"
> - If *country_of_residence* not in (11124, 11840, 99999), then *region_of_residence* = "OVS"

Note that *region_of_residence* can also be added to the incoming auxiliary data.

For non-PIK ports of entry, the joint proportions of *duration2*, *purpose4* and *arriving_from* are calculated from the **historical data only** 
and applied to each record from the `ipil_air` data to split each *count_of_travellers* by these three characteristics.

For PIK ports of entry:
> - From the inception of IPIL Air until the *December 2027* reference month, the proportions from PIK and from the historical data are 
calculated and averaged (50-50 contribution), and the resultant proportions applied to each record from the `ipil_air` data to split each 
*count_of_travellers* by these three characteristics.
> - As of the *January 2028* reference month, the proportions from **PIK only** are calculated and applied to each record from the `ipil_air` data
to split each *count_of_travellers* by these three characteristics.

Note: The list of PIK ports of entry can be extracted from the PIK work location trans action file (**work_locations__pik.csv**) as work location 
values, and linked to port of entry values with the **work_locations.csv** reference file.

##### Applying the Reference Proportions
The appropriate reference proportions are applied to each record from the `ipil_air` data within the same 
*port*-*vehicle_type*-*region_of_residence* group, and the *count_of_travellers* split across the various values of *duration2*, 
*purpose4* and *arriving_from*. For example, all IPIL Air records within the month having *port* = 48701 (Calgary Airport), 
*vehicle_type* = 111 (Commercial aircraft) and *region_of_residence* = "OVS" (overseas) are considered together when applying the 
reference proportions.

The original *count_of_travellers* should be respected, so the total for the row with maximum count number in the split category should 
take the original *count_of_travellers* and subtract the totals from all other split categories to ensure that the original total is 
respected. The other characteristics of each record (e.g., date, gender) should also be respected after applying the proportions.

Note that small counts in the `ipil_air` data will make it difficult to apply proportions, so any records with *count_of_travellers* 
<= 5 should be uniformly coded directly to the most popular category for the *port*, *vehicle_type* and *region_of_residence* from 
the `travellers` file.

For example, if there are only 4 Canadian-resident Stanhope train travellers (*port* = 24354, *region_of_residence* = "CAN" and 
*vehicle_type* = 216) in a particular IPIL Air row, and the most popular categories from the `travellers` file are *duration2* = 1 
("Same-day"), *purpose4* = 2 ("Crew") and *arriving_from* = 1 ("U.S. only"), all 4 travellers from this IPIL Air row are coded to 
those categories, even if there are some other categories present in the `travellers` file.

If there is no reference data available for the *port*, *vehicle_type* and *region_of_residence* combination in IPIL Air,the national 
(all ports) proportion can be used for the *vehicle_type* and *region_of_residence* combination.

##### Deterministically Overwrite Characteristics Relevant to All Work Locations
The stateless and refugee cases (*country_of_residence* still = 99999 after `ipil_air_030` and with *citizenship_code* in ("XA",
"XXB","XXC")) can be coded directly as:
> - *duration2* = 9 (Duration not available)
> - *purpose4* = 4 (Other purpose)
> - *arriving_from* = 2 (Direct from another country)
> For non-air travellers (*mode* = "Land", "Rail" or "Marine"), *arriving_from* can be coded as:
> - *arriving_from* = 1 (U.S. Only) for Canadian and American travellers (*country_of_residence* in (11124,11840))
> - *arriving_from* = 3 (Overseas via the U.S.) for overseas travellers (*country_of_residence* not in (11124,11840))

##### Deterministic Imputation For Specific Work Locations
The following work locations are known to serve only cargo trains, so all trip purposes can be set to crew (*purpose4* = 2): St. Croix
(2310), Woburn (3090), Abercorn (3180), Hemmingford (3331), Stanhope (3540), Emerson (5021 and 5022) and North Portal (6021 and 6025).

Concretely, if *wloc* in (2310,3090,3180,3331,3540,5021,5022,6021,6025) and *vehicle_type* = 216, then *purpose4* = 2.

### Validity
January 2025 - present

### Required Auxiliary Inputs
The work location reference file is required.
The PIK work location trans action file is required.
The PIK transformed data for the same month being processed for IPIL Air is required.
The aggregated 2024 `travellers` data for the same month being processed for IPIL Air is required.

### Related Pages
[Documentation for PIK transformed data]({{fc_baseurl.doc}}/datasource/pik/business_rule/pik_110)
