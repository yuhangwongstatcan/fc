# Documentation for Business Rule ipil_air_005

### ID
ipil_air_005

### Name
Impute mode of transportation for IPIL Air travellers with unknown mode

### Type
Imputation

### Purpose
Impute a mode of transportation for travellers where the mode variable is blank, using the most common mode for the work location
where the traveller crossed the border.

### Additional Details

##### Determine most common mode of transportation for each work location
Most (if not all) work locations in IPIL Air have only a single mode of transportation that is permitted, so we can deterministically
(or pseudo-deterministically) impute a mode of transportation for cases the *mode* variable is blank by determining the most common
*mode* in each *wloc*.

Concretely, calculate the sum of *count_of_travellers* by *wloc* and *mode* for the entire month of data being processed, and for
each *wloc*, retain the *mode* with the maximum *count_of_travellers*.

##### Imputation
For each record where the *mode* variable is missing, attribute the most common mode of transportation for its *wloc*, as determined
in the previous step.

### Validity
January 2025 - present

### Required Auxiliary Inputs
None

### Related Pages
None
