# Documentation for Validation ipil_air_v010

### ID
ipil_air_v010

### Related Business Rule
ipil_air_010

### Name
Summary of IPIL Air Work Location Issues

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected data (work location and/or transportation type) received in IPIL Air
and a summary of data that was received but rejected.

### Additional Details

##### Unexpected Work Locations or Transportation Types
This validation is produced for the Production Team to examine records that could not be matched to the `ipil_air` work location reference file 
based on work location and transportation type (*wloc* and *mode* from the raw data), indicating that the the work location-transportation type
has not previously been encountered.

These cases could indicate work locations that were not previously in IPIL Air or work locations that are accepting a new mode of transportation.
In both instances, the new data need to be checked to see if they will be accepted or rejected from IPIL Air.

These cases are flagged in the validation output file as *work_location_issue_type* = "Unexpected WLOC or Mode".

##### Rejected Data
As IPIL Air is phased in, certain work locations and/or transportation types are not accepted from IPIL Air since they continue to be sourced
from a different data source (for example, E311 declaration cards, E63 reports, etc.), and these are identified in the `ipil_air` work location
reference file with an action of "X", meaning to reject the data.

Although these cases have been specifically labelled as "X" (reject), so they don't have an unknown status, it is still beneficial during the
IPIL Air rollout for the production team to review the rejected data on a monthly basis to assess the volumes.

These cases are flagged in the validation file as *work_location_issue_type* = "Rejected Data".

##### Output File and Dashboard Display
The output file from the validation contains a count of travellers for each *work_location_issue_type*, grouped by *date*, *wloc*, *wloc_name* 
and *mode*.

Recoded cases (*action* beginning with "R", such as R111, R215, R216, R315) do not need to be included in the validation output.

The dashboard displays a filterable table with the various *work_location_issue_type* issues. 

Filters are available by year and month, as well as an auxiliary filter by work location issue type.

### Validity
January 2025 - present

### Required Auxiliary Inputs
The IPIL Air work location reference file is required.

### Related Pages
[Documentation for ipil_air_010]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_010)
