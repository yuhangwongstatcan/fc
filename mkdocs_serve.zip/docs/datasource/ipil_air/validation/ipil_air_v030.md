# Documentation for Validation ipil_air_v030

### ID
ipil_air_v030

### Related Business Rule
ipil_air_030

### Name
Summary of IPIL Air Country Imputation

### Type
Validation

### Purpose
Provide a visualization for end users to view a breakdown of countries of residence in IPIL Air that were imputed for records with generic
or unknown citizenship values.

### Additional Details

##### Validation Output
The output from the validation is a summary table by date (*date*), work location (*wloc*) and work location name (*wloc_name*) with the count of 
travellers imputed to each *country_of_residence* by type of unknown citizenship.

For the type of unknown citizenship, it can be logged under *unknown_citizenship* with the following values:
> - "Blank" if *citizenship* is blank (originally the error code "#NAME?" in the Excel file)
> - "United Nations" if *citizenship_code* = "UNA" or "UNO"
> - "Unspecified" if *citizenship_code* = "XX"
> - "European Union" if *citizenship_code* = "EUE"

##### Dashboard Display
The dashboard displays a bar chart with the bars representing the number of travellers imputed for each country of residence.

Filters are provided for year, month and type of unknown citizenship. If the type of citizenship filter is unused, then the end
user can view an overall summary of imputed countries of residence.

### Validity
January 2025 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation on ipil_air_030]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_030)
