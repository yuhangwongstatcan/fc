# Documentation for Validation ipil_air_v000

### ID
ipil_air_v000

### Related Business Rule
None (The processing done in ipil_air_000 is unrelated to this validation.)

### Name
Summary of Unexpected Values - IPIL Air

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of unexpected values for discrete variables in IPIL Air.

### Additional Details

##### Variable Values
The system is only expecting to see certain values in each discrete variable, as specified in the `dim.py` file for IPIL Air. The valid
values are based on the Excel files received historically from CBSA. The Production Team needs to be aware of unexpected values, because the 
system may not be able to handle them, or they could indicate invalid records from IPIL Air raw data.

Specifically, the following variables should have their values validated:
> - *gender* in ("Male","Female","Unspecified","Unknown")
> - *mode* in ("Air","Land","Rail","Marine")
> - *citizenship_code* among the approximately 270 valid values specified in the `ipil_air` `dim.py` file
>   - Note that blank values of *citizenship_code* are not output in this validation. They are expected, and are treated with imputation in `ipil_air_030`


##### Dashboard Display
Any invalid values are displayed in a bar chart grouping invalid codes by variable name.  

This graphic can be filtered dynamically by month and year.

### Validity
January 2025 - present

### Required Auxiliary Inputs
None

### Related Pages
None
