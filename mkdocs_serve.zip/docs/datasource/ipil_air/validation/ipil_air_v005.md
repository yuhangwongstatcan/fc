# Documentation for Validation ipil_air_v005

### ID
ipil_air_v005

### Related Business Rule
ipil_air_005

### Name
Summary of IPIL Air Mode of Transportation Imputation

### Type
Validation

### Purpose
Provide a visualization for end users to view a breakdown of modes of transportation in IPIL Air that were imputed for records where
the `mode` variable is blank.

### Additional Details

##### Validation Output
The output from the validation is a summary table by date (*date*), work location (*wloc*) and work location name (*wloc_name*) with 
the count of travellers imputed to each *mode*.

##### Dashboard Display
The dashboard displays a bar chart with the bars representing the number of travellers imputed for each mode of transportation and 
work location.

Filters are provided for year and month.

### Validity
January 2025 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation on ipil_air_005]({{fc_baseurl.doc}}/datasource/ipil_air/business_rule/ipil_air_005)
