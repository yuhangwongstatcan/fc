# What is a Data Source?

# What Data Sources are used?
There are currently 13 data sources that are used in the Frontier Counts program.