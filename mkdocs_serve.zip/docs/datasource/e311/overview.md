# E311 Data Source

### E311 Declaration Cards
E311 cards are the customs declaration cards that travellers fill out in order to declare themselves and their goods to the Canada Border Services 
Agency upon arrival in Canada. Prior to 2017 and the introduction of the Primary Inspection Kiosks (PIK), E311 cards were the primary means for 
travellers to make their customs declaration and approximately 22 million cards were received annually from the various ports of entry. Now that 
PIK are available at 10 major Canadian airports, it is expected that only approximately 1 million or less E311 cards will be received annually, 
mostly from minor airports and other points of entry (land borders and marine ports).

Once all fields have been filled out, travellers hand in their cards to CBSA officers, and CBSA in turn forwards these cards to Statistics Canada 
in envelopes or boxes for processing. The cards are received in Operations and Integration Division and captured using a combination of automated 
software (AnyDoc) and human intervention.

### Initial Processing by Operations and Integration Division (OID)

Before the data are received in the Inbox of the Frontier Counts system, they are processed in OID by scanning the cards and capturing both the 
data and the card images. The E311 capture system in OID was also redesigned for 2022 in conjunction with the Frontier Counts system redesign to 
make it simpler and more accurate given the reduced number of cards that are now processed compared to when the prior system was implemented.

Upon reception, cards are first batched for the scanning sofware, with batches having a common year, month, port of entry and mode of 
transportation. This batch-level information is transferred to all individual cards in the batch. The individual cards are then scanned (by batch) 
and all of the required fields captured by automated software and verified by an operator. The operator also makes some corrections and denotes 
some indicators if CBSA officers make relevant marks on the declaration cards (e.g. relevant handwritten notes) that cannot be read by the 
automated sofware.

The captured cards and their data go through a quality control verification process, and then the files are output from the AnyDoc system as a 
positional flat file with all of the information from the batch and from the individual cards. The cards are then copied to the inbox location of
the Frontier Counts system to be ingested.

### Data Reception in the Frontier Counts System
E311 data is received in positional flat (.txt) files. One file is provided for each processing batch of cards and the records are at the level of
individual declaration cards.

The parameters of the received files are as follows:
> - File type: .txt
> - Naming conventions:
>>  - File name of the form: ####################.txt (Note: #################### is a twenty digit numeric ID)
>>>   - Note: To identify E311 files, can use the pattern: ####################.txt ("twenty digits".txt)
> - Timeliness: Ad hoc, depending on how quickly individual ports can send cards each month
>>  - Note: Multiple batchs can be processed by OID in a given day, so multiple E311 batch text files can be received each day
> - Granularity: Data is available at the level of individual declaration cards; day of arrival is often available, but not always
> - Date Variable:
>>  - *agent_stamp*, if available and in the correct month (see subsequent section)
>>  - *date_of_signature* otherwise, if available and in the correct month (see subsequent section)
>>  - Otherwise, only year and month available, via *year* and *month*
> - Format: 
>>  - YYYYMMDD

### E311 Loader Function
The E311 raw data is created by extracting data from the text file according to position and length of the variables as follows:

| Variable | Start Position | End Position | Length |
| ------ | ------ | ------ | ------ |
| batch_id | 1 | 2 | 2 |
| mode | 3 | 3 | 1 |
| port | 4 | 6 | 3 |
| year | 7 | 10 | 4 |
| month | 11 | 12 | 2 |
| doc_num | 21 | 24	| 4 |
| traveller_flow | 25 | 29 | 5 |				
| traveller_count | 30 | 30 | 1 |
| name1 | 31 | 80 | 50 |
| date_of_birth1 | 81 |	88 | 8 |
| citizenship1 | 89 | 93 | 5 |
| name2 | 94 | 143 | 50 |
| date_of_birth2 | 144 | 151 | 8 |
| citizenship2 | 152 | 156 | 5 |
| name3 | 157 |	206 | 50 |
| date_of_birth3 | 207 | 214 | 8 |
| citizenship3 | 215 | 219 | 5 |
| name4 | 220 |	269 | 50 |
| date_of_birth4 | 270 | 277 | 8 |
| citizenship4 | 278 | 282 | 5 |
| province_or_state	| 283 |	292 | 10 |
| country_code | 293 | 297 | 5 |
| town_or_city | 298 | 347 | 50 |
| postal_code | 348 | 356 |	9 |
| arriving_by_boxes | 357 | 360 | 4 |				
| arriving_by_detail | 361 | 410 | 50 |
| purpose_of_trip | 411 | 413 |	3 |	 				
| arriving_from	| 414|	416 | 3 | 				
| duration_of_stay | 417 | 419 | 3 |
| depart_date1 | 420 | 427 | 8 |
| depart_date2 | 428 | 435 | 8 |
| date_of_signature | 436 |	443 | 8 |
| agent_stamp | 444 | 451 |	8 |
| additional_indicators_q |	452 | 452 |	1 |
| crew | 453 | 453 | 1 |
| immigration | 454 | 454 |	1 |
| military | 455 | 455 | 1 |
| other_non_visitors | 456 | 456 | 1 |
| workers | 457 | 457 |	1 |
| cargo | 458 |	458 | 1 |
| private | 459 | 459 |	1 |
| did_not_fly | 460 | 460 |	1 |

Note: After the data is extracted, the **system** date and time (in EST) when the data was placed in raw (execution datetime of the 
Check Inbox pipeline run that moved the data from the inbox to the raw location) is also included, in the format YYYY-MM-DD HH:MM:SS. Since 
multiple files can be received on an ad hoc basis, this will allow tracking of all of the E311 data that was received in the Frontier Counts 
system. This additional variable is called *reception_datetime*.

### Triaging E311 Data to Raw Storage

As with other data sources, E311 is triaged to raw storage based on date, however unlike other data sources which have a consistent temporal
data availability (date is available vs. month only is available), E311 can have a mix since it is based on cards as completed by travellers, and 
they may misunderstand the instructions or omit some information.

As previously alluded to, the E311 data from inbox should triaged as follows:

> - If the *agent_stamp* is available AND year(*agent_stamp*) = *year* AND month(*agent_stamp*) = *month*, then store in a daily RAW file (e.g. 
> YYYYMMDD.csv) where YYYYMMDD = *agent_stamp*
> - Else if the *date_of_signature* is available AND year(*date_of_signature*) = *year* AND month(*date_of_signature*) = *month*, then store in a 
> daily RAW file (e.g. YYYYMMDD.csv) where YYYYMMDD = *date_of_signature*
> - Else (i.e. *agent_stamp* and *date_of_signature* were both unavailable or dated as the incorrect year and/or month), then store in a generic RAW
> file YYYYMM99.csv, where YYYY is extracted from *year* and MM is derived from *month*

### Conflicts and Duplicate Removal

The conflict functionality in the Frontier Counts system was developed in order to flag and handle cases where multiple files are received for 
a given time period (e.g. month) when only one was expected. This is the case for many of the Frontier Counts data sources, so the default behaviour
is for a file conflict to be generated.

Since, however, it is expected that E311 cards for a given time period (day or generic month [YYYYMM99.csv] as described in the previous section) 
will be received across various files and frequently throughout the month, the default behaviour for the E311 data source will deviate slightly in 
order to avoid generating an inordinate number of conflicts for the Production Team to review.

The E311 data will go through the following process after the triage by day described above:
> - For each daily file (YYYYMMDD.csv or YYYYMM99.csv), check if there is already a corresponding file with the same name stored in raw/e311
> - If there is not, output the daily file directly to raw/e311
> - If there is already a RAW file with the same name, append the contents of the new daily file to the existing one
> - After the append, remove any true duplicates (every variable except *reception_datetime* is duplicated)
> - Write the appended file to the raw/e311 location

### Variables in the Raw Data
The variables in the raw e311 data are as follows:

> - batch_id: Identification number for the batch that the card came from
> - mode: Mode of transportation, extracted from the batch-level information as identified by an OID operator
> - port: Port of entry (3 digits) in Canada, extracted from the batch-level information as identified by an OID operator
> - year: Year of arrival in Canada, extracted from the batch-level information as identified by an OID operator
> - month: Month of arrival in Canada, extracted from the batch-level information as identified by an OID operator
> - doc_num: Identification number for the individual document (declaration card) within the batch
> - traveller_flow: Identifier of type of traveller from CBSA "office use" checkboxes at the top of the E311 card
>>  - A 1 in the first position indicates Canadian residency
>>  - A 2 in the second position indicates U.S. residency
>>  - A 3 in the third position indicates residency in a country other than Canada or the United States
>>  - A 4 in the fourth position indicates crew
>>  - A 5 in the fifth position indicates "other"
> - traveller_count: Count of travellers making their declaration on the same card (travellers must all live at the same address)
> - name1: Name of the first traveller declaring
> - date_of_birth1: Date of birth of the first traveller declaring
> - citizenship1: Citizenship of the first traveller declaring; code mapping to the **countries.csv** reference file
> - name2: Name of the second traveller declaring, if applicable
> - date_of_birth2: Date of birth of the second traveller declaring, if applicable
> - citizenship2: Citizenship of the second traveller declaring, if applicable
> - name3: Name of the third traveller declaring, if applicable
> - date_of_birth3: Date of birth of the third traveller declaring, if applicable
> - citizenship3: Citizenship of the third traveller declaring, if applicable
> - name4: Name of the fourth traveller declaring, if applicable
> - date_of_birth4: Date of birth of the fourth traveller declaring, if applicable
> - citizenship4: Citizenship of the fourth traveller declaring, if applicable
> - province_or_state: Province or state that the traveller(s) reside in
> - country_code: Country that the traveller(s) reside in; code mapping to the **countries.csv** reference file
> - town_or_city: City that the traveller(s) reside in
> - postal_code: Postal code that the traveller(s) reside in
> - arriving_by_boxes: Checkboxes to indicate which mode of transportation was used to enter Canada
>>  - A 1 in the first position indicates Air
>>  - A 2 in the second position indicates Rail
>>  - A 3 in the third position indicates Marine
>>  - A 4 in the fourth position indicates Highway
> - arriving_by_detail: Identifier for the transportation used to enter Canada, typically a flight number or vessel name or train number
> - purpose_of_trip: Checkboxes to indicate what the main trip purpose was
>>  - A 1 in the first position indicates Study
>>  - A 2 in the second position indicates Personal
>>  - A 3 in the third position indicates Business
> - arriving_from: Checkboxes to indicate where the traveller(s) are arriving from
>>  - A 1 in the first position indicates U.S. Only
>>  - A 2 in the second position indicates Overseas Direct
>>  - A 3 in the third position indicates Overseas Via U.S.
> - duration_of_stay: Continuous variable indicating the number of days that visitor(s) to Canada will remain in the country
> - depart_date1: Date when the first traveller declaring left Canada (only applicable to Canadian residents returning)
> - depart_date2: Date when the second traveller declaring, if applicable, left Canada (only applicable to Canadian resident returning)
> - date_of_signature: Date accompanying the signature; used as date of arrival
> - agent_stamp: Date on a CBSA agent's stamp, if present; used as date of arrival, superseding date of signature
> - additional_indicators_q: Dichotomous variable indicating whether there were relevant handwritten notes on the card from a CBSA agent
> - crew: Indicator of whether there was a handwritten note for crew on the card; 0 or 1
> - immigration: Indicator of whether there was a handwritten note for immigration on the card; 0 or 2
> - military: Indicator of whether there was a handwritten note for military on the card; 0 or 3
> - other_non_visitors: Indicator of whether there was a handwritten note for another type of non-visitor (e.g. diplomat, refugee, etc.) on the 
> card; 0 or 4
> - workers: Indicator of whether there was a handwritten note for workers on the card; 0 or 5
> - cargo: Indicator of whether there was a handwritten note indicating a cargo movement on the card; 0 or 6
> - private: Indicator of whether there was a handwritten note indicating a private movement on the card; 0 or 7
> - did_not_fly: Indicator of whether there was a handwritten note indicating that the traveller did not actually fly; 0 or 8
> - reception_datetime: Date and time at which the Check Inbox pipeline run occurred which moved the record from Inbox to Raw storage

### Validation

The loader function for E311 will also log information for a validation and its corresponding dashboard summarizing the count of cards received to 
date in the month by port and by day (if available). The validation is called "Card Volumes in RAW E311 Data".

**Note:** Typically validations are associated to business rules (edits or imputations) and logged from the individual data source pipeline during 
the execution of the corresponding business rule code. This validation (done within the E311 Loader function) is a special case because we want it 
to update without the Production Team needing to run the dedicated e311 pipelines. By having the validation logged from the Loader function, the 
Production Team can see the summary validation updates after simply "Check Inbox" is run.

##### Information to be Logged

The validation function will log a count of cards (count of records) grouped by the following: *year*, *month*, *port* and date (YYYY-MM-DD) (dates 
as split for the triaging to RAW and recorded in the file names - i.e. either a specific date if valid based on conditions described above or 
YYYY-MM-99 otherwise).

##### Dashboard Display

The dashboard for this validation displays two bar graphs:
> - One with count of cards by *port*, sorted descending by card volume
> - One by date, sorted in chronological order with '99' cases at the end

The two bar graphs can filter each other (i.e. clicking a port specific port in the former graph filters the second to only display daily
information for that port, and vice versa). There is also a high-level filter provided for *year* and *month*, as the Production Team will examine
the dashboards monthly, so will need the ability to specifically filter a month.
