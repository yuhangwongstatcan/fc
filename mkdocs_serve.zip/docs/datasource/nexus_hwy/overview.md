# NEXUS Highway Data Source

### NEXUS Program
The NEXUS program is a trusted traveller program which allows pre-approved travellers to pass between Canada and the United States with minimal
interaction with border authorities (CBSA or U.S. Customs and Border Protection).

Since highway travellers using the NEXUS program have specific lanes, there is no overlap between NEXUS and other data sources. For example, NEXUS 
travellers by land do not pass through an IPIL Highway or IPIL Air processing lane.

### Data Reception
Note: NEXUS Highway data and NEXUS Air data are received in the same file each month, so this section is duplicated in the documentation of NEXUS
Highway and NEXUS Air since they will be processed by the same loader function.

NEXUS Highway data is received (with NEXUS Air data) in a single Excel file each month. The file provides an aggregate monthly total by port of
entry and, in some tabs of the Excel file, by citizenship.

The parameters of the received files are as follows:
> - File type: .xlsx (Excel)
> - Naming conventions:
>>  - File name of the form: Month YYYY - STAT CAN Monthly Nexus Report.xlsx
>>>   - Note: To identify NEXUS files, can use the pattern: *STAT CAN Monthly Nexus Report.xlsx
>>  - There are three tabs in the Excel file:
>>>   - NEXUS vs all Conveyances: Showing NEXUS Highway vehicle traffic
>>>   - NEXUS Land Citizenship: Showing NEXUS Highway travellers
>>>   - NEXUS Air Citizenship: Showing NEXUS Air travellers
> - Timeliness: One file is received monthly near the middle of the following month
>>  - For example, file for February received in mid-March
> - Granularity: Monthly
> - Date Variable: N/A; year needs to be extracted from YYYY of the file name, and month from the "Month" of the file name
> - Format: 
>>  - YYYY is a four-digit year
>>  - Month can be three (e.g. "Mar") or four (e.g. "Sept") characters, or the whole month name (e.g. "January")

### NEXUS Loader Function
As noted, since there is one file which contains data for both NEXUS Highway and NEXUS Air, there is only one loader function for both.

To create the nexus_hwy raw data with the loader function, the following steps needs to be done:
> - Extract the date from the file name as YYYY-MM-DD, where YYYY is extracted from the YYYY of the file name, MM is extracted from "Month" 
> of the file name and DD = 01. Since the length of "Month" can vary, the easiest way is to take the first three characters and base MM on those
>>  - Copy this *date* to every record in the raw data

> - From the tab "NEXUS vs all Conveyances", keep the columns B ("Land Border"), C ("Program") and the appropriate data column (one from D-O)
>>  - Columns are named for months, from April to March. Keep the column that corresponds to the month from the file name
>>>   - For example, if the file name is "Jan 2021 - ...", keep the column "January"
> - Drop the rest of the columns
> - From the tab "NEXUS vs all Conveyances", remove all summary rows, where "Land Border" (Column B) contains "Region" or "ROLL-UP"
> - From the tab "NEXUS vs all Conveyances", remove all non-NEXUS rows by keeping only rows where "Program" (Column C) = "NEXUS"
> - Remove any comments from the port names: in "Land Border" by removing anything in parentheses, including the parenthenses themselves

> - From the tab "NEXUS Land Citizenship", keep the columns B ("Land Border"), C ("Citizenship") and the appropriate data column (one from D-O)
>>  - Columns are named for months, from April to March. Keep the column that corresponds to the month from the file name
> - Drop the rest of the columns
> - From the tab "NEXUS Land Citizenship", remove all summary rows where "Land Border" (Column B) contains "ROLL-UP" or "Citizenship" (Column C) = "Total"
> - Remove the header and footnote rows (if applicable) by keeping only non-blank "Citizenship" values
> - Remove any comments from the port names: in "Land Border" by removing anything in parentheses, including the parentheses themselves

### Variables in the Raw Data
To create the nexus_hwy raw data, combine the data from the vehicle and traveller tabs by "Land Border" as follows:
>   - *date* (format YYYY-MM-DD), as extracted from the file name
>   - *wloc* from "Land Border"
>   - *citizenship*, as "Citizenship" from "NEXUS Land Citizenship"; from "NEXUS vs all Conveyances", insert rows as "Citizenship" = "VEHICLE"
>   - *count*, as the value from the appropriate month column
