# Documentation for Validation nexus_hwy_v020

### ID
nexus_hwy_v020

### Related Business Rule
nexus_hwy_020

### Name
Summary of NEXUS Highway Adjusted Vehicle Counts

### Type
Validation

### Purpose
Provide a visualization for end users to view a summary of vehicle counts that were adjusted in NEXUS Highway due to the work location having a higher 
number of travellers than vehicles for the month.

### Additional Details

In some cases, a NEXUS work location can report a higher number of vehicles crossing the border than travellers. This is not possible since all 
travellers in a vehicle passing through a NEXUS lane must also have valid NEXUS passes.

It is presumed in these cases that the vehicle count is incorrect due to errors with vehicle detection systems in the NEXUS lanes, and as such the
number of vehicles is adjusted down to equal the number of travellers.

The validation permits the Frontier Counts production team to examine these adjustments. Any adjustments that are significant and/or recurrent could
be flagged to CBSA for investigation.

##### Dashboard Display
The dashboard displays a filterable table with the original and adjusted vehicle counts for each work location where an adjustment occurred. 

Filters are available by year and month.

### Validity
March 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
[Documentation for nexus_hwy_020]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_020)
