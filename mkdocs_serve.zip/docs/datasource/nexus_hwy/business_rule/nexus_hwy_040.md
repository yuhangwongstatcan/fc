# Documentation for Business Rule nexus_hwy_040

### ID
nexus_hwy_040

### Name
Impute licence plate country in NEXUS Highway

### Type
Imputation

### Purpose
Assign licence plate country for vehicles in NEXUS Highway.

### Additional Details
The licence plate country of a vehicle (at a minimum, Canada versus United States) is a required element for Frontier Counts, but CBSA is not able
to provide this information for NEXUS Highway vehicles, so it needs to be imputed. 

Based on studies of IPIL Highway data (where both country of residence/citizenship and plate region is available), it is reasonable to assume in 
most cases that Canadians are travelling in Canadian-plated vehicles and Americans are travelling in American-plated vehicles. As such, for NEXUS
Highway, we impute the plate country of vehicles to Canada or United States based on the proportion of traveller citizenships.

For example, if there are 100 vehicles at a given work location, with 119 travellers (57 Canada and 62 United States), then we impute **48**
(round(100 x 57/119)) Canadian-plated vehicles and **52** (100-(round(100 x 57/119))) American-plated vehicles.

The easiest way to add this to the dataframe is to use the *plate_country* variable from the VEHICLES and TRAVELLERS tables, which will be encoded
shortly. We code the resultant *count* of Canadian-plated vehicles as *plate_country* = 1 and the resultant count of American-plated vehicles as
*plate_country* = 2. At the traveller level, for consistency, we will also assume that *plate_country* reflects *citizenship*.

### Validity
January 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
None
