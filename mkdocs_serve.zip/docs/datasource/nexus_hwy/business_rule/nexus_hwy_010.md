# Documentation for Business Rule nexus_hwy_010

### ID
nexus_hwy_010

### Name
Remove NEXUS Highway records with unexpected work locations

### Type
Edit

### Purpose
Remove records from the NEXUS Highway raw data that cannot be matched to the work location reference file, or for which the file indicates that they are
not accepted, until they can be reviewed.

### Additional Details
The NEXUS Highway system is only known to be used (meaning a special NEXUS lane is available) at a finite number of land ports of entry and the 
Production Team needs to be aware of any unexpected work locations as this could represent a new NEXUS Highway location (in which case the 
**work_locations__nexus_hwy.csv** reference file needs to be updated) or an indication of erroneous or invalid data (in which case the records should 
be removed).

The NEXUS Highway raw data should be joined with the **work_locations__nexus_hwy.csv** reference file on work location (*work_location* variable from 
the NEXUS Highway data, as coded from the business rule nexus_hwy_005) and *transportation_type* = "nexus_hwy__211" (since all NEXUS Highway data 
are considered automobiles).

If the corrseponding action is "A" (accept) in the work location reference file, the record should be maintained.

A record should be removed in the following cases:
> - The *work_location* code cannot be matched to the work location reference file
> - The *work_location* can be matched, but there is no corresponding "nexus_hwy__211" entry for *transportation_type*
> - The *work_location* variable is blank

These removed records will be examined as part of the nexus_hwy_v010 validation.

### Validity
January 2017 - present

### Required Auxiliary Inputs
The nexus_hwy work location reference file is required.

### Related Pages
[Documentation on Work Locations]({{fc_baseurl.doc}}/reference/work_locations)
[Documentation for nexus_hwy_005]({{fc_baseurl.doc}}/datasource/nexus_hwy/business_rule/nexus_hwy_005) 
