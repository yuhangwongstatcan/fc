# Documentation for Business Rule nexus_hwy_030

### ID
nexus_hwy_030

### Name
Impute citizenship for unknown and other categories in NEXUS Highway

### Type
Imputation

### Purpose
For cases where the citizenship is listed as "Unknown" or "Other" in NEXUS Highway, impute a country of citizenship, as this will later be used as
a proxy for country of residence in the database.

### Additional Details
The NEXUS program is only supposed to be available to residents of Canada or the United States, or Mexican residents who are part of the Viajero
Confiable program.  

The "Other" category contains these Viajero Confiable passengers and also permanent residents of Canada or the U.S. with other citizenships. Since 
we have no indication of what proportion of the "Other" travellers the Mexican residents represent, we simply consider all as Canadian or American 
residents.

Concretely, we redistribute the categories of "Unknown" and "Other" to "Canada" and "United States" based on the known proportion of Canadian and American
citizenships. For example, if there are 7 Unknown citizenships and 3 Other citizenships at a given work location, we have 10 travellers to be
redistributed. If there are 1622 travellers with "known" *citizenship* (1234 Canada and 388 United States), then add 8 Canada citizenships
(round(10 x 1234/1622)) and 2 United States citizenships (10 - (round(10 x 1234/1622))), and remove the rows for "Unknown" and "Other".

In the rare case where there is no known proportion (i.e. both "Canada" and "United States" are zero), redistribute evenly between the two, giving
the extra traveller in the case of an odd number to "Canada".

### Validity
January 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
None
