# Documentation for Business Rule nexus_hwy_050

### ID
nexus_hwy_050

### Name
Impute trip duration for NEXUS Highway travellers

### Type
Imputation

### Purpose
Assign a trip duration of same day or overnight to travellers in NEXUS Highway.

### Additional Details
There is no trip duration available from the NEXUS Highway summary file that we currently receive, but this is a required element (at a minimum
same day and overnight) for Frontier Counts, so an imputation is required. 

IPIL Highway data cannot be used as an auxiliary proportion because NEXUS travellers are very different from IPIL Highway travellers (the 
proportion of same day is much higher because they are mostly commuters or frequent border-crossers). Instead, fixed proportions by port are 
used based on the results of a survey of NEXUS travellers done in 2011.

The proportions are as follows: 
> - 95% same day for Rte-55 Stanstead (3141), Aldergrove (8174), Boundary Bay (8150) and Abbotsford-Huntingdon (8173)
> - 60% same day for Americans at Pacific Highway (8132) and Douglas (8135)
> - 70% same day for Canadians at Pacific Highway (8132) and Douglas (8135)
> - 80% same day for all other work locations

The easiest way to add this to the dataframe is to use the *duration2* variable from the TRAVELLERS table, which will be encoded shortly. After
applying the appropriate proportion to the *count* of travellers by work location and citizenship, we code the resultant *count* of same-day 
travellers as *duration2* = 1 and the resultant count of overnight travellers as *duration2* = 2.

### Validity
January 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
None
