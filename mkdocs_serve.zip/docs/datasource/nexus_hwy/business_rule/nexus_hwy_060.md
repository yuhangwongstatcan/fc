# Documentation for Business Rule nexus_hwy_060

### ID
nexus_hwy_060

### Name
NEXUS Highway transformation to vehicles table

### Type
Transformation

### Purpose
Generate the NEXUS Highway contribution to the vehicles table in the correct schema.

### Additional Details
The way in which the intermediate dataframes are created is such that the clean NEXUS Highway data has records for vehicles and records for
travellers. To generate the NEXUS Highway contribution to the aggregate VEHICLES table, extract the vehicle-level records (*citizenship* = 
"VEHICLE") and code the columns of the VEHICLES table as follows:

The *year* column is extracted from the *date* variable.  

The *month* column is extracted from the *date* variable.  

The *day* column is coded as 99 ("Not available") in all cases.  

The *port* column is coded based on linking *work_location* to the work location reference file and extracting the corresponding port value.

The *mode* column is coded as 2 ("Land") in all cases.  

The *vehicle_type* column is coded as 211 ("Automobile") in all cases.

The *plate_country* column is copied from the imputed *plate_country* variable.

The *plate_region* column is coded as NA ("Not available") in all cases.

The *work_location* column is copied from the *work_location* variable.

The *data_source* column is coded as 14 ("Nexus Highway") in all cases for this data source.

Once all columns are coded, the *count_of_entries* is determined by taking the sum of *count* grouped across all transformed variables.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The work location reference file is required.

### Related Pages
None
