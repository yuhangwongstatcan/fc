# Documentation for Business Rule nexus_hwy_070

### ID
nexus_hwy_070

### Name
NEXUS Highway transformation to travellers table

### Type
Transformation

### Purpose
Generate the NEXUS Highway contribution to the travellers table in the correct schema.

### Additional Details
The way in which the intermediate dataframes are created is such that the clean NEXUS Highway data has records for vehicles and records for
travellers. To generate the NEXUS Highway contribution to the aggregate TRAVELLERS table, extract the traveller-level records (*citizenship* != 
"VEHICLE") and code the columns of the TRAVELLERS table as follows:

The *year* column is extracted from the *date* variable.  

The *month* column is extracted from the *date* variable.  

The *day* column is coded as 99 ("Not available") in all cases.  

The *port* column is coded based on linking *work_location* to the work location reference file and extracting the corresponding port value.

The *mode* column is coded as 2 ("Land") in all cases.  

The *vehicle_type* column is coded as 211 ("Automobile") in all cases.

The *plate_country* column is copied from the imputed *plate_country* variable.

The *plate_region* column is coded as NA ("Not available") in all cases.

The *arriving_from* column is coded as 1 ("United States only") in all cases.

The *country_of_residence* column is coded based on the *citizenship* variable as:
> - If *citizenship* = "Canada" then *country_of_residence* = 11124
> - Else if *citizenship* = "United States" then *country_of_residence* = 11840

The *purpose9* and *purpose4* columns are coded as 19 ("Visit, not otherwise specified") and 1 ("Visit") respectively.

The *duration2* column is copied from the imputed *duration2* variable.

The *duration3* and *duration5* columns are coded as 99 ("Not available") and 99 ("Not available") respectively.

The *traveller_type* column is derived from other columns in the travellers table as follows:
> - If *duration2* = 1 ("Same day") then *traveller_type* = 1 ("Excursionist")
> - Else if *duration2* = 2 ("Overnight"), then *traveller_type* = 2 ("Tourist")
Note: There are no "Other travellers" in NEXUS Highway; all are considered visitors or returning visitors.

The *work_location* column is copied from the *work_location* variable.

The *data_source* column is coded as 14 ("Nexus Highway") in all cases for this data source.

Once all columns are coded, the *count_of_entries* is determined by taking the sum of *count* grouped across all transformed variables.

### Validity
January 2022 - present

### Required Auxiliary Inputs
The work location reference file is required.

### Related Pages
None
