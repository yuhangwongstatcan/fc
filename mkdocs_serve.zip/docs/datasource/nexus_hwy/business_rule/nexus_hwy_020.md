# Documentation for Business Rule nexus_hwy_020

### ID
nexus_hwy_020

### Name
Correct number of NEXUS Highway vehicles if higher than travellers

### Type
Edit

### Purpose
If the number of vehicles at a port of entry in NEXUS Highway is higher than the total number of travellers at the same port, reduce the number
of vehicles to equal the number of travellers.

### Additional Details
It should not be possible for the number of vehicles passing through a NEXUS lane to be higher than the number of travellers, since each vehicle
must have at least a driver, however it does sometimes occur in the data. The assumption, after discussions with CBSA, is that these situations are
caused by vehicles that went into the NEXUS lane inadvertently, but the passage could not be completed because the occupants were not NEXUS 
cardholders so the vehicle was captured by the camera system, but the travellers had to complete their border crossing at a regular lane (likely
IPIL Highway).

As such, the decision was taken to remove vehicles rather than add travellers because it is more likely that the NEXUS Highway raw data is 
overrepresenting the number of vehicles.

Concretely, if the sum of the counts of all traveller citizenships (Canada, United States, Unknown, Other) at a given work location is less than
the count of "VEHICLE" at the same work location, reduce the *count* of "VEHICLE" to equal the total traveller count.

### Validity
January 2017 - present

### Required Auxiliary Inputs
None

### Related Pages
None
