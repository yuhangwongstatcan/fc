# Power BI Visualizations

On the production bucket at `fc-bucket/dashboards/aggregation_validations` and `fc-bucket/dashboards/data_source_validations` you can find Frontier Count's Power BI validation visualizations. 

These dashboards are intended for use by the production team to get an overview of the state of the data in the FC system as it's processed. More information, including a link to an introductory video, can be found on the [production documentation website](https://tourism-tourisme.pages.cloud.statcan.ca/frontiercounts/frontier-counts/fc-docs-site/05_validations/review_validation_dashboards/).
