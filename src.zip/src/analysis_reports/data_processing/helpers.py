"""
Helper functions for data manipulation in CAD reports
"""
import pandas as pd


def decimal_to_percentage(val: float):
    # pandas >= 3 yields pd.NA (not np.nan) for missing values in nullable
    # dtypes, and pd.NA formats as "<NA>". Normalise so reports keep "nan%".
    if pd.isna(val):
        val = float("nan")
    return "{:.1%}".format(val)


def format_with_commas(x):
    if pd.isna(x):
        return x
    elif isinstance(x, (int, float)):
        return "{:,}".format(x)
    else:
        return x


def pivot_groupby(
    data: pd.DataFrame,
    index: str,
    columns: str,
    values_new: str = "count",
    values_orig: str = "count_of_entries",
    numeric_only=True,
):
    output = (
        data.groupby([index, columns])
        .sum(numeric_only=numeric_only)
        .reset_index()
        .rename({values_orig: values_new}, axis=1)
    ).pivot(index=index, columns=columns, values=values_new)
    return output
