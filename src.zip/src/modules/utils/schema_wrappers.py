"""
Implements better FC-specific error messages for Pandera Schemas
"""
import pandera.pandas as pa
import pandas as pd


# A list of columns that should be included to provide enough context to the production team
error_context_columns = [
    "year",  # universal
    "month",  # universal
    "day",  # universal
    "date",  # universal
    "port",  # universal
    "batch_id",  # e311
    "agent_stamp",  # e311
    "report_number",  # e63
    "date_of_arrival",  # e63-1
]


class SchemaValueError(Exception):
    """
    A custom error type that we can define to provide better error messages for the production team
    """

    def __init__(self, df_error, message):
        self.df_error = df_error
        self.message = message
        super().__init__(self.message)


class FCSchemaModel(pa.DataFrameModel):
    """
    Wraps the base pa.DataFrameModel class to provide some better error output for the production team
    """
    @classmethod
    def validate(cls, dataframe, *args, **kwargs):
        """
        validate is a wrapper for the validate method in the pa.DataFrameModel class

        Since this is the exit point for the validation of dataframes this is where the
        new error message is being applied
        """
        try:
            return super().validate(dataframe, *args, **kwargs)
        except pa.errors.SchemaError as e:
            # Set Pandas options to fix display issues
            pd.set_option("display.max_rows", None)
            pd.set_option("display.max_columns", None)
            pd.set_option("display.width", None)
            pd.set_option("display.max_colwidth", None)

            # Capturing the indices where the validation failed.
            # Extract failure indices safely
            if "index" in e.failure_cases:
                failure_indices = e.failure_cases["index"].tolist()
            else:
                failure_indices = []

            # Extracting rows from the original dataframe that caused the failures.
            df_error = dataframe.loc[failure_indices].copy()

            error_col = getattr(e.schema, "name", None)

            # Columns to include: error columns + context columns
            columns_to_include = set(error_context_columns)
            if error_col:
                columns_to_include.add(error_col)

            included_cols = [
                col for col in df_error.columns if col in columns_to_include
            ]

            # Anonymize data not in included columns
            for col in df_error.columns:
                if col not in included_cols:
                    df_error[col] = "..."

            error_message = (
                f"\n\nData validation failed for column: {error_col}\n\n"
                f"Error-causing rows:\n\n{df_error}"
            )

            raise SchemaValueError(df_error=df_error, message=error_message) from None
