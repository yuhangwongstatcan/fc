import datetime

class PipelineUID:
    __uid = datetime.datetime.now(datetime.UTC).isoformat()

    @staticmethod
    def get_uid():
        return PipelineUID.__uid
