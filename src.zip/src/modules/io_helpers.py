from pathlib import Path

import pandas as pd
import pandera.pandas as pa


def safe_read_pandas(path: Path, Schema: pa.DataFrameModel) -> pd.DataFrame:
    """
    Given path to CSV, return df validated against a pandera schema.
    """
    safe_df = Schema.validate(pd.read_csv(path))
    return safe_df.fillna(pd.NA)
