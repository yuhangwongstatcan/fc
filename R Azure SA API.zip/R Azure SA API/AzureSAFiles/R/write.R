#' Create a new file
#'
#' Creates a file at `path`, either empty or with the given content. Fails if
#' the file already exists unless `overwrite = TRUE`.
#'
#' @param conn A connection from [sa_connect()].
#' @param path Path of the new file within the container.
#' @param content `NULL` for an empty file, a character vector (written as
#'   UTF-8 lines), or a raw vector (written as-is).
#' @param overwrite Replace an existing file?
#' @return `path`, invisibly.
#' @export
sa_create_file <- function(conn, path, content = NULL, overwrite = FALSE) {
  check_conn(conn)
  path <- norm_path(path)
  check_target(conn, path, overwrite)
  bytes <- if (is.null(content)) {
    raw(0)
  } else if (is.raw(content)) {
    content
  } else if (is.character(content)) {
    text_to_raw(content)
  } else {
    stop("`content` must be NULL, a character vector or a raw vector.", call. = FALSE)
  }
  upload_bytes(conn, bytes, path)
}

#' Save an R object to a file
#'
#' Serialises `x` and writes it to `path`. The format comes from `type`, or
#' from the file extension when `type = "auto"`:
#'
#' * `csv` / `tsv`: a data frame, written without row names.
#' * `rds`: any R object, via [saveRDS()].
#' * `json`: via `jsonlite::write_json()` (needs `jsonlite`).
#' * `text`: a character vector, one element per line.
#' * `raw`: a raw vector, written as-is.
#'
#' @param conn A connection from [sa_connect()].
#' @param x The object to save.
#' @param path Destination path within the container.
#' @param type File format; see Details.
#' @param overwrite Replace an existing file?
#' @param ... Passed to the writer ([utils::write.table()], [saveRDS()] or
#'   `jsonlite::write_json()`).
#' @return `path`, invisibly.
#' @export
sa_save <- function(conn, x, path,
                    type = c("auto", "csv", "tsv", "rds", "json", "text", "raw"),
                    overwrite = FALSE, ...) {
  check_conn(conn)
  type <- match.arg(type)
  path <- norm_path(path)
  if (type == "auto") type <- type_from_ext(path)
  check_target(conn, path, overwrite)

  if (type == "raw") {
    if (!is.raw(x)) stop("type = 'raw' needs a raw vector.", call. = FALSE)
    return(upload_bytes(conn, x, path))
  }
  if (type == "text") return(upload_bytes(conn, text_to_raw(as.character(x)), path))

  tmp <- tempfile()
  on.exit(unlink(tmp), add = TRUE)
  switch(type,
    csv = write_delim(x, tmp, sep = ",", ...),
    tsv = write_delim(x, tmp, sep = "\t", ...),
    rds = saveRDS(x, tmp, ...),
    json = {
      need_pkg("jsonlite")
      jsonlite::write_json(x, tmp, ...)
    }
  )
  upload_local(conn, tmp, path)
}

#' Upload local files or folders
#'
#' @param conn A connection from [sa_connect()].
#' @param src Local file or folder.
#' @param path Destination path within the container. Defaults to the local
#'   file/folder name at the container root.
#' @param overwrite Replace existing remote files?
#' @return `path`, invisibly.
#' @export
sa_upload <- function(conn, src, path = basename(src), overwrite = FALSE) {
  check_conn(conn)
  path <- norm_path(path)
  if (!file.exists(src)) stop("Local path '", src, "' does not exist.", call. = FALSE)

  if (!dir.exists(src)) {
    check_target(conn, path, overwrite)
    return(upload_local(conn, src, path))
  }

  if (!is_root(path)) make_dir(conn, path)
  subdirs <- list.dirs(src, full.names = FALSE, recursive = TRUE)
  for (d in subdirs[nzchar(subdirs)]) make_dir(conn, join_path(path, d))
  files <- list.files(src, recursive = TRUE, all.files = TRUE, no.. = TRUE)
  for (f in files) {
    target <- join_path(path, f)
    check_target(conn, target, overwrite)
    upload_local(conn, file.path(src, f), target)
  }
  invisible(path)
}

text_to_raw <- function(x) {
  if (length(x) == 0L) return(raw(0))
  charToRaw(enc2utf8(paste0(paste(x, collapse = "\n"), "\n")))
}

# Write a data frame with "\n" line endings and UTF-8 on every platform.
write_delim <- function(x, file, sep, ...) {
  con <- file(file, open = "wb")
  on.exit(close(con))
  args <- utils::modifyList(
    list(x = x, file = con, sep = sep, row.names = FALSE, eol = "\n",
         qmethod = "double", na = "NA"),
    list(...)
  )
  do.call(utils::write.table, args)
}
