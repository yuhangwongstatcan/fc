# Internal helpers shared by the sa_* functions.

check_conn <- function(conn) {
  if (!inherits(conn, "sa_conn")) {
    stop("`conn` must be a connection created with sa_connect().", call. = FALSE)
  }
  conn$container
}

# Normalise a remote path: forward slashes, no leading/trailing slash,
# no duplicate slashes. "" means the container root.
norm_path <- function(path) {
  if (!is.character(path) || length(path) != 1L || is.na(path)) {
    stop("`path` must be a single string.", call. = FALSE)
  }
  p <- gsub("\\\\", "/", path)
  p <- gsub("/{2,}", "/", p)
  p <- sub("^/+", "", p)
  p <- sub("/+$", "", p)
  if (p == ".") p <- ""
  p
}

is_root <- function(path) identical(path, "")

parent_dir <- function(path) {
  d <- dirname(path)
  if (d == ".") "" else d
}

# Join path pieces, ignoring empty ones.
join_path <- function(...) {
  parts <- c(...)
  parts <- parts[nzchar(parts)]
  norm_path(paste(parts, collapse = "/"))
}

# Is `path` a file? (exists and is not a directory)
remote_is_file <- function(conn, path) {
  if (is_root(path)) return(FALSE)
  cont <- conn$container
  if (conn$service == "blob") {
    props <- blob_props(cont, path)
    return(!is.null(props) && !is_hns_folder(props))
  }
  isTRUE(AzureStor::storage_file_exists(cont, path)) &&
    !isTRUE(remote_is_dir(conn, path))
}

# Is `path` a directory?
remote_is_dir <- function(conn, path) {
  if (is_root(path)) return(TRUE)
  cont <- conn$container
  if (conn$service == "blob") {
    # AzureStor::blob_dir_exists() treats any zero-length blob as a folder,
    # which misreports empty files, so check it ourselves.
    props <- blob_props(cont, path)
    if (!is.null(props)) return(is_hns_folder(props))
    res <- AzureStor::do_container_op(cont, options = list(
      comp = "list", restype = "container", maxresults = 1,
      delimiter = "/", prefix = paste0(path, "/")
    ))
    return(length(res$Blobs) > 0L)
  }
  isTRUE(tryCatch(AzureStor::storage_dir_exists(cont, path), error = function(e) FALSE))
}

blob_props <- function(cont, path) {
  tryCatch(AzureStor::get_storage_properties(cont, path), error = function(e) NULL)
}

is_hns_folder <- function(props) {
  identical(tolower(as.character(props[["x-ms-meta-hdi_isfolder"]])), "true")
}

# Stop unless it is OK to write to `path`.
check_target <- function(conn, path, overwrite) {
  if (is_root(path)) stop("Target path cannot be the container root.", call. = FALSE)
  if (remote_is_dir(conn, path)) {
    stop("'", path, "' is a folder; cannot write a file there.", call. = FALSE)
  }
  if (!overwrite && remote_is_file(conn, path)) {
    stop("'", path, "' already exists. Use overwrite = TRUE to replace it.", call. = FALSE)
  }
  invisible(TRUE)
}

# Make sure the parent folder of `path` exists. Needed on Azure Files, and on
# ADLS so moves/renames land in a real directory. A no-op for flat blob storage.
ensure_parent <- function(conn, path) {
  parent <- parent_dir(path)
  if (!is_root(parent) && conn$service != "blob") make_dir(conn, parent)
  invisible(NULL)
}

# Upload a local file or a raw vector to `path`.
upload_bytes <- function(conn, bytes, path) {
  ensure_parent(conn, path)
  con <- rawConnection(bytes)
  on.exit(close(con))
  with_quiet_progress(AzureStor::storage_upload(conn$container, con, path))
  invisible(path)
}

upload_local <- function(conn, file, path) {
  ensure_parent(conn, path)
  with_quiet_progress(AzureStor::storage_upload(conn$container, file, path))
  invisible(path)
}

download_bytes <- function(conn, path) {
  with_quiet_progress(AzureStor::storage_download(conn$container, path, NULL))
}

with_quiet_progress <- function(expr) {
  opts <- options(azure_storage_progress_bar = FALSE)
  on.exit(options(opts))
  force(expr)
}

# Guess the file format from the extension.
type_from_ext <- function(path) {
  ext <- tolower(tools::file_ext(path))
  switch(ext,
         csv = "csv",
         tsv = "tsv",
         rds = "rds",
         json = "json",
         txt = , md = , log = , sql = , r = , py = , yaml = , yml = , xml = ,
         html = , htm = , sh = , ini = , cfg = "text",
         "raw")
}

# URL-encode each segment of a path but keep the slashes.
encode_path <- function(path) {
  segs <- strsplit(path, "/", fixed = TRUE)[[1]]
  paste(vapply(segs, utils::URLencode, character(1), reserved = TRUE), collapse = "/")
}
