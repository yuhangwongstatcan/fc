#' Connect to a container in an Azure Storage Account
#'
#' Creates a connection object used by every other `sa_*` function. The
#' connection points at a single container (Blob), filesystem (ADLS Gen2) or
#' file share (Azure Files).
#'
#' Credentials are passed straight through to Azure. This package does not
#' create, store or manage identities or permissions. If no credential argument
#' is given, the following environment variables are used, in order:
#' `AZURE_STORAGE_CONNECTION_STRING`, then `AZURE_STORAGE_ACCOUNT` together with
#' one of `AZURE_STORAGE_KEY` or `AZURE_STORAGE_SAS`.
#'
#' @param container Name of the container / filesystem / file share. Can also
#'   be an existing `AzureStor` container object, in which case all other
#'   arguments are ignored.
#' @param account Storage account name (e.g. `"mystorageacct"`) or a full
#'   endpoint URL (e.g. `"https://mystorageacct.dfs.core.windows.net/"`).
#' @param key Storage account access key.
#' @param sas Shared access signature (with or without the leading `?`).
#' @param token An OAuth token object (e.g. from `AzureAuth::get_azure_token()`)
#'   or a bearer token string.
#' @param connection_string A storage account connection string.
#' @param service Which endpoint to use: `"blob"`, `"dfs"` (ADLS Gen2) or
#'   `"file"` (Azure Files). `"auto"` reads it from the endpoint URL and
#'   otherwise defaults to `"blob"`. Use `"dfs"` for accounts with hierarchical
#'   namespace enabled: you get real folders and atomic moves.
#' @param endpoint_suffix DNS suffix used when `account` is a bare name.
#' @param create_container If `TRUE`, create the container if it does not
#'   exist.
#'
#' @return An object of class `sa_conn`.
#' @examples
#' \dontrun{
#' conn <- sa_connect("raw-data", account = "mystorageacct", key = Sys.getenv("SA_KEY"))
#' conn <- sa_connect("raw-data", account = "mystorageacct", sas = my_sas, service = "dfs")
#' conn <- sa_connect("raw-data", connection_string = Sys.getenv("SA_CONN_STR"))
#' }
#' @export
sa_connect <- function(container,
                       account = NULL,
                       key = NULL,
                       sas = NULL,
                       token = NULL,
                       connection_string = NULL,
                       service = c("auto", "blob", "dfs", "file"),
                       endpoint_suffix = "core.windows.net",
                       create_container = FALSE) {
  if (inherits(container, c("blob_container", "adls_filesystem", "file_share"))) {
    return(new_sa_conn(container))
  }
  if (!is.character(container) || length(container) != 1L || !nzchar(container)) {
    stop("`container` must be a single non-empty string.", call. = FALSE)
  }
  service <- match.arg(service)

  # Fall back to environment variables when nothing was supplied.
  if (is.null(account) && is.null(connection_string)) {
    env_cs <- Sys.getenv("AZURE_STORAGE_CONNECTION_STRING")
    if (nzchar(env_cs)) {
      connection_string <- env_cs
    } else if (nzchar(Sys.getenv("AZURE_STORAGE_ACCOUNT"))) {
      account <- Sys.getenv("AZURE_STORAGE_ACCOUNT")
    } else {
      stop("Supply `account` or `connection_string` (or set AZURE_STORAGE_CONNECTION_STRING).",
           call. = FALSE)
    }
  }

  if (!is.null(connection_string)) {
    cs <- parse_connection_string(connection_string)
    if (service == "auto") service <- "blob"
    url <- connection_string_endpoint(cs, service)
    key <- key %||% cs$AccountKey
    sas <- sas %||% cs$SharedAccessSignature
  } else {
    if (service == "auto") service <- detect_service(account)
    url <- build_endpoint_url(account, service, endpoint_suffix)
  }

  if (is.null(key) && is.null(sas) && is.null(token)) {
    if (nzchar(Sys.getenv("AZURE_STORAGE_KEY"))) key <- Sys.getenv("AZURE_STORAGE_KEY")
    else if (nzchar(Sys.getenv("AZURE_STORAGE_SAS"))) sas <- Sys.getenv("AZURE_STORAGE_SAS")
  }
  if (!is.null(sas)) sas <- sub("^\\?", "", sas)

  endp <- AzureStor::storage_endpoint(url, key = key, token = token, sas = sas,
                                      service = azurestor_service(service))
  cont <- AzureStor::storage_container(endp, container)

  if (create_container) {
    exists <- tryCatch({
      AzureStor::list_storage_files(cont, info = "name", recursive = FALSE)
      TRUE
    }, error = function(e) FALSE)
    if (!exists) cont <- AzureStor::create_storage_container(endp, container)
  }
  new_sa_conn(cont)
}

new_sa_conn <- function(cont) {
  service <- if (inherits(cont, "adls_filesystem")) "dfs"
             else if (inherits(cont, "file_share")) "file"
             else "blob"
  structure(list(container = cont, service = service), class = "sa_conn")
}

#' @export
print.sa_conn <- function(x, ...) {
  ep <- x$container$endpoint
  auth <- if (!is.null(ep$key)) "account key"
          else if (!is.null(ep$token)) "OAuth token"
          else if (!is.null(ep$sas)) "SAS"
          else "anonymous"
  cat("<Azure Storage connection>\n")
  cat("  URL:     ", ep$url, x$container$name, "\n", sep = "")
  cat("  Service: ", x$service, "\n", sep = "")
  cat("  Auth:    ", auth, "\n", sep = "")
  invisible(x)
}

# ---- helpers -----------------------------------------------------------------

azurestor_service <- function(service) {
  switch(service, blob = "blob", dfs = "adls", file = "file")
}

detect_service <- function(account) {
  if (grepl("^https?://", account)) {
    if (grepl("\\.dfs\\.", account)) return("dfs")
    if (grepl("\\.file\\.", account)) return("file")
  }
  "blob"
}

build_endpoint_url <- function(account, service, suffix) {
  if (grepl("^https?://", account)) return(ensure_trailing_slash(account))
  sprintf("https://%s.%s.%s/", account, service, suffix)
}

ensure_trailing_slash <- function(x) if (grepl("/$", x)) x else paste0(x, "/")

parse_connection_string <- function(x) {
  parts <- strsplit(trimws(x), ";", fixed = TRUE)[[1]]
  parts <- parts[nzchar(trimws(parts))]
  # split on the first "=" only: keys and SAS values contain "=" themselves
  keys <- trimws(sub("=.*$", "", parts))
  vals <- sub("^[^=]*=", "", parts)
  out <- as.list(vals)
  names(out) <- keys
  if (identical(tolower(out$UseDevelopmentStorage), "true")) {
    out <- utils::modifyList(list(
      DefaultEndpointsProtocol = "http",
      AccountName = "devstoreaccount1",
      AccountKey = paste0("Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6",
                          "tK/K1SZFPTOtr/KBHBeksoGMGw=="),
      BlobEndpoint = "http://127.0.0.1:10000/devstoreaccount1",
      FileEndpoint = "http://127.0.0.1:10003/devstoreaccount1"
    ), out[setdiff(names(out), "UseDevelopmentStorage")])
  }
  out
}

connection_string_endpoint <- function(cs, service) {
  explicit <- switch(service,
                     blob = cs$BlobEndpoint,
                     dfs = cs$DfsEndpoint %||% dfs_from_blob(cs$BlobEndpoint),
                     file = cs$FileEndpoint)
  if (!is.null(explicit)) return(ensure_trailing_slash(explicit))
  if (is.null(cs$AccountName)) {
    stop("Connection string has no AccountName or ", service, " endpoint.", call. = FALSE)
  }
  proto <- cs$DefaultEndpointsProtocol %||% "https"
  suffix <- cs$EndpointSuffix %||% "core.windows.net"
  sprintf("%s://%s.%s.%s/", proto, cs$AccountName, service, suffix)
}

dfs_from_blob <- function(blob_url) {
  if (is.null(blob_url) || !grepl("\\.blob\\.", blob_url)) return(NULL)
  sub("\\.blob\\.", ".dfs.", blob_url)
}

`%||%` <- function(x, y) if (is.null(x)) y else x
