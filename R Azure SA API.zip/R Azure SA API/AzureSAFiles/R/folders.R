#' Create a folder
#'
#' Creates `path` and any missing parent folders. Does nothing if the folder
#' already exists.
#'
#' On a Blob container without hierarchical namespace, folders are virtual:
#' they only exist while a file is inside them. In that case `sa_mkdir()`
#' writes an empty `.keep` file so the folder is visible right away. Set
#' `keep_file = FALSE` to skip this. Folders on ADLS Gen2 (`service = "dfs"`)
#' and Azure Files are real and need no placeholder.
#'
#' @param conn A connection from [sa_connect()].
#' @param path Folder path within the container.
#' @param keep_file On flat Blob storage, write a `.keep` placeholder file?
#' @return `path`, invisibly.
#' @export
sa_mkdir <- function(conn, path, keep_file = TRUE) {
  check_conn(conn)
  path <- norm_path(path)
  if (is_root(path)) return(invisible(path))
  if (remote_is_file(conn, path)) {
    stop("'", path, "' exists and is a file.", call. = FALSE)
  }
  make_dir(conn, path)
  if (conn$service == "blob" && keep_file && !remote_is_dir(conn, path)) {
    upload_bytes(conn, raw(0), join_path(path, ".keep"))
  }
  invisible(path)
}

make_dir <- function(conn, path) {
  if (is_root(path) || remote_is_dir(conn, path)) return(invisible(path))
  cont <- conn$container
  if (conn$service == "file") {
    # Azure Files cannot create nested folders in one call.
    make_dir(conn, parent_dir(path))
    AzureStor::create_storage_dir(cont, path)
  } else {
    # ADLS creates parents itself; on Blob storage this makes a real folder
    # when hierarchical namespace is on and is otherwise a no-op.
    with_quiet_progress(AzureStor::create_storage_dir(cont, path))
  }
  invisible(path)
}

#' Delete a file or folder
#'
#' @param conn A connection from [sa_connect()].
#' @param path File or folder to delete.
#' @param recursive Must be `TRUE` to delete a folder that is not empty.
#' @return `TRUE`, invisibly.
#' @export
sa_delete <- function(conn, path, recursive = FALSE) {
  cont <- check_conn(conn)
  path <- norm_path(path)
  if (is_root(path)) stop("Refusing to delete the container root.", call. = FALSE)

  if (remote_is_file(conn, path)) {
    AzureStor::delete_storage_file(cont, path, confirm = FALSE)
    return(invisible(TRUE))
  }
  if (!remote_is_dir(conn, path)) stop("'", path, "' does not exist.", call. = FALSE)

  contents <- sa_list(conn, path, recursive = TRUE)
  if (nrow(contents) > 0L && !recursive) {
    stop("Folder '", path, "' is not empty. Use recursive = TRUE.", call. = FALSE)
  }

  switch(conn$service,
    dfs = AzureStor::delete_adls_dir(cont, path, recursive = TRUE, confirm = FALSE),
    blob = {
      files <- contents$name[!contents$is_dir]
      for (f in files) AzureStor::delete_blob(cont, f, confirm = FALSE)
      # HNS folders exist as blobs themselves; delete deepest first.
      dirs <- c(contents$name[contents$is_dir], path)
      dirs <- dirs[order(-nchar(dirs))]
      for (d in dirs) {
        if (!is.null(blob_props(cont, d))) AzureStor::delete_blob(cont, d, confirm = FALSE)
      }
    },
    file = {
      for (f in contents$name[!contents$is_dir]) {
        AzureStor::delete_azure_file(cont, f, confirm = FALSE)
      }
      dirs <- c(contents$name[contents$is_dir], path)
      for (d in dirs[order(-nchar(dirs))]) AzureStor::delete_azure_dir(cont, d, confirm = FALSE)
    }
  )
  invisible(TRUE)
}
