#' Copy a file or folder
#'
#' Copies `from` to `to`. Folders are copied with everything in them. If `to`
#' is an existing folder, the item is copied into it (like `cp`).
#'
#' Within one Blob container the copy is done server-side. In other cases
#' (ADLS, Azure Files, or across containers/accounts) the data passes through
#' a temporary local file.
#'
#' @param conn A connection from [sa_connect()].
#' @param from Source file or folder.
#' @param to Destination path.
#' @param overwrite Replace existing files at the destination?
#' @param dest_conn Connection for the destination. Defaults to `conn`; pass
#'   another connection to copy between containers or storage accounts.
#' @return The final destination path, invisibly.
#' @export
sa_copy <- function(conn, from, to, overwrite = FALSE, dest_conn = conn) {
  check_conn(conn)
  check_conn(dest_conn)
  from <- norm_path(from)
  to <- resolve_target(dest_conn, from, norm_path(to))
  copy_impl(conn, from, to, overwrite, dest_conn)
}

copy_impl <- function(conn, from, to, overwrite, dest_conn) {
  same <- same_container(conn, dest_conn)
  if (same && identical(from, to)) stop("Source and destination are the same.", call. = FALSE)

  if (remote_is_file(conn, from)) {
    copy_one_file(conn, from, dest_conn, to, overwrite)
    return(invisible(to))
  }
  if (!remote_is_dir(conn, from)) stop("'", from, "' does not exist.", call. = FALSE)
  if (same && is_inside(to, from)) {
    stop("Cannot copy folder '", from, "' into itself.", call. = FALSE)
  }

  contents <- sa_list(conn, from, recursive = TRUE)
  prefix <- if (is_root(from)) "" else paste0(from, "/")
  rel <- substring(contents$name, nchar(prefix) + 1L)

  # Check every destination file first so a failed copy leaves nothing behind.
  files <- !contents$is_dir
  if (!overwrite) {
    for (r in rel[files]) {
      if (remote_is_file(dest_conn, join_path(to, r))) {
        stop("'", join_path(to, r), "' already exists. Use overwrite = TRUE.", call. = FALSE)
      }
    }
  }
  make_dir(dest_conn, to)
  for (r in rel[!files]) make_dir(dest_conn, join_path(to, r))
  for (i in which(files)) {
    copy_one_file(conn, contents$name[i], dest_conn, join_path(to, rel[i]), overwrite = TRUE)
  }
  invisible(to)
}

#' Move or rename a file or folder
#'
#' Moves `from` to `to`. If `to` is an existing folder, the item is moved into
#' it (like `mv`).
#'
#' On ADLS Gen2 (`service = "dfs"`) a move within one filesystem is a single
#' atomic rename, even for large folders. Elsewhere it is a copy followed by a
#' delete of the source.
#'
#' @inheritParams sa_copy
#' @return The final destination path, invisibly.
#' @export
sa_move <- function(conn, from, to, overwrite = FALSE, dest_conn = conn) {
  cont <- check_conn(conn)
  check_conn(dest_conn)
  from <- norm_path(from)
  if (is_root(from)) stop("Cannot move the container root.", call. = FALSE)
  to <- resolve_target(dest_conn, from, norm_path(to))
  same <- same_container(conn, dest_conn)
  if (same && identical(from, to)) return(invisible(to))

  src_is_file <- remote_is_file(conn, from)
  if (!src_is_file && !remote_is_dir(conn, from)) {
    stop("'", from, "' does not exist.", call. = FALSE)
  }
  if (same && !src_is_file && is_inside(to, from)) {
    stop("Cannot move folder '", from, "' into itself.", call. = FALSE)
  }

  if (remote_is_dir(dest_conn, to)) stop("Folder '", to, "' already exists.", call. = FALSE)
  if (!overwrite && remote_is_file(dest_conn, to)) {
    stop("'", to, "' already exists. Use overwrite = TRUE.", call. = FALSE)
  }

  if (same && conn$service == "dfs") {
    ensure_parent(conn, to)
    adls_rename(cont, from, to, overwrite)
    return(invisible(to))
  }

  copy_impl(conn, from, to, overwrite, dest_conn)
  sa_delete(conn, from, recursive = TRUE)
  invisible(to)
}

# ---- helpers -----------------------------------------------------------------

# cp/mv semantics: copying into an existing folder keeps the source name.
resolve_target <- function(dest_conn, from, to) {
  if (is_root(to) || remote_is_dir(dest_conn, to)) join_path(to, basename(from)) else to
}

is_inside <- function(path, folder) {
  is_root(folder) || identical(path, folder) || startsWith(path, paste0(folder, "/"))
}

same_container <- function(a, b) {
  identical(a$container$endpoint$url, b$container$endpoint$url) &&
    identical(a$container$name, b$container$name)
}

copy_one_file <- function(src_conn, from, dest_conn, to, overwrite) {
  check_target(dest_conn, to, overwrite)
  if (same_container(src_conn, dest_conn) && src_conn$service == "blob") {
    ok <- tryCatch({
      blob_server_copy(src_conn$container, from, to)
      TRUE
    }, error = function(e) FALSE)
    if (ok) return(invisible(to))
  }
  tmp <- tempfile()
  on.exit(unlink(tmp), add = TRUE)
  with_quiet_progress(AzureStor::storage_download(src_conn$container, from, tmp))
  upload_local(dest_conn, tmp, to)
  invisible(to)
}

# Server-side Copy Blob within one container, waiting for it to finish.
blob_server_copy <- function(cont, from, to, timeout = 600) {
  src <- paste0(cont$endpoint$url, cont$name, "/", encode_path(from))
  if (!is.null(cont$endpoint$sas)) src <- paste0(src, "?", cont$endpoint$sas)
  AzureStor::do_container_op(cont, to, headers = list(`x-ms-copy-source` = src),
                             http_verb = "PUT")
  start <- Sys.time()
  repeat {
    status <- AzureStor::get_storage_properties(cont, to)[["x-ms-copy-status"]]
    if (is.null(status) || identical(status, "success")) return(invisible(TRUE))
    if (status %in% c("failed", "aborted")) stop("Server-side copy ", status, call. = FALSE)
    if (difftime(Sys.time(), start, units = "secs") > timeout) {
      stop("Server-side copy timed out", call. = FALSE)
    }
    Sys.sleep(1)
  }
}

# Atomic rename on ADLS Gen2 (works for files and folders).
adls_rename <- function(cont, from, to, overwrite) {
  source <- paste0("/", cont$name, "/", encode_path(from))
  if (!is.null(cont$endpoint$sas)) source <- paste0(source, "?", cont$endpoint$sas)
  headers <- list(`x-ms-rename-source` = source)
  if (!overwrite) headers[["If-None-Match"]] <- "*"
  AzureStor::do_container_op(cont, to, options = list(mode = "legacy"),
                             headers = headers, http_verb = "PUT")
  invisible(TRUE)
}
