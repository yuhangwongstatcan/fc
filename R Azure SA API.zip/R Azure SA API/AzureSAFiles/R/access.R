#' List files and folders
#'
#' @param conn A connection from [sa_connect()].
#' @param path Folder to list. `""` (the default) is the container root.
#' @param recursive If `TRUE`, include the contents of sub-folders.
#'
#' @return A data frame with columns `name` (full path), `size` (bytes, `NA`
#'   for folders) and `is_dir`.
#' @export
sa_list <- function(conn, path = "", recursive = FALSE) {
  cont <- check_conn(conn)
  path <- norm_path(path)
  if (!is_root(path) && !remote_is_dir(conn, path)) {
    stop("Folder '", path, "' does not exist.", call. = FALSE)
  }
  dir <- if (is_root(path)) "/" else path

  res <- switch(conn$service,
    blob = AzureStor::list_blobs(cont, dir = dir, info = "all", recursive = recursive),
    dfs  = AzureStor::list_adls_files(cont, dir = dir, info = "all", recursive = recursive),
    file = list_share_files(cont, dir, recursive)
  )
  normalise_listing(res, conn$service)
}

list_share_files <- function(cont, dir, recursive) {
  res <- AzureStor::list_azure_files(cont, dir = dir, info = "all")
  if (!recursive || nrow(res) == 0L) return(res)
  subdirs <- res$name[res$isdir]
  for (d in subdirs) res <- rbind(res, list_share_files(cont, d, TRUE))
  res
}

normalise_listing <- function(res, service) {
  empty <- data.frame(name = character(), size = numeric(), is_dir = logical())
  if (is.null(res) || NROW(res) == 0L) return(empty)
  if (is.character(res)) {
    return(data.frame(name = res, size = NA_real_, is_dir = FALSE))
  }
  col <- function(...) {
    for (nm in c(...)) if (!is.null(res[[nm]])) return(res[[nm]])
    NULL
  }
  name <- col("name")
  size <- col("size", "contentLength", "Content-Length")
  is_dir <- col("isdir", "isDirectory")
  if (is.null(is_dir)) {
    meta <- col("hdi_isfolder", "x-ms-meta-hdi_isfolder")
    is_dir <- if (is.null(meta)) grepl("/$", name) else tolower(as.character(meta)) == "true"
  }
  is_dir <- as.logical(is_dir)
  is_dir[is.na(is_dir)] <- FALSE
  size <- if (is.null(size)) rep(NA_real_, length(name)) else as.numeric(size)
  size[is_dir] <- NA_real_

  out <- data.frame(name = sub("/$", "", sub("^/", "", name)),
                    size = size, is_dir = is_dir, stringsAsFactors = FALSE)
  out <- out[order(!out$is_dir, out$name), , drop = FALSE]
  rownames(out) <- NULL
  out
}

#' Check whether a file or folder exists
#'
#' @param conn A connection from [sa_connect()].
#' @param path Path within the container.
#' @param type `"any"`, `"file"` or `"dir"`.
#' @return `TRUE` or `FALSE`.
#' @export
sa_exists <- function(conn, path, type = c("any", "file", "dir")) {
  check_conn(conn)
  type <- match.arg(type)
  path <- norm_path(path)
  switch(type,
    file = remote_is_file(conn, path),
    dir  = remote_is_dir(conn, path),
    any  = remote_is_file(conn, path) || remote_is_dir(conn, path)
  )
}

#' Read a file into R
#'
#' Downloads a file into memory and parses it according to `type`. For large
#' files that you only need on disk, use [sa_download()] instead.
#'
#' @param conn A connection from [sa_connect()].
#' @param path Path of the file within the container.
#' @param type How to parse the file. `"auto"` picks from the extension:
#'   `.csv` -> data frame, `.tsv` -> data frame, `.rds` -> R object, `.json` ->
#'   parsed JSON (needs the `jsonlite` package), common text extensions ->
#'   character string, anything else -> raw vector. `"lines"` returns a
#'   character vector with one element per line.
#' @param ... Passed to the parser ([utils::read.csv()], [utils::read.delim()]
#'   or `jsonlite::fromJSON()`).
#' @return The parsed content.
#' @export
sa_read <- function(conn, path,
                    type = c("auto", "csv", "tsv", "rds", "json", "text", "lines", "raw"),
                    ...) {
  check_conn(conn)
  type <- match.arg(type)
  path <- norm_path(path)
  if (!remote_is_file(conn, path)) stop("File '", path, "' does not exist.", call. = FALSE)
  if (type == "auto") type <- type_from_ext(path)

  bytes <- download_bytes(conn, path)
  as_text <- function() {
    txt <- rawToChar(strip_bom(bytes))
    Encoding(txt) <- "UTF-8"
    txt
  }

  switch(type,
    raw   = bytes,
    text  = as_text(),
    lines = strsplit(sub("\r?\n$", "", as_text()), "\r?\n")[[1]],
    csv   = utils::read.csv(text = as_text(), stringsAsFactors = FALSE, ...),
    tsv   = utils::read.delim(text = as_text(), stringsAsFactors = FALSE, ...),
    json  = {
      need_pkg("jsonlite")
      jsonlite::fromJSON(as_text(), ...)
    },
    rds   = {
      tmp <- tempfile(fileext = ".rds")
      on.exit(unlink(tmp), add = TRUE)
      writeBin(bytes, tmp)
      readRDS(tmp)
    }
  )
}

#' Download a file or folder to local disk
#'
#' @param conn A connection from [sa_connect()].
#' @param path Remote file or folder.
#' @param dest Local destination path. Defaults to the remote file/folder name
#'   in the working directory.
#' @param overwrite Replace existing local files?
#' @return The local path, invisibly.
#' @export
sa_download <- function(conn, path, dest = basename(path), overwrite = FALSE) {
  cont <- check_conn(conn)
  path <- norm_path(path)

  if (remote_is_file(conn, path)) {
    if (file.exists(dest) && !overwrite) {
      stop("Local file '", dest, "' exists. Use overwrite = TRUE.", call. = FALSE)
    }
    dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
    with_quiet_progress(AzureStor::storage_download(cont, path, dest, overwrite = TRUE))
    return(invisible(dest))
  }

  if (!remote_is_dir(conn, path)) stop("'", path, "' does not exist.", call. = FALSE)
  files <- sa_list(conn, path, recursive = TRUE)
  dir.create(dest, recursive = TRUE, showWarnings = FALSE)
  prefix <- if (is_root(path)) "" else paste0(path, "/")
  for (i in seq_len(nrow(files))) {
    rel <- substring(files$name[i], nchar(prefix) + 1L)
    local <- file.path(dest, rel)
    if (files$is_dir[i]) {
      dir.create(local, recursive = TRUE, showWarnings = FALSE)
    } else {
      sa_download(conn, files$name[i], local, overwrite = overwrite)
    }
  }
  invisible(dest)
}

strip_bom <- function(bytes) {
  bom <- as.raw(c(0xEF, 0xBB, 0xBF))
  if (length(bytes) >= 3L && identical(bytes[1:3], bom)) bytes[-(1:3)] else bytes
}

need_pkg <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop("Package '", pkg, "' is required for this file type. Install it with install.packages('",
         pkg, "').", call. = FALSE)
  }
}
