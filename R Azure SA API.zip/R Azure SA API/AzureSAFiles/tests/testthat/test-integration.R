# End-to-end tests against a real storage account or the Azurite emulator.
#
# They run only when AZURESAFILES_TEST_CONNSTR is set, e.g.
#   AZURESAFILES_TEST_CONNSTR="UseDevelopmentStorage=true"           (Azurite)
#   AZURESAFILES_TEST_CONNSTR="DefaultEndpointsProtocol=https;AccountName=...;AccountKey=..."
# Optionally set AZURESAFILES_TEST_SERVICE to "blob" (default), "dfs" or "file".
# A temporary container is created and deleted for each run.

connstr <- Sys.getenv("AZURESAFILES_TEST_CONNSTR")
service <- Sys.getenv("AZURESAFILES_TEST_SERVICE", "blob")

skip_if_no_storage <- function() {
  skip_if(!nzchar(connstr), "AZURESAFILES_TEST_CONNSTR not set")
}

local_test_conn <- function(env = parent.frame()) {
  name <- paste0("sa-test-", paste(sample(c(letters, 0:9), 10, TRUE), collapse = ""))
  conn <- sa_connect(name, connection_string = connstr, service = service,
                     create_container = TRUE)
  withr::defer(
    try(AzureStor::delete_storage_container(conn$container$endpoint, name, confirm = FALSE),
        silent = TRUE),
    envir = env
  )
  conn
}

test_that("create, save, read, list and exists", {
  skip_if_no_storage()
  conn <- local_test_conn()

  sa_create_file(conn, "empty.txt")
  expect_true(sa_exists(conn, "empty.txt", "file"))
  expect_false(sa_exists(conn, "empty.txt", "dir"))
  expect_equal(sa_read(conn, "empty.txt", "raw"), raw(0))
  expect_error(sa_create_file(conn, "empty.txt"), "already exists")

  sa_create_file(conn, "notes/hello.txt", c("line 1", "café"))
  expect_equal(sa_read(conn, "notes/hello.txt", "lines"), c("line 1", "café"))
  expect_true(sa_exists(conn, "notes", "dir"))

  df <- data.frame(id = 1:3, name = c("a", "b,c", NA), stringsAsFactors = FALSE)
  sa_save(conn, df, "data/df.csv")
  expect_equal(sa_read(conn, "data/df.csv"), df)

  sa_save(conn, list(x = 1, y = letters), "data/obj.rds")
  expect_equal(sa_read(conn, "data/obj.rds"), list(x = 1, y = letters))

  expect_error(sa_save(conn, df, "data/df.csv"), "already exists")
  sa_save(conn, df[1, ], "data/df.csv", overwrite = TRUE)
  expect_equal(nrow(sa_read(conn, "data/df.csv")), 1L)

  top <- sa_list(conn)
  expect_setequal(top$name, c("data", "notes", "empty.txt"))
  expect_equal(top$is_dir[top$name == "data"], TRUE)

  all <- sa_list(conn, recursive = TRUE)
  expect_true(all(c("data/df.csv", "data/obj.rds", "notes/hello.txt") %in% all$name))
  expect_error(sa_list(conn, "nope"), "does not exist")
})

test_that("folders, copy, move and delete", {
  skip_if_no_storage()
  conn <- local_test_conn()

  sa_mkdir(conn, "a/b")
  expect_true(sa_exists(conn, "a/b", "dir"))
  sa_create_file(conn, "a/b/one.txt", "1")
  sa_create_file(conn, "a/two.txt", "2")

  # file copy, and copy into an existing folder keeps the name
  sa_copy(conn, "a/two.txt", "copy.txt")
  expect_equal(sa_read(conn, "copy.txt"), "2\n")
  sa_mkdir(conn, "dest")
  expect_equal(sa_copy(conn, "copy.txt", "dest"), "dest/copy.txt")
  expect_true(sa_exists(conn, "dest/copy.txt", "file"))
  expect_error(sa_copy(conn, "copy.txt", "dest/copy.txt"), "already exists")

  # folder copy
  sa_copy(conn, "a", "a2")
  expect_equal(sa_read(conn, "a2/b/one.txt"), "1\n")
  expect_equal(sa_read(conn, "a2/two.txt"), "2\n")
  expect_true(sa_exists(conn, "a/b/one.txt"))
  expect_error(sa_copy(conn, "a", "a/b"), "into itself")

  # file move / rename
  sa_move(conn, "copy.txt", "renamed.txt")
  expect_false(sa_exists(conn, "copy.txt"))
  expect_equal(sa_read(conn, "renamed.txt"), "2\n")

  # folder move
  sa_move(conn, "a2", "moved/a2")
  expect_false(sa_exists(conn, "a2"))
  expect_equal(sa_read(conn, "moved/a2/b/one.txt"), "1\n")

  # delete
  expect_error(sa_delete(conn, "moved"), "not empty")
  sa_delete(conn, "moved", recursive = TRUE)
  expect_false(sa_exists(conn, "moved"))
  sa_delete(conn, "renamed.txt")
  expect_false(sa_exists(conn, "renamed.txt"))
  expect_error(sa_delete(conn, ""), "root")
})

test_that("upload and download round trip", {
  skip_if_no_storage()
  conn <- local_test_conn()

  local <- tempfile("up")
  dir.create(file.path(local, "sub"), recursive = TRUE)
  writeLines("top", file.path(local, "top.txt"))
  writeBin(as.raw(1:10), file.path(local, "sub", "bin.dat"))

  sa_upload(conn, local, "uploaded")
  expect_equal(sa_read(conn, "uploaded/sub/bin.dat"), as.raw(1:10))

  out <- tempfile("down")
  sa_download(conn, "uploaded", out)
  expect_equal(readBin(file.path(out, "sub", "bin.dat"), "raw", 100), as.raw(1:10))
  expect_true(file.exists(file.path(out, "top.txt")))
})
