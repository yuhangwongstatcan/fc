test_that("norm_path cleans up remote paths", {
  expect_equal(norm_path("/a/b/"), "a/b")
  expect_equal(norm_path("a//b\\c"), "a/b/c")
  expect_equal(norm_path("/"), "")
  expect_equal(norm_path("."), "")
  expect_error(norm_path(c("a", "b")))
  expect_error(norm_path(NA_character_))
})

test_that("join_path and parent_dir", {
  expect_equal(join_path("", "x.csv"), "x.csv")
  expect_equal(join_path("a/", "/b", "c.txt"), "a/b/c.txt")
  expect_equal(parent_dir("a/b/c.txt"), "a/b")
  expect_equal(parent_dir("c.txt"), "")
})

test_that("is_inside detects nested paths", {
  expect_true(is_inside("a/b", "a"))
  expect_true(is_inside("a", "a"))
  expect_false(is_inside("ab", "a"))
  expect_true(is_inside("anything", ""))
})

test_that("type_from_ext maps extensions", {
  expect_equal(type_from_ext("x/data.CSV"), "csv")
  expect_equal(type_from_ext("m.rds"), "rds")
  expect_equal(type_from_ext("cfg.json"), "json")
  expect_equal(type_from_ext("notes.txt"), "text")
  expect_equal(type_from_ext("img.png"), "raw")
  expect_equal(type_from_ext("noext"), "raw")
})

test_that("text_to_raw writes UTF-8 with LF endings", {
  expect_equal(text_to_raw(c("a", "b")), charToRaw("a\nb\n"))
  expect_equal(text_to_raw(character()), raw(0))
  expect_equal(rawToChar(text_to_raw("\u00e9")), enc2native("\u00e9\n"))
})

test_that("strip_bom removes a UTF-8 BOM", {
  expect_equal(strip_bom(as.raw(c(0xEF, 0xBB, 0xBF, 0x41))), as.raw(0x41))
  expect_equal(strip_bom(as.raw(0x41)), as.raw(0x41))
})

test_that("encode_path keeps slashes and encodes segments", {
  expect_equal(encode_path("a b/c#d.txt"), "a%20b/c%23d.txt")
})

test_that("connection strings are parsed", {
  cs <- parse_connection_string(paste0(
    "DefaultEndpointsProtocol=https;AccountName=acct;AccountKey=abc==;",
    "EndpointSuffix=core.windows.net"))
  expect_equal(cs$AccountName, "acct")
  expect_equal(cs$AccountKey, "abc==")
  expect_equal(connection_string_endpoint(cs, "blob"), "https://acct.blob.core.windows.net/")
  expect_equal(connection_string_endpoint(cs, "dfs"), "https://acct.dfs.core.windows.net/")

  dev <- parse_connection_string("UseDevelopmentStorage=true")
  expect_equal(connection_string_endpoint(dev, "blob"), "http://127.0.0.1:10000/devstoreaccount1/")

  sas <- parse_connection_string("BlobEndpoint=https://x.blob.core.windows.net;SharedAccessSignature=sv=1&sig=a%3D")
  expect_equal(sas$SharedAccessSignature, "sv=1&sig=a%3D")
  expect_equal(connection_string_endpoint(sas, "dfs"), "https://x.dfs.core.windows.net/")
})

test_that("sa_connect builds the right endpoint without calling Azure", {
  withr_env <- Sys.getenv(c("AZURE_STORAGE_CONNECTION_STRING", "AZURE_STORAGE_ACCOUNT",
                            "AZURE_STORAGE_KEY", "AZURE_STORAGE_SAS"))
  on.exit(do.call(Sys.setenv, as.list(withr_env)))
  Sys.unsetenv(names(withr_env))

  conn <- sa_connect("data", account = "acct", key = "a2V5", service = "dfs")
  expect_s3_class(conn, "sa_conn")
  expect_equal(conn$service, "dfs")
  expect_s3_class(conn$container, "adls_filesystem")
  expect_equal(conn$container$endpoint$url, "https://acct.dfs.core.windows.net/")

  conn <- sa_connect("data", account = "https://acct.file.core.windows.net", sas = "?sv=1")
  expect_equal(conn$service, "file")
  expect_equal(conn$container$endpoint$sas, "sv=1")

  conn <- sa_connect("data", connection_string = "UseDevelopmentStorage=true")
  expect_equal(conn$service, "blob")
  expect_false(is.null(conn$container$endpoint$key))
  expect_output(print(conn), "account key")

  expect_error(sa_connect("data"), "Supply `account`")
  expect_error(sa_list(list(), ""), "sa_connect")
})

test_that("normalise_listing gives a consistent shape", {
  blob <- data.frame(name = c("b.txt", "dir/"), size = c(10, NA), isdir = c(FALSE, TRUE))
  out <- normalise_listing(blob, "blob")
  expect_equal(names(out), c("name", "size", "is_dir"))
  expect_equal(out$name, c("dir", "b.txt"))
  expect_equal(out$is_dir, c(TRUE, FALSE))

  adls <- data.frame(name = c("x", "y.csv"), contentLength = c(0, 5), isDirectory = c(TRUE, FALSE))
  out <- normalise_listing(adls, "dfs")
  expect_equal(out$size, c(NA, 5))

  expect_equal(nrow(normalise_listing(NULL, "blob")), 0L)
})
