library(testthat)
library(AzureSAFiles)

test_check("AzureSAFiles")
