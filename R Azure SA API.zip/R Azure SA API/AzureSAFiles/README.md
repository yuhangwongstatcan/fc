# AzureSAFiles

Simple file operations on an Azure Storage Account from R: read, create, save,
copy, move and delete files, and create folders. Works with Blob containers,
ADLS Gen2 filesystems and Azure File shares. Built on Microsoft's
[`AzureStor`](https://cran.r-project.org/package=AzureStor) package.

Authentication is passed in by the caller (connection string, account key, SAS
or OAuth token). The package does not create or manage identities or
permissions.

## Install

```r
install.packages(c("AzureStor", "jsonlite"))   # jsonlite only needed for .json files
install.packages("path/to/AzureSAFiles", repos = NULL, type = "source")
```

## Connect

```r
library(AzureSAFiles)

# Account key
conn <- sa_connect("my-container", account = "mystorageacct", key = Sys.getenv("SA_KEY"))

# SAS token
conn <- sa_connect("my-container", account = "mystorageacct", sas = Sys.getenv("SA_SAS"))

# Connection string
conn <- sa_connect("my-container", connection_string = Sys.getenv("SA_CONN_STR"))

# ADLS Gen2 (hierarchical namespace): use the dfs endpoint for real folders
# and atomic moves
conn <- sa_connect("my-filesystem", account = "mystorageacct", key = key, service = "dfs")

# With nothing supplied, AZURE_STORAGE_CONNECTION_STRING, or AZURE_STORAGE_ACCOUNT
# plus AZURE_STORAGE_KEY / AZURE_STORAGE_SAS, are read from the environment.
conn <- sa_connect("my-container")
```

## Functions

| Task              | Function                                              |
|-------------------|-------------------------------------------------------|
| List              | `sa_list(conn, "folder", recursive = FALSE)`          |
| Check existence   | `sa_exists(conn, path, type = "any" / "file" / "dir")`|
| Access (read)     | `sa_read(conn, "data/x.csv")`                         |
| Download to disk  | `sa_download(conn, "folder_or_file", "local/path")`   |
| Create file       | `sa_create_file(conn, "notes/readme.txt", "hello")`   |
| Save R object     | `sa_save(conn, df, "out/result.csv")`                 |
| Upload from disk  | `sa_upload(conn, "local/file_or_folder", "remote/path")` |
| Copy              | `sa_copy(conn, "a.csv", "backup/a.csv")`              |
| Move / rename     | `sa_move(conn, "in/a.csv", "processed/a.csv")`        |
| Create folder     | `sa_mkdir(conn, "2026/11")`                           |
| Delete            | `sa_delete(conn, "tmp", recursive = TRUE)`            |

## Examples

```r
# Read: the format comes from the extension (csv, tsv, rds, json, text), or set type=
df   <- sa_read(conn, "input/survey.csv")
obj  <- sa_read(conn, "models/fit.rds")
txt  <- sa_read(conn, "config/settings.txt")
rows <- sa_read(conn, "logs/run.log", type = "lines")
img  <- sa_read(conn, "images/logo.png")          # raw vector

# Save: fails if the file exists unless overwrite = TRUE
sa_save(conn, df, "output/survey_clean.csv")
sa_save(conn, fit, "models/fit.rds", overwrite = TRUE)
sa_create_file(conn, "output/_SUCCESS")         # empty marker file

# Folders, copy, move
sa_mkdir(conn, "archive/2026")
sa_copy(conn, "output", "archive/2026")          # copies folder into archive/2026/output
sa_move(conn, "input/survey.csv", "processed/survey.csv")

# Copy between containers or accounts
other <- sa_connect("backup", account = "otheracct", key = other_key)
sa_copy(conn, "output", "output-2026-11-24", dest_conn = other)
```

## Behaviour notes

* **Overwrite is off by default.** Every write, copy and move stops if the
  target file exists unless `overwrite = TRUE`.
* **Copy/move into a folder**: if `to` is an existing folder, the item is placed
  inside it, as with `cp` and `mv`.
* **Moves**: on ADLS Gen2 (`service = "dfs"`) a move within one filesystem is a
  single atomic rename, even for large folders. Elsewhere a move is a copy
  followed by a delete.
* **Copies**: within one Blob container the copy runs server-side. Otherwise the
  data passes through a temporary local file.
* **Folders on flat Blob storage** are virtual. `sa_mkdir()` writes an empty
  `.keep` file so the folder shows up straight away (`keep_file = FALSE` skips
  it). If your account has hierarchical namespace enabled, use
  `service = "dfs"` instead.
* `sa_read()` loads the whole file into memory. For large files use
  `sa_download()`.

## Tests

```r
testthat::test_local("AzureSAFiles")
```

Unit tests run offline. The integration tests run only when
`AZURESAFILES_TEST_CONNSTR` is set. They create and then delete a temporary
container:

```sh
# Azurite emulator (npm install -g azurite; azurite --skipApiVersionCheck)
AZURESAFILES_TEST_CONNSTR="UseDevelopmentStorage=true"

# or a real test account; also set AZURESAFILES_TEST_SERVICE=dfs to test ADLS Gen2
AZURESAFILES_TEST_CONNSTR="DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net"
```
