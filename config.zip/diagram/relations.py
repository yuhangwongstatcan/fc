# Reads the .diagram.yaml file
# Translates to .dot file with template

import yaml
import os
from string import Template
from typing import Iterator, List, NamedTuple, Tuple, Optional, Dict
import re
from dataflow import DataflowDiagram
import csv


class TableColumnDef(NamedTuple):
    name: str
    type: str
    primary_key: bool


class TableNode(NamedTuple):
    stage: str
    name: str
    datasource: Optional[str] = None

    def __hash__(self):
        if self.datasource:
            return hash((self.stage, self.datasource, self.name))
        return hash((self.stage, self.name))

    def __eq__(self, node: "TableNode") -> bool:
        return self.stage == node.stage and self.name == node.name and self.datasource == node.datasource

    def __str__(self) -> str:
        if self.datasource:
            return f"{self.stage}/{self.datasource}/{self.name}"
        return f"{self.stage}/{self.name}"

    def __repr__(self) -> str:
        return str(self)

    @staticmethod
    def parse(text: str) -> "TableNode":
        match = re.match("(\w+)/(\w+)(/(\w+))?", text)
        if not match:
            raise Exception(f"Cannot parse {text}")
        if match.group(4):
            return TableNode(stage=match.group(1),
                             datasource=match.group(2),
                             name=match.group(4))
        else:
            return TableNode(stage=match.group(1), name=match.group(2))

    @staticmethod
    def cluster(nodes: Iterator["TableNode"]) -> Dict:
        """
        Cluster the nodes by the stage and then the datasource
        """
        output = {}
        for node in nodes:
            stage = node.stage
            if stage not in output:
                output[stage] = {}
            root = output[stage]
            datasource = node.datasource
            if datasource:
                if datasource not in root:
                    root[datasource] = {}
                root = root[datasource]
            name = node.name
            if name not in root:
                root[name] = node
        return output


class TableColumn(NamedTuple):
    stage: str
    datasource: Optional[str]
    node_name: str
    column_name: str

    def node(self) -> TableNode:
        return TableNode(self.stage, self.node_name, self.datasource)


class TableRelation(NamedTuple):
    src: TableColumn
    target: TableColumn
    edge_label: Optional[str] = None


class DataflowEdge(NamedTuple):
    src: TableNode
    target: TableNode


MINIO_ROOT = os.path.join("tests", "mock_minio")


class TableIndex(NamedTuple):
    """
    Read the __index.csv files
    """
    stage: str
    name: str
    columns: List[TableColumnDef]  # name, type

    @staticmethod
    def load(node: TableNode) -> Optional["TableIndex"]:
        """
        Load stage/table
        Load reference/table
        """
        filename = "__".join([node.name, node.stage, "index"]) + ".csv"
        path = os.path.join(MINIO_ROOT, node.stage, node.name, filename)
        try:
            with open(path, "r", encoding="utf-8") as csvfile:
                csvreader = csv.reader(csvfile)
                headers = next(csvreader, None)

                NAME = 1
                TYPE = 2
                PRIMARY_KEY = 3
                return TableIndex(
                    stage=node.stage,
                    name=node.name,
                    columns=[
                        TableColumnDef(name=row[NAME],
                                       type=row[TYPE],
                                       primary_key=True
                                       if row[PRIMARY_KEY] == "1" else False)
                        for row in csvreader
                    ])
        except:
            print(f"Error loading index file for {node}")
            return None


class RelationsDiagram:
    def __init__(self, data, dataflow):
        self.name = data["name"]
        template_root = os.path.join("diagram", "templates")
        template_name = data["template"]
        template_path = os.path.join(template_root, template_name)
        with open(template_path, "r", encoding="utf-8") as tin:
            self.template = Template(tin.read())
        with open(os.path.join(template_root, "cluster.dot.template"),
                    "r",
                    encoding="utf-8") as tin:
            self.cluster_template = Template(tin.read())

        # parse relations
        self.relations = [
            self.__parse_edge__(edge) for edge in data["edges"]
        ] if "edges" in data else []

        # parse nodes
        nodes = [TableNode.parse(node_str) for node_str in data["nodes"]] if "nodes" in data else []
        # add all implicit nodes from the table relations
        self.nodes = set(nodes)
        for relation in self.relations:
            self.nodes.add(relation.src.node())
            self.nodes.add(relation.target.node())

        # add all implicit nodes from the data flow edges (transitively)
        self.dataflow = dataflow
        self.dataflow_edges = set()

        new_nodes = set()
        for node in self.nodes:
            for src_node, target_node in self.__compute_dataflow_descendants__(
                    node):
                self.dataflow_edges.add(
                    DataflowEdge(src=src_node, target=target_node))
                new_nodes.add(target_node)
        self.nodes = self.nodes.union(new_nodes)

        # load TableIndex for each TableNode in self.node
        self.tables = {}
        for node in self.nodes:
            table_index = TableIndex.load(node)
            if table_index:
                self.tables[node] = table_index

    def __compute_dataflow_descendants__(
            self, node: TableNode) -> Iterator[Tuple[TableNode, TableNode]]:
        adjacency = self.dataflow.adjacency
        node_str = str(node)
        if node_str in adjacency:
            for adjacent_node_str in adjacency[node_str]:
                adjacent_node = TableNode.parse(adjacent_node_str)
                yield node, adjacent_node
                yield from self.__compute_dataflow_descendants__(adjacent_node)

    def __parse_table_column__(self, text: str) -> TableColumn:
        """
        raw/pik:wloc
        """
        match = re.match("(\w+)/(\w+)(/(\w+))?:(\w+)", text)
        if not match:
            raise Exception(f"Cannot parse table column {text}")
        stage = match.group(1)
        if match.group(4):
            datasource = match.group(2)
            node_name = match.group(4)
        else:
            datasource = None
            node_name = match.group(2)
        column_name = match.group(5)
        return TableColumn(stage=stage,
                           datasource=datasource,
                           node_name=node_name,
                           column_name=column_name)

    def __parse_edge__(self, text: str) -> TableRelation:
        """
        raw/pik:wloc -- reference/work_locations:work_location
        raw/pik:rescntry -[MAPPING]- reference/countries:country_of_residence
        """
        match = re.match("([\w+/:]+)\s*(-(\[(\w+)\])?-)\s*([\w+/:]+)", text)
        if not match:
            raise Exception(f"Cannot parse edge: {text}")
        src = match.group(1)
        edge_label = match.group(4)
        target = match.group(5)
        src = self.__parse_table_column__(src)
        target = self.__parse_table_column__(target)
        return TableRelation(src=src, target=target, edge_label=edge_label)

    def __to_cluster__(self, name: str, data) -> str:
        """
        data is a {} containing a tree of named clusters/nodes
        """
        nodes = []
        clusters = {}
        for key, value in data.items():
            if type(value) == type({}):
                clusters[key] = value
            else:
                nodes.append(value)
        return self.cluster_template.substitute({
            'name':
            name,
            'label':
            name.upper(),
            'clusters':
            "\n".join(
                self.__to_cluster__(key, value)
                for key, value in clusters.items()),
            'nodes':
            "\n".join(self.__to_node__(node) for node in nodes)
        })

    def __table_index_to_graphviz__(self, table_index: TableIndex) -> str:
        columns = "|".join(f"<{column.name}>{column.name}: {column.type}"
                           for column in table_index.columns)
        return f"<_title_>{table_index.name.upper()}|{columns}"

    def __to_node__(self, node: TableNode) -> str:
        if node in self.tables:
            table_index = self.tables[node]
            label = self.__table_index_to_graphviz__(table_index)
        else:
            label = node.name.upper()
        name = str(node).replace("/", "_").upper()
        return f"{name} [label=\"{label}\"]"

    def __to_dataflow_edge__(self, dataflow_edge: DataflowEdge) -> str:
        src = str(dataflow_edge.src).replace("/", "_").upper()
        target = str(dataflow_edge.target).replace("/", "_").upper()
        return f"{src}:_title_ -- {target}:_title_ [dir=forward];"

    def __to_relation_edge__(self, relation: TableRelation) -> str:
        src = relation.src
        target = relation.target

        src_node = str(src.node()).upper().replace("/", "_")
        target_node = str(target.node()).upper().replace("/", "_")

        edge_label_node = ""
        if relation.edge_label:
            edge_name = f"{src_node}_{target_node}_{relation.edge_label.upper()}"
            edge_label = f" {edge_name} --"
            edge_label_node = f"{edge_name} [style=\"rectangle\", label=\"{relation.edge_label.upper()}\"];"
        else:
            edge_label = ""
        return "\n".join([
            edge_label_node,
            f"{src_node}:{src.column_name} --{edge_label} {target_node}:{target.column_name} [arrowtail=none];"
        ])

    def to_graphviz(self) -> str:
        """
        Generate Graphviz DOT file from template
        """
        clusters = TableNode.cluster(self.nodes)
        edges = [
            *(self.__to_dataflow_edge__(dataflow_edge)
              for dataflow_edge in self.dataflow_edges),
            *(self.__to_relation_edge__(relation)
              for relation in self.relations)
        ]
        return self.template.substitute({
            'name': self.name,
            'clusters':
            "\n".join(
                self.__to_cluster__(key, value)
                for key, value in clusters.items()),
            'nodes':
            "",
            'edges':
            "\n".join(edges)
        })

if __name__ == "__main__":
    MOCK_MINIO = os.path.join("tests", "mock_minio")
    OUTDIR = os.path.join("diagram", "diagrams")

    relations_diagram_yaml = os.path.join(MOCK_MINIO, "table_relation.diagram.yaml")
    with open(os.path.join(MOCK_MINIO, "dataflow.diagram.yaml"), "r", encoding="utf-8") as f_dataflow:
        dataflow_yaml = yaml.safe_load(f_dataflow)
        dataflow = DataflowDiagram(dataflow_yaml)
    with open(os.path.join(MOCK_MINIO, "table_relation.diagram.yaml"), "r", encoding = "utf-8") as f_relations:
        for data in yaml.safe_load_all(f_relations):
            datasource = data["datasource"]
            relations = RelationsDiagram(data, dataflow)
            with open(os.path.join(OUTDIR, f"{datasource}.table_relation.dot"),
                    "w",
                    encoding="utf-8") as fout:
                fout.write(relations.to_graphviz())