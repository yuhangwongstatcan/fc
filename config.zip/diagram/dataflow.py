# Reads the .diagram.yaml file
# Translates to .dot file with template

import os
from string import Template
from typing import Tuple
import re

EDGE_RE = re.compile("[A-Za-z_0-9]")
class DataflowDiagram:
    def __init__(self, data):
        self.name = data["name"]
        template_root = os.path.join("diagram", "templates")
        template_name = data["template"]
        template_path = os.path.join(template_root, template_name)
        with open(template_path, "r", encoding="utf-8") as tin:
            self.template = Template(tin.read())
        with open(os.path.join(template_root, "cluster.dot.template"), "r", encoding="utf-8") as tin:
            self.cluster_template = Template(tin.read())

        # transformed/trc/vehicles
        nodes = set([self.__parse_node__(node) for node in data["nodes"]] if "nodes" in data else [])
        
        # ('transformed/trc/vehicles', '->', 'aggregated/vehicles')
        edges = [self.__parse_edge__(edge) for edge in data["edges"]] if "edges" in data else []

        # resolve @ in edge targets
        # raw/e311 -> clean/@ = raw/e311 -> clean/e311
        for index, (src, edge_type, target) in enumerate(edges):
            nodes.add(src)
            if "@" in target:
                replacement = src.split("/")[-1]
                target = target.replace("@", replacement)
                edges[index] = src, edge_type, target

            # extract all implicit nodes from the edges
            # these are nodes specified in the edge definitions but not specified elsewhere
            if "*" not in target:
                nodes.add(target)
        
        self.nodes = sorted(list(nodes))
        self.edges = sorted(list(self.__resolve_edges__(edges, nodes)), key = lambda x: x[0])

        # { clean/ipil_hwy: [transformed/ipil_hwy/vehicles, transformed/ipil_hwy/travellers] }
        adjacency = {}
        for src, _, target in self.edges:
            if src in adjacency:
                adjacency[src].append(target)
            else:
                adjacency[src] = [target]
        self.adjacency = adjacency

    def __resolve_edges__(self, edges, nodes):
        for index, edge in enumerate(edges):
            src, edge_type, target = edge
            index = target.find("*")
            if index > -1:
                # search for matching nodes
                prefix = target[:index]
                matched_nodes = [node for node in nodes if node.startswith(prefix)]
                for target in matched_nodes:
                    yield src, edge_type, target
            else:
                yield edge

    def __parse_node__(self, text: str) -> str:
        match = re.match("[\w/]+", text)
        if not match:
            raise Exception(f"Node parse error: {text}")
        return match.group(0)

    def __parse_edge__(self, text: str) -> Tuple[str, str, str]:
        """
        Edge types: ->
        """
        match = re.match("([\w/]+)\s*(->)\s*([\w/@\*]+)", text)
        # expect match != None, match.groups() have length 3
        if not match:
            raise Exception(f"Edge parse error: {text}")
        src = match.group(1)
        edge_type = match.group(2)
        target = match.group(3)
        return src, edge_type, target

    def __to_node__(self, name: str, label: str) -> str:
        return f"{name.upper()} [label=\"{label.upper()}\"]"

    def __to_cluster__(self, name: str, data, prefix: str = "") -> str:
        """
        data is a {} containing a tree of named clusters/nodes
        """
        nodes = []
        clusters = {}
        for key, value in data.items():
            if len(value) > 0:
                clusters[key] = value
            else:
                nodes.append((f"{prefix}{key}", key))
        return self.cluster_template.substitute({
            'name': name,
            'label': name.upper(),
            'clusters': "\n".join(self.__to_cluster__(key, value, f"{prefix}{key}_") for key, value in clusters.items()),
            'nodes': "\n".join(self.__to_node__(name, label) for name, label in nodes)
        })

    def __to_edge__(self, src: str, edge_type: str, target: str) -> str:
        # ('transformed/trc/vehicles', '->', 'aggregated/vehicles')
        src = src.replace("/", "_").upper()
        target = target.replace("/", "_").upper()
        return f"{src} -- {target}"

    def to_graphviz(self) -> str:
        clusters = {}
        nodes = []

        for node in self.nodes:
            segments = node.split("/")
            value = segments[-1]
            if len(segments) > 1:
                root = clusters
                for segment in segments:
                    if segment in root:
                        root = root[segment]
                    else:
                        root[segment] = {}
                        root = root[segment]
            else:
                nodes.append(value)

        return self.template.substitute({
            'clusters': "\n".join(self.__to_cluster__(key, value, f"{key}_") for key, value in clusters.items()),
            'nodes': "\n".join(self.__to_node__(node, node) for node in nodes),
            'edges': "\n".join(self.__to_edge__(src, edge_type, target) for src, edge_type, target in self.edges)
        })

if __name__ == "__main__":
    MOCK_MINIO = os.path.join("tests", "mock_minio")
    OUTDIR = os.path.join("diagram", "diagrams")
    with open(os.path.join(MOCK_MINIO, "dataflow.diagram.yaml"), "r", encoding="utf-8") as fin:
        dataflow = DataflowDiagram()
        with open(os.path.join(OUTDIR, "dataflow.dot"), "w", encoding="utf-8") as fout:
            fout.write(dataflow.to_graphviz())