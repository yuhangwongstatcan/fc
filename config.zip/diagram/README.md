To generate the diagrams for documentation, simply run `python diagram/main.py` from the `src` folder. The script will automatically pull information from the following sources:
- `tests/mock_minio/dataflow.diagram.yaml`
- `tests/mock_minio/table_relation.diagram.yaml`
- `tests/mock_minio/{stage}/{datasource}/*__index.csv`

The intermediate outputs are in Graphviz format stored in .dot files under the directory `src/diagram/diagrams`.

The final SVG outputs are written to `docs/img/diagrams`