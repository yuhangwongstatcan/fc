import os
import yaml
from dataflow import DataflowDiagram
from relations import RelationsDiagram

if __name__ == "__main__":
    MOCK_MINIO = os.path.join("tests", "mock_minio")
    OUTDIR = os.path.join("diagram", "diagrams")

    if not os.path.exists(OUTDIR):
        os.makedirs(OUTDIR)
    relations_diagram_yaml = os.path.join(MOCK_MINIO, "table_relation.diagram.yaml")
    with open(os.path.join(MOCK_MINIO, "dataflow.diagram.yaml"), "r", encoding="utf-8") as f_dataflow:
        dataflow_yaml = yaml.safe_load(f_dataflow)
        dataflow = DataflowDiagram(dataflow_yaml)
    with open(os.path.join(OUTDIR, "dataflow.dot"), "w", encoding="utf-8") as fout:
        fout.write(dataflow.to_graphviz())
    with open(os.path.join(MOCK_MINIO, "table_relation.diagram.yaml"), "r", encoding = "utf-8") as f_relations:
        for data in yaml.safe_load_all(f_relations):
            datasource = data["datasource"]
            relations = RelationsDiagram(data, dataflow)
            with open(os.path.join(OUTDIR, f"{datasource}.table_relation.dot"),
                    "w",
                    encoding="utf-8") as fout:
                fout.write(relations.to_graphviz())

    DOC_DIAGRAM_DIR = os.path.join("..", "docs", "img", "diagrams")
    if not os.path.exists(DOC_DIAGRAM_DIR):
        os.makedirs(DOC_DIAGRAM_DIR)
    for file in os.listdir(OUTDIR):
        name, ext = os.path.splitext(file)
        if ext.lower() == ".dot":
            path = os.path.join(OUTDIR, file)
            out_path = os.path.join(DOC_DIAGRAM_DIR, f"{name}.svg")
            os.system(f"dot -Tsvg {path} -o {out_path}")