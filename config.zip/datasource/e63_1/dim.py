"""
    Program: dim.py

    Author: Fang Wang, fang.wang@statcan.gc.ca

    Created: March 2023

    Purpose:
        Create enumerable classes of dimension variables and their possible values
        to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class ITINERARY_CAN(AutoEnum):
    non = "N"
    oui = "O"
    yes = "Y"


class ITINERARY_OVS(AutoEnum):
    non = "N"
    oui = "O"
    yes = "Y"

class ITINERARY_USA(AutoEnum):
    non = "N"
    oui = "O"
    yes = "Y"

class PASSENGER_TYPE(AutoEnum):
    crew = "crew"
    passenger = "passenger"


