from typing import Dict, List
import numpy as np
import pandas as pd

from datasource.e63_1.schema import RawSchema,RAW_COLUMNS


def recursive_donor_imputation(
    df: pd.DataFrame,
    mask: pd.Series,
    cols: Dict[str, List[str]],
    groupby_cols: List[str],
    imputation_target: str,
    nearest_neighbour_col: str,
    rec_counter: int,
    rec_max: int,
    direction: str = "nearest",
) -> pd.DataFrame:
    if not any(mask):
        return df[RAW_COLUMNS]
    # If we bottom out the recursion, simply return since there is no default
    # behaviour for the base case.
    if rec_counter > rec_max:
        return df[RAW_COLUMNS]
    left = df[mask].sort_values(by="merge_asof_distance")
    left = left.drop(columns=["timedelta"])
    right = df[~mask].sort_values(by="merge_asof_distance")

    # We only want to keep a subset of the right table to join.
    RIGHT_COLS_KEEP = (
        cols[rec_counter]
        + [imputation_target]
        + ["merge_asof_distance"]
        + ["timedelta"]
    )
    left = pd.merge_asof(
        left,
        right[RIGHT_COLS_KEEP],
        on="merge_asof_distance",
        direction=direction,
        by=cols[rec_counter],
    )
    # Calculate the "modified" date of departure based on the timedelta
    left[f"{imputation_target}_x"] = (
        pd.to_datetime(left[RawSchema.date_of_arrival]) + left["timedelta"]
    )

    left = left.rename(columns={f"{imputation_target}_x": imputation_target})
    left = left.drop(columns=[f"{imputation_target}_y"], errors="ignore",)
    df = pd.concat([left, right])
    # Note: this mask is specific to e63_1_050 - a general implementation would need to
    # provide a way to dynamically pass the mask condition and re-evaluate it on each
    # recursive call.
    mask = df[imputation_target].isna()
    return recursive_donor_imputation(
        df,
        mask,
        cols,
        groupby_cols,
        imputation_target,
        nearest_neighbour_col,
        rec_counter + 1,
        rec_max,
        direction,
    )


def e63_1_040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute date of departure from Canada

    Args:
        df:
            A pandas dataframe with unimputed dates of departure from Canada
    
    Returns:
        df:
            A pandas dataframe where dates of departure from Canada have been imputed
    """
    if df.empty:
        raise ValueError(
            "Empty input DataFrame passed to function; expected an input with at least one row."
        )

    # Define initial conditions for the recursive merge_asof routine.
    COLS = {
        0: [RawSchema.port, RawSchema.date_of_arrival],
        1: [RawSchema.port, "month"],
        2: ["month"],
    }
    RECURSION_MAX = len(COLS.keys()) - 1
    GROUPBY_COLS = [RawSchema.ship]
    
    # pd.merge_asof requires a numpy primitive type, so need to cast to np.int64
    df["count"] = df["count"].astype(np.int64)

    # Create month column in case it is required as part of the
    df["month"] = df[RawSchema.date_of_arrival].str.split("-", expand=True)[1]

    # Create the "time delta" to be added when a donor is found. This is required
    # because we are imputing an "end date" relative to the start date of the
    # record whose end date is missing.
    df["timedelta"] = pd.to_datetime(
        df[RawSchema.date_of_departure]
    ) - pd.to_datetime(df[RawSchema.date_of_arrival])
    
    # Need to use total sums by ship as the distance metric in both left and
    # right tables.
    df_sums = df.groupby(by=GROUPBY_COLS, as_index=False).sum(RawSchema.count)
    LEFT_SUMS_COLS_KEEP = GROUPBY_COLS + [RawSchema.count]
    df = pd.merge(
        df, df_sums[LEFT_SUMS_COLS_KEEP], on=GROUPBY_COLS, how="left"
    )
    df[RawSchema.count] = df[f"{RawSchema.count}_x"]
    df["merge_asof_distance"] = df[f"{RawSchema.count}_y"]
    df = df.drop(columns=[f"{RawSchema.count}_x", f"{RawSchema.count}_y"])
    MASK = df[[RawSchema.date_of_departure]].isna().all(1)
    
    # Call the recursive donor imputation function
    df = recursive_donor_imputation(
        df,
        MASK,
        COLS,
        GROUPBY_COLS,
        RawSchema.date_of_departure,
        RawSchema.count,
        0,
        RECURSION_MAX,
    )
    df[RawSchema.date_of_departure] = pd.to_datetime(
        df[RawSchema.date_of_departure]
    ).dt.strftime("%Y-%m-%d")

    df = RawSchema(df)

    return df
