import pandas as pd
import numpy as np
import datetime

from modules.utils.loaders import Loader
from config.api import Mapping
from datasource.e63_1.schema import RawSchema,RAW_COLUMNS
from datasource.travellers.dim import COUNTRY_OF_RESIDENCE

def create_imputation_dataframe(
    df: pd.DataFrame, num_unknown_passengers: int, seed: int
) -> pd.DataFrame:
    # Reset the random seed for every group
    np.random.seed(seed)
    imputation_df = pd.DataFrame(
        {
            "random_number": np.random.uniform(0, 1, num_unknown_passengers),
            RawSchema.country_of_residence: [
                "" for i in range(0, num_unknown_passengers)
            ],
        }
    )
    # Use the generated intervals and the uniform random numbers to provide
    # a country assignment.
    for _, row in df.iterrows():
        # Assign country_of_residence based on the random number and bounds
        imputation_df.loc[
            (imputation_df["random_number"] >= row["lower_bound"])
            & (imputation_df["random_number"] < row["upper_bound"]),
            RawSchema.country_of_residence,
        ] = row[RawSchema.country_of_residence]
    # COUNT(count) GROUP BY country_of_residence to get the number of extra
    # travellers to allocate to each country code.
    imputation_df = imputation_df.groupby(
        RawSchema.country_of_residence, as_index=False
    ).count()
    imputation_df.columns = [RawSchema.country_of_residence, "extra_travellers"]
    imputation_df["extra_travellers"] = imputation_df["extra_travellers"].astype(pd.Int64Dtype()) 
    return imputation_df

def add_interval_bounds(df: pd.DataFrame) -> pd.DataFrame:
    df["proportion"] = df["count"] / int(df["count"].sum())
    # Generate lower/upper bounds based on these proportions
    df["lower_bound"] = df["proportion"].cumsum().shift(fill_value=0)
    df["upper_bound"] = df["proportion"].cumsum()
    return df


def impute_countries(x: pd.DataFrame, seed: int) -> pd.DataFrame:
    # Only consider rows where country_code != 99998
    COUNTRY_UNKNOWN = x[RawSchema.country_of_residence] == "99998"
    # If there are no records with country unknown,
    # return x as there is no imputation required.
    if not COUNTRY_UNKNOWN.any():
        return x
    # Keep track of the number of unknown passengers, and drop that row
    # from the table (the unknown passengers will be redistributed across
    # the remaining passengers).
    NUM_UNKNOWN = x.loc[COUNTRY_UNKNOWN, "count"].squeeze()
    x = x.loc[~COUNTRY_UNKNOWN, :]
    # Generate the within-group proportion
    x = add_interval_bounds(x)
    # Generate the imputation dataframe
    imputation_df = create_imputation_dataframe(x, NUM_UNKNOWN, seed)
    # Merge the imputation_df back to x using country_of_residence as the
    # merge key.
    x = pd.merge(x, imputation_df, on=RawSchema.country_of_residence, how="left")
    x["extra_travellers"] = x["extra_travellers"].replace(pd.NA, 0)
    # Add the imputed extra travellers to the count
    x["count"] = x["count"] + x["extra_travellers"]
    # Return the dataframe with only the original schema columns
    x = x[RAW_COLUMNS]
    return x


def e63_1_030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute country od residence when unknown/other

    Args:
        df:
            A pandas dataframe with unknown/other country of residence
    
    Returns:
        df:
            A pandas dataframe where unknown/other have been distributed to known
    """
    if df.empty:
        raise ValueError("Empty input dataframe was received.")
    
    # Using country mapping file to get country codes so as not to hard code them
    country = Loader.get_map_obj(
        Mapping.map__pik__raw__rescntry__pik__clean__country_of_residence
    )
    UNCONSIDERED_COUNTRIES = [COUNTRY_OF_RESIDENCE.canada.value, COUNTRY_OF_RESIDENCE.united_states.value]
    current_date = datetime.datetime.strptime(
        df[RawSchema.date_of_arrival].iloc[0], "%Y-%m-%d"
    )
    SEED = int(str(current_date.year) + f"{current_date.month:02d}")
    
    # 1. Generate the imputed values for non Canada / non US travellers.
    tmp = (
        df.loc[
            ~(df[RawSchema.country_of_residence].isin(UNCONSIDERED_COUNTRIES)), :,
        ]
        .groupby(
            by=[
                RawSchema.date_of_arrival,
                RawSchema.passenger_type,
                RawSchema.ship,
            ],
            as_index=False,
        )
        .apply(impute_countries, seed=SEED)
    )

    # 2. Left join on df to get back the new counts for each imputed record.
    MERGE_COLS = [
        RawSchema.date_of_arrival,
        RawSchema.ship,
        RawSchema.passenger_type,
        RawSchema.country_of_residence,
    ]
    KEEP_COLS = MERGE_COLS + [RawSchema.count]
    df = pd.merge(df, tmp[KEEP_COLS], on=MERGE_COLS, how="left")
    # Every row where `count_y` is not pd.NA, we assign `count_x` <- `count_y`.
    df.loc[~df["count_y"].isna(), "count_x"] = df.loc[
        ~df["count_y"].isna(), "count_y"
    ]
    
    # Rename `count_x` to `count`
    df = df.rename(columns={"count_x": RawSchema.count})
    
    # Now that the imputation has been carried out, drop the rows where
    # country_of_residence == 99998 (i.e. we have assigned their counts
    # to other records, so we drop them from the input table).
    COUNTRY_KNOWN = df["country_of_residence"] != "99998"
    df = df.loc[COUNTRY_KNOWN, RAW_COLUMNS].reset_index(drop=True)
    
    return df