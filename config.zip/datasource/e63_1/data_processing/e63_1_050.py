from typing import Dict, List
import numpy as np
import pandas as pd

from datasource.e63_1.schema import (
    CleanSchema,
    RawSchema,
    CLEAN_COLUMNS
)

def recursive_donor_imputation(
    df: pd.DataFrame,
    mask: pd.Series,
    cols: Dict[str, List[str]],
    groupby_cols: List[str],
    imputation_target: str,
    nearest_neighbour_col: str,
    rec_counter: int,
    rec_max: int,
    direction: str = "nearest",
) -> pd.DataFrame:
    if not any(mask):
        return df[CLEAN_COLUMNS]
    # If we bottom out the recursion, simply return since there is no default
    # behaviour for the base case.
    if rec_counter > rec_max:
        return df[CLEAN_COLUMNS]
    left = df[mask].sort_values(by="merge_asof_distance")
    right = df[~mask].sort_values(by="merge_asof_distance")

    # We only want to keep a subset of the right table to join.
    RIGHT_COLS_KEEP = (
        cols[rec_counter]
        + [imputation_target, RawSchema.itinerary_can, RawSchema.itinerary_ovs]
        + ["merge_asof_distance"]
    )
    left = pd.merge_asof(
        left,
        right[RIGHT_COLS_KEEP],
        on="merge_asof_distance",
        direction=direction,
        by=cols[rec_counter],
    )
    left[f"{imputation_target}_x"] = left[f"{imputation_target}_y"]
    left[f"{RawSchema.itinerary_can}_x"] = left[f"{RawSchema.itinerary_can}_y"]
    left[f"{RawSchema.itinerary_ovs}_x"] = left[f"{RawSchema.itinerary_ovs}_y"]

    left = left.rename(
        columns={
            f"{imputation_target}_x": imputation_target,
            f"{RawSchema.itinerary_can}_x": RawSchema.itinerary_can,
            f"{RawSchema.itinerary_ovs}_x": RawSchema.itinerary_ovs,
        }
    )
    left = left.drop(
        columns=[
            f"{imputation_target}_y",
            f"{RawSchema.itinerary_can}_y",
            f"{RawSchema.itinerary_ovs}_y",
        ],
        errors="ignore",
    )
    df = pd.concat([left, right])
    # Note: this mask is specific to e63_1_050 - a general implementation would need to
    # provide a way to dynamically pass the mask condition and re-evaluate it on each
    # recursive call.
    mask = (
        df[
            [
                RawSchema.itinerary_usa,
                RawSchema.itinerary_can,
                RawSchema.itinerary_ovs,
            ]
        ]
        .isna()
        .all(1)
    )
    return recursive_donor_imputation(
        df,
        mask,
        cols,
        groupby_cols,
        imputation_target,
        nearest_neighbour_col,
        rec_counter + 1,
        rec_max,
        direction,
    )


def e63_1_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute values for the three variables defining the itinerary for any ships (records) where they are all left blank.

    Args:
        df:
            A pandas dataframe with itinerary values that are blank
    
    Returns:
        df:
            A pandas dataframe where all blank itinerary values have been imputed
    """
    if df.empty:
        raise ValueError(
            "Empty input DataFrame passed to function; expected an input with at least one row."
        )

    # Define initial conditions for the recursive merge_asof routine.
    COLS = {
        0: [RawSchema.port, RawSchema.date_of_arrival],
        1: [RawSchema.port, "month"],
        2: ["month"],
    }
    RECURSION_MAX = len(COLS.keys()) - 1
    GROUPBY_COLS = [RawSchema.ship]
    
    # pd.merge_asof requires a numpy primitive type, so need to cast to np.int64
    df["count"] = df["count"].astype(np.int64)

    # Create month column in case it is required as part of the
    df["month"] = df[RawSchema.date_of_arrival].str.split("-", expand=True)[1]

    # Need to use total sums by ship as the distance metric in both left and
    # right tables.
    df_sums = df.groupby(by=GROUPBY_COLS, as_index=False).sum(RawSchema.count)
    LEFT_SUMS_COLS_KEEP = GROUPBY_COLS + [RawSchema.count]
    df = pd.merge(
        df, df_sums[LEFT_SUMS_COLS_KEEP], on=GROUPBY_COLS, how="left"
    )
    df[RawSchema.count] = df[f"{RawSchema.count}_x"]
    df["merge_asof_distance"] = df[f"{RawSchema.count}_y"]
    df = df.drop(columns=[f"{RawSchema.count}_x", f"{RawSchema.count}_y"])
    MASK = (
        df[
            [
                RawSchema.itinerary_usa,
                RawSchema.itinerary_can,
                RawSchema.itinerary_ovs,
            ]
        ]
        .isna()
        .all(1)
    )
    
    # Call the recursive donor imputation function
    df = recursive_donor_imputation(
        df,
        MASK,
        COLS,
        GROUPBY_COLS,
        RawSchema.itinerary_usa,
        RawSchema.count,
        0,
        RECURSION_MAX,
    )

    df = CleanSchema(df)

    return df