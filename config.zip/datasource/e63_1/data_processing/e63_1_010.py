"""
Implements the validation associated with the business rule e63_1_010
"""

import pandas as pd

from modules.utils.loaders import Loader
from config.api import DataSource, Stage
from config.api import WorkLocationsTransAction
from datasource.e63_1.schema import RawSchema,ValidationSchema,E63_1_V010_COLUMNS
from datasource.work_locations_trans_action.schema import ReferenceSchema as TransActionSchema
from datasource.work_locations_trans_action.dim import ACTION


def e63_1_010(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove records from the e63_1 raw data that cannot be matched to the work location 
    reference file, or for which the file indicates that they are not accepted, until 
    they can be reviewed.

    Args:
        df:
            A pandas dataframe with unacceptable work locations
    
    Returns:
        df:
            A pandas dataframe with unacceptable work locations removed
        
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    """
    
    # Load in and process work locations data
    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__e63_1,
    )
    work_locations =  TransActionSchema(work_locations)
    
    # Obtain mask of all records in df that do not conform with work locations acceptability 
    df = RawSchema(df)
    invalid_mask = (
        ~(
            df[RawSchema.port].isin(
                work_locations[
                    work_locations[TransActionSchema.action]==ACTION.accept.value
                ][TransActionSchema.work_location].values.astype(str)
            )
        ) 
        | (df[RawSchema.port].isnull()) 
        | (
            df[RawSchema.port].isin(
                work_locations[
                    work_locations[TransActionSchema.transportation_type]!="e63_1__311"
                ][TransActionSchema.work_location].values.astype(str)
            )
        )
    )
    
    # Subset df to remove from unacceptable work locations
    auxiliary_df = df[invalid_mask].copy()  
    df = df[~invalid_mask]  
    return df, auxiliary_df

def e63_1_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule e63_1_010

    Args:
        df:
            a pandas dataframe containing records that possibly contain
            invalid work locations
        
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    
    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """

    if not auxiliary_df.empty:
        auxiliary_df = auxiliary_df.rename(columns={"date_of_arrival":"date"})

        # Group by port and date columns to get the sum of counts in each invalid record group
        validation_df = auxiliary_df.groupby(by=[RawSchema.port, ValidationSchema.date],dropna=False, as_index= False)
        validation_df = validation_df[[RawSchema.count]].apply(lambda x: x.astype("Int64").sum())

        # select only columns from the schema
        validation_df = validation_df[E63_1_V010_COLUMNS]

        # Ensure that the dataframe adheres to the schema
        validation_df = ValidationSchema(validation_df) 
        
        validation_df = validation_df.sort_values(RawSchema.count)
    else:
        # If the auxiliary df is empty,
        # return a blank df following the expected output schema
        validation_df = pd.DataFrame({key: pd.Series(dtype=str(ValidationSchema.to_schema().columns[key].dtype)) for key in E63_1_V010_COLUMNS})

    return validation_df