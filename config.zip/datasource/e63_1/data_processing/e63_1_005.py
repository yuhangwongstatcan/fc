import pandas as pd

from modules.utils.loaders import Loader
from config.api import DataSource, Stage

from datasource.e63_1.schema import RawSchema,RAW_COLUMNS
from config.api import WorkLocationsTransAction
from datasource.work_locations_trans_action.schema import ReferenceSchema as TransActionSchema

def e63_1_005(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure that all port codes from the E63-1 raw data are 5 digits.

    Args:
        df:
            A pandas dataframe with port codes that are not 5 digits
    
    Returns:
        df:
            A pandas dataframe where all port codes are five digits
    """
    # Load in and process work locations data
    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__e63_1,
    )
    work_locations = TransActionSchema(work_locations)
    work_locations = work_locations.rename(columns={"work_location":"port"})
    
    # remove?? check later: df[RawSchema.port] = df[RawSchema.port]

    # Add one or two leading 0 when the port number is only two or one digit
    df.loc[df[RawSchema.port].str.len() == 1, RawSchema.port] = "00"+df[df[RawSchema.port].str.len() == 1][RawSchema.port]
    df.loc[df[RawSchema.port].str.len() == 2, RawSchema.port] = "0"+df[df[RawSchema.port].str.len() == 1][RawSchema.port]
    df["is_invalid"] = df[RawSchema.port].str.len() == 3
    
    # The left dataframe is the table with port values that need to be encoded (3 digits -> 5 digits)
    left = df[df["is_invalid"]]
    right = work_locations
    
    # Conditional on being a valid port, the digit portion is everything from the second
    # character position onward (inclusive)
    right["port_sub"] = right["port"].str[2:].copy()
    
    # Keep only relevant columns for illustration purposes
    left = left[[RawSchema.port]].copy()
    right = right[["port", "port_sub"]].copy()
    
    # Left join on date, wloc, and flight/flight digits for left/right tables respectively
    left.loc[:, "copy_index"] = left.index
    values_to_update = pd.merge(
        left,
        right,
        left_on=[RawSchema.port],
        right_on=["port_sub"],
        how="left"
    ).set_index("copy_index")
    
    # Update port values
    df.loc[df["is_invalid"],[RawSchema.port],] = values_to_update[["port_y",]].values

    # Temporary code to recode certain country codes until use of
    # new E63-1 template is widespread among ports

    # These country codes were updated in May 2023 to reflect updated
    # continents for these countries, but if older E63-1 templates are
    # returned then the country code may not be correct

    # British Indian Ocean Territory
    df.loc[
        df[RawSchema.country_of_residence] == '44086',
        RawSchema.country_of_residence,
    ] = '32086'
    # Christmas Island
    df.loc[
        df[RawSchema.country_of_residence] == '51162',
        RawSchema.country_of_residence,
    ] = '53162'
    # Cocos Islands
    df.loc[
        df[RawSchema.country_of_residence] == '51166',
        RawSchema.country_of_residence,
    ] = '53166'
    # Norfolk Island
    df.loc[
        df[RawSchema.country_of_residence] == '51574',
        RawSchema.country_of_residence,
    ] = '52574'


    # select only columns from the schema
    df = df[RAW_COLUMNS] 
    
    # Ensure that the dataframe adheres to the schema
    df = RawSchema(df)

    return df