import pandas as pd

from datasource.e63_1.schema import RawSchema,RAW_COLUMNS
from datasource.e63_1.dim import (
    ITINERARY_USA,
    ITINERARY_CAN,
    ITINERARY_OVS
)                   

def e63_1_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove coasting record.

    Args:
        df:
            A pandas dataframe with coasting records
    
    Returns:
        df:
            A pandas dataframe without coasting records
        
    """

    # count occurances of the bellow null values per row, if between 1 and 2, remove as coasting, otherwise leave for imputation
    df['cond_count'] = 0

    df.loc[df[RawSchema.itinerary_usa].isnull(), 'cond_count'] += 1
    df.loc[df[RawSchema.itinerary_can].isnull(), 'cond_count'] += 1
    df.loc[df[RawSchema.itinerary_ovs].isnull(), 'cond_count'] += 1

    # Set blank iternary values to "N", then remove coasting vessels based on documentation criteria
    df.loc[df[RawSchema.itinerary_usa].isnull() & df['cond_count'].isin([1,2]), RawSchema.itinerary_usa] = ITINERARY_USA.non.value
    df.loc[df[RawSchema.itinerary_can].isnull() & df['cond_count'].isin([1,2]), RawSchema.itinerary_can] = ITINERARY_CAN.non.value
    df.loc[df[RawSchema.itinerary_ovs].isnull() & df['cond_count'].isin([1,2]), RawSchema.itinerary_ovs] = ITINERARY_OVS.non.value


    invalid_mask = (df[RawSchema.itinerary_usa] == ITINERARY_USA.non.value) & (df[RawSchema.itinerary_ovs] == ITINERARY_OVS.non.value) & (
        df[RawSchema.itinerary_can].isin([ITINERARY_CAN.non.value, ITINERARY_CAN.oui.value, ITINERARY_CAN.yes.value])
    )
    
    # Subset df to remove from "coasting" cruise ship
    output = df[~invalid_mask].copy()
    output = output[RAW_COLUMNS]
    output = RawSchema(output)
    # auxiliary_df = df[invalid_mask]
    # auxiliary_df = auxiliary_df[Raw_COLUMNS]
    # auxiliary_df = RawSchema(auxiliary_df)
    
    return output
