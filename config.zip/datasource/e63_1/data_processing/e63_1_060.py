"""
Implements the e63_1_060 Business Rule
"""

import pandas as pd
import datetime

from datasource.e63_1.schema import CleanSchema
from datasource.e63_1.dim import (
    PASSENGER_TYPE,
    ITINERARY_OVS,
    ITINERARY_USA
)

from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_GROUPBY,
    TRANSFORMED_COLUMNS,
)

from datasource.common.dim import (
    MODE,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
    PLATE_REGION,
)

from datasource.travellers.dim import (
    ARRIVING_FROM,
    COUNTRY_OF_RESIDENCE,
    PURPOSE4,
    PURPOSE9,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    DATA_SOURCE,
)
from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema


def e63_1_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    Performs the business logic that transforms cleaned PIK data into PIK's contribution
    to the travellers table.

    Args:
        df: pd.DataFrame

    Returns:
        RuleOutput:
            An instance of RuleOutput containing PIK's contribution to the travellers table.
    """

    # expected_worklocations = pd.read_csv('./tests/mock_minio/reference/work_locations_trans_action/work_locations__pik.csv')
    # 1. Add a data source column and set it to PIK
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.E63_1.value

    df[
        [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
    ] = df[CleanSchema.date_of_arrival].str.split("-", expand=True)

    df[TransformedSchema.month] = df[TransformedSchema.month].replace({r"0(\d)":r"\1"}, regex=True)
    df[TransformedSchema.day] = df[TransformedSchema.day].replace({r"0(\d)":r"\1"}, regex=True)

    df[TransformedSchema.work_location] = df[CleanSchema.port]
    df[TransformedSchema.country_of_residence] = df[CleanSchema.country_of_residence]

    df[TransformedSchema.mode] = MODE.water.value
    df[TransformedSchema.vehicle_type] = VEHICLE_TYPE.cruise_ship.value
    df[TransformedSchema.plate_country] = PLATE_COUNTRY.not_available.value
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value
    
    # Assign purpose based on documentation
    arrive_mask1 = df[CleanSchema.country_of_residence].isin([COUNTRY_OF_RESIDENCE.canada.value,COUNTRY_OF_RESIDENCE.united_states.value])
    arrive_mask2 = arrive_mask1&(df[CleanSchema.itinerary_usa].isin([ITINERARY_USA.oui.value,ITINERARY_USA.yes.value])) \
        &(df[CleanSchema.itinerary_ovs].isin([ITINERARY_OVS.oui.value,ITINERARY_OVS.yes.value]))
    df.loc[arrive_mask2, [TransformedSchema.arriving_from]] = ARRIVING_FROM.ovs_via_us.value
    
    arrive_mask3 = arrive_mask1&(df[CleanSchema.itinerary_usa].isin([ITINERARY_USA.oui.value,ITINERARY_USA.yes.value]))
    df.loc[~arrive_mask2&arrive_mask3, [TransformedSchema.arriving_from]] = ARRIVING_FROM.us_only.value
    
    arrive_mask4 = arrive_mask1&(df[CleanSchema.itinerary_ovs].isin([ITINERARY_OVS.oui.value,ITINERARY_OVS.yes.value]))
    df.loc[(~arrive_mask2&~arrive_mask3)&arrive_mask4, [TransformedSchema.arriving_from]] = ARRIVING_FROM.ovs_direct.value
    
    arrive_mask5 = ~arrive_mask1&(df[CleanSchema.itinerary_usa].isin([ITINERARY_USA.oui.value,ITINERARY_USA.yes.value]))
    df.loc[arrive_mask5, [TransformedSchema.arriving_from]] = ARRIVING_FROM.ovs_via_us.value
    
    arrive_mask6 = ~arrive_mask1&(~df[CleanSchema.itinerary_usa].isin([ITINERARY_USA.oui.value,ITINERARY_USA.yes.value]))
    df.loc[arrive_mask6, [TransformedSchema.arriving_from]] = ARRIVING_FROM.ovs_direct.value

    purp_mask1 = df[CleanSchema.passenger_type] == PASSENGER_TYPE.crew.value
    df.loc[purp_mask1, [TransformedSchema.purpose4, TransformedSchema.purpose9]] = [
        PURPOSE4.crew.value,
        PURPOSE9.crew.value,
    ]
    purp_mask2 = df[CleanSchema.passenger_type] == PASSENGER_TYPE.passenger.value
    df.loc[purp_mask2, [TransformedSchema.purpose4, TransformedSchema.purpose9]] = [
        PURPOSE4.visit.value,
        PURPOSE9.visit.value,
    ]

    # Assign duration based on documentation
    mask1 = (df[CleanSchema.date_of_departure] == df[CleanSchema.date_of_arrival])
    mask2 = (pd.to_datetime(df[CleanSchema.date_of_departure])-pd.to_datetime(df[CleanSchema.date_of_arrival]))==datetime.timedelta(1)
    mask3 = (pd.to_datetime(df[CleanSchema.date_of_departure])-pd.to_datetime(df[CleanSchema.date_of_arrival]))==datetime.timedelta(2)
    mask4 = (pd.to_datetime(df[CleanSchema.date_of_departure])-pd.to_datetime(df[CleanSchema.date_of_arrival])).isin([datetime.timedelta(3),datetime.timedelta(3),
        datetime.timedelta(4),datetime.timedelta(5),datetime.timedelta(6),datetime.timedelta(7)])
    mask5 = (~mask1&~mask2&~mask3&~mask4&~mask4)

    df.loc[mask1, [TransformedSchema.duration2, TransformedSchema.duration3, TransformedSchema.duration5]] = [
        DURATION2.same_day.value,
        DURATION3.same_day.value,
        DURATION5.same_day.value
    ]

    df.loc[mask2, [TransformedSchema.duration2, TransformedSchema.duration3, TransformedSchema.duration5]] = [
        DURATION2.overnight.value,
        DURATION3.one_night.value,
        DURATION5.one_two_nights.value
    ]

    df.loc[mask3, [TransformedSchema.duration2, TransformedSchema.duration3, TransformedSchema.duration5]] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.one_two_nights.value
    ]

    df.loc[mask4, [TransformedSchema.duration2, TransformedSchema.duration3, TransformedSchema.duration5]] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.three_seven_nights.value
    ]

    df.loc[mask5, [TransformedSchema.duration2, TransformedSchema.duration3, TransformedSchema.duration5]] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.eight_plus_nights.value
    ]

    mask12 = df[TransformedSchema.purpose4] == PURPOSE4.crew.value
    df.loc[mask12,
        TransformedSchema.traveller_type] = TRAVELLER_TYPE.other_traveller.value

    mask13 = df[TransformedSchema.duration2] == DURATION2.same_day.value
    df.loc[~mask12&mask13,
        TransformedSchema.traveller_type] = TRAVELLER_TYPE.excursionist.value

    mask14 = df[TransformedSchema.duration2] == DURATION2.overnight.value
    df.loc[(~mask12&~mask13)&mask14,
        TransformedSchema.traveller_type] = TRAVELLER_TYPE.tourist.value

    df[TransformedSchema.count_of_entries] = df[CleanSchema.count]
    
    df = df[
        [
            TransformedSchema.year,
            TransformedSchema.month,
            TransformedSchema.day,
            WorkLocationsSchema.port,
            TransformedSchema.mode,
            TransformedSchema.vehicle_type,
            TransformedSchema.plate_country,
            TransformedSchema.plate_region,
            TransformedSchema.arriving_from,
            TransformedSchema.country_of_residence,
            TransformedSchema.purpose9,
            TransformedSchema.purpose4,
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
            TransformedSchema.traveller_type,
            WorkLocationsSchema.work_location,
            TransformedSchema.data_source,
            TransformedSchema.count_of_entries
        ]
    ]
    
    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = df.groupby(by=TRANSFORMED_GROUPBY, dropna=False).sum().reset_index()
    
    # Reorder the re-named columns
    df = df[TRANSFORMED_COLUMNS]
    df = TransformedSchema(df)

    # Sort entries from left to right
    output = df.sort_values(TRANSFORMED_COLUMNS, ascending=True)

    return output
