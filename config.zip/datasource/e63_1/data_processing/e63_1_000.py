"""
Implements the validation associated with the business rule e63_1_000
"""
import pandas as pd
from datasource.e63_1.schema import RawSchema, ValidationSchema,E63_1_V000_COLUMNS

from config.api import DataSource
from modules.utils.data_manipulation import validate_dimensions


def e63_1_v000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation to check unexpected values in dimension variables.

    Args:
        df:
            a pandas dataframe containing records that possibly contain
            invalid itineraries and passenger types.
    
    Returns:
        df:
            Copy of the input dataframe since no processing is done.
        
        validation_df:
            A summary of the unexpected dimension variables values
            for use in the validation dashboards.

    """
    # call helper function to validate dims
    validation_df = validate_dimensions(
        df,
        RawSchema,
        ValidationSchema,
        cname_loc=RawSchema.port,
        cname_date=RawSchema.date_of_arrival,
        datasource=DataSource.e63_1,
    )
    
    validation_df = validation_df.rename(columns={"date_of_arrival":"date"})
    validation_df = validation_df[E63_1_V000_COLUMNS]
    # Check and coerce the validation schema as required
    validation_df = ValidationSchema(validation_df)
    
    return df, validation_df