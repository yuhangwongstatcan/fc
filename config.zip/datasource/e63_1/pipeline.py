"""
**Author(s)**

-Fang Wang - `fang.wang@statcan.gc.ca`

**Created On:** March 2023

**Description:**

The pipeline definitions for the E63_1 data source. Two pipelines are defined in this
module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`

"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID
from modules.pipeline import validation_writer

from config.api import Stage, DataSource, S3

from datasource.e63_1.data_processing import *
from datasource.e63_1.schema import *


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the E63-1 data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data files created by the loader
        df = Loader.query(Stage.RAW, self.datasource, year=self.year, month=self.month)

        # Make sure that the df adheres to the Raw Schema
        df = RawSchema(df)

        # VALIDATION 000: Check for unexpected values in dimension variables
        print("   1.Starting processing e63_1_000")
        df, validation_df = e63_1_v000(df)
        validation_writer(validation_df, e63_1_v000, self.datasource, self.date)
        logging.info("Finished processing e63_1_000")
        print("   1.Finished processing e63_1_000")

        # Ensure that all port values in the dataframe have five digits
        print("   2.Starting processing e63_1_005")
        df = e63_1_005(df)
        logging.info("Finished processing e63_1_005")
        print("   2.Finished processing e63_1_005")

        # Remove E63-1 records from unexpected work locations/ports
        # VALIDATION 010: Check for  unexpected work locations/ports
        print("   3.Starting processing e63_1_010")
        df, auxiliary_df = e63_1_010(df)
        validation_df = e63_1_v010(df, auxiliary_df)
        validation_writer(validation_df, e63_1_v010, self.datasource, self.date)
        logging.info("Finished processing e63_1_010")
        print("   3.Finished processing e63_1_010")

        # Remove records for travellers on a cruise ship that is defined as "coasting",
        # as these travellers are out of scope for Frontier Counts.
        print("   4.Starting processing e63_1_020")
        df = e63_1_020(df)
        logging.info("Finished processing e63_1_020")
        print("   4.Finished processing e63_1_020")

        # Impute country of residence when unknown/other from E63-1
        print("   5.Starting processing e63_1_030")
        df = e63_1_030(df)
        logging.info("Finished processing e63_1_030")
        print("   5.Finished processing e63_1_030")

        # Impute date of departure from Canada for E63-1
        print("   6.Starting processing e63_1_040")
        df = e63_1_040(df)
        logging.info("Finished processing e63_1_040")
        print("   6.Finished processing e63_1_040")

        # Impute itinerary variables for E63-1
        print("   7.Starting processing e63_1_050")
        df = e63_1_050(df)
        logging.info("Finished processing e63_1_050")
        print("   7.Finished processing e63_1_050")

        # Make sure that the output df adheres to the Clean Schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        e63_1_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN, self.datasource, self.year, self.month, self.day
            ),
        )

        # Add pipeline output to outputs dictionary
        self.outputs[self.datasource.value] = e63_1_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the E63-1 data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the CLEAN data files
        df = Loader.query(
            Stage.CLEAN, self.datasource, year=self.year, month=self.month
        )

        # Perform the tranformation to get the vehicles table
        if df.empty:
            raise ValueError(
                "Input DataFrame to business rule e63_1_060.py is empty. Pipeline cannot proceed."
            )

        # Make sure that the input df adheres to the clean schema
        df = CleanSchema(df)

        # Create the E63_1 contribution to the aggregated travellers table
        print("Starting processing e63_1_060")
        travellers = e63_1_060(df)
        logging.info("Finished processing e63_1_060")
        print("Finished processing e63_1_060")

        # Make sure that the TRAVELLERS output df adheres to the transformed schema
        travellers = TransformedSchema(travellers)

        # Save travellers outputs to dictionary
        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )

        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.travellers.value] = travellers_output
