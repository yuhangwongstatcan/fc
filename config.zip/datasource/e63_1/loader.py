#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import re
import tempfile
import shutil
import glob
import pandas as pd
import pandera as pa
import warnings
import numpy as np
from os.path import join
from pathlib import Path
from datetime import datetime

from pandas.core.frame import DataFrame

from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage
from config.api import S3
from config.argo import ArgoStatusCodes
from modules.utils.schema import tuplify
from modules.utils.data_manipulation import upload_files
from modules.utils.datasource_loader_helpers import InvalidDateError, InvalidPortError

from datasource.e63_1.schema import RawSchema, RAW_COLUMNS
from datasource.travellers.dim import COUNTRY_OF_RESIDENCE

# List of columns to sort E63-1 by for raw
E63_1_SORT_COLUMNS = RawSchema.get_keys()

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")


def numbers_port(string):
    result = re.sub("[^\d]", "", str(string))
    if result == "":
        raise InvalidPortError(string)
    return result


def copy(string):
    return string


def date(string):
    match = re.match("(\d\d)\/(\d\d)\/(\d\d\d\d)", str(string))
    if match:
        day, month, year = match.groups()
        return f"{year}-{month}-{day}"
    else:
        raise InvalidDateError(string)


def extract(dx):
    dx = dx.replace(np.nan, 0)
    return dx.loc[dx.iloc[:, 1] != 0]


def can_us(dx):
    dx.iloc[0, 0] = 11124
    dx.iloc[1, 0] = 11840
    return extract(dx)


def exel_conf():
    return {
        1: {
            "name": "Passengers-Passagers",
            "attrs": [
                {"col": 0, "row": 2, "func": numbers_port, "name": "port"},
                {"col": 4, "row": 4, "func": date, "name": "date_of_departure"},
                {"col": 4, "row": 2, "func": date, "name": "date_of_arrival"},
                {"col": 0, "row": 7, "func": copy, "name": "ship"},
                {"col": 9, "row": 3, "func": copy, "name": "itinerary_usa"},
                {"col": 9, "row": 4, "func": copy, "name": "itinerary_can"},
                {"col": 9, "row": 5, "func": copy, "name": "itinerary_ovs"},
            ],
            "list": [
                {
                    "rows": {"start": 6, "end": 8},
                    "cols": {"start": 5, "end": 7},
                    "func": can_us,
                    "attrs": [{"name": "passenger_type", "value": "passenger"}],
                },
                {
                    "rows": {"start": 10, "end": 94},
                    "cols": {"start": 1, "end": 3},
                    "func": extract,
                    "attrs": [{"name": "passenger_type", "value": "passenger"}],
                },
                {
                    "rows": {"start": 10, "end": 94},
                    "cols": {"start": 5, "end": 7},
                    "func": extract,
                    "attrs": [{"name": "passenger_type", "value": "passenger"}],
                },
                {
                    "rows": {"start": 10, "end": 94},
                    "cols": {"start": 8, "end": 10},
                    "func": extract,
                    "attrs": [{"name": "passenger_type", "value": "passenger"}],
                },
            ],
            "passenger_type": "passenger",
        },
        2: {
            "name": "Crew-Équipage",
            "attrs": [
                {"col": 0, "row": 2, "func": numbers_port, "name": "port"},
                {"col": 4, "row": 4, "func": date, "name": "date_of_departure"},
                {"col": 4, "row": 2, "func": date, "name": "date_of_arrival"},
                {"col": 0, "row": 7, "func": copy, "name": "ship"},
                {"col": 9, "row": 3, "func": copy, "name": "itinerary_usa"},
                {"col": 9, "row": 4, "func": copy, "name": "itinerary_can"},
                {"col": 9, "row": 5, "func": copy, "name": "itinerary_ovs"},
            ],
            "list": [
                {
                    "rows": {"start": 6, "end": 8},
                    "cols": {"start": 5, "end": 7},
                    "func": can_us,
                    "attrs": [{"name": "passenger_type", "value": "crew"}],
                },
                {
                    "rows": {"start": 10, "end": 94},
                    "cols": {"start": 1, "end": 3},
                    "func": extract,
                    "attrs": [{"name": "passenger_type", "value": "crew"}],
                },
                {
                    "rows": {"start": 10, "end": 94},
                    "cols": {"start": 5, "end": 7},
                    "func": extract,
                    "attrs": [{"name": "passenger_type", "value": "crew"}],
                },
                {
                    "rows": {"start": 10, "end": 94},
                    "cols": {"start": 8, "end": 10},
                    "func": extract,
                    "attrs": [{"name": "passenger_type", "value": "crew"}],
                },
            ],
        },
    }


def read_excel(
    filename: str, excel_conf: dict, schema: pa.SchemaModel
) -> dict[DataFrame]:
    """
    Uses a configuration to extract DataFrames from excel sheets.
    """
    tmp = pd.DataFrame(columns=RAW_COLUMNS)
    dfs = {}
    for sheet, conf in excel_conf.items():
        conf = tuplify(conf)
        df = pd.read_excel(filename, sheet_name=conf.name, engine="openpyxl")
        dfs[sheet] = df
        for r in conf.list:
            dx = df.iloc[r.rows.start : r.rows.end, r.cols.start : r.cols.end]
            dx = r.func(dx).reset_index(drop=True)
            dx.columns = [schema.country_of_residence, schema.count]
            # Need to check for the case where no country is specified.
            # In this case, apply the label 99998. Note that CBSA may specify
            # many rows where a country isn't specified. We need to collapse
            # all of these country records into a single row with the country
            # of residence label 99998.
            if (dx[schema.country_of_residence] == 0).any():
                dx = dx.groupby(by=schema.country_of_residence, as_index=False).sum()
                dx.loc[
                    (dx[schema.country_of_residence] == 0),
                    schema.country_of_residence,
                ] = COUNTRY_OF_RESIDENCE.overseas.value
            for attr in r.attrs:
                dx[attr.name] = attr.value
            tmp = pd.concat((tmp, dx), axis=0)

    sheet1, sheet2 = 1, 2
    conf = tuplify(excel_conf[sheet1])

    for attr in conf.attrs:
        value1 = attr.func(dfs[sheet1].iloc[attr.row, attr.col])
        value2 = attr.func(dfs[sheet2].iloc[attr.row, attr.col])
        tmp[attr.name] = value1 or value2

    return tmp


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load pik data from the momentary S3Location.
    This is the loader entry point for the pik datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """
    downloaddir = client.get_dir(location)

    e63_1_folder = tempfile.mkdtemp()

    data = pd.DataFrame(columns=RAW_COLUMNS)
    for f in glob.glob(join(downloaddir, "*.xlsx")):
        try:
            # print("e63-1 reading file: ", f)
            tmp = read_excel(f, exel_conf(), RawSchema)
            data = pd.concat((data, tmp), axis=0, ignore_index=True)
        except:
            # Return false if there was a processing error in any file
            import traceback as tb

            print("Error reading e63-1 file: ", f)
            fname = f.replace(downloaddir, "")
            fname = fname.replace("/", "")
            dst = S3.get_error_location(DataSource.e63_1, fname)
            src = S3.obj_to_loc(Stage.INBOX.value.bucket, "inbox/" + fname)
            print("Moving to error location:", dst)
            client.mv_loc(src, dst)
            tb.print_exc()
            print("Exit on error.")
            ArgoStatusCodes.exit_error_location()
            return False
    # If date of arrival is empty for all records, return False since there will be
    # no data to process
    if data[RawSchema.date_of_arrival].isna().all():
        return False
    gdf = data.groupby(RawSchema.date_of_arrival)
    dfs = {_date: gdf.get_group(_date) for _date in gdf.groups}

    date_pattern = re.compile("(\d{4})-(\d{2})-(\d{2})")
    localnames = []
    for _date, _df in dfs.items():
        match = date_pattern.match(_date)
        if match:
            year, month, day = match.groups()
            filename = join(
                e63_1_folder,
                S3.get_s3_basename(stage, DataSource.e63_1, year, month, day),
            )
            localnames.append(filename)
            # Need to check if the filename already exists in /raw/e63_1/<year>/<month>.
            data_date = datetime.strptime(_date, "%Y-%m-%d")
            s3_basename = f"{Path(filename).stem}.csv"
            s3_prefix = Path(
                Stage.RAW.name.lower(),
                DataSource.e63_1.value,
                str(data_date.year),
                str(data_date.month),
            )
            data_loc = S3Location(
                bucket=Stage.RAW.value.bucket, prefix=s3_prefix, basename=s3_basename
            )
            # If a conflict exists, we need to check if there are any true duplicates
            # (i.e. everything except `count` is identical).
            if client.stat_loc(data_loc):
                existing_df = client.get_CSV(data_loc).astype(str)
                _df = _df.astype(str)
                concatenated = pd.concat([existing_df, _df])
                TRUE_DUPLICATES = concatenated.duplicated(
                    subset=concatenated.columns.drop(RawSchema.count)
                )
                # If there is a true duplicate, then let _df be written to CSV
                # and go through the normal flow (i.e. conflict will be generated
                # automatically).
                #
                # Else, if there is no duplicate: delete the existing file in S3,
                # let _df = concat, and let _df go through the normal flow (i.e.
                # there is no longer a file in S3 with the given name, so the
                # concatenated file will be written to the expected location without
                # generating a conflict).
                if not any(TRUE_DUPLICATES):
                    _df = concatenated
                    client.rm(
                        bucket=data_loc.bucket,
                        folder=str(Path(data_loc.prefix, data_loc.basename)),
                    )
            _df.to_csv(filename, mode="a", index=False, header=None)

    upload_files(
        client,
        localnames,
        stage,
        DataSource.e63_1,
        RawSchema,
        E63_1_SORT_COLUMNS,
        fallback_on_conflicts=False,
    )

    shutil.rmtree(downloaddir)
    shutil.rmtree(e63_1_folder)
    return True
