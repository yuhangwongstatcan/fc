"""
    Program: schema.py

    Author: Fang Wang, fang.wang@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the e36-1 data source.
"""
import pandera as pa
from pandera.typing import Series
from typing import Optional

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.e63_1.dim import (
    ITINERARY_CAN,
    ITINERARY_OVS,
    ITINERARY_USA,
    PASSENGER_TYPE,
)

from datasource.common.types import SafeIntToStringType


class RawSchema(FCSchemaModel):
    """
    Schema for E63-1 RAW data.
    """

    date_of_arrival: Series[pa.String] = pa.Field(
        description="Date that cruise ship arrived in port of call",
        # str_matches=r"\(19[7-9][0-9]|20[0-2][0-9])\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])"
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
    )
    port: Series[SafeIntToStringType] = pa.Field(
        description="Arrival port in Canada (should be first port of call for the ship in Canada)",
        nullable=True,
        coerce=True,
    )
    ship: Series[pa.String] = pa.Field(
        description="Name of the cruise ship",
        coerce=True,
    )
    date_of_departure: Series[pa.String] = pa.Field(
        description="Date that cruise ship left Canada or Canadian waters",
        # str_matches=r"\(19[7-9][0-9]|20[0-2][0-9])\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])"
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        nullable=True,
        coerce=True,
        # ge=date_of_arrival,
    )
    itinerary_usa: Series[pa.String] = pa.Field(
        description="Indicator variable identifying if the ship visited the United States in a prior port of call on the same itinerary",
        isin=ITINERARY_USA.list(),
        nullable=True,
        raise_warning=True,
        coerce=True,
    )
    itinerary_can: Series[pa.String] = pa.Field(
        description="Indicator variable identifying if the ship visited Canada in a prior port of call on the same itinerary",
        isin=ITINERARY_CAN.list(),
        nullable=True,
        raise_warning=True,
        coerce=True,
    )
    itinerary_ovs: Series[pa.String] = pa.Field(
        description="Indicator variable identifying if the ship visited a country other than the United States or Canada in a prior port of call on the same itinerary",
        isin=ITINERARY_OVS.list(),
        nullable=True,
        raise_warning=True,
        coerce=True,
    )
    passenger_type: Series[pa.String] = pa.Field(
        description="Indicator of the type of passenger, either 'passenger' or 'crew'",
        isin=PASSENGER_TYPE.list(),
        # nullable=True,
        raise_warning=True,
    )
    country_of_residence: Series[SafeIntToStringType] = pa.Field(
        description="Country code for the country of residence of the passengers or crew",
        str_matches=r"\d{5}",
        coerce=True,
    )
    count: Series[pa.INT64] = pa.Field(
        description="Count of arrivals",
        ge=0,
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [
            RawSchema.date_of_arrival,
            RawSchema.port,
            RawSchema.ship,
            RawSchema.passenger_type,
            RawSchema.country_of_residence,
        ]


class CleanSchema(RawSchema):
    """"""

    port: Series[SafeIntToStringType] = pa.Field(
        description="Arrival port in Canada (should be first port of call for the ship in Canada)",
        str_matches=r"\d{5}",
        nullable=True,
        coerce=True,
    )
    date_of_departure: Series[pa.String] = pa.Field(
        description="Date that cruise ship left Canada or Canadian waters",
        # str_matches=r"\(19[7-9][0-9]|20[0-2][0-9])\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])"
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        #  ge=date_of_arrival,
        coerce=True,
    )
    itinerary_usa: Series[pa.String] = pa.Field(
        description="Indicator variable identifying if the ship visited the United States in a prior port of call on the same itinerary",
        isin=ITINERARY_USA.list(),
        nullable=True,
        raise_warning=True,
        coerce=True,
    )
    itinerary_can: Series[pa.String] = pa.Field(
        description="Indicator variable identifying if the ship visited Canada in a prior port of call on the same itinerary",
        isin=ITINERARY_CAN.list(),
        nullable=True,
        raise_warning=True,
        coerce=True,
    )
    itinerary_ovs: Series[pa.String] = pa.Field(
        description="Indicator variable identifying if the ship visited a country other than the United States or Canada in a prior port of call on the same itinerary",
        isin=ITINERARY_OVS.list(),
        nullable=True,
        raise_warning=True,
        coerce=True,
    )


class ValidationSchema(pa.SchemaModel):
    """
    Schema for e63-1 VALIDATION data.
    """

    variable: Optional[Series[pa.String]] = pa.Field(
        description="Dimension column name as in the original data source",
        isin=["itinerary_usa", "itinerary_can", "itinerary_ovs", "passenger_type"],
        coerce=True,
    )
    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Value not listed in the Dimension for the column",
        nullable=True,
        coerce=True,
    )
    date: Optional[Series[pa.String]] = pa.Field(
        description="Date in the format YYYY-MM-DD",
        # str_matches=r"\(19[7-9][0-9]|20[0-2][0-9])\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])"
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
    )
    location: Optional[Series[pa.String]] = pa.Field(
        description="Location (port) associated with the invalid record",
        str_matches=r"\d{5}",
        coerce=True,
    )
    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of arrivals",
        ge=0,
        coerce=True,
    )
    port: Optional[Series[SafeIntToStringType]] = pa.Field(
        description="Arrival port in Canada (should be first port of call for the ship in Canada)",
        str_matches=r"\d{5}",
        nullable=True,
        coerce=True,
    )


# Columns for schema
RAW_COLUMNS = [col for col in RawSchema.to_schema().columns.keys()]
CLEAN_COLUMNS = [col for col in CleanSchema.to_schema().columns.keys()]

E63_1_V000_COLUMNS = [
    ValidationSchema.variable,
    ValidationSchema.unexpected_value,
    ValidationSchema.date,
    ValidationSchema.location,
    ValidationSchema.count,
]

E63_1_V010_COLUMNS = [
    ValidationSchema.date,
    ValidationSchema.port,
    ValidationSchema.count,
]
