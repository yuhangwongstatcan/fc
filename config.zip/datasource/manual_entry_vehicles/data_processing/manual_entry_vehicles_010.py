import pandas as pd
import math

from config.api import Stage, DataSource
from modules.utils.loaders import Loader

from modules.utils.manual_entry_helpers import get_impute_number_subset

from datasource.manual_entry_vehicles.schema import RawSchema
from datasource.vehicles.schema import AggregatedSchema as VehiclesSchema


def manual_entry_vehicles_010(df: pd.DataFrame, reference_year: int) -> pd.DataFrame:
    """
    Performs imputation specifically on rows with empty count_of_entries column values.

    Args:
        df:
            A pandas dataframe with possible some empty count of entries values

    Returns:
        df:
            A pandas dataframe with imputed counts of entries
    """
    REFERENCE_YEAR = reference_year

    # Adjust month to drop leading zeros and keep only required columns
    df[RawSchema.month] = df[RawSchema.month].astype(int).astype(str)

    previous = Loader.query(
        Stage.AGGREGATED,
        datasource=DataSource.vehicles,
        year=REFERENCE_YEAR,
        month=int(df.iloc[0][RawSchema.month]),
        day=1,
    )
    previous = VehiclesSchema(previous)

    # For all rows where count of entries is null, we want to use year t-p of the same month and
    # take average grouped by all available properties.
    for idx, row in df.loc[df[RawSchema.count_of_entries].isnull(), :].iterrows():
        # Get the condition to get the appropriate subset of travellers
        condition = get_impute_number_subset(
            row,
            exclude=[
                RawSchema.year,
                RawSchema.count_of_entries,
                RawSchema.data_source,
            ],
        )
        cond_mask = previous.eval(condition)
        if previous[cond_mask].empty:
            continue

        # Get the subset of vehicles and get the average value of this subset
        row[RawSchema.count_of_entries] = math.floor(
            float(previous.loc[cond_mask, RawSchema.count_of_entries].mean())
        )
        df.iloc[idx, df.columns.get_loc(RawSchema.count_of_entries)] = row[
            RawSchema.count_of_entries
        ]
    # If no count of entries could be imputed from the reference year, assume there are no such records and drop the row.
    df = df[~df[RawSchema.count_of_entries].isna()]

    return df
