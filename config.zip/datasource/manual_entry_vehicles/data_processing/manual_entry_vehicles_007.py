import pandas as pd

from config.api import DataSource, ManualEntryTrackerVehicles

from modules.utils.loaders import Loader

from config.api import Stage

from datasource.manual_entry_tracker_vehicles.schema import (
    ReferenceSchema as TrackerSchema,
)


def manual_entry_vehicles_v007(df: pd.DataFrame) -> pd.DataFrame:
    """
    Carries out the manaul entry tracker logic. Checks which rows were present in manual entry
    tracker and not in manual entry data

    Args:
        df:
            A pandas dataframe of manual entry data for vehicles.

    Returns:
        df:
            A pandas dataframe of manual entry data for vehicles.
            
        auxiliary_df:
            A pandas dataframe of entries from the tracker that were
            not present in the manual entries (missing data).
    """
    # Load the tracker to get the vehicles data we expect to receive
    # for manual entry
    tracker = Loader.get(
        Stage.REFERENCE,
        DataSource.manual_entry_tracker_vehicles,
        ManualEntryTrackerVehicles.manual_entry_tracker_vehicles,
    )

    # Ensure that the tracker file matches the schema
    tracker = TrackerSchema(tracker)

    match = pd.merge(
        df, tracker, how="outer", on=tracker.columns.tolist(), indicator=True
    )
    validation_df = match.query('_merge != "left_only" & _merge != "both"')[
        tracker.columns
    ]

    return df, validation_df
