"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define the schema model for the MANUAL ENTRY VEHICLES data source.
"""

import pandera as pa
from pandera.typing import Series

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.common.dim import (
    MONTH,
    DAY,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
)
from datasource.travellers.dim import DATA_SOURCE

from datasource.common.types import SafeIntToStringType


class RawSchema(FCSchemaModel):
    """
    Raw schema for the MANUAL ENTRY VEHICLES data source.
    """

    year: Series[SafeIntToStringType] = pa.Field(
        description="Year in which the border crossing occurred",
        str_matches=r"\d{4}",
        coerce=True,
    )
    month: Series[SafeIntToStringType] = pa.Field(
        description="Month in which the border crossing occurred",
        isin=MONTH,
        coerce=True,
    )
    day: Series[SafeIntToStringType] = pa.Field(
        description="Day in which the border crossing occurred",
        isin=DAY.list(),
        coerce=True,
        nullable=True,
    )
    port: Series[SafeIntToStringType] = pa.Field(
        description="Statistics Canada port of the border crossing",
        str_matches=r"\d{5}",
        coerce=True,
    )
    vehicle_type: Series[SafeIntToStringType] = pa.Field(
        description="Vehicle type",
        isin=VEHICLE_TYPE.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    plate_country: Series[SafeIntToStringType] = pa.Field(
        description="Country of vehicle licence plate, if applicable",
        isin=PLATE_COUNTRY.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    data_source: Series[SafeIntToStringType] = pa.Field(
        description="Canada Border Services Agency data source",
        isin=DATA_SOURCE.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    count_of_entries: Series[pa.INT64] = pa.Field(
        description="Count of border crossings",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [
            RawSchema.year,
            RawSchema.month,
            RawSchema.day,
            RawSchema.port,
            RawSchema.vehicle_type,
            RawSchema.plate_country,
            RawSchema.data_source,
        ]


class CleanSchema(RawSchema):
    """
    Clean schema for the MANUAL ENTRY VEHICLES data source.
    """
