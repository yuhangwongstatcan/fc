"""
**Author(s)**

    Jacob Doering (jacob.doering@statcan.gc.ca)

**Created On:** April 2023

**Description:**

The pipeline definitions for the manual entry vehicles data source. 
Two pipelines are defined in this module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`
"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.pipeline import validation_writer
from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID

from config.api import Stage, DataSource, S3

from datasource.manual_entry_vehicles.data_processing import *
from datasource.manual_entry_vehicles.schema import RawSchema, CleanSchema

from datasource.vehicles.schema import TransformedSchema as VehiclesSchema


class PipelineRawClean(BasePipeline):
    """
    Aggregates all Data Capture entries into one CSV
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Intial dataframe
        df = Loader.query(
            Stage.RAW,
            datasource=self.datasource,
            year=self.year,
            month=self.month,
        )

        # Make sure that the df adheres to the raw schema
        df = RawSchema(df)

        # Tranform the df to the clean schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        vehicles_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN,
                self.datasource,
                self.year,
                self.month,
                self.day,
            ),
        )

        # Add pipeline output to outputs dictionary
        if vehicles_clean.data is not None and not vehicles_clean.data.empty:
            self.outputs[self.datasource.value] = vehicles_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the
    manual entry vehicles data source.
    """

    def pipeline(self):
        # reference_year is an attribute of BasePipeline
        # Note: reference_year will be passed as a run time parameter in the future
        REFERENCE_YEAR = self.reference_year

        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the CLEAN data file
        df = Loader.query(
            Stage.CLEAN, datasource=self.datasource, year=self.year, month=self.month
        )

        # Make sure the input dataframe adheres to the clean schema
        df = CleanSchema(df)

        # VALIDATION: Unexpected manual entries (not present in the tracker)
        print("   1.Starting processing manual_entry_vehicles_005")
        df, validation_df = manual_entry_vehicles_v005(df)
        validation_writer(
            validation_df, manual_entry_vehicles_v005, self.datasource, self.date
        )
        logging.info("Finished processing manual_entry_vehicles_005")
        print("   1.Finished processing manual_entry_vehicles_005")

        # VALIDATION: Missing manual entry data (present in the tracker but not the manual entries)
        print("   2.Starting processing manual_entry_vehicles_007")
        df, validation_df = manual_entry_vehicles_v007(df)
        validation_writer(
            validation_df, manual_entry_vehicles_v007, self.datasource, self.date
        )
        logging.info("Finished processing manual_entry_vehicles_007")
        print("   2.Finished processing manual_entry_vehicles_007")

        # Impute count of entries for manual entries where is was left blank
        print("   3.Starting processing manual_entry_vehicles_010")
        df = manual_entry_vehicles_010(df, REFERENCE_YEAR)
        logging.info("Finished processing manual_entry_vehicles_010")
        print("   3.Finished processing manual_entry_vehicles_010")

        # Empty rule to keep the same pipeline organization as manual entry travellers
        print("   4.Starting processing manual_entry_vehicles_020")
        df = manual_entry_vehicles_020(df)
        logging.info("Finished processing manual_entry_vehicles_020")
        print("   4.Finished processing manual_entry_vehicles_020")

        # Impute all non-declared variables that are required for the vehicles table
        print("   5.Starting processing manual_entry_vehicles_030")
        vehicles_df = manual_entry_vehicles_030(df, REFERENCE_YEAR)
        logging.info("Finished processing manual_entry_vehicles_030")
        print("   5.Finished processing manual_entry_vehicles_030")

        # Ensure that the output dataframe adheres to the VEHICLES schema
        vehicles_df = VehiclesSchema(vehicles_df)

        manual_entry_transformed_vehicles = PipelineOutput(
            data=vehicles_df,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.vehicles,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED,
                self.datasource,
                self.year,
                self.month,
                self.day,
            ),
        )
        # Add pipeline output to outputs dictionary - check if each output exists before trying to
        # write it to MinIO.
        if (
            manual_entry_transformed_vehicles.data is not None
            and not manual_entry_transformed_vehicles.data.empty
        ):
            self.outputs[self.datasource.value] = manual_entry_transformed_vehicles
