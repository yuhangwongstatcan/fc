"""
    Program: schema.py

    Author: Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the NEXUS Air data source.
"""
from typing import Optional

import pandera as pa
from pandera.typing import Series

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.trc.dim import DURATION2, CONVEYANCE_TYPE, TRAV_CHAR

from datasource.common.types import SafeIntToStringType


# Define pandera fields
DATE_FIELD = pa.Field(
    description="""Month of arrival in Canada, of the form YYYY-MM-DD,
        with DD fixed as 01""",
    str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
    coerce=True,
)
LOCATION_FIELD = pa.Field(
    description="CBSA Telephone Reporting Centre reporting site", coerce=True
)
CONVEYANCE_TYPE_FIELD = pa.Field(
    description="""Type of transportation used to cross the border, either
        Airplane, Pleasure Craft, Automobile, Snowmobile or All-Terrain Vehicle""",
    isin=CONVEYANCE_TYPE.list(),
    coerce=True,
    raise_warning=True,
)
COUNTRY_FIELD = pa.Field(description="Country of residence of travellers", coerce=True)
WORK_LOCATION_FIELD = pa.Field(
    description="""CBSA work location as mapped from the TRC reporting
    site text str name""",
    str_matches=r"\d{4}",
    nullable=True,
    coerce=True,
)
COUNTRY_OF_RESIDENCE_FIELD = pa.Field(
    description="""Country of residence of travellers in Frontier Counts
    country code""",
    str_matches=r"\d{5}",
    nullable=True,
    coerce=True,
)
PORT_FIELD = pa.Field(
    description="CBSA port of entry as mapped from the work location",
    str_matches=r"\d{5}",
    coerce=True,
)
DURATION2_FIELD = pa.Field(
    description="""Trip duration of the travellers, either same-day or
    overnight""",
    isin=DURATION2.list(),
    coerce=True,
    nullable=True,
    raise_warning=True,
)


# Define schemas
class RawSchema(FCSchemaModel):
    """
    Schema for TRC RAW data.
    """

    date: Series[pa.String] = DATE_FIELD

    district: Series[pa.String] = pa.Field(description="CBSA district", coerce=True)
    location: Series[pa.String] = LOCATION_FIELD

    conveyance_type: Series[pa.String] = CONVEYANCE_TYPE_FIELD

    country: Series[pa.String] = COUNTRY_FIELD

    trav_char: Series[pa.String] = pa.Field(
        description="""Traveller characteristics including duration or
        arriving from""",
        isin=TRAV_CHAR.list(),
        coerce=True,
        raise_warning=True,
    )

    count: Series[pa.INT64] = pa.Field(
        description="Count of arrivals", ge=0, coerce=True
    )

    work_location: Optional[Series[SafeIntToStringType]] = WORK_LOCATION_FIELD
    country_of_residence: Optional[
        Series[SafeIntToStringType]
    ] = COUNTRY_OF_RESIDENCE_FIELD
    port: Optional[Series[SafeIntToStringType]] = PORT_FIELD
    duration2: Optional[Series[SafeIntToStringType]] = DURATION2_FIELD

    @staticmethod
    def get_keys():
        return [
            RawSchema.date,
            RawSchema.district,
            RawSchema.location,
            RawSchema.conveyance_type,
            RawSchema.country,
            RawSchema.trav_char,
        ]


class CleanSchema(RawSchema):
    work_location: Series[SafeIntToStringType] = WORK_LOCATION_FIELD
    country_of_residence: Series[SafeIntToStringType] = COUNTRY_OF_RESIDENCE_FIELD
    port: Series[SafeIntToStringType] = PORT_FIELD
    duration2: Series[SafeIntToStringType] = DURATION2_FIELD


class ValidationSchema(pa.SchemaModel):
    """
    Schema for variables appearing in validation output but not RAW or CLEAN TRC data
    """

    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of a TRC dimension variable with unexpected values",
        coerce=True,
    )

    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value observed in a TRC dimension variable",
        coerce=True,
        nullable=True,
    )

    location: Optional[Series[pa.String]] = pa.Field(
        description="Geographical location where an unexpected dimension variable occurred",
        coerce=True,
    )

    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences of a particular validation case",
        ge=0,
        coerce=True,
    )

    action: Optional[Series[pa.String]] = pa.Field(
        description="Processing behaviour to be passed on to a later function",
        coerce=True,
    )

    date: Optional[Series[pa.String]] = DATE_FIELD

    work_location: Optional[Series[pa.String]] = WORK_LOCATION_FIELD

    location: Optional[Series[pa.String]] = LOCATION_FIELD

    conveyance_type: Optional[Series[pa.String]] = CONVEYANCE_TYPE_FIELD

    country: Optional[Series[pa.String]] = COUNTRY_FIELD


# Define columns for subsetting dataframes when temporary columns are used
RAWSCHEMA_COLUMNS = [
    col
    for col in RawSchema.to_schema().columns.keys()
    if RawSchema.to_schema().columns[col].required
]
TRC_005_COLUMNS = [*RAWSCHEMA_COLUMNS, RawSchema.work_location]
TRC_020_COLUMNS = [*TRC_005_COLUMNS, RawSchema.country_of_residence]
TRC_030_COLUMNS = [*TRC_020_COLUMNS, RawSchema.port, RawSchema.duration2]

CLEANSCHEMA_COLUMNS = [col for col in CleanSchema.to_schema().columns.keys()]

TRC_V000_COLUMNS = [
    ValidationSchema.variable,
    ValidationSchema.unexpected_value,
    ValidationSchema.date,
    ValidationSchema.location,
    ValidationSchema.count,
]
TRC_V010_COLUMNS = [
    ValidationSchema.date,
    ValidationSchema.work_location,
    ValidationSchema.location,
    ValidationSchema.conveyance_type,
    ValidationSchema.action,
    ValidationSchema.count,
]
TRC_V020_COLUMNS = [
    ValidationSchema.date,
    ValidationSchema.country,
    ValidationSchema.count,
]
