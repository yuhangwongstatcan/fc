#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import argparse
import tempfile
import shutil
import zipfile
import pathlib
import pandas as pd
from bs4 import BeautifulSoup
from os.path import join
from os.path import basename
import os
from config.api import S3

from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage

from config.api import DEFAULT_BUCKET

from modules.utils.data_manipulation import upload_files

from datasource.trc.schema import RawSchema, RAWSCHEMA_COLUMNS
from datasource.trc.dim import TRAV_CHAR

# List of columns to sort TRC by for raw
TRC_SORT_COLUMNS = RawSchema.get_keys()


def parse_csv(files: list) -> pd.DataFrame:
    processed = []
    for file in files:
        header = pd.read_csv(file, encoding="latin-1",dtype=str,nrows=1,header=None)
        date = header.iloc[0,1].split("-")
        df = pd.read_csv(file, encoding="latin-1",dtype=str,header=1)        
        
        US_1_day = df.loc[~((df.loc[:,"US 1 Day"].isnull()) | (df.loc[:,"US 1 Day"] == "0"))].copy()
        US_1_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = US_1_day.iloc[:,[0, 1, 2, 3]]
        US_1_day[RawSchema.country] = "United States of America"
        US_1_day[RawSchema.trav_char] = TRAV_CHAR.passenger_sdy.value
        
        US_2_day = df.loc[~((df.loc[:,"US 2 Day"].isnull()) | (df.loc[:,"US 2 Day"] == "0"))].copy()
        US_2_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = US_2_day.iloc[:,[0, 1, 2, 4]]
        US_2_day[RawSchema.country] = "United States of America"
        US_2_day[RawSchema.trav_char] = TRAV_CHAR.passenger_ovn.value
        
        CAD_from_US_1_day = df.loc[~((df.loc[:,"CAN from US 1 Day"].isnull()) | (df.loc[:,"CAN from US 1 Day"] == "0"))].copy()
        CAD_from_US_1_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = CAD_from_US_1_day.iloc[:,[0, 1, 2, 5]]
        CAD_from_US_1_day[RawSchema.country] = "Canada"
        CAD_from_US_1_day[RawSchema.trav_char] = TRAV_CHAR.passenger_sdy.value
        
        CAD_from_US_2_day = df.loc[~((df.loc[:,"CAN from US 2 Day"].isnull()) | (df.loc[:,"CAN from US 2 Day"] == "0"))].copy()
        CAD_from_US_2_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = CAD_from_US_2_day.iloc[:,[0, 1, 2, 6]]
        CAD_from_US_2_day[RawSchema.country] = "Canada"
        CAD_from_US_2_day[RawSchema.trav_char] = TRAV_CHAR.passenger_ovn.value
        
        CAD_from_Other_1_day = df.loc[~((df.loc[:,"CAN from Oth 1 Day"].isnull()) | (df.loc[:,"CAN from Oth 1 Day"] == "0"))].copy()
        CAD_from_Other_1_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = CAD_from_Other_1_day.iloc[:,[0, 1, 2, 7]]
        CAD_from_Other_1_day[RawSchema.country] = "Canada"
        CAD_from_Other_1_day[RawSchema.trav_char] = TRAV_CHAR.passenger_sdy.value
        
        CAD_from_Other_2_day = df.loc[~((df.loc[:,"CAN from Oth 2 Day"].isnull()) | (df.loc[:,"CAN from Oth 2 Day"] == "0"))].copy()
        CAD_from_Other_2_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = CAD_from_Other_2_day.iloc[:,[0, 1, 2, 8]]
        CAD_from_Other_2_day[RawSchema.country] = "Canada"
        CAD_from_Other_2_day[RawSchema.trav_char] = TRAV_CHAR.passenger_ovn.value
        
        Other_1_day = df.loc[~((df.loc[:,"Oth 1 Day"].isnull()) | (df.loc[:,"Oth 1 Day"] == "0"))].copy()
        Other_1_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = Other_1_day.iloc[:,[0, 1, 2, 10]]
        Other_1_day[RawSchema.country] = Other_1_day.iloc[:,9]
        Other_1_day[RawSchema.trav_char] = TRAV_CHAR.passenger_sdy.value
        
        Other_2_day = df.loc[~((df.loc[:,"Oth 2 Day"].isnull()) | (df.loc[:,"Oth 2 Day"] == "0"))].copy()
        Other_2_day[
            [
                RawSchema.district,
                RawSchema.location,
                RawSchema.conveyance_type,
                RawSchema.count,
            ]
        ] = Other_2_day.iloc[:,[0, 1, 2, 11]]
        Other_2_day[RawSchema.country] = Other_2_day.iloc[:,9]
        Other_2_day[RawSchema.trav_char] = TRAV_CHAR.passenger_ovn.value
        
        dataframe = US_1_day.append(
            [US_2_day, CAD_from_US_1_day,CAD_from_US_2_day, CAD_from_Other_1_day, CAD_from_Other_2_day, Other_1_day, Other_2_day]
        )

        dataframe[RawSchema.date] = date[0] + "-" + date[1] + "-01"
        dataframe = dataframe[RAWSCHEMA_COLUMNS]
        dataframe = dataframe.sort_values(
            by=[RawSchema.district, RawSchema.location]
        )
        processed.append(dataframe)
    return processed


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load ipil_hwy data from the momentary S3Location.
    This is the loader entry point for the ipil_hwy datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """

    zippath = tempfile.mkdtemp()

    print(f"Inspecting s3 location: {location.bucket} {location.prefix}")

    # List all the files inside the S3Location looking for zip or sigular .dat files.
    # All files are download and extracted in a temporary local folder.

    print(f"\tDownloaded:")
    for obj in client.ls_objs(
        location.bucket,
        recursive=True,
        prefix=location.prefix,
        only_files=True,
        default_folder_file=False,
    ):
        localname = join(zippath, basename(obj.object_name))
        client.fget_object(location.bucket, obj.object_name, localname)
        print(f"\t\t{localname}")
    try:
        files = sorted([f.as_posix() for f in pathlib.Path(zippath).rglob("*.csv")])
        tmpdir = tempfile.mkdtemp()

        processed = parse_csv(files)
        localnames = set([])
        for df in processed:
            year = int(df[RawSchema.date].iloc[0].split("-")[0])
            month = int(df[RawSchema.date].iloc[0][-5:-3])
            filename = S3.get_s3_basename(
                stage, DataSource.trc, year=year, month=month, day=1
            )
            # df.to_csv(filename, index=False, header=schema.COLUMNS)
            path = os.path.join(tmpdir, filename)
            localnames.add(path)
            df.to_csv(path, mode="a", index=False, header=None)
    except Exception:
        return False

    upload_files(
        client,
        localnames,
        stage,
        DataSource.trc,
        RawSchema,
        TRC_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )

    shutil.rmtree(zippath)
    shutil.rmtree(tmpdir)
    return True


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="Loading")
    parser.add_argument("--bucket", default=DEFAULT_BUCKET)
    parser.add_argument(
        "--prefix", default="processing/IPIL/2020_11_27_14:42:19.923851178/"
    )
    parser.add_argument("--basename", default="")
    args = parser.parse_args()

    client = S3Client.get_client()
    loc = S3Location(bucket=args.bucket, prefix=args.prefix, basename=args.basename)
    loader(client, loc)
