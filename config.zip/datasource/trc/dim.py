"""
    Program: dim.py

    Author: Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Create enumerable classes of dimension variables and their possible values
        to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class DURATION2(AutoEnum):
    same_day = "1"
    overnight = "2"


class CONVEYANCE_TYPE(AutoEnum):
    airplane = "Airplane"
    pleasurecraft = "Pleasure Craft"
    automobile = "Automobile"
    snowmobile = "Snowmobile"
    allterrainvehicle = "All-Terrain Vehicle"
    


class TRAV_CHAR(AutoEnum):
    passenger_ovn = "passenger_ovn"
    passenger_ovs = "passenger_ovs"
    passenger_sdy = "passenger_sdy"
    passenger_usa = "passenger_usa"
    vehicle = "VEHICLE"
