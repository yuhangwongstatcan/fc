# Pipeline implementations for the trc data source.
"""
**Author(s)**

- Tristan Garry - tristan.garry@statcan.gc.ca
- Collin Brown - `collin.brown@statcan.gc.ca`

**Created On:** March 2023

**Description:**

The pipeline definitions for the IPIL highway data source. Two pipelines are defined in this
module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`

"""
import logging

from modules.pipeline import BasePipeline, PipelineOutput, validation_writer

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID

from config.api import Stage
from config.api import DataSource
from config.api import S3

from datasource.trc.schema import RawSchema, CleanSchema

from datasource.trc.data_processing import *

from datasource.vehicles.schema import TransformedSchema as VehiclesSchema
from datasource.travellers.schema import TransformedSchema as TravellersSchema


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the TRC data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in initial RAW data file and apply the RAW schema to it
        df = Loader.query(
            Stage.RAW, datasource=self.datasource, year=self.year, month=self.month
        )
        df = RawSchema(df)
        logging.info("Successfully loaded RAW TRC data")
        print("Successfully loaded RAW TRC data")

        # VALIDATION: Check for unexpected values in dimensions
        print("   1.Starting processing trc_000")
        validation_df = trc_v000(df)
        validation_writer(validation_df, trc_v000, self.datasource, self.date)
        logging.info("Finished processing trc_000")
        print("   1.Finished processing trc_000")

        # Add the work location code
        print("   2.Starting processing trc_005")
        df = trc_005(df)
        logging.info("Finished processing trc_005")
        print("   2.Finished processing trc_005")

        # Recode vehicle type that is not permitted at certain work locations
        print("   3.Starting processing trc_010")
        df, auxiliary_df = trc_010(df)
        # VALIDATION: Check for invalid work locations
        validation_df = trc_v010(df, auxiliary_df)
        validation_writer(validation_df, trc_v010, self.datasource, self.date)
        logging.info("Finished processing trc_010")
        print("   3.Finished processing trc_010")

        # Add the FC country code
        print("   4.Starting processing trc_020")
        df, auxiliary_df = trc_020(df)
        # Validation: Check for improperly recoded countries
        validation_df = trc_v020(df, auxiliary_df)
        validation_writer(validation_df, trc_v020, self.datasource, self.date)
        logging.info("Finished processing trc_020")
        print("   4.Finished processing trc_020")

        # Impute stay duration
        print("   5.Starting processing trc_030")
        df = trc_030(df)
        logging.info("Finished processing trc_030")
        print("   5.Finished processing trc_030")

        # Determine number of vehicles, and license plate country for imputed vehicles
        print("   6.Starting processing trc_040")
        df = trc_040(df)
        logging.info("Finished processing trc_040")
        print("   6.Finished processing trc_040")

        # Make sure that the output adheres to the clean schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        trc_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[self.datasource.value] = trc_clean
        logging.info("Finished processing TRC RAW -> CLEAN pipeline")
        print("Finished processing TRC RAW -> CLEAN pipeline")


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the TRC data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()
        # Get the initial pandas data frame
        basename = S3.get_s3_basename(
            Stage.CLEAN,
            datasource=self.datasource,
            year=self.year,
            month=self.month,
            day=self.day,
        )
        df = Loader.get(Stage.CLEAN, datasource=self.datasource, basename=basename)

        # Make sure the input df adheres to the clean schema
        df = CleanSchema(df)

        # Perform the tranformation to get the vehicles table
        print("   1.Starting processing trc_050")
        vehicles = trc_050(df)
        logging.info("Finished processing trc_050")
        print("   1.Finished processing trc_050")
        # Make sure it adheres to the vehicles schema
        if isinstance(vehicles, pd.DataFrame) and not vehicles.empty:
            vehicles = VehiclesSchema(vehicles)

        # Perform the transformation to get the travellers table
        print("   2.Starting processing trc_060")
        travellers = trc_060(df)
        logging.info("Finished processing trc_060")
        print("   2.Finished processing trc_060")
        # Make sure it adheres to the travellers schema
        if isinstance(travellers, pd.DataFrame) and not travellers.empty:
            travellers = TravellersSchema(travellers)

        # Save vehicles/travellers outputs to dictionary
        if isinstance(vehicles, pd.DataFrame) and not vehicles.empty:
            vehicles_output = PipelineOutput(
                data=vehicles,
                stage=Stage.TRANSFORMED,
                datasource=DataSource.vehicles,
                basename=S3.get_s3_basename(
                    Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
                ),
            )
        if isinstance(travellers, pd.DataFrame) and not travellers.empty:
            travellers_output = PipelineOutput(
                data=travellers,
                stage=Stage.TRANSFORMED,
                datasource=DataSource.travellers,
                basename=S3.get_s3_basename(
                    Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
                ),
            )
        # Add pipeline output to outputs dictionary
        if isinstance(vehicles, pd.DataFrame) and not vehicles.empty:
            self.outputs[DataSource.vehicles.value] = vehicles_output
        if isinstance(travellers, pd.DataFrame) and not travellers.empty:
            self.outputs[DataSource.travellers.value] = travellers_output
        logging.info("Finished processing TRC CLEAN -> TRANSFORMED pipeline")
        print("Finished processing TRC CLEAN -> TRANSFORMED pipeline")
