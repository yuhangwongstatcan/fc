"""
Implements the trc_010 business rule and validation
"""
import pandas as pd

from config.api import DataSource

from config.api import Stage

from modules.utils.loaders import Loader

from datasource.trc.schema import RawSchema, ValidationSchema, TRC_005_COLUMNS, TRC_V010_COLUMNS
from datasource.work_locations_action.schema import ReferenceSchema as ActionSchema
from datasource.work_locations_trans.schema import ReferenceSchema as TransSchema
from datasource.work_locations_trans_action.schema import ReferenceSchema as TransActionSchema
from datasource.work_locations_trans_action.dim import ACTION

from config.api import WorkLocationsTransAction
from config.api import WorkLocationsAction
from config.api import WorkLocationsTransportation

from modules.utils.data_manipulation import work_locations_recode


def trc_010(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Use work location to recode vehicle type that are not permitted at certain work locations 
    and remove records with unexpected work locastion/transportion types.

    Args:
        df:
            A pandas dataframe with null dates and non-permitted work locations present
    Returns:
        a pandas dataframe with all records containing empty dates removed and 
        recoded work locations
    """
    # Setup for work locations recode inputs
    wl_trans = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans,
        WorkLocationsTransportation.work_locations_trans__trc,
    )
    wl_trans = TransSchema(wl_trans)

    wl_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_action,
        WorkLocationsAction.work_locations_action__trc,
    )
    wl_action = ActionSchema(wl_action)

    wl_trans_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__trc,
    )
    wl_trans_action = TransActionSchema(wl_trans_action)

    # Copy input so it is not updated in place
    df_copy = df.copy()

    work_location_column = RawSchema.work_location
    
    # Recode the work locations
    df, auxiliary_df = work_locations_recode(
        df_copy,
        wl_trans,
        wl_action,
        wl_trans_action,
        work_location_column,
        TransSchema,
        ActionSchema,
        TransActionSchema,
        ACTION,
    )
    # Resubset df to removing working columns added from work_locations_recode
    df = RawSchema(df[TRC_005_COLUMNS])
    return df, auxiliary_df


def trc_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule trc_010

    Args:
        df:
            a pandas dataframe containing records that possibly contain
            invalid work locations
    Returns:
        A pandas dataframe containing information regarding the frequency of
        invalid work locations
    """
    if not auxiliary_df.empty:
        # Group by non-counts columns to get the sum of counts in each invalid record group
        validation_df = auxiliary_df.groupby(
            by=[
                ValidationSchema.work_location,
                ValidationSchema.date,
                ValidationSchema.location,
                ValidationSchema.conveyance_type,
                ValidationSchema.action,
            ],
            dropna=False,
            as_index=False,
        )
        validation_df = validation_df[[ValidationSchema.count]].apply(
            lambda x: x.astype("Int64").sum()
        )

        # Subset to expected output columns 
        validation_df = validation_df[TRC_V010_COLUMNS]
        validation_df = validation_df.sort_values(ValidationSchema.count)
        validation_df = ValidationSchema(validation_df)
    else:
        # If the auxiliary df is empty,
        # return a blank df following the expected output schema
        validationschema_cols = ValidationSchema.to_schema().columns
        validation_df = pd.DataFrame({col: pd.Series(dtype=str(validationschema_cols[col].dtype)) \
                                      for col in TRC_V010_COLUMNS})
    return validation_df
