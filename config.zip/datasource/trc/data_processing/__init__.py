from datasource.trc.data_processing.trc_000 import *
from datasource.trc.data_processing.trc_005 import *
from datasource.trc.data_processing.trc_010 import *
from datasource.trc.data_processing.trc_020 import *
from datasource.trc.data_processing.trc_030 import *
from datasource.trc.data_processing.trc_040 import *
from datasource.trc.data_processing.trc_050 import *
from datasource.trc.data_processing.trc_060 import *