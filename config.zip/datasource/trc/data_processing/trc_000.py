"""
Implements the trc_000 business rule and validation
"""
import pandas as pd

from config.api import DataSource

from modules.utils.data_manipulation import validate_dimensions

from datasource.trc.schema import RawSchema, ValidationSchema


def trc_v000(df: pd.DataFrame) -> pd.DataFrame:
    """
   Provide a visualization for end users to view a summary of unexpected values for discrete variables in TRC.

    Args:
        input:
            a pandas dataframe containing records that possibly contain
            invalid column values
    Returns:
        validation_df_test:
            Validation file summarizing the unexpected values which will be used in dashboards.
    """
    cname_loc = RawSchema.location
    cname_date = RawSchema.date

    # As of April 2023, TRC has been migrated over to the generic dimension validation function
    validation_df = validate_dimensions(
        df=df,
        raw_schema=RawSchema,
        val_schema=ValidationSchema,
        cname_loc=cname_loc,
        cname_date=cname_date,
        datasource=DataSource.trc
    )

    validation_df = ValidationSchema(validation_df)
    return validation_df
