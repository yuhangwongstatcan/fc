"""
Implements the trc_060 Business Rule
"""

import pandas as pd
import logging

from config.api import Mapping
from modules.utils.loaders import Loader

# Travellers imports
from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    COUNTRY_OF_RESIDENCE,
    DURATION2,
    DURATION3,
    DURATION5,
    PURPOSE4,
    PURPOSE9,
    DATA_SOURCE,
    VEHICLE_TYPE,
    TRAVELLER_TYPE,
    MODE,
    PLATE_REGION,
    PLATE_COUNTRY,
    DAY,
)

# TRC imports
from datasource.trc.schema import CleanSchema
from datasource.trc.dim import TRAV_CHAR, CONVEYANCE_TYPE


def trc_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Bryan Southwell - `bryan.southwell.brown@canada.ca`
    - Tristan Garry - `tristan.garry@statcan.gc.ca`

    **Created On:** May, 2021

    **Description:**

    Performs the business logic that transforms cleaned TRC data into TRC's contribution
    to the travellers table.

    Args:
        df: pd.DataFrame


    Returns:
        output:
            A pandas dataframe with TRC's contribution to the travellers table.
    """
    # check for travellers contribution:
    if df[df[CleanSchema.trav_char] != "VEHICLE"].empty:
        logging.info("There is no TRC travellers contribution for this period.")
        print("There is no TRC travellers contribution for this period.")
        return

    # Load mapping file
    country = Loader.get_map_obj(
        Mapping.map__pik__raw__rescntry__pik__clean__country_of_residence
    )

    # Drop entries that should not make it into the travellers table
    df = df[df[CleanSchema.trav_char] != "VEHICLE"].copy()

    # 1. Add a data source column and set it to trc
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.TRC.value

    # Extract date information
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        CleanSchema.date
    ].str.split("-", expand=True)
    # Clean leading 0s
    df[TransformedSchema.month] = df[TransformedSchema.month].replace(
        {r"0(\d)": r"\1"}, regex=True
    )

    # We don't store date info
    df[TransformedSchema.day] = DAY.not_available.value

    # Assign mode values based on documentation
    df.loc[
        df[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.airplane.value,
        TransformedSchema.mode,
    ] = MODE.air.value
    
    df.loc[
        df[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.pleasurecraft.value,
        TransformedSchema.mode,
    ] = MODE.water.value

    df.loc[
        df[CleanSchema.conveyance_type].isin(
                [CONVEYANCE_TYPE.automobile.value, CONVEYANCE_TYPE.snowmobile.value, CONVEYANCE_TYPE.allterrainvehicle.value]
            ),
        TransformedSchema.mode,
    ] = MODE.land.value
    
    # Assign vehicle type values based on documentation
    df.loc[
        df[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.airplane.value,
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.private_aircraft.value
    
    df.loc[
        df[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.pleasurecraft.value,
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.private_boat.value
    
    df.loc[
        df[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.automobile.value,
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.automobile.value

    df.loc[
        df[CleanSchema.conveyance_type].isin([CONVEYANCE_TYPE.snowmobile.value,CONVEYANCE_TYPE.allterrainvehicle.value]),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.other_land_vehicle.value

    # Null plate country and region
    df[TransformedSchema.plate_country] = PLATE_COUNTRY.not_available.value
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value

    # Assign arriving from values based on documentation
    arrive_mask1 = df[CleanSchema.trav_char] == TRAV_CHAR.passenger_usa.value
    arrive_mask2 = df[CleanSchema.trav_char] == TRAV_CHAR.passenger_ovs.value
    arrive_mask3 = (
        df[CleanSchema.trav_char].isin(
            [TRAV_CHAR.passenger_sdy.value, TRAV_CHAR.passenger_ovn.value]
        )
    ) & (
        df[TransformedSchema.country_of_residence].astype(str)
        == COUNTRY_OF_RESIDENCE.united_states.value
    )
    arrive_mask4 = (
        df[CleanSchema.trav_char].isin(
            [TRAV_CHAR.passenger_sdy.value, TRAV_CHAR.passenger_ovn.value]
        )
    ) & (
        df[TransformedSchema.country_of_residence].astype(str)
        != COUNTRY_OF_RESIDENCE.united_states.value
    )

    df.loc[
        arrive_mask1, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.us_only.value
    df.loc[
        ~arrive_mask1 & arrive_mask2, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.ovs_via_us.value
    df.loc[
        ~arrive_mask1 & ~arrive_mask2 & arrive_mask3, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.us_only.value
    df.loc[
        ~arrive_mask1 & ~arrive_mask2 & ~arrive_mask3 & arrive_mask4,
        [TransformedSchema.arriving_from],
    ] = ARRIVING_FROM.ovs_via_us.value

    # Assign purpose based on documentation
    purp_mask1 = df[CleanSchema.location].str.contains("CFB")
    df.loc[purp_mask1, [TransformedSchema.purpose4, TransformedSchema.purpose9]] = [
        PURPOSE4.other_purpose.value,
        PURPOSE9.military.value,
    ]
    df.loc[~purp_mask1, [TransformedSchema.purpose4, TransformedSchema.purpose9]] = [
        PURPOSE4.visit.value,
        PURPOSE9.visit.value,
    ]

    df[TransformedSchema.duration3] = DURATION3.not_available.value
    df[TransformedSchema.duration5] = DURATION5.not_available.value

    # Assign traveller type based on documentation
    travel_mask1 = df[TransformedSchema.purpose4] == PURPOSE4.other_purpose.value
    df.loc[
        travel_mask1, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.other_traveller.value

    travel_mask2 = df[TransformedSchema.duration2] == DURATION2.same_day.value
    df.loc[
        ~travel_mask1 & travel_mask2, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.excursionist.value

    travel_mask3 = df[TransformedSchema.duration2] == DURATION2.overnight.value
    df.loc[
        (~travel_mask1 & ~travel_mask2) & travel_mask3,
        TransformedSchema.traveller_type,
    ] = TRAVELLER_TYPE.tourist.value

    df[TransformedSchema.count_of_entries] = df[CleanSchema.count]
    df = df[TRANSFORMED_COLUMNS]
    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = (
        df.groupby(
            by=TRANSFORMED_GROUPBY,
            dropna=False,
        )
        .sum()
        .reset_index()
        .astype(
            {
                TransformedSchema.count_of_entries: "Int64",
            }
        )
        .fillna(pd.NA)
    )
    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS
    # Reorder the re-named columns
    df = df[TRANSFORMED_COLUMNS]
    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]
    # Sort entries from left to right
    output = df.sort_values(TRANSFORMED_COLUMNS, ascending=True)

    output = TransformedSchema(output)
    return output
