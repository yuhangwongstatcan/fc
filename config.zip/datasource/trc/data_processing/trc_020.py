"""
Implements the trc_020 Business Rule
"""
import pandas as pd

from config.api import DataSource

from config.api import Stage
from config.api import Mapping

from modules.utils.loaders import Loader

from datasource.trc.schema import RawSchema, ValidationSchema, TRC_020_COLUMNS, TRC_V020_COLUMNS
from datasource.countries.schema import ReferenceSchema as CountriesSchema

from config.api import Countries

from datetime import datetime


def trc_020(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Add the Frontier Counts country code to the TRC clean data by linking directly to the countries reference file,
    or to the auxiliary TRC country mapping file.

    Args:
        df:
            A pandas dataframe without fc country codes
    Returns:
        df:
            A pandas dataframe with FC country codes added

        validation_df:
            A pandas dataframe where country of residence is null
    """
    # Load in mapping files
    countries = Loader.get(Stage.REFERENCE, DataSource.countries, Countries.countries)
    countries = CountriesSchema(countries)
    countries["country_name_upper"] = countries[CountriesSchema.country_name_en].str.upper()

    countries_trc = pd.DataFrame(
        Loader.get_map_obj(
            Mapping.map__trc__raw__country__trc__clean__country_of_residence
        )
    )[:-1] # This [:-1] removes the last key, which is a summary of the rest of the dataframe

    # Convert to float, then int, then str
    # The float conversion needs to be done due to a known bug in pandas as seen here: 
    # https://github.com/pandas-dev/pandas/issues/25472
    # The fix seems to have been applied in pandas 1.4, and as of this comment we are using pandas 1.1.4
    countries_trc['value'] = countries_trc['value'].astype('float').astype('Int64').astype('str')
    countries_trc["key"] = countries_trc["key"].str.upper()

    # Map input country names to FC country codes
    df["country_upper"] = df[RawSchema.country].str.upper()

    # first merge df and countries.csv file to bring in country_of_residence
    df = pd.merge(
        df,
        countries,
        left_on="country_upper",
        right_on="country_name_upper",
        how="left",
    )

    # Then use specific trc country mapping file to bring in any unfilled countries of residence
    df = pd.merge(
        df, countries_trc, left_on="country_upper", right_on="key", how="left"
    )

    # Assign "value" from countries_trc to country_of_residence colummns

    # Handle Excel date values
    BASEYEAR = datetime(1900, 1, 1).toordinal()
    COUNTRYEXPIREDATE_EXCEL_TO_INT = (df[CountriesSchema.country_end]).astype("Int64")
    COUNTRYORDINAL = BASEYEAR + COUNTRYEXPIREDATE_EXCEL_TO_INT - 2
    countrycodedatetime = COUNTRYORDINAL.astype('datetime64[ns]')
    todaysdatetime = datetime.today()
    COUNTRYCODE_ISNULL = df[RawSchema.country_of_residence].isnull()
    COUNTRYCODE_EXPIRES = ~df[CountriesSchema.country_end].isnull()
    COUNTRYCODE_ISEXPIRED = todaysdatetime > countrycodedatetime

    value_assignment_mask = ((COUNTRYCODE_ISNULL | (COUNTRYCODE_EXPIRES & COUNTRYCODE_ISEXPIRED)) & ~df["value"].isnull())
    df.loc[value_assignment_mask, RawSchema.country_of_residence] = df.loc[value_assignment_mask, "value"]

    # Auxiliary df is where records of country of residence are null
    auxiliary_df = df[df[RawSchema.country_of_residence].isnull()]

    # Remove any rows that could not be matched with either country file
    df = df[~df[RawSchema.country_of_residence].isnull()]

    # Subset and reset data types 
    df = RawSchema(df[TRC_020_COLUMNS])

    return df, auxiliary_df


def trc_v020(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule TRC_020

    Args:
        input:
            a pandas dataframe containing records that possibly contain
            invalid countries
    Returns:
        The return value of trc_v020
    """
    if not auxiliary_df.empty:
        # Get invalid country and date counts
        validation_df = auxiliary_df.groupby(by=[ValidationSchema.date, 
                                                 ValidationSchema.country],
                                                 dropna=False, 
                                                 as_index=False)
        validation_df = validation_df[[ValidationSchema.count]].apply(
            lambda x: x.astype("Int64").sum()
        )

        validation_df = validation_df[TRC_V020_COLUMNS]
        validation_df = ValidationSchema(validation_df)
    else:
        # If the auxiliary df is empty,
        # return a blank df following the schema
        validationschema_cols = ValidationSchema.to_schema().columns
        validation_df = pd.DataFrame({col: pd.Series(dtype=str(validationschema_cols[col].dtype)) \
                                      for col in TRC_V020_COLUMNS})
    return validation_df
