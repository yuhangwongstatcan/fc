"""
Implements the trc_005 business rule
"""
import pandas as pd

from datasource.trc.schema import RawSchema, TRC_005_COLUMNS

from modules.utils.loaders import Loader

from config.api import Mapping


def trc_005(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add the work location code to the TRC input data, which will be used with the trc
    work location reference file to determine which data is accepted.

    Args:
        df:
            A pandas dataframe without work location
    Returns:
        A pandas dataframe with work location values
    """
    # Load in and process work locations data
    work_locations = Loader.get_map_df(
        Mapping.map__trc__raw__reporting_location__trc__clean__work_location
    )
    work_locations["key"] = work_locations["key"].str.upper()
    work_locations["key"] = work_locations["key"].str.strip()

    # Process df to merge with work locations
    df["temp_work"] = df[RawSchema.location].str.upper()
    df["temp_work"] = df["temp_work"].str.strip()
    df["temp_work"] = df["temp_work"].str.replace(r" - \[TRS\]$", "", regex=True)
    df = pd.merge(
        df, work_locations, left_on=["temp_work"], right_on=["key"], how="left"
    ).fillna(pd.NA)

    df = df.rename(columns={"value": RawSchema.work_location})
    # Output a dataframe with the RawSchema + the work_location column
    df = RawSchema(df[TRC_005_COLUMNS])

    return df