"""
Implements the trc_030 Business Rule
"""
import pandas as pd

from config.api import DataSource, WorkLocations

from config.api import Stage
from config.api import Mapping

from modules.utils.loaders import Loader

from datasource.trc.schema import RawSchema, TRC_030_COLUMNS
from datasource.trc.dim import TRAV_CHAR, DURATION2

from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema


def trc_030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute a duration of same-day or overnight
    for all Canadian resident travellers reported in the TRC system.

    Args:
        df:
            A pandas dataframe without duration for stays for Canadian travellers
    Returns:
        a pandas dataframe with imputed duration of stay
    """
    # Load mapping file and extract important constants
    country = Loader.get_map_obj(
        Mapping.map__pik__raw__rescntry__pik__clean__country_of_residence
    )
    USA = str(country.k_USA.value)
    CANADA = str(country.k_CAN.value)

    # Load work locations reference file
    work_locations = Loader.get(
        Stage.REFERENCE, DataSource.work_locations, WorkLocations.work_locations,
    )
    work_locations = WorkLocationsSchema(work_locations)
    
    # Merge in work locations 
    df = pd.merge(
        df, work_locations, on=[RawSchema.work_location], how="left"
    )

    # Assign trip duration for passenger_SDY travellers
    df.loc[
        (df[RawSchema.trav_char] == TRAV_CHAR.passenger_sdy.value),
        RawSchema.duration2,
    ] = DURATION2.same_day.value
    # Assign trip duration for passenger_OVN travellers
    df.loc[
        (df[RawSchema.trav_char] == TRAV_CHAR.passenger_ovn.value),
        RawSchema.duration2,
    ] = DURATION2.overnight.value

    # Get data that needs to be imputed
    auxiliary_df = df[
        (df[RawSchema.country_of_residence] == CANADA)
        & (
            df[RawSchema.trav_char].isin(
                [TRAV_CHAR.passenger_usa.value, TRAV_CHAR.passenger_ovs.value]
            )
        )
    ]

    US_passengers = df[df[RawSchema.country] == "United States of America"][
        [
            RawSchema.port,
            RawSchema.location,
            RawSchema.count,
            RawSchema.duration2,
            RawSchema.trav_char,
        ]
    ]

    # If there are any rows that need trip duration imputed
    if not auxiliary_df.empty:
        # go through the hierarchial breakdowns starting with movemnt match
        # In case more than one available US passenger with type OVN or SDY, group US_passengers
        US_passengers = US_passengers.groupby(
            by=[
                RawSchema.location,
                RawSchema.trav_char,
                RawSchema.port,
                RawSchema.duration2,
            ],
            dropna=False,
            as_index=False,
        )
        US_passengers = (
            US_passengers[["count"]]
            .apply(lambda x: x.astype("Int64").sum())
            .fillna(pd.NA)
        )
        movement_match = pd.merge(
            auxiliary_df, US_passengers, on=[RawSchema.location], how="left"
        )
        movement_match = movement_match.rename(columns={"duration2_y": "duration2"})
        first_breakdown = movement_match[movement_match["count_y"].isnull()]
        movement_match = movement_match[~movement_match["count_y"].isnull()]
        US_passengers_sum = US_passengers.copy()
        US_passengers_sum["passenger_sum"] = US_passengers_sum[RawSchema.count]
        US_passengers_sum = US_passengers_sum.groupby(
            by=[RawSchema.location, RawSchema.port],
            dropna=False,
            as_index=False,
        )
        US_passengers_sum = (
            US_passengers_sum[["passenger_sum"]]
            .apply(lambda x: x.astype("Int64").sum())
            .fillna(pd.NA)
        )
        movement_match = pd.merge(
            movement_match,
            US_passengers_sum,
            on=[RawSchema.location],
            how="left",
        )
        movement_match = movement_match.drop(
            columns=["duration2_x", "port_y", "port_x", "trav_char_y"]
        )
        movement_match = movement_match.rename(
            columns={
                "duration2_y": RawSchema.duration2,
                "trav_char_x": RawSchema.trav_char,
            }
        )

        # Calculate proportion as the count from the duration category against
        # all travellers with known duration
        movement_match["proportion"] = (
            movement_match["count_y"] / movement_match["passenger_sum"]
        )

        sdy_mask = movement_match[RawSchema.duration2] == DURATION2.same_day.value
        ovn_mask = movement_match[RawSchema.duration2] == DURATION2.overnight.value

        # For same-day travellers, apply the calculated proportion directly to the
        # count of same-day Canadian travellers
        movement_match.loc[sdy_mask, RawSchema.count] = round(
            movement_match["count_x"][sdy_mask] * movement_match["proportion"][sdy_mask]
        )
        # For overnight travellers, use the complement of the proportion and subtract
        # the result from the total number of Canadian travellers.
        # By using this method instead of directly applying the proportion for overnight
        # travellers, we ensure that the original total is respected, even with rounding
        movement_match.loc[ovn_mask, RawSchema.count] = movement_match["count_x"][
            ovn_mask
        ] - round(
            movement_match["count_x"][ovn_mask]
            * (1 - movement_match["proportion"][ovn_mask])
        )
        movement_match = movement_match[TRC_030_COLUMNS]

        if not first_breakdown.empty:
            # Only on port
            first_breakdown = first_breakdown.drop(
                columns=["count_y", "duration2", "duration2_x", "port_y", "trav_char_y"]
            )
            first_breakdown = first_breakdown.rename(
                columns={
                    "count_x": RawSchema.count,
                    "port_x": RawSchema.port,
                    "trav_char_x": RawSchema.trav_char,
                }
            )
            US_passengers = US_passengers.drop(
                columns=[RawSchema.duration2, RawSchema.location]
            )
            US_passengers = US_passengers.groupby(
                by=[RawSchema.trav_char, RawSchema.port],
                dropna=False,
                as_index=False,
            )
            US_passengers = (
                US_passengers[["count"]]
                .apply(lambda x: x.astype("Int64").sum())
                .fillna(pd.NA)
            )
            US_passengers_sum = US_passengers_sum.drop(
                columns=[RawSchema.location]
            )
            US_passengers_sum = US_passengers_sum.groupby(
                by=[RawSchema.port], dropna=False, as_index=False
            )
            US_passengers_sum = (
                US_passengers_sum[["passenger_sum"]]
                .apply(lambda x: x.astype("Int64").sum())
                .fillna(pd.NA)
            )
            first_breakdown = pd.merge(
                first_breakdown, US_passengers, on=[RawSchema.port], how="left"
            )
            second_breakdown = first_breakdown[first_breakdown["count_y"].isnull()]
            first_breakdown = first_breakdown[~first_breakdown["count_y"].isnull()]
            first_breakdown = pd.merge(
                first_breakdown,
                US_passengers_sum,
                on=[RawSchema.port],
                how="left",
            )

            first_breakdown.loc[
                first_breakdown["trav_char_y"] == TRAV_CHAR.passenger_sdy.value,
                [RawSchema.duration2],
            ] = DURATION2.same_day.value
            first_breakdown.loc[
                first_breakdown["trav_char_y"] == TRAV_CHAR.passenger_ovn.value,
                [RawSchema.duration2],
            ] = DURATION2.overnight.value
            first_breakdown = first_breakdown.rename(
                columns={"trav_char_x": RawSchema.trav_char}
            )

            first_breakdown["proportion"] = (
                first_breakdown["count_y"] / first_breakdown["passenger_sum"]
            )

            sdy_mask_fb = first_breakdown[RawSchema.duration2] == DURATION2.same_day.value
            ovn_mask_fb = first_breakdown[RawSchema.duration2] == DURATION2.overnight.value

            first_breakdown.loc[sdy_mask_fb, RawSchema.count] = round(
                first_breakdown["count_x"][sdy_mask_fb]
                * first_breakdown["proportion"][sdy_mask_fb]
            )
            first_breakdown.loc[ovn_mask_fb, RawSchema.count] = first_breakdown[
                "count_x"
            ][ovn_mask_fb] - round(
                first_breakdown["count_x"][ovn_mask_fb]
                * (1 - first_breakdown["proportion"][ovn_mask_fb])
            )

            first_breakdown = first_breakdown[TRC_030_COLUMNS]
            movement_match = movement_match.append(first_breakdown)
            if not second_breakdown.empty:
                # Only on province
                second_breakdown["province"] = (
                    second_breakdown[RawSchema.port]
                    .astype(str)
                    .str.slice(stop=2)
                    .astype(int)
                    .astype("Int64")
                )
                US_passengers["province"] = (
                    US_passengers[RawSchema.port]
                    .astype(str)
                    .str.slice(stop=2)
                    .astype(int)
                    .astype("Int64")
                )
                US_passengers_sum["province"] = (
                    US_passengers_sum[RawSchema.port]
                    .astype(str)
                    .str.slice(stop=2)
                    .astype(int)
                    .astype("Int64")
                )
                US_passengers = US_passengers.drop(columns=[RawSchema.port])
                US_passengers = US_passengers.groupby(
                    by=[RawSchema.trav_char, "province"],
                    dropna=False,
                    as_index=False,
                )
                US_passengers = (
                    US_passengers[["count"]]
                    .apply(lambda x: x.astype("Int64").sum())
                    .fillna(pd.NA)
                )
                US_passengers_sum = US_passengers_sum.drop(
                    columns=[RawSchema.port]
                )
                US_passengers_sum = US_passengers_sum.groupby(
                    by=["province"], dropna=False, as_index=False
                )
                US_passengers_sum = (
                    US_passengers_sum[["passenger_sum"]]
                    .apply(lambda x: x.astype("Int64").sum())
                    .fillna(pd.NA)
                )
                second_breakdown = second_breakdown.drop(
                    columns=["count_y", "trav_char_y"]
                )
                second_breakdown = second_breakdown.rename(
                    columns={
                        "count_x": "count",
                        "trav_char_x": RawSchema.trav_char,
                    }
                )
                second_breakdown = pd.merge(
                    second_breakdown, US_passengers, on=["province"], how="left"
                )
                third_breakdown = second_breakdown[second_breakdown["count_y"].isnull()]
                second_breakdown = second_breakdown[
                    ~second_breakdown["count_y"].isnull()
                ]
                second_breakdown = pd.merge(
                    second_breakdown, US_passengers_sum, on=["province"], how="left"
                )

                second_breakdown.loc[
                    second_breakdown["trav_char_y"] == TRAV_CHAR.passenger_sdy.value,
                    [RawSchema.duration2],
                ] = DURATION2.same_day.value
                second_breakdown.loc[
                    second_breakdown["trav_char_y"] == TRAV_CHAR.passenger_ovn.value,
                    [RawSchema.duration2],
                ] = DURATION2.overnight.value
                second_breakdown = second_breakdown.rename(
                    columns={"trav_char_x": RawSchema.trav_char}
                )

                second_breakdown["proportion"] = (
                    second_breakdown["count_y"] / second_breakdown["passenger_sum"]
                )
                sdy_mask_sb = (
                    second_breakdown[RawSchema.duration2] == DURATION2.same_day.value
                )
                ovn_mask_sb = (
                    second_breakdown[RawSchema.duration2] == DURATION2.overnight.value
                )

                second_breakdown.loc[sdy_mask_sb, RawSchema.count] = round(
                    second_breakdown["count_x"][sdy_mask_sb]
                    * second_breakdown["proportion"][sdy_mask_sb]
                )
                second_breakdown.loc[
                    ovn_mask_sb, RawSchema.count
                ] = second_breakdown["count_x"][ovn_mask_sb] - round(
                    second_breakdown["count_x"][ovn_mask_sb]
                    * (1 - second_breakdown["proportion"][ovn_mask_sb])
                )

                second_breakdown = second_breakdown[TRC_030_COLUMNS]
                movement_match = movement_match.append(second_breakdown)
                if not third_breakdown.empty:
                    # All of Canada
                    third_breakdown = third_breakdown.drop(columns=["count_y"])
                    third_breakdown = third_breakdown.rename(
                        columns={"count_x": "count"}
                    )
                    US_passengers = df[
                        df[RawSchema.country] == "United States of America"
                    ][
                        [
                            RawSchema.date,
                            RawSchema.count,
                            RawSchema.trav_char,
                        ]
                    ]
                    US_passengers["month"] = US_passengers["date"].iloc[0].split("-")[1]
                    third_breakdown["month"] = (
                        third_breakdown["date"].iloc[0].split("-")[1]
                    )
                    US_passengers = US_passengers.groupby(
                        by=["month", RawSchema.trav_char],
                        dropna=False,
                        as_index=False,
                    )
                    US_passengers = (
                        US_passengers[["count"]]
                        .apply(lambda x: x.astype("Int64").sum())
                        .fillna(pd.NA)
                    )
                    US_passengers_sum = US_passengers.copy()
                    US_passengers_sum["passenger_sum"] = US_passengers[
                        RawSchema.count
                    ].sum()
                    US_passengers_sum = US_passengers_sum.groupby(
                        by=["month", RawSchema.trav_char],
                        dropna=False,
                        as_index=False,
                    )
                    US_passengers_sum = (
                        US_passengers_sum[["passenger_sum"]]
                        .apply(lambda x: x.astype("Int64").sum())
                        .fillna(pd.NA)
                    )
                    US_passengers_sum = US_passengers_sum.head(1)
                    third_breakdown = pd.merge(
                        third_breakdown, US_passengers, on=["month"], how="left"
                    )

                    third_breakdown.loc[
                        (third_breakdown["trav_char"] == TRAV_CHAR.passenger_sdy.value),
                        RawSchema.duration2,
                    ] = DURATION2.same_day.value
                    third_breakdown.loc[
                        third_breakdown["trav_char"] == TRAV_CHAR.passenger_ovn.value,
                        [RawSchema.duration2],
                    ] = DURATION2.overnight.value

                    third_breakdown["proportion"] = (
                        third_breakdown["count_y"] / third_breakdown["count_y"].sum()
                    )

                    sdy_mask_tb = (
                        third_breakdown[RawSchema.duration2] == DURATION2.same_day.value
                    )
                    ovn_mask_tb = (
                        third_breakdown[RawSchema.duration2] == DURATION2.overnight.value
                    )

                    third_breakdown.loc[sdy_mask_tb, RawSchema.count] = round(
                        third_breakdown["count_x"][sdy_mask_tb]
                        * third_breakdown["proportion"][sdy_mask_tb]
                    )
                    third_breakdown.loc[
                        ovn_mask_tb, RawSchema.count
                    ] = third_breakdown["count_x"][ovn_mask_tb] - round(
                        third_breakdown["count_x"][ovn_mask_tb]
                        * (1 - third_breakdown["proportion"][ovn_mask_tb])
                    )

                    third_breakdown = third_breakdown[TRC_030_COLUMNS]
                    movement_match = movement_match.append(third_breakdown)

        df = df[~df[RawSchema.duration2].isnull()]
        df = df.append(movement_match) 

    df = RawSchema(df)
    # Subset to get rid of working columns
    return df[TRC_030_COLUMNS]
