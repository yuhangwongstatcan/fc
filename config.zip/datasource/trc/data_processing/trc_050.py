"""
Implements the trc_050 Business Rule
"""
import pandas as pd
import logging

from datasource.vehicles.schema import (
    TransformedSchema, 
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY)
from datasource.trc.schema import CleanSchema

from datasource.vehicles.dim import (
    MODE, 
    VEHICLE_TYPE, 
    DATA_SOURCE, 
    PLATE_REGION, 
    PLATE_COUNTRY, 
    DAY)
from datasource.trc.dim import CONVEYANCE_TYPE


def trc_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Bryan Southwell - `bryan.southwell@canada.ca`

    **Created On:** June, 2021

    **Description:**

    Ensures that all transformations for the VEHICLE dataset can be done
    correctly from the cleaned trc data.

    Args:
        input: pd.DataFrame
            A pandas dataframe with clean data in the CBSA format.

    Returns:
        pd.DataFrame:
            A pandas dataframe containing trc's contribution to the vehicles table.
    """
    # check for vehicles contribution:
    if df[df[CleanSchema.trav_char]=="VEHICLE"].empty:
        logging.info("There is no TRC vehicles contribution for this period.")
        print("There is no TRC vehicles contribution for this period.")
        return
    
    # 1. Add a data source column and set it to trc
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.TRC.value

    # Extract only the rows where trav_char == VEHICLE
    df = df[df[CleanSchema.trav_char]=="VEHICLE"]
    # Create year month and day columns
    df[
        [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
    ] = df[CleanSchema.date].str.split("-", expand=True)

    df[TransformedSchema.month] = df[TransformedSchema.month].replace({r"0(\d)":r"\1"}, regex=True)

    df.loc[:,TransformedSchema.day] = DAY.not_available.value
    df[TransformedSchema.port] = df[CleanSchema.port]

    df[TransformedSchema.mode] = MODE.land.value

    df.loc[df[CleanSchema.conveyance_type]==CONVEYANCE_TYPE.automobile.value, TransformedSchema.vehicle_type] = VEHICLE_TYPE.automobile.value
    df.loc[df[CleanSchema.conveyance_type]==CONVEYANCE_TYPE.snowmobile.value, TransformedSchema.vehicle_type] = VEHICLE_TYPE.other_land_vehicle.value
    df.loc[df[CleanSchema.conveyance_type]==CONVEYANCE_TYPE.allterrainvehicle.value, TransformedSchema.vehicle_type] = VEHICLE_TYPE.other_land_vehicle.value
    
    df.loc[df[CleanSchema.country]=="Canada", TransformedSchema.plate_country] = PLATE_COUNTRY.canada.value
    df.loc[df[CleanSchema.country]=="United States of America", TransformedSchema.plate_country] = PLATE_COUNTRY.united_states.value

    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value

    df[TransformedSchema.count_of_entries] = df[CleanSchema.count]
    df = df[TRANSFORMED_COLUMNS]
    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = (
        df.groupby(
            by=TRANSFORMED_GROUPBY,
            dropna=False,
        ).sum().reset_index()
    )

    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS
    # Reorder the re-named columns
    df = df[TRANSFORMED_COLUMNS]
    df = TransformedSchema(df)
    
    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]
    # Sort entries from left to right
    output = df.sort_values(TRANSFORMED_COLUMNS,ascending=True,)

    return output
