"""
Implements the trc_040 Business Rule
"""
import numpy as np
import pandas as pd

from config.api import DataSource

from config.api import Stage

from config.constants import TRC_040_PROPORTION_DEFAULT

from modules.utils.loaders import Loader

from datasource.trc.schema import CleanSchema, CLEANSCHEMA_COLUMNS
from datasource.vehicles.schema import TransformedSchema as VehiclesSchema
from datasource.travellers.schema import TransformedSchema as TravellersSchema

from datasource.trc.dim import CONVEYANCE_TYPE
from datasource.vehicles.dim import VEHICLE_TYPE

from config.api import S3


def trc_040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Determine number of vehicles in TRC, as well as the licence plate country for the imputed vehicles

    Args:
        df:
            A pandas dataframe without vehicle trav_char rows
    Returns:
        a pandas dataframe with imputed number of vehicles
    """
    year, month, _ = df[CleanSchema.date].iloc[0].split("-")
    year = int(year)
    month = int(month)    
    # Load in reference files
    basename = S3.get_s3_basename(
        Stage.TRANSFORMED, DataSource.ipil_hwy, year, month, 1
    )
    ipil_hwy_vehicles_table = Loader.get(
        Stage.TRANSFORMED, DataSource.vehicles, basename
    )
    ipil_hwy_vehicles_table = VehiclesSchema(ipil_hwy_vehicles_table)

    ipil_hwy_travellers_table = Loader.get(
        Stage.TRANSFORMED, DataSource.travellers, basename
    )
    ipil_hwy_travellers_table = TravellersSchema(ipil_hwy_travellers_table)

    # Get Canadian Travellers by reporting site
    canadian_travellers = (
        df.loc[
            (df[CleanSchema.country] == "Canada"),
            [CleanSchema.count, CleanSchema.location],
        ]
        .groupby(by=[CleanSchema.location], as_index=False)
        .sum(CleanSchema.count)
    ).rename(columns={CleanSchema.count: "canadian_count"})

    # Get American Travellers by reporting site
    american_travellers = (
        df.loc[
            (df[CleanSchema.country] == "United States of America"),
            [CleanSchema.count, CleanSchema.location],
        ]
        .groupby(by=[CleanSchema.location], as_index=False)
        .sum(CleanSchema.count)
    ).rename(columns={CleanSchema.count: "american_count"})

    # Merge in calculated travellers
    df = pd.merge(
        df, canadian_travellers, on=CleanSchema.location, how="left"
    )
    df = pd.merge(
        df, american_travellers, on=CleanSchema.location, how="left"
    )

    # Get totals for Canada, American, and travellers in order to calculate the proportion as described in the documentation
    rows_to_impute = df[
        df[CleanSchema.conveyance_type].isin(
            [CONVEYANCE_TYPE.automobile.value, CONVEYANCE_TYPE.snowmobile.value, CONVEYANCE_TYPE.allterrainvehicle.value]
        )
    ]

    ipil_hwy_vehicles_table = ipil_hwy_vehicles_table[
        (
            ipil_hwy_vehicles_table[VehiclesSchema.vehicle_type].isin(
                [VEHICLE_TYPE.automobile.value, VEHICLE_TYPE.other_land_vehicle.value]
            )
        )
    ]
    ipil_hwy_travellers_table = ipil_hwy_travellers_table[
        (
            ipil_hwy_travellers_table[TravellersSchema.vehicle_type].isin(
                [VEHICLE_TYPE.automobile.value, VEHICLE_TYPE.other_land_vehicle.value]
            )
        )
    ]

    # Sum entries by vehicle and port
    sum_vehicles = ipil_hwy_vehicles_table.groupby(
        by=[VehiclesSchema.port, VehiclesSchema.vehicle_type],
        dropna=False,
        as_index=False,
    )
    sum_vehicles = sum_vehicles[[VehiclesSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    sum_travellers = ipil_hwy_travellers_table.groupby(
        by=[TravellersSchema.port, TravellersSchema.vehicle_type],
        dropna=False,
        as_index=False,
    )
    sum_travellers = sum_travellers[[VehiclesSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    )
    
    # Recode vehicle type according to documentation
    sum_vehicles.loc[
        sum_vehicles[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.automobile.value,
        CleanSchema.conveyance_type,
    ] = CONVEYANCE_TYPE.automobile.value
    sum_vehicles["before_split"] = sum_vehicles["count_of_entries"]
    sum_vehicles.loc[
        sum_vehicles[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        CleanSchema.conveyance_type,
    ] = "Snowmobile,All-Terrain Vehicle"
    sum_vehicles.loc[
        sum_vehicles[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        CleanSchema.conveyance_type,
    ] = sum_vehicles.loc[
        sum_vehicles[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        CleanSchema.conveyance_type,
    ].str.split(",")
    sum_vehicles = sum_vehicles.explode(CleanSchema.conveyance_type)
    sum_vehicles.loc[
        sum_vehicles[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        "count_of_entries",
    ] = np.round(np.ceil(sum_vehicles.loc[
        sum_vehicles[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        "count_of_entries",
    ]*0.5))
    sum_vehicles.loc[
        sum_vehicles[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.allterrainvehicle.value,
        "count_of_entries",
    ] = sum_vehicles.loc[
        sum_vehicles[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.allterrainvehicle.value,
        "before_split",
    ] - sum_vehicles.loc[
        sum_vehicles[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.allterrainvehicle.value,
        "count_of_entries",
    ]
    sum_vehicles = sum_vehicles.drop(columns=["before_split"])

    sum_travellers.loc[
        sum_travellers[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.automobile.value,
        CleanSchema.conveyance_type,
    ] = CONVEYANCE_TYPE.automobile.value
    sum_travellers["before_split"] = sum_travellers["count_of_entries"]
    sum_travellers.loc[
        sum_travellers[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        CleanSchema.conveyance_type,
    ] = "Snowmobile,All-Terrain Vehicle"
    sum_travellers.loc[
        sum_travellers[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        CleanSchema.conveyance_type,
    ] = sum_travellers.loc[
        sum_travellers[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        CleanSchema.conveyance_type,
    ].str.split(",")
    sum_travellers = sum_travellers.explode(CleanSchema.conveyance_type)
    sum_travellers.loc[
        sum_travellers[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        "count_of_entries",
    ] = np.round(np.ceil(sum_travellers.loc[
        sum_travellers[VehiclesSchema.vehicle_type] == VEHICLE_TYPE.other_land_vehicle.value,
        "count_of_entries",
    ]*0.5))
    sum_travellers.loc[
        sum_travellers[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.allterrainvehicle.value,
        "count_of_entries",
    ] = sum_travellers.loc[
        sum_travellers[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.allterrainvehicle.value,
        "before_split",
    ] - sum_travellers.loc[
        sum_travellers[CleanSchema.conveyance_type] == CONVEYANCE_TYPE.allterrainvehicle.value,
        "count_of_entries",
    ]
    sum_travellers = sum_travellers.drop(columns=["before_split"])

    # group by date, district, reporting site, work location, port, conveyance_type (then drop everything else)
    GROUPBY_COLS = [
        CleanSchema.date,
        CleanSchema.district,
        CleanSchema.location,
        CleanSchema.work_location,
        CleanSchema.port,
        CleanSchema.conveyance_type,
    ]
    rows_to_impute = (
        rows_to_impute[
            GROUPBY_COLS + [CleanSchema.count, "canadian_count", "american_count"]
        ]
        .groupby(by=GROUPBY_COLS, as_index=False)
        .sum()
    )

    # Every row in this new table gets `trav_char` = VEHICLE
    rows_to_impute[CleanSchema.trav_char] = "VEHICLE"
    rows_to_impute[CleanSchema.duration2] = pd.NA
    # country and country_of_residence just gets coded to "Canada" or
    # "United States of America" then use the corresponding country of residence code
    # then merge with proportion after so its between [0,1]
    rows_to_impute[CleanSchema.country] = "Canada,United States of America"
    rows_to_impute[CleanSchema.country] = rows_to_impute[
        CleanSchema.country
    ].str.split(",")
    rows_to_impute = rows_to_impute.explode(CleanSchema.country)
    # Fill country_of_residence
    rows_to_impute[CleanSchema.country_of_residence] = pd.NA

    def get_trc_vehicle_proportions(
        sum_vehicles: pd.DataFrame, sum_travellers: pd.DataFrame
    ) -> pd.DataFrame:
        """Given a sum of vehicles/sum of travellers tables, calculates the
        proportion grouped by (1) port (2) province and (3) all of Canada.
        Returns the resulting proportion dataframe to the caller.

        Args:
            sum_vehicles (pd.DataFrame): [description]
            sum_travellers (pd.DataFrame): [description]

        Returns:
            pd.DataFrame: [description]
        """
        proportion = sum_vehicles.copy()
        proportion["proportion"] = (
            sum_vehicles[VehiclesSchema.count_of_entries]
            / sum_travellers[VehiclesSchema.count_of_entries]
        )
        return proportion.drop(columns=["count_of_entries"])

    proportion = get_trc_vehicle_proportions(sum_vehicles, sum_travellers)
    rows_to_impute = pd.merge(
        rows_to_impute,
        proportion,
        on=[CleanSchema.conveyance_type, CleanSchema.port],
        how="left",
    )

    # If rows to impute contains rows that require a proportion, use the
    # province, not just the port.
    if rows_to_impute["proportion"].isnull().any():
        # Recompute sum_vehicles/sum_travellers at province level
        rows_to_impute["province"] = rows_to_impute[CleanSchema.port].str[0:2]
        sum_vehicles["province"] = sum_vehicles[CleanSchema.port].str[0:2]
        sum_vehicles.drop(columns=[CleanSchema.port, "vehicle_type"])
        sum_vehicles = sum_vehicles.groupby(
            by=["province", CleanSchema.conveyance_type], as_index=False
        ).sum("count_of_entries")
        sum_travellers["province"] = sum_travellers[CleanSchema.port].str[0:2]
        sum_travellers.drop(columns=[CleanSchema.port, "vehicle_type"])
        sum_travellers = sum_travellers.groupby(
            by=["province", CleanSchema.conveyance_type], as_index=False
        ).sum("count_of_entries")
        # Recalculate proportions
        proportion = get_trc_vehicle_proportions(sum_vehicles, sum_travellers)
        rows_to_impute = pd.merge(
            rows_to_impute,
            proportion,
            on=[CleanSchema.conveyance_type, "province"],
            how="left",
        )
        rows_to_impute.loc[
            (rows_to_impute["proportion_x"].isna()), "proportion_x"
        ] = rows_to_impute.loc[(rows_to_impute["proportion_x"].isna()), "proportion_y"]
        rows_to_impute = rows_to_impute.rename(columns={"proportion_x": "proportion"})
        rows_to_impute = rows_to_impute.drop(columns=["proportion_y"])
        # If we still have records that need to be imputed, consider all of
        # Canada in the aggregation
        if rows_to_impute["proportion"].isnull().any():
            sum_vehicles = sum_vehicles.drop(columns=["province"])
            sum_vehicles = sum_vehicles.groupby(
                by=[CleanSchema.conveyance_type], as_index=False
            ).sum("count_of_entries")
            sum_travellers = sum_travellers.drop(columns=["province"])
            sum_travellers = sum_travellers.groupby(
                by=[CleanSchema.conveyance_type], as_index=False
            ).sum("count_of_entries")
            proportion = get_trc_vehicle_proportions(sum_vehicles, sum_travellers)
            rows_to_impute = pd.merge(
                rows_to_impute, proportion, on=[CleanSchema.conveyance_type], how="left"
            )
            rows_to_impute.loc[
                (rows_to_impute["proportion_x"].isna()), "proportion_x"
            ] = rows_to_impute.loc[
                (rows_to_impute["proportion_x"].isna()), "proportion_y"
            ]
            rows_to_impute = rows_to_impute.rename(
                columns={"proportion_x": "proportion"}
            )
            rows_to_impute = rows_to_impute.drop(columns=["proportion_y"])
            # If there are still records who have proportion of pd.NA, just
            # assign a default.
            if rows_to_impute["proportion"].isnull().any():
                rows_to_impute.loc[
                    (rows_to_impute["proportion"].isna()), "proportion"
                ] = TRC_040_PROPORTION_DEFAULT
    # Use the proportion to calculated the for Canada and US residence VEHICLE
    CANADA = (rows_to_impute[CleanSchema.country] == "Canada")
    USA = (rows_to_impute[CleanSchema.country] == "United States of America")
    rows_to_impute.loc[CANADA, CleanSchema.count] = np.round(
        (rows_to_impute.loc[CANADA, "canadian_count"])
        / (
            rows_to_impute.loc[CANADA, "canadian_count"]
            + rows_to_impute.loc[CANADA, "american_count"]
        )
        * np.ceil(
            rows_to_impute.loc[CANADA, "proportion"]
            * rows_to_impute.loc[CANADA, "count"]
        )
    )
    rows_to_impute.loc[USA, CleanSchema.count,] = np.round(
        (rows_to_impute.loc[USA, "american_count"])
        / (
            rows_to_impute.loc[USA, "canadian_count"]
            + rows_to_impute.loc[USA, "american_count"]
        )
        * np.ceil(
            rows_to_impute.loc[USA, "proportion"] * rows_to_impute.loc[USA, "count"]
        )
    )
    rows_to_impute = rows_to_impute[CLEANSCHEMA_COLUMNS]
    # Append the VEHICLE rows to input
    df = df.append(rows_to_impute)

    df = CleanSchema(df)

    df = df[df[CleanSchema.count] > 0]
    df = df[CLEANSCHEMA_COLUMNS]
    return df
