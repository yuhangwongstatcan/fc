"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the IPIL Highway data source.
"""
import pandera as pa
from pandera.typing import Series
from typing import Optional

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.ipil_hwy.dim import (
    VEHI,
    COUNTRY,
    PROVINCE,
    CANPASS1,
    CANPASS2,
    WATER_FLAG,
)

from datasource.ipil_hwy.utils import RemovalReasons

from datasource.common.types import SafeIntToStringType

# Field definitions as constants where they are used in both RAW and CLEAN
WATER_FLAG_FIELD = pa.Field(
    description="Indicator variable for if the vehicle passed through a CANPASS lane.",
    isin=WATER_FLAG.list(),
    coerce=True,
    nullable=True,
    raise_warning=True,
)

PORT_FIELD = pa.Field(
    description="Code for the CBSA port of entry that the vehicle passed through.",
    str_matches=r"\d{5}",
    coerce=True,
)

COUNTRY_OF_RESIDENCE_FIELD = pa.Field(
    description="The country code corresponding to the country of residence for the travellers.",
    str_matches=r"\d{5}",
    nullable=True,
    coerce=True,
)


class RawSchema(FCSchemaModel):
    """
    Schema for the IPIL Highway RAW data.
    """

    vehi: Series[pa.String] = pa.Field(
        description="Vehicle type, either automobile, motorcycle, commercial truck, bus, pedestrian or other land vehicle.",
        isin=VEHI.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    cdsd: Series[pa.INT64] = pa.Field(
        description="Number of same-day Canadian resident travellers in the vehicle.",
        ge=0,  # There must be zero or more same-day passengers
        nullable=True,
        coerce=True,
    )
    cd1d: Series[pa.INT64] = pa.Field(
        description="Number of one-night Canadian resident travellers in the vehicle.",
        ge=0,
        nullable=True,
        coerce=True,
    )
    cd2d: Series[pa.INT64] = pa.Field(
        description="Number of two-or-more-night Canadian resident travellers in the vehicle.",
        ge=0,
        nullable=True,
        coerce=True,
    )
    ussd: Series[pa.INT64] = pa.Field(
        description="Number of same-day American resident travellers in the vehicle.",
        ge=0,  # There must be zero or more same-day passengers
        nullable=True,
        coerce=True,
    )
    us1d: Series[pa.INT64] = pa.Field(
        description="Number of one-night American resident travellers in the vehicle.",
        ge=0,
        nullable=True,
        coerce=True,
    )
    us2d: Series[pa.INT64] = pa.Field(
        description="Number of two-or-more-night American resident travellers in the vehicle.",
        ge=0,
        nullable=True,
        coerce=True,
    )
    osd: Series[pa.INT64] = pa.Field(
        description="Number of same-day overseas resident travellers in the vehicle.",
        ge=0,  # There must be zero or more same-day passengers
        nullable=True,
        coerce=True,
    )
    o1d: Series[pa.INT64] = pa.Field(
        description="Number of one-night overseas resident travellers in the vehicle.",
        ge=0,
        nullable=True,
        coerce=True,
    )
    o2d: Series[pa.INT64] = pa.Field(
        description="Number of two-or-more-night overseas resident travellers in the vehicle.",
        ge=0,
        nullable=True,
        coerce=True,
    )
    country: Series[pa.String] = pa.Field(
        description="Country of the licence plate of the vehicle, either Canada, United States, Mexico, Puerto Rico or Other (XX)",
        isin=COUNTRY.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    date: Series[pa.String] = pa.Field(
        description="Date that the vehicle crossed the border.",
        str_matches=r"\d{4}\/(0[1-9]|1[012])\/(0[1-9]|[12][0-9]|3[01])",  # I.e. date looks like YYYY/MM/DD
        nullable=True,
        coerce=True,
    )
    sin: Series[pa.INT64] = pa.Field(
        description="Time the vehicle crossed into the border checkpoint (number of seconds past midnight on the current day).",
        ge=0,
        le=86400,
        coerce=True,
    )
    sout: Series[pa.INT64] = pa.Field(
        description="Time the vehicle passed out of the border checkpoint (number of seconds past midnight on the current day).",
        ge=0,
        le=86400,
        coerce=True,
    )
    lane: Series[pa.String] = pa.Field(
        description="Lane which the vehicle passed through the port of entry, or mobile device identification that was used to process the vehicle",
        coerce=True,
    )
    cport: Series[SafeIntToStringType] = pa.Field(
        description="Code for the CBSA work location that the vehicle passed through.",
        str_matches=r"\d{4}",
        coerce=True,
    )
    province: Series[pa.String] = pa.Field(
        description="Region (province or state) of the licence plate of the vehicle.",
        isin=PROVINCE.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    canpass1: Series[pa.String] = pa.Field(
        description="Indicator variable for if the travellers are members of the CANPASS program.",
        isin=CANPASS1.list(),
        coerce=True,
        raise_warning=True,
    )
    canpass2: Series[pa.String] = pa.Field(
        description="Indicator variable for if the vehicle passed through a CANPASS lane.",
        isin=CANPASS2.list(),
        coerce=True,
        raise_warning=True,
    )
    water_flag: Optional[Series[pa.String]] = WATER_FLAG_FIELD
    port: Optional[Series[SafeIntToStringType]] = PORT_FIELD
    country_of_residence: Optional[
        Series[SafeIntToStringType]
    ] = COUNTRY_OF_RESIDENCE_FIELD

    @staticmethod
    def get_keys():
        return [
            RawSchema.date,
            RawSchema.sin,
            RawSchema.lane,
            RawSchema.cport,
        ]


class CleanSchema(RawSchema):
    """
    Schema for the IPIL Highway CLEAN data.
    """

    water_flag: Series[pa.String] = WATER_FLAG_FIELD
    port: Series[SafeIntToStringType] = PORT_FIELD
    country_of_residence: Series[SafeIntToStringType] = COUNTRY_OF_RESIDENCE_FIELD


class ValidationSchema(pa.SchemaModel):
    """
    Schema for variables appearing in validation output but not in RAW or CLEAN IPIL Highway data.
    All elements are defined as optional because the schema is used across all validations and
    specific columns may appear in certain validations, but not in others.
    """

    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of an IPIL Highway dimension variable with unexpected values.",
        coerce=True,
    )
    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value observed in an IPIL-Highway dimension variable.",
        coerce=True,
        nullable=True,
    )
    location: Optional[Series[pa.String]] = pa.Field(
        description="Geographical location where an unexpected dimension variable occurred.",
        str_matches=r"\d{4}",
        coerce=True,
    )
    from_vehi: Optional[Series[pa.String]] = pa.Field(
        description="Vehicle type that a recoded record is being changed FROM.",
        coerce=True,
        nullable=True,
    )
    to_vehi: Optional[Series[pa.String]] = pa.Field(
        description="Vehicle type that a recoded record is being changed TO.",
        coerce=True,
    )
    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences of a particular validation case.",
        ge=0,
        coerce=True,
    )
    bus_recoded: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of records where overfull cars were recoded to buses.",
        ge=0,
        coerce=True,
    )
    unchanged_bus: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of records where the original vehicle type was bus.",
        ge=0,
        coerce=True,
    )
    unchanged_car: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of records where cars were not recoded to bus because the number of passengers was sufficiently low.",
        ge=0,
        coerce=True,
    )
    total_passengerscount: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of records for a particular validation case.",
        gt=0,
        coerce=True,
    )
    total_passengerssum: Optional[Series[pa.INT64]] = pa.Field(
        description="Sum of travellers for a particular validation case.",
        ge=0,
        coerce=True,
    )
    removal_reason: Optional[Series[pa.String]] = pa.Field(
        description="Reason that a record was removed from IPIL Highway RAW data.",
        isin=RemovalReasons.list(),
        coerce=True,
    )
    imputation_method: Optional[Series[pa.String]] = pa.Field(
        description="Method used to impute country of residence in IPIL Highway.",
        coerce=True,
    )
