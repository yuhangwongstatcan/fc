#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import argparse
import tempfile
import shutil
import zipfile
import pathlib
from os.path import join
from os.path import basename

from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage
from config.api import DEFAULT_BUCKET

import multiprocessing
from modules.utils.data_manipulation import process_files
from modules.utils.data_manipulation import upload_files

from datasource.ipil_hwy.schema import RawSchema

# List of columns to sort IPIL Highway by for raw
IPIL_HIGHWAY_SORT_COLUMNS = RawSchema.get_keys()


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load ipil_hwy data from the momentary S3Location.
    This is the loader entry point for the ipil_hwy datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """

    zippath = tempfile.mkdtemp()

    print(f"Inspecting s3 location: {location.bucket} {location.prefix}")

    # List all the files inside the S3Location looking for zip or sigular .dat files.
    # All files are download and extracted in a temporary local folder.

    pool_unzip = multiprocessing.Pool(multiprocessing.cpu_count())
    print(f"\tDownloaded:")
    for obj in client.ls_objs(
        location.bucket,
        recursive=True,
        prefix=location.prefix,
        only_files=True,
        default_folder_file=False,
    ):
        localname = join(zippath, basename(obj.object_name))
        client.fget_object(location.bucket, obj.object_name, localname)
        print(f"\t\t{localname}")
        pool_unzip.apply_async(
            unzip, args=(localname, zippath,), callback=success, error_callback=error,
        )

    pool_unzip.close()
    pool_unzip.join()

    files = sorted([f.as_posix() for f in pathlib.Path(zippath).rglob("*.dat")])
    tmpdir = tempfile.mkdtemp()

    # Get the index position of the date column. Headers are labelled as index at this point
    date_position = list(RawSchema.to_schema().columns.keys()).index(RawSchema.date)

    processed = process_files(
        files,  # List with full filenames of files to process
        tmpdir,  # Temporary directory to store the output
        stage,
        DataSource.ipil_hwy,
        date_position,  # Column name of the date field
        "(\d{4})\/(\d{2})\/(\d{2})",  # Regular expression of the date column, allowing you to capture year,month,day
        ",",  # CSV separator
        None,
    )  # Header

    # If processing failed, then return False so the file can be triaged to the
    # 'error' location on s3 object storage.
    if not processed:
        return False
    upload_files(
        client,
        processed,
        stage,
        DataSource.ipil_hwy,
        RawSchema,
        IPIL_HIGHWAY_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )

    shutil.rmtree(zippath)
    shutil.rmtree(tmpdir)
    return True


def unzip(localname, dirpath):
    if zipfile.is_zipfile(localname):
        print(f"extracting: {localname}")
        with zipfile.ZipFile(localname, "r") as zip_ref:
            zip_ref.extractall(dirpath)


def error(*args, **k):
    print(args, k)


def success(*a, **k):
    pass
    # print(a,k)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="Loading")
    parser.add_argument("--bucket", default=DEFAULT_BUCKET)
    parser.add_argument(
        "--prefix", default="processing/IPIL/2020_11_27_14:42:19.923851178/"
    )
    parser.add_argument("--basename", default="")
    args = parser.parse_args()

    client = S3Client.get_client()
    loc = S3Location(bucket=args.bucket, prefix=args.prefix, basename=args.basename)
    loader(client, loc)
