"""
    Program: dim.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Create enumerable classes of dimension variables and their possible values
        to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from enum import auto
from config.api import AutoEnum


class VEHI(AutoEnum):

    car = "A"
    bus = "B"
    truck = "C"
    motorcycle = "M"
    other_land_vehicle = "O"
    pedestrian = "P"
    non_motorized = "N"


class COUNTRY(AutoEnum):

    canada = "CD"
    canada_legacy = "CA"
    mexico = "MX"
    puerto_rico = "PR"
    united_states = "US"
    XX = auto()
    other = "Other"


class PROVINCE(AutoEnum):
    AB = auto()
    AK = auto()
    AL = auto()
    AR = auto()
    AZ = auto()
    BC = auto()
    CA = auto()
    CG = auto()
    CO = auto()
    CT = auto()
    DC = auto()
    DE = auto()
    FL = auto()
    GA = auto()
    HI = auto()
    IA = auto()
    ID = auto()
    IL = auto()
    IN = auto()
    KS = auto()
    KY = auto()
    LA = auto()
    MA = auto()
    MB = auto()
    MD = auto()
    ME = auto()
    MEX = auto()
    MI = auto()
    MN = auto()
    MO = auto()
    MS = auto()
    MT = auto()
    MX = auto()
    MXC = auto()
    NA = auto()
    NB = auto()
    NC = auto()
    ND = auto()
    NE = auto()
    NH = auto()
    NJ = auto()
    NL = auto()
    NM = auto()
    NS = auto()
    NT = auto()
    NU = auto()
    NV = auto()
    NY = auto()
    OH = auto()
    OK = auto()
    ON = auto()
    OR = auto()
    PA = auto()
    PE = auto()
    PR = auto()
    QC = auto()
    RI = auto()
    SC = auto()
    SD = auto()
    SK = auto()
    TN = auto()
    TX = auto()
    UT = auto()
    VA = auto()
    VT = auto()
    WA = auto()
    WI = auto()
    WV = auto()
    WY = auto()
    XX = auto()
    YT = auto()


class CANPASS1(AutoEnum):
    yes = auto()
    no = auto()


class CANPASS2(AutoEnum):
    yes = auto()
    no = auto()


class WATER_FLAG(AutoEnum):
    ferry = auto()
    private_boat = "private watercraft"


class STATE_LIST(AutoEnum):
    AK = auto()
    AL = auto()
    AR = auto()
    AZ = auto()
    CA = auto()
    CO = auto()
    CT = auto()
    DC = auto()
    DE = auto()
    FL = auto()
    GA = auto()
    HI = auto()
    IA = auto()
    ID = auto()
    IL = auto()
    IN = auto()
    KS = auto()
    KY = auto()
    LA = auto()
    MA = auto()
    MD = auto()
    ME = auto()
    MI = auto()
    MN = auto()
    MO = auto()
    MS = auto()
    MT = auto()
    NC = auto()
    ND = auto()
    NE = auto()
    NH = auto()
    NJ = auto()
    NM = auto()
    NV = auto()
    NY = auto()
    OH = auto()
    OK = auto()
    OR = auto()
    PA = auto()
    RI = auto()
    SC = auto()
    SD = auto()
    TN = auto()
    TX = auto()
    UT = auto()
    VA = auto()
    VT = auto()
    WA = auto()
    WI = auto()
    WV = auto()
    WY = auto()


class PROVINCE_LIST(AutoEnum):
    AB = auto()
    BC = auto()
    MB = auto()
    NB = auto()
    NL = auto()
    NS = auto()
    NT = auto()
    NU = auto()
    ON = auto()
    PE = auto()
    QC = auto()
    SK = auto()
    YT = auto()
