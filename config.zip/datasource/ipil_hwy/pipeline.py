"""
**Author(s)**

    Jacob Doering (jacob.doering@statcan.gc.ca)

**Created:** March 2023

**Description:**

The pipeline definitions for the ipil_hwy data source.
Two pipelines are defined in this module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`
"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID
from modules.pipeline import validation_writer

from config.api import Stage
from config.api import DataSource
from config.api import S3

from datasource.ipil_hwy.data_processing import *
from datasource.ipil_hwy.schema import RawSchema, CleanSchema
from datasource.ipil_hwy.dim import *

from datasource.vehicles.schema import TransformedSchema as VehiclesSchema
from datasource.travellers.schema import TransformedSchema as TravellersSchema


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the IPIL Highway data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data file created by the loader
        df = Loader.query(Stage.RAW, self.datasource, year=self.year, month=self.month)

        # Make sure that the df adheres to the raw schema
        df = RawSchema(df)

        # VALIDATION: Check for unexpected values in dimension variables
        print("   1.Starting processing ipil_hwy_000")
        df, validation_df = ipil_hwy_v000(df)
        validation_writer(validation_df, ipil_hwy_v000, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_000")
        print("   1.Finished processing ipil_hwy_000")

        # Remove unused data based on unexpected work locations or vehicle types
        print("   2.Starting processing ipil_hwy_010")
        df, auxiliary_df = ipil_hwy_010(df)
        # VALIDTION: Check for new or unexpected data / work locations
        validation_df = ipil_hwy_v010(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v010, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_010")
        print("   2.Finished processing ipil_hwy_010")

        # VALIDATION: Daily volume of IPIL Highway travellers
        print("   3.Starting processing ipil_hwy_030")
        df, validation_df = ipil_hwy_v030(df)
        validation_writer(validation_df, ipil_hwy_v030, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_030")
        print("   3.Finished processing ipil_hwy_030")

        # Recode any legacy Canada "CA" codes to "CD"
        df = ipil_hwy_040(df)

        # Recode country to United States for any valid state licence plate codes
        df = ipil_hwy_050(df)

        # Recode country to Canada for any valid province licence plate codes
        df = ipil_hwy_060(df)

        # Recode licence plate country and state for Mexico and Puerto Rico
        df = ipil_hwy_070(df)

        # Recode overfull cars (8+ passengers) as buses
        print("   4.Starting processing ipil_hwy_080")
        df, auxiliary_df = ipil_hwy_080(df)
        # VALIDATION: Summarize the recoding of overfull buses
        validation_df = ipil_hwy_v080(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v080, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_080")
        print("   4.Finished processing ipil_hwy_080")

        # Remove invalid records - blank province of licence plate (excluding Mexico)
        print("   5.Starting processing ipil_hwy_090")
        df, auxiliary_df = ipil_hwy_090(df)
        # VALIDATION: Summarize the invalid records with blank province of licence plate
        validation_df = ipil_hwy_v090(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v090, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_090")
        print("   5.Finished processing ipil_hwy_090")

        # Remove invalid records - zero or missing number of travellers
        print("   6.Starting processing ipil_hwy_100")
        df, auxiliary_df = ipil_hwy_100(df)
        # VALIDATION: Summarize the invalid records with zero or missing number of travellers
        validation_df = ipil_hwy_v100(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v100, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_100")
        print("   6.Finished processing ipil_hwy_100")

        # Remove invalid records - duplicates
        print("   7.Starting processing ipil_hwy_110")
        df, auxiliary_df = ipil_hwy_110(df)
        # VALIDATION: Summarize the invalid duplicate records
        validation_df = ipil_hwy_v110(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v110, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_110")
        print("   7.Finished processing ipil_hwy_110")

        # Remove invalid records - missing dates
        print("   8.Starting processing ipil_hwy_120")
        df, auxiliary_df = ipil_hwy_120(df)
        # VALIDATION: Summarize the invalid records with missing dates
        validation_df = ipil_hwy_v120(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v120, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_120")
        print("   8.Finished processing ipil_hwy_120")

        # Impute overfull trucks using a nearest neighbour donor record
        print("   9.Starting processing ipil_hwy_130")
        df, auxiliary_df = ipil_hwy_130(df)
        # vALIDATION: Summarize the imputed overfull truck records
        validation_df = ipil_hwy_v130(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v130, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_130")
        print("   9.Finished processing ipil_hwy_130")

        # Impute overfull buses using a nearest neighbour donor record
        print("   10.Starting processing ipil_hwy_140")
        df, auxiliary_df = ipil_hwy_140(df)
        # vALIDATION: Summarize the imputed overfull bus records
        validation_df = ipil_hwy_v140(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v140, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_140")
        print("   10.Finished processing ipil_hwy_140")

        # Impute overfull motorcycles using a nearest neighbour donor record
        print("   11.Starting processing ipil_hwy_150")
        df, auxiliary_df = ipil_hwy_150(df)
        # VALIDATION: Summarize the imputed overfull motorcycle records
        validation_df = ipil_hwy_v150(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v150, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_150")
        print("   11.Finished processing ipil_hwy_150")

        # Impute country of residence for overseas travellers
        print("   12.Starting processing ipil_hwy_v155")
        df, auxiliary_df = ipil_hwy_155(df)
        # VALIDATION: Summarize the imputed countries of residence
        validation_df = ipil_hwy_v155(df, auxiliary_df)
        validation_writer(validation_df, ipil_hwy_v155, self.datasource, self.date)
        logging.info("Finished processing ipil_hwy_v155")
        print("   12.Finished processing ipil_hwy_v155")

        # Make sure the output dataframe adheres to the clean schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        ipil_hwy_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=DataSource.ipil_hwy,
            basename=S3.get_s3_basename(
                Stage.CLEAN, DataSource.ipil_hwy, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.ipil_hwy.value] = ipil_hwy_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the IPIL Highway data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        df = Loader.query(
            Stage.CLEAN, self.datasource, year=self.year, month=self.month
        )

        # Make sure that the input df adheres to the clean schema
        df = CleanSchema(df)

        # Perform the tranformation to get the vehicles table
        vehicles = ipil_hwy_160(df)

        # Make sure that the vehicles df adheres to the transformed schema
        vehicles = VehiclesSchema(vehicles)

        # Perform the transformation to get the travellers table
        travellers = ipil_hwy_170(df)

        # Make sure that the travellers df adheres to the transformed schema
        travellers = TravellersSchema(travellers)

        # Save vehicles/travellers outputs to dictionary
        vehicles_output = PipelineOutput(
            data=vehicles,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.vehicles,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, DataSource.ipil_hwy, self.year, self.month, self.day
            ),
        )
        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, DataSource.ipil_hwy, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.vehicles.value] = vehicles_output
        self.outputs[DataSource.travellers.value] = travellers_output
