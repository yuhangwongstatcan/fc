import pandas as pd

from datasource.ipil_hwy.utils import get_total_passengers, df_groupby
from datasource.ipil_hwy.utils import RemovalReasons
from datasource.ipil_hwy.schema import RawSchema, ValidationSchema


def ipil_hwy_110(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes duplicates by removing records with the same work location (CPORT),
    lane, date, and time in (SIN). Keeps first entry by default.

    Args:
        df:
            A pandas dataframe considering all records that should be scanned
            for duplicates. When multiple files are considered, it is assumed
            that input has already concatenated them all into a single input.
    Returns:
        df:
            A pandas dataframe with all duplicates removed.
        auxiliary_df:
            A pandas dataframe of the removed duplicate records.
    """
    mask = df.duplicated(
        [RawSchema.cport, RawSchema.lane, RawSchema.date, RawSchema.sin]
    )
    auxiliary_df = pd.DataFrame()
    auxiliary_df = auxiliary_df.append(df.loc[mask])
    df = df.loc[~mask]

    return df, auxiliary_df


def ipil_hwy_v110(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_110

    Args:
        df:
            A pandas dataframe with duplicates removed.
        auxiliary_df:
            A pandas dataframe of removed duplicate records.
    Returns:
        validation_df:
            A summary dataframe of the records removed in ipil_hwy_110 that will be
            used in the validation dashboards.
    """
    auxiliary_df = get_total_passengers(auxiliary_df, RawSchema)

    groupby_set = [RawSchema.date, RawSchema.cport, RawSchema.country]
    aggregations = ["count", "sum"]
    validation_df = df_groupby(
        df=auxiliary_df,
        groupby_set=groupby_set,
        aggregation_column="total_passengers",
        aggregation=aggregations,
    ).astype(
        {
            ValidationSchema.total_passengerscount: "Int64",
            ValidationSchema.total_passengerssum: "Int64",
        }
    )

    validation_df[RawSchema.date] = validation_df[RawSchema.date].str.replace("/", "-")
    # Specify removal reason
    validation_df[ValidationSchema.removal_reason] = RemovalReasons.duplicate.value

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
