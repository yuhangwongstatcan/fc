import pandas as pd

from datasource.ipil_hwy.schema import RawSchema
from datasource.ipil_hwy.dim import COUNTRY, PROVINCE_LIST


def ipil_hwy_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensures that any records with a valid Canadian province licence plate are
    (re)coded as country "CD".

    Args:
        input:
            a pandas dataframe where a valid Canadian province may contain
            a country code that does not equal "CD".

    Returns:
        a pandas dataframe where all valid Canadian provinces contain the
        country code "CD"
    """
    mask = (df[RawSchema.province].isin(PROVINCE_LIST.list())) & (
        df[RawSchema.country] != COUNTRY.canada.value
    )
    df.loc[mask, RawSchema.country] = COUNTRY.canada.value

    return df
