import pandas as pd

from datasource.ipil_hwy.utils import get_total_passengers, df_groupby
from datasource.ipil_hwy.utils import RemovalReasons
from datasource.ipil_hwy.schema import RawSchema, ValidationSchema


def ipil_hwy_100(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensures that any records with zero travellers or a missing number of passengers are removed.

    Args:
        df:
            A pandas dataframe that possibly contains records with zero or
            a missing number of passengers.
    Returns:
        df:
            A pandas dataframe that removes all records where number of passengers
            is zero or missing.
        auxiliary_df:
            A pandas dataframe containing records with zero or a missing number
            of travellers that will be summarized for validation.
    """
    # Note: Pandas treats NaN as zeros when summing. So if the sum of the nine
    # columns below is zero, all values were either NaN, zero, or some
    # combination of the two. Want to keep all rows with at least one traveller.
    mask = get_total_passengers(df, RawSchema)["total_passengers"] > 0
    auxiliary_df = df[~mask]
    # Restrict the output to only the schema columns
    df = df[mask].drop(["total_passengers"], axis=1)

    return df, auxiliary_df


def ipil_hwy_v100(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_100

    Args:
        df:
            A pandas dataframe with zero or missing number of traveller records removed.
        auxiliary_df:
            A pandas dataframe of zero or missing number of traveller records.
    Returns:
        validation_df:
            A summary dataframe of the records removed in ipil_hwy_100 that will be
            used in the validation dashboards.
    """

    groupby_set = [RawSchema.date, RawSchema.cport, RawSchema.country]
    aggregations = ["count", "sum"]
    validation_df = df_groupby(
        df=auxiliary_df,
        groupby_set=groupby_set,
        aggregation_column="total_passengers",
        aggregation=aggregations,
    ).astype(
        {
            ValidationSchema.total_passengerscount: "Int64",
            ValidationSchema.total_passengerssum: "Int64",
        }
    )
    validation_df[RawSchema.date] = validation_df[RawSchema.date].str.replace("/", "-")
    # Specify removal reason
    validation_df[
        ValidationSchema.removal_reason
    ] = RemovalReasons.zero_travellers.value

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
