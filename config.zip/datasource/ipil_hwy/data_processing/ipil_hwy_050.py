import pandas as pd

from datasource.ipil_hwy.schema import RawSchema
from datasource.ipil_hwy.dim import COUNTRY, STATE_LIST


def ipil_hwy_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensures that any records with a valid U.S. state licence plate are
    (re)coded as country "US".

    Args:
        df:
            A pandas dataframe where a valid US state may contain a country
            code that does not equal "US".

    Returns:
        df:
            A pandas dataframe where all valid US states contain the country
            code "US"
    """
    mask = (df[RawSchema.province].isin(STATE_LIST.list())) & (
        df[RawSchema.country] != COUNTRY.united_states.value
    )
    df.loc[mask, RawSchema.country] = COUNTRY.united_states.value

    return df
