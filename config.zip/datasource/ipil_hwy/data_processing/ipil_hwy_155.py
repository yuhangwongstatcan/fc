from datetime import datetime
import logging

import numpy as np
import pandas as pd
from minio.error import NoSuchKey

from config.constants import (
    COUNTRY_NOT_APPLICABLE,
    COUNTRY_OVERSEAS,
    COUNTRY_CANADA,
    COUNTRY_USA,
)
from config.constants import BC_YT, AB, SK_MB, ON, QC, NB_NS

from config.api import Countries
from config.api import Mapping
from config.api import DataSource
from config.api import Stage
from config.api import S3

from modules.utils.loaders import Loader

from datasource.ipil_hwy.schema import RawSchema, CleanSchema, ValidationSchema
from datasource.ipil_hwy.dim import VEHI, WATER_FLAG

from datasource.manual_entry_travellers.schema import CleanSchema as ManualEntrySchema

from datasource.travellers.schema import TransformedSchema
from datasource.travellers.dim import TRAVELLER_TYPE
from datasource.common.dim import VEHICLE_TYPE

from datasource.mapping.schema import ReferenceSchema as MappingSchema
from datasource.countries.schema import ReferenceSchema as CountriesSchema
from datasource.provinces_and_territories.schema import ReferenceSchema as PTSchema
from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema


def ipil_hwy_155(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute country of residence for overseas travellers in IPIL Highway

    Args:
        df:
            A pandas dataframe with only a generic overseas category.

    Returns:
        df:
            A pandas dataframe which has a country of residence assigned to
            each record.
    """
    #  ____  _____ _____ _   _ ____
    # / ___|| ____|_   _| | | |  _ \
    # \___ \|  _|   | | | | | | |_) |
    #  ___) | |___  | | | |_| |  __/
    # |____/|_____| |_|  \___/|_|
    # TODO: investigate why indexes are changed prior to this point.
    df = df.reset_index()

    # Mappings
    ipil_vehicle_type_map = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__ipil_hwy__clean__vehi__travellers__transformed__vehicle_type,
    )
    ipil_vehicle_type_map = MappingSchema(ipil_vehicle_type_map)

    ipil_vehicle_type_map = ipil_vehicle_type_map.rename(
        columns={
            MappingSchema.key: CleanSchema.vehi,
            MappingSchema.value: ManualEntrySchema.vehicle_type,
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)

    # Reference Tables
    countries = Loader.get(Stage.REFERENCE, DataSource.countries, Countries.countries)
    countries = CountriesSchema(countries)

    provinces = Loader.get(Stage.REFERENCE, DataSource.provinces_and_territories, None)
    provinces = PTSchema(provinces)

    # Runtime Parameters

    # Note that we get the year/month by inspecting the first row of the input
    # dataframe (all rows have the same year/month by definition)
    DATE = datetime.strptime(df[CleanSchema.date].iloc[0], "%Y/%m/%d")
    # Generate and set the random seed for numpy's PRN generator
    RANDOM_SEED = int(f"{DATE.year}{DATE.month:02d}")
    np.random.seed(RANDOM_SEED)

    # Masks

    IS_OVERSEAS = (
        df[[CleanSchema.osd, CleanSchema.o1d, CleanSchema.o2d,]].sum(axis=1) > 0
    )

    #  ____  ____  _____ ____  ____   ___   ____ _____ ____ ____
    # |  _ \|  _ \| ____|  _ \|  _ \ / _ \ / ___| ____/ ___/ ___|
    # | |_) | |_) |  _| | |_) | |_) | | | | |   |  _| \___ \___ \
    # |  __/|  _ <| |___|  __/|  _ <| |_| | |___| |___ ___) |__) |
    # |_|   |_| \_\_____|_|   |_| \_\\___/ \____|_____|____/____/

    # We have to add a `vehicle_type` column to ipil_hwy to merge records
    # from the various reference distributions.
    df = df.reset_index(drop=True)
    df = pd.merge(df, ipil_vehicle_type_map, on=[CleanSchema.vehi], how="left")

    # Special case 1: if water_flag == private boat then
    # vehicle_type <- "321" (Private boats)
    df.loc[
        df[CleanSchema.water_flag] == WATER_FLAG.private_boat.value,
        ManualEntrySchema.vehicle_type,
    ] = VEHICLE_TYPE.private_boat.value

    # Special case 2: if water_flag == ferry and vehi = "P" then
    # vehicle_type <- "314" (Pedestrians aboard ferries)
    df.loc[
        (df[CleanSchema.water_flag] == WATER_FLAG.ferry.value)
        & (df[CleanSchema.vehi] == VEHI.pedestrian.value),
        ManualEntrySchema.vehicle_type,
    ] = VEHICLE_TYPE.ferry_pedestrian.value

    # Special case 3: if water_flag == ferry and vehi != "P" then
    # vehicle_type <- "313" (Private vehicles aboard ferries)
    df.loc[
        (df[CleanSchema.water_flag] == WATER_FLAG.ferry.value)
        & (df[CleanSchema.vehi] != VEHI.pedestrian.value),
        ManualEntrySchema.vehicle_type,
    ] = VEHICLE_TYPE.ferry_private_vehicle.value

    # Merge ipil_hwy input with the work_locations table to get the port
    # corresponding to each work location.
    work_locations = Loader.get(Stage.REFERENCE, DataSource.work_locations, None)
    work_locations = WorkLocationsSchema(work_locations)

    df = pd.merge(
        df,
        work_locations[[WorkLocationsSchema.port, WorkLocationsSchema.work_location]],
        left_on=CleanSchema.cport,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )
    # Re-coerce the schema after the pd.merge
    df = RawSchema(df)

    # For every row that is overseas, assign the row a random number between 0
    # and 1 from a uniform distribution.
    df["random_number"] = np.random.uniform(0, 1, len(df))

    # Placeholder for `country_of_residence` column
    df[CleanSchema.country_of_residence] = pd.NA

    # Placeholder column to hold the imputation method - this is a transient
    # column that only exists to pass auxiliary data to the validation that
    # calls this function.
    df["imputation_method"] = pd.NA
    #   _____     _______ ____  ____  _____    _    ____
    #  / _ \ \   / / ____|  _ \/ ___|| ____|  / \  / ___|
    # | | | \ \ / /|  _| | |_) \___ \|  _|   / _ \ \___ \
    # | |_| |\ V / | |___|  _ < ___) | |___ / ___ \ ___) |
    #  \___/  \_/  |_____|_| \_\____/|_____/_/   \_\____/

    #  ____  _____ ____   ___  ____ _____ ____
    # |  _ \| ____|  _ \ / _ \|  _ \_   _/ ___|
    # | |_) |  _| | |_) | | | | |_) || | \___ \
    # |  _ <| |___|  __/| |_| |  _ < | |  ___) |
    # |_| \_\_____|_|    \___/|_| \_\|_| |____/

    # For the manual_entry_travellers dataframe, we want to consider the subset
    # of entries where (a) the travellers is OVERSEAS, (b) the port is contained
    # in the current ipil_hwy dataframe, and (c) the vehicle_type is contained
    # in the current ipil_hwy dataframe. Any rows of manual_entry_travellers that
    # meet these conditions can be used as a reference distribution to impute the
    # corresponding ipil_hwy records.

    # Load the manual entry dataframe
    manual_entry_basename = S3.get_s3_basename(
        Stage.TRANSFORMED, DataSource.manual_entry_travellers, DATE.year, DATE.month, 1,
    )
    # Get unique vehicle_type and port values from manual_entry_travellers
    UNIQUE_PORTS = list(df.loc[IS_OVERSEAS, ManualEntrySchema.port].unique())
    UNIQUE_VEHICLE_TYPES = (
        df.loc[IS_OVERSEAS, ManualEntrySchema.vehicle_type].unique().tolist()
    )
    # If there is no manual_entry_travellers file for the month, catch this error and
    # immediately skip to PIK
    DEFAULT_TO_PIK = False
    manual_entry_travellers = pd.DataFrame({})
    try:
        manual_entry_travellers = Loader.get(
            Stage.TRANSFORMED, DataSource.travellers, manual_entry_basename
        )
        # Define set of boolean masks that determine whether manual_entry_travellers
        # is an appropriate imputation donor
        # TODO: need to check joint condition not independently
        PORT_EXISTS_IN_IPIL_HWY = manual_entry_travellers[CleanSchema.port].isin(
            UNIQUE_PORTS
        )
        VEHICLE_TYPE_EXISTS_IN_IPIL_HWY = manual_entry_travellers[
            ManualEntrySchema.vehicle_type
        ].isin(UNIQUE_VEHICLE_TYPES)
        # Only consider subset of manual_entry_travellers that exists in ipil_hwy
        manual_entry_travellers = manual_entry_travellers[
            PORT_EXISTS_IN_IPIL_HWY & VEHICLE_TYPE_EXISTS_IN_IPIL_HWY
        ]
    # Note: it is necessary to check for both NoSuchKey (thrown by MinIO) and
    # FileNotFoundError (thrown by the filesystem). If we are running the test
    # suite, the `Loader` class will use mock_minio on the filesystem.
    except (NoSuchKey, FileNotFoundError):
        DEFAULT_TO_PIK = True
        logging.info(
            "No manual_entry_travellers data found for current month. Using PIK instead."
        )
        print(
            "No manual_entry_travellers data found for current month. Using PIK instead."
        )
    # If manual_entry_travellers is empty (e.g. there is zero overlap of ports
    # and vehicle_type between ipil_hwy and manual_entry_travellers) or loading
    # failed (e.g. b/c the file didn't exist on MinIO), skip to the next
    # possible reference distribution
    if not DEFAULT_TO_PIK and not manual_entry_travellers.empty:
        # For each unique combination of `port` and `vehicle_type`, we want to SUM
        # and GROUP BY country_of_residence, and use the resulting frequency
        # distribution as the imputation distribution for ipil_hwy records who match
        # the same `port` and `vehicle_type`.

        for group_tuple, group in manual_entry_travellers.groupby(
            [ManualEntrySchema.port, ManualEntrySchema.vehicle_type,], as_index=False,
        ):
            # Define the conditions under which ipil_hwy records can be imputed by
            # the reference distribution created on the current iteration.
            # Note that `group_tuple` contains the tuple of groupby values for
            # the current iteration. E.g. ('12345', '12') would indicate that for
            # the current iteration, we have port = 12345 and vehicle_type = 12.
            IPIL_HWY_PORT_MATCH = df[ManualEntrySchema.port] == group_tuple[0]
            IPIL_HWY_VEHICLE_TYPE_MATCH = (
                df[ManualEntrySchema.vehicle_type] == group_tuple[1]
            )
            IMPUTATION_TARGET = (
                IS_OVERSEAS & IPIL_HWY_PORT_MATCH & IPIL_HWY_VEHICLE_TYPE_MATCH
            )
            # If there does not exist at least one row in ipil_hwy that is
            # suitable for imputation, skip to the next imputation group.
            if not IMPUTATION_TARGET.any():
                continue
            # For each "outer" group, group by `country_of_residence` and sum
            # on `count_of_entries`
            imputation_distribution = group.groupby(
                [
                    ManualEntrySchema.country_of_residence,
                    ManualEntrySchema.port,
                    ManualEntrySchema.vehicle_type,
                ],
                as_index=False,
            ).sum(ManualEntrySchema.count_of_entries)
            # Calculate the proportion of travellers ineach country
            imputation_distribution["proportion"] = (
                imputation_distribution[ManualEntrySchema.count_of_entries]
                / imputation_distribution[ManualEntrySchema.count_of_entries].sum()
            )
            # Sort on `country_of_residence`
            imputation_distribution = imputation_distribution.sort_values(
                ManualEntrySchema.country_of_residence
            )
            # Generate upper/lower bounds for the imputation distribution so
            # that we can assign a country based on which interval each row's
            # random number falls into.
            imputation_distribution["upper_bound"] = imputation_distribution[
                "proportion"
            ].cumsum()
            imputation_distribution["lower_bound"] = (
                imputation_distribution["proportion"].cumsum().shift(fill_value=0)
            )

            # For each row of the imputation distribution, we need to evaluate
            # which rows of ipil_hwy should have the current row's country
            # assigned to them.

            for _, row in imputation_distribution.iterrows():
                # Generate the conditions for the upper/lower bounds of the
                # current row of the imputation distribution.
                GT_LOWER_BOUND = df["random_number"] >= row["lower_bound"]
                LT_UPPER_BOUND = df["random_number"] < row["upper_bound"]
                # Store the imputed value followed by the imputation method
                df.loc[
                    IMPUTATION_TARGET & GT_LOWER_BOUND & LT_UPPER_BOUND,
                    [ManualEntrySchema.country_of_residence, "imputation_method",],
                ] = [
                    row[ManualEntrySchema.country_of_residence],
                    "Manual Entry",
                ]

    #  ____ ___ _  __
    # |  _ \_ _| |/ /
    # | |_) | || ' /
    # |  __/| || . \
    # |_|  |___|_|\_\

    # For PIK, we want to consider the subset of entries where
    # (a) `traveller_type` is 1 or 2, and (b) the "province group" is in the
    # current ipil_hwy dataframe. All rows of PIK that meet these conditions
    # can be used as a reference distribution to impute the corresponding
    # ipil_hwy records.

    # Load PIK dataframe
    pik_basename = S3.get_s3_basename(
        Stage.TRANSFORMED, DataSource.pik, DATE.year, DATE.month, 1
    )
    # We either need to get the current year's PIK dataset or, if it is not
    # available, use the same month from the previous year.
    try:
        pik_travellers = Loader.get(
            Stage.TRANSFORMED, DataSource.travellers, pik_basename
        )
    except (NoSuchKey, FileNotFoundError):
        logging.info(
            "No PIK data found for current year. Using PIK data for the previous year instead."
        )
        print(
            "No PIK data found for current year. Using PIK data for the previous year instead."
        )
        pik_basename = S3.get_s3_basename(
            Stage.TRANSFORMED, DataSource.pik, DATE.year - 1, DATE.month, 1
        )
        try:
            pik_travellers = Loader.get(
                Stage.TRANSFORMED, DataSource.travellers, pik_basename
            )
        except (NoSuchKey, FileNotFoundError) as e:
            logging.info(
                "No PIK data found for previous year. Throw exception as no suitable imputation data can be used."
            )
            print(
                "No PIK data found for previous year. Throw exception as no suitable imputation data can be used."
            )
            raise e

    # We need to start by defining the `province_group` variable, because there
    # is zero overlap between the ports of PIK and the ports of IPIL_HWY. The Frontier Counts team
    # has defined a mapping between PIK work locations and so-called
    # "province groups". Province groups can be derived for IPIL HWY by taking
    # the first two characters of `port`.

    PROVINCE_TO_GROUP_MAPPING = {
        "BC": BC_YT,
        "YT": BC_YT,
        "AB": AB,
        "SK": SK_MB,
        "MB": SK_MB,
        "ON": ON,
        "QC": QC,
        "NB": NB_NS,
        "NS": NB_NS,
    }

    # Define province groups in IPIL HWY using SGC code from
    # provinces_and_territories table.
    df[PTSchema.sgc_code] = df[ManualEntrySchema.port].str[0:2]
    df = pd.merge(
        left=df,
        right=provinces[[PTSchema.sgc_code, PTSchema.alpha_code]],
        on=[PTSchema.sgc_code],
        how="left",
    )
    df["province_group"] = df[PTSchema.alpha_code].replace(PROVINCE_TO_GROUP_MAPPING)

    # Define province groups in PIK based on the Frontier Counts team's mapping
    pik_travellers.loc[
        pik_travellers[TransformedSchema.work_location].isin(["8212"]),
        "province_group",
    ] = BC_YT
    pik_travellers.loc[
        pik_travellers[TransformedSchema.work_location].isin(["7011", "7023"]),
        "province_group",
    ] = AB
    pik_travellers.loc[
        pik_travellers[TransformedSchema.work_location].isin(["5102"]),
        "province_group",
    ] = SK_MB
    pik_travellers.loc[
        pik_travellers[TransformedSchema.work_location].isin(
            ["4312", "4971", "4974", "4952"]
        ),
        "province_group",
    ] = ON
    pik_travellers.loc[
        pik_travellers[TransformedSchema.work_location].isin(["3123", "3961"]),
        "province_group",
    ] = QC
    pik_travellers.loc[
        pik_travellers[TransformedSchema.work_location].isin(["7593"]),
        "province_group",
    ] = NB_NS

    # Only consider rows where `traveller_type` is 1 or 2 and only cases where the
    # PIK travellers are overseas.
    CORRECT_TRAVELLER_TYPE = pik_travellers[TransformedSchema.traveller_type].isin(
        [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
    )

    # Get the country codes for "Not applicable", "overseas", "canada", "usa"
    # dynamically from configuration to avoid hard-coding values in the script.
    # Reason to do this is to make maintenance easier by requiring future
    # changes to configuration to be made in one place only.

    NOT_APPLICABLE_CODE = countries.loc[
        countries[CountriesSchema.country_name_en].str.lower()
        == COUNTRY_NOT_APPLICABLE.lower(),
        CountriesSchema.country_of_residence,
    ].squeeze()
    OVERSEAS_CODE = countries.loc[
        countries[CountriesSchema.country_name_en].str.lower()
        == COUNTRY_OVERSEAS.lower(),
        CountriesSchema.country_of_residence,
    ].squeeze()
    USA_CODE = countries.loc[
        countries[CountriesSchema.country_name_en].str.lower() == COUNTRY_USA.lower(),
        CountriesSchema.country_of_residence,
    ].squeeze()
    CANADA_CODE = countries.loc[
        countries[CountriesSchema.country_name_en].str.lower()
        == COUNTRY_CANADA.lower(),
        CountriesSchema.country_of_residence,
    ].squeeze()
    OVERSEAS_TRAVELLER = ~pik_travellers[TransformedSchema.country_of_residence].isin(
        [NOT_APPLICABLE_CODE, OVERSEAS_CODE, USA_CODE, CANADA_CODE]
    )

    # Consider only the subset of PIK records where we have an overseas traveller
    # who has `traveller_type` of 1 or 2.

    pik_travellers = pik_travellers[CORRECT_TRAVELLER_TYPE & OVERSEAS_TRAVELLER]

    # If pik_travellers is empty, skip to the next reference distribution.
    if not pik_travellers.empty:

        # For each value of `province_group`, we want to SUM and GROUP BY
        # `country_of_residence`, and use the resulting frequency distribution
        # as the basis of the imputation distribution for ipil_hwy records
        # that have the same `traveller_type` and `province_group`.

        for province_group, group in pik_travellers.groupby(
            ["province_group"], as_index=False
        ):

            # The logic below is very similar to the first imputation procedure
            # earlier in this business rule. Please refer to those comments for
            # an explanation as to what each line is doing.

            IPIL_HWY_PROVINCE_GROUP_MATCH = df["province_group"] == province_group

            # Note that some rows may have already been imputed in the manual_entry
            # imputation section. We are running these imputations in the order of
            # highest data quality, so a previous imputation should *not* be
            # overwritten by a subsequent imputation.

            NOT_ALREADY_IMPUTED = df[ManualEntrySchema.country_of_residence].isna()
            IMPUTATION_TARGET = (
                IS_OVERSEAS & IPIL_HWY_PROVINCE_GROUP_MATCH & NOT_ALREADY_IMPUTED
            )

            if not IMPUTATION_TARGET.any():
                continue

            imputation_distribution = group.groupby(
                ["province_group", ManualEntrySchema.country_of_residence,],
                as_index=False,
            ).sum(ManualEntrySchema.count_of_entries)

            imputation_distribution["proportion"] = (
                imputation_distribution[ManualEntrySchema.count_of_entries]
                / imputation_distribution[ManualEntrySchema.count_of_entries].sum()
            )

            imputation_distribution = imputation_distribution.sort_values(
                ManualEntrySchema.country_of_residence
            )

            imputation_distribution["upper_bound"] = imputation_distribution[
                "proportion"
            ].cumsum()
            imputation_distribution["lower_bound"] = (
                imputation_distribution["proportion"].cumsum().shift(fill_value=0)
            )

            for _, row in imputation_distribution.iterrows():
                # Generate the conditions for the upper/lower bounds of the
                # current row of the imputation distribution.
                GT_LOWER_BOUND = df["random_number"] >= row["lower_bound"]
                LT_UPPER_BOUND = df["random_number"] < row["upper_bound"]
                # Store the imputed value followed by the imputation method
                df.loc[
                    IMPUTATION_TARGET & GT_LOWER_BOUND & LT_UPPER_BOUND,
                    [ManualEntrySchema.country_of_residence, "imputation_method",],
                ] = [
                    row[ManualEntrySchema.country_of_residence],
                    "PIK",
                ]

    #  ____ ___ _  __             _    _     _
    # |  _ \_ _| |/ /            / \  | |   | |
    # | |_) | || ' /   _____    / _ \ | |   | |
    # |  __/| || . \  |_____|  / ___ \| |___| |___
    # |_|  |___|_|\_\         /_/   \_\_____|_____|

    #   ____    _    _   _    _    ____    _
    #  / ___|  / \  | \ | |  / \  |  _ \  / \
    # | |     / _ \ |  \| | / _ \ | | | |/ _ \
    # | |___ / ___ \| |\  |/ ___ \| |_| / ___ \
    #  \____/_/   \_\_| \_/_/   \_\____/_/   \_\

    # If there are still rows that are not imputed, use PIK data from all of
    # Canada as a reference distribution. If no such match is found, simply
    # assign '99999' as the country_of_residence.

    if not pik_travellers.empty:

        # For this last case, we just require that the row has not already been
        # imputed and that the row is an overseas record.

        NOT_ALREADY_IMPUTED = df[ManualEntrySchema.country_of_residence].isna()
        IMPUTATION_TARGET = IS_OVERSEAS & NOT_ALREADY_IMPUTED

        imputation_distribution = group.groupby(
            [ManualEntrySchema.country_of_residence], as_index=False,
        ).sum(ManualEntrySchema.count_of_entries)

        imputation_distribution["proportion"] = (
            imputation_distribution[ManualEntrySchema.count_of_entries]
            / imputation_distribution[ManualEntrySchema.count_of_entries].sum()
        )

        imputation_distribution = imputation_distribution.sort_values(
            ManualEntrySchema.country_of_residence
        )

        imputation_distribution["upper_bound"] = imputation_distribution[
            "proportion"
        ].cumsum()
        imputation_distribution["lower_bound"] = (
            imputation_distribution["proportion"].cumsum().shift(fill_value=0)
        )

        for _, row in imputation_distribution.iterrows():
            # Generate the conditions for the upper/lower bounds of the
            # current row of the imputation distribution.
            GT_LOWER_BOUND = df["random_number"] >= row["lower_bound"]
            LT_UPPER_BOUND = df["random_number"] < row["upper_bound"]
            # Store the imputed value followed by the imputation method
            df.loc[
                IMPUTATION_TARGET & GT_LOWER_BOUND & LT_UPPER_BOUND,
                [ManualEntrySchema.country_of_residence, "imputation_method",],
            ] = [
                row[ManualEntrySchema.country_of_residence],
                "All of Canada",
            ]
    #  _____ ___  ____  __  __    _  _____ _____ ___ _   _  ____
    # |  ___/ _ \|  _ \|  \/  |  / \|_   _|_   _|_ _| \ | |/ ___|
    # | |_ | | | | |_) | |\/| | / _ \ | |   | |  | ||  \| | |  _
    # |  _|| |_| |  _ <| |  | |/ ___ \| |   | |  | || |\  | |_| |
    # |_|   \___/|_| \_\_|  |_/_/   \_\_|   |_| |___|_| \_|\____|

    # If no country of residence can be imputed, the default value should be
    # the missing value code provided in the dimension for this column.
    NOT_APPLICABLE_CODE = countries.loc[
        countries[CountriesSchema.country_name_en].str.lower()
        == COUNTRY_NOT_APPLICABLE.lower(),
        CountriesSchema.country_of_residence,
    ].squeeze()
    COUNTRY_IS_NA = df[CleanSchema.country_of_residence].isna()
    df.loc[COUNTRY_IS_NA, CleanSchema.country_of_residence] = NOT_APPLICABLE_CODE

    # Pass an auxiliary df containing the required data for the validation for
    # this function.
    auxiliary_df = df[~df["imputation_method"].isna()]

    df = df.drop(
        [
            "index",
            "vehicle_type",
            "work_location",
            "random_number",
            "imputation_method",
            "sgc_code",
            "alpha_code",
            "province_group",
        ],
        axis=1,
    )

    return df, auxiliary_df


def ipil_hwy_v155(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_155

    Args:
        df:
            A pandas dataframe containing records that have possibly had their
            country of residence imputed.
        auxiliary_df:
            A pandas dataframe containing a summary of the imputation process
            including the data source used for the imputation.
    Returns:
        validation_df:
            A summary of the imputation for country of residence for use in the
            validation dashboards.
    """
    if not auxiliary_df.empty:
        validation_df = auxiliary_df.copy()
        # Add some of this logic into business rule and pass validation_df as auxiliary to validation
        validation_df[CleanSchema.province] = (
            validation_df[CleanSchema.port].str.slice(stop=2).copy()
        )
        validation_df[ValidationSchema.count] = (
            validation_df[[CleanSchema.osd, CleanSchema.o1d, CleanSchema.o2d]]
            .sum(axis=1)
            .copy()
        )
        validation_df = validation_df[
            [
                CleanSchema.date,
                CleanSchema.province,
                CleanSchema.vehi,
                ValidationSchema.imputation_method,
                CleanSchema.country_of_residence,
                ValidationSchema.count,
            ]
        ]
        validation_df = validation_df.groupby(
            by=[
                CleanSchema.date,
                CleanSchema.province,
                CleanSchema.vehi,
                ValidationSchema.imputation_method,
                CleanSchema.country_of_residence,
            ],
            dropna=False,
            as_index=False,
        ).sum()

        validation_df[CleanSchema.date] = validation_df[CleanSchema.date].str.replace(
            "/", "-"
        )
        validation_df[ValidationSchema.count] = validation_df[
            ValidationSchema.count
        ].astype("Int64")

    else:
        validation_df = pd.DataFrame(
            columns=[
                CleanSchema.date,
                CleanSchema.province,
                CleanSchema.vehi,
                ValidationSchema.imputation_method,
                CleanSchema.country_of_residence,
                ValidationSchema.count,
            ]
        )

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
