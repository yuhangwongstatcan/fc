import pandas as pd

from datasource.ipil_hwy.utils import get_total_passengers, df_groupby
from datasource.ipil_hwy.utils import RemovalReasons
from datasource.ipil_hwy.schema import RawSchema, ValidationSchema


def ipil_hwy_120(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes entries with a missing date.

    Args:
        df:
            A pandas dataframe with null dates present
    Returns:
        df:
            A pandas dataframe with all records containing empty dates removed.
        auxiliary_df:
            A pandas dataframe with records containing empty dates.
    """
    auxiliary_df = df[df[RawSchema.date].isnull()]
    df = df[~df[RawSchema.date].isnull()]

    return df, auxiliary_df


def ipil_hwy_v120(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_120

    Args:
        df:
            A pandas dataframe where records with null dates have been removed.
        auxiliary_df:
            A pandas dataframe of records with null dates.
    Returns:
        validation_df:
            A summary dataframe of the records removed in ipil_hwy_120 that will be
            used in the validation dashboards.
    """
    auxiliary_df = get_total_passengers(auxiliary_df, RawSchema)

    groupby_set = [RawSchema.date, RawSchema.cport, RawSchema.country]
    aggregations = ["count", "sum"]
    validation_df = df_groupby(
        df=auxiliary_df,
        groupby_set=groupby_set,
        aggregation_column="total_passengers",
        aggregation=aggregations,
    ).astype(
        {
            ValidationSchema.total_passengerscount: "Int64",
            ValidationSchema.total_passengerssum: "Int64",
        }
    )
    # Specify removal reason
    validation_df[ValidationSchema.removal_reason] = RemovalReasons.missing_date.value

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
