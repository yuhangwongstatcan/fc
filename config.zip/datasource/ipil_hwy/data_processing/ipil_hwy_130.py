import pandas as pd

from datasource.ipil_hwy.utils import get_total_passengers, overfull_vehicle_br
from datasource.ipil_hwy.utils import overfull_vehicle_validation

from datasource.ipil_hwy.schema import CleanSchema, ValidationSchema
from datasource.ipil_hwy.dim import VEHI


def ipil_hwy_130(df: pd.DataFrame) -> pd.DataFrame:
    """
    Imputes a new total number of passengers in overfull trucks,
    which have more than 4 passengers.

    Args:
        df:
            A pandas dataframe where trucks may have more passengers than
            the allowed limit.
    Returns:
        df:
            A pandas dataframe where overfull trucks have had their passengers adjusted.
    """
    # Keep a copy of the dataframe before any imputation is done
    auxiliary_df = df.copy()

    # Create a Unix timestamp column that can be used for the nearest neighbour
    # merge
    df.loc[:, "date_"] = pd.to_datetime(df[CleanSchema.date])
    df.loc[:, "unix_timestamp"] = (
        df["date_"].astype(int) / 10 ** 9 + df[CleanSchema.sin]
    )
    df = df.sort_values("unix_timestamp")
    # Set unix timestamp to be date type
    df["unix_timestamp"] = pd.to_datetime(df["unix_timestamp"], unit="s")
    # Define a new column caleld "total_passengers" that will be used in
    # downstream calculations.
    df = get_total_passengers(df, CleanSchema)

    # Define the mask that selects all trucks with too many passengers
    mask = (df[CleanSchema.vehi] == VEHI.truck.value) & (df["total_passengers"] > 4)
    mask_compliment = (df[CleanSchema.vehi] == VEHI.truck.value) & (
        df["total_passengers"] <= 4
    )
    df = overfull_vehicle_br(df, mask, mask_compliment, CleanSchema)
    # TODO: dropping these columns to pass the test - might want to rethink the
    # creation and dropping of these columns to avoid unecessary computation.

    df = df.drop(["date_", "unix_timestamp"], axis=1)

    return df, auxiliary_df


def ipil_hwy_v130(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_130

    Args:
        df: 
            A pandas dataframe containing imputed records for overfull trucks.
        auxiliary_df:
            The pandas dataframe prior to the imputation for overfull trucks.

    Returns:
        validation_df:
            A summary of the imputed overfull trucks for use in the dashboards.
    """
    # Get input schema for this validation
    validation_df = overfull_vehicle_validation(auxiliary_df, df, CleanSchema)

    validation_df[CleanSchema.date] = validation_df[CleanSchema.date].str.replace(
        "/", "-"
    )

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
