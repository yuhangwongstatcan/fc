import pandas as pd

from datasource.ipil_hwy.schema import RawSchema
from datasource.ipil_hwy.dim import COUNTRY


def ipil_hwy_040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensures that any country codes of CA are recoded as CD.

    Args:
        df:
            A pandas dataframe containing records that possibly contain country codes of CA.
    Returns:
        df:
            A pandas dataframe where any country codes of CA have been replaced with CD.
    """
    # Get country dimension
    df.loc[
        df[RawSchema.country] == COUNTRY.canada_legacy.value, RawSchema.country
    ] = COUNTRY.canada.value

    return df
