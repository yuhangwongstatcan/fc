import pandas as pd

from datasource.ipil_hwy.utils import get_total_passengers, df_groupby
from datasource.ipil_hwy.utils import RemovalReasons

from datasource.ipil_hwy.schema import RawSchema, ValidationSchema
from datasource.ipil_hwy.dim import PROVINCE, COUNTRY


def ipil_hwy_090(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensures that any records with a missing or invalid province/state code are
    removed. An exception is Mexican vehicles (country = 'MX'), as those
    records always have a missing province, which is coded to 'MX' based on the
    country (see ipil_hwy_060).

    Args:
        df:
            A pandas dataframe that possibly contains records where province or
            state code is missing (and country is not "MX").
    Returns:
        df:
            A pandas dataframe that removes any records where province or state
            code is missing and country is not "MX".
        auxiliary_df:
            A pandas dataframe containing records where province or state code
            is missing that will summarized for validations.
    """
    # A record is invalid if province is not a valid state/province code AND
    # country is not 'MX'
    invalid_mask = ~(df[RawSchema.province].isin(PROVINCE.list())) & (
        df[RawSchema.country] != COUNTRY.mexico.value
    )
    # Keep for validations if invalid
    auxiliary_df = df[invalid_mask]
    # Keep in the output dataframe if valid
    df = df[~invalid_mask]

    return df, auxiliary_df


def ipil_hwy_v090(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_090

    Args:
        df:
            A pandas dataframe with valid records based on province of licence plate.
        auxiliary_df:
            A pandas dataframe of invalid records that were removed to due the
            value of the province of licence plate.
    Returns:
        validation_df:
            A summary dataframe of the records removed in ipil_hwy_090 that will be
            used in the validation dashboards.
    """
    # Get total passengers
    auxiliary_df = get_total_passengers(auxiliary_df, RawSchema)

    # Get the daily volume validation (counts by date)
    groupby_set = [RawSchema.date, RawSchema.cport, RawSchema.country]
    aggregations = ["count", "sum"]
    validation_df = df_groupby(
        df=auxiliary_df,
        groupby_set=groupby_set,
        aggregation_column="total_passengers",
        aggregation=aggregations,
    ).astype(
        {
            ValidationSchema.total_passengerscount: "Int64",
            ValidationSchema.total_passengerssum: "Int64",
        }
    )
    validation_df[RawSchema.date] = validation_df[RawSchema.date].str.replace("/", "-")
    # Specify removal reason
    validation_df[
        ValidationSchema.removal_reason
    ] = RemovalReasons.invalid_province.value

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df

