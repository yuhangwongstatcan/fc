import pandas as pd

from config.api import DataSource

from modules.utils.data_manipulation import validate_dimensions

from datasource.ipil_hwy.schema import RawSchema, ValidationSchema
from datasource.ipil_hwy.dim import *


def ipil_hwy_v000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate the dimension variables to find unexpected values.

    Args:
        df:
            A pandas dataframe of records that possibly contain
            unexpected dimension values.
    Returns:
        df:
            Copy of the input dataframe since no processing is done.

        validation_df:
            Validation file summarizing the unexpected values which will be used in dashboards.
    """

    # Declare which column from input are for : "location" and "date"
    cname_loc = RawSchema.cport
    cname_date = RawSchema.date

    validation = validate_dimensions(
        df, RawSchema, ValidationSchema, cname_loc, cname_date, DataSource.ipil_hwy
    )

    # Special cases we want to drop from validation report
    EXCLUDE_MISSING_PROVINCES = ~(
        (validation[ValidationSchema.variable] == "province")
        & (validation[ValidationSchema.unexpected_value].isna())
    )
    validation = validation[EXCLUDE_MISSING_PROVINCES]

    # Fix date formatting
    validation[RawSchema.date] = validation[RawSchema.date].str.replace("/", "-")

    # Check and coerce the validation schema as required
    validation_df = ValidationSchema(validation)

    return df, validation_df
