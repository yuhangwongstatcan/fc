import pandas as pd

from datasource.ipil_hwy.utils import unix_timestamp_from_sin_and_date
from datasource.ipil_hwy.utils import get_total_passengers, overfull_vehicle_br
from datasource.ipil_hwy.utils import overfull_vehicle_validation

from datasource.ipil_hwy.schema import RawSchema, CleanSchema, ValidationSchema
from datasource.ipil_hwy.dim import VEHI


def ipil_hwy_150(df: pd.DataFrame) -> pd.DataFrame:
    """
    Imputes a new total number of apssengers in overfull motorcycles,
    which have more than 3 passengers.

    Args:
        df:
            A pandas dataframe where motorcycles may have more passengers than
            the allowed limit.
    Returns:
        df:
            A pandas dataframe where overfull motorcycles have had their passengers adjusted.
    """
    # Keep a copy of the dataframe before any imputation is done.
    auxiliary_df = df.copy()

    # Create a Unix timestamp column that can be used for the nearest neighbour
    # merge
    if "unix_timestamp" not in df:
        df.loc[:, "unix_timestamp"] = df.apply(
            lambda x: unix_timestamp_from_sin_and_date(
                x[CleanSchema.sin], x[CleanSchema.date]
            ),
            axis=1,
        )
    df = df.sort_values("unix_timestamp")
    # Set unix timestamp to be date type
    df["unix_timestamp"] = pd.to_datetime(df["unix_timestamp"], unit="s")
    # Define a new column caleld "total_passengers" that will be used in
    # downstream calculations.
    if "total_passengers" not in df:
        df = get_total_passengers(df, CleanSchema)
    # Define the mask that selects all commercial vehicles with too many
    # passengers
    mask = (df[CleanSchema.vehi] == VEHI.motorcycle.value) & (
        df["total_passengers"] > 3
    )
    mask_compliment = (df[CleanSchema.vehi] == VEHI.motorcycle.value) & (
        df["total_passengers"] <= 3
    )
    df = overfull_vehicle_br(df, mask, mask_compliment, CleanSchema)
    # TODO: dropping these columns to pass the test - might want to rethink the
    # creation and dropping of these columns to avoid unecessary computation.

    df = df.drop(["unix_timestamp"], axis=1)

    # Recheck and re-coerce the schema in case the merging operation caused
    # unexpected behaviour in some of the variables
    df = RawSchema(df)

    return df, auxiliary_df


def ipil_hwy_v150(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_150

    Args:
        df:
            A pandas dataframe containing imputed records for overfull motorcycles.
        auxiliary_df:
            The pandas dataframe prior to the imputation for overfull motorcycles.
    Returns:
        validation_df:
            A summary of the imputed overfull motorcycles for use in the dashboards.
    """
    validation_df = overfull_vehicle_validation(auxiliary_df, df, CleanSchema)

    validation_df[CleanSchema.date] = validation_df[CleanSchema.date].str.replace(
        "/", "-"
    )

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
