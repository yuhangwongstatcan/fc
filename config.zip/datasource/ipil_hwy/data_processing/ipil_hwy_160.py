import pandas as pd

from config.api import Stage, DataSource, Mapping
from modules.utils.loaders import Loader

from datasource.ipil_hwy.schema import CleanSchema
from datasource.vehicles.schema import TransformedSchema

from datasource.ipil_hwy.dim import VEHI, WATER_FLAG
from datasource.vehicles.schema import (
    DATA_SOURCE,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)
from datasource.common.dim import MODE, VEHICLE_TYPE

from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema
from datasource.mapping.schema import ReferenceSchema as MappingSchema


def ipil_hwy_160(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Collin Brown - `collin.brown@canada.ca`

    **Created On:** November, 2020

    **Description:**

    Ensures that all transformations for the VEHICLE dataset can be done
    correctly from the cleaned IPIL-Hwy data.

    Args:
        df: pd.DataFrame
            The IPIL_HWY clean table for the current month.

    Returns:
        vehicles: pd.DataFrame
            A pandas dataframe containing IPIL_HWY's contribution to the vehicles table.
    """
    work_locations = Loader.get(Stage.REFERENCE, DataSource.work_locations, None)
    work_locations = WorkLocationsSchema(work_locations)

    ipil_vehicle_mapping = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__ipil_hwy__clean__vehi__vehicles__transformed__vehicle_type,
    )
    ipil_country_mapping = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__ipil_hwy__clean__country__vehicles__transformed__plate_country,
    )

    # Exclude any rows with vehi == P or water_flag == private watercraft
    df = df[
        ~(
            (df[CleanSchema.vehi] == VEHI.pedestrian.value)
            | (df[CleanSchema.water_flag] == WATER_FLAG.private_boat.value)
        )
    ]
    # 1. Add a data source column and set it to IPIL-HWY
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.IPIL_Highway.value

    # 2. Parse %Y/%m/%d string of date column into three columns: 'year', 'month', 'day'
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        CleanSchema.date
    ].str.split("/", expand=True)
    df.loc[:, TransformedSchema.month] = df.loc[:, TransformedSchema.month].replace(
        {r"0(\d)": r"\1"}, regex=True
    )
    df.loc[:, TransformedSchema.day] = (
        df.loc[:, TransformedSchema.day]
        .replace({r"0(\d)": r"\1"}, regex=True)
        .astype("float")
        .astype("Int64")
    )
    # 3. Create location variables: port and work_location
    # Merge with port list using 'cport' field
    df = pd.merge(
        df,
        work_locations[
            [
                WorkLocationsSchema.work_location,
            ]
        ],
        left_on=CleanSchema.cport,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )

    # 4. Create mode of transportation field
    df.loc[
        :, TransformedSchema.mode
    ] = MODE.land.value  # for ipil_hwy mode is always LAND
    df.loc[
        ~df[CleanSchema.water_flag].isna(), TransformedSchema.mode
    ] = MODE.water.value

    # 5. Use mapping files to code vehicle type and plate country
    ipil_vehicle_mapping = ipil_vehicle_mapping.rename(
        columns={
            MappingSchema.key: CleanSchema.vehi,
            MappingSchema.value: TransformedSchema.vehicle_type,
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)
    df = pd.merge(df, ipil_vehicle_mapping, on=[CleanSchema.vehi], how="left")

    ipil_country_mapping = ipil_country_mapping.rename(
        columns={
            MappingSchema.key: CleanSchema.country,
            MappingSchema.value: TransformedSchema.plate_country,
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)
    df = pd.merge(df, ipil_country_mapping, on=[CleanSchema.country], how="left")

    df = df.rename(columns={CleanSchema.province: TransformedSchema.plate_region})

    # Since we are producing the vehicles table, drop a record if vehicle type
    # is pedestrian
    df = df[df[CleanSchema.vehi] != VEHI.pedestrian.value]
    # If vehicle is car, motorcycle, other, commercial truck, bus, or non-motorized, and waterflag==ferry, then
    # recode to vehicle type = 313
    is_valid_vehi = df[CleanSchema.vehi].isin(
        [
            VEHI.car.value,
            VEHI.motorcycle.value,
            VEHI.other_land_vehicle.value,
            VEHI.truck.value,
            VEHI.bus.value,
            VEHI.non_motorized.value,
        ]
    )
    is_ferry = df[CleanSchema.water_flag] == WATER_FLAG.ferry.value
    df.loc[
        (is_valid_vehi) & (is_ferry), TransformedSchema.vehicle_type
    ] = VEHICLE_TYPE.ferry_private_vehicle.value
    # Last step: Count of entries
    # Select all columns we want to keep for the final table
    df = df[TRANSFORMED_GROUPBY]

    # Create column to store the counts from the GROUP BY in
    df.loc[:, TransformedSchema.count_of_entries] = 0
    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = (
        df.groupby(
            by=TRANSFORMED_GROUPBY,
            dropna=False,
            as_index=False,
        )
        .count()
        .reset_index()
    ).astype({TransformedSchema.count_of_entries: "Int64"})
    # Reorder the columns to match the desired output format
    df = df[TRANSFORMED_COLUMNS]

    df = TransformedSchema(df)
    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]

    # Sort output on counts
    # Add data source column to output
    vehicles = df.sort_values(
        [
            TransformedSchema.data_source,
            TransformedSchema.year,
            TransformedSchema.month,
            TransformedSchema.day,
            TransformedSchema.port,
            TransformedSchema.work_location,
            TransformedSchema.mode,
            TransformedSchema.vehicle_type,
            TransformedSchema.plate_country,
            TransformedSchema.plate_region,
            TransformedSchema.count_of_entries,
        ],
        ascending=True,
    )
    return vehicles
