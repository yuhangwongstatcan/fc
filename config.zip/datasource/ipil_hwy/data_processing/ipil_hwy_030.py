import pandas as pd

from modules.utils.loaders import Loader

from config.api import Stage, DataSource, Ports
from config.api import GroupByAggTypes

from datasource.ipil_hwy.utils import get_total_passengers
from datasource.ipil_hwy.utils import df_groupby
from datasource.ipil_hwy.schema import RawSchema, ValidationSchema
from datasource.ports.schema import ReferenceSchema as PortsSchema
from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema


def ipil_hwy_v030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Summarize the number of daily arrivals in IPIL Highway.

    Args:
        df:
            A pandas dataframe in which unexpected or invalid data
            has been removed.
    Returns:
        df:
            Copy of the input dataframe since no processing is done.
        validation_df:
            Validation file summarizing number of daily arrivals.
    """

    # Get total passengers
    val_df = get_total_passengers(df, RawSchema)

    # Read in the work locations file and check against the schema
    work_locations = Loader.get(Stage.REFERENCE, DataSource.work_locations, None,)
    work_locations = WorkLocationsSchema(work_locations)

    # Read in the ports file and check against the schema
    ports = Loader.get(Stage.REFERENCE, DataSource.ports, Ports.ports,)
    ports = PortsSchema(ports)

    val_df = pd.merge(
        val_df,
        work_locations[[WorkLocationsSchema.port, WorkLocationsSchema.work_location]],
        left_on=RawSchema.cport,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )
    val_df = pd.merge(
        val_df,
        ports[[PortsSchema.port, PortsSchema.sgc_code]],
        left_on=WorkLocationsSchema.port,
        right_on=PortsSchema.port,
        how="left",
    )
    groupby_df = df_groupby(
        val_df,
        [RawSchema.date, RawSchema.cport, PortsSchema.sgc_code, RawSchema.vehi,],
        "total_passengers",
        [GroupByAggTypes.count.value],
    )
    groupby_df = groupby_df.rename(columns={PortsSchema.sgc_code: RawSchema.province})
    groupby_df = groupby_df.astype({"total_passengerscount": "Int64"})
    # Reformat the date column
    groupby_df[RawSchema.date] = groupby_df[RawSchema.date].str.replace("/", "-")

    validation_df = groupby_df.rename(
        columns={"total_passengerscount": ValidationSchema.count}
    )

    # Remove the total passengers column
    df = df.drop(["total_passengers"], axis=1)

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return df, validation_df
