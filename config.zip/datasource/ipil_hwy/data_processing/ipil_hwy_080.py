import pandas as pd

from datasource.ipil_hwy.utils import get_total_passengers
from datasource.ipil_hwy.schema import RawSchema, ValidationSchema
from datasource.ipil_hwy.dim import VEHI


def ipil_hwy_080(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensures that any automobile records (vehi = 'A') with more than eight
    total passengers are recoded as buses (vehi = 'B').

    Args:
        df:
            A pandas dataframe where there may be automobile records that
            contain more than 8 passengers.
    Returns:
        df:
            A pandas dataframe where any automobile records containing more than
            8 passengers are recoded to bus.
    """

    df = get_total_passengers(df, RawSchema)
    auxiliary_df = df.copy()
    mask = (df[RawSchema.vehi] == VEHI.car.value) & (df["total_passengers"] > 8)
    df.loc[mask, RawSchema.vehi] = VEHI.bus.value

    df = df.drop(["total_passengers"], axis=1)

    return df, auxiliary_df


def ipil_hwy_v080(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule ipil_hwy_080

    Args:
        df:
            A pandas dataframe with records recoded from car to bus.
        auxiliary_df:
            The original pandas dataframe before recoding car to bus.
    Returns:
        validation_df:
            A pandas dataframe summarizing the recoding of car to bus
            that will be used in the validation dashboards.
    """

    # This rule can only apply changes in one direction: car --> bus, so get
    # the rows for which input["vehi"] does not equal output["vehi"]
    auxiliary_df.loc[:, ValidationSchema.bus_recoded] = (
        auxiliary_df[RawSchema.vehi] != df[RawSchema.vehi]
    )
    # Get the number of buses/cars that are unchanged
    auxiliary_df.loc[:, ValidationSchema.unchanged_bus] = (
        auxiliary_df[RawSchema.vehi] == VEHI.bus.value
    ) & (~auxiliary_df[ValidationSchema.bus_recoded])
    auxiliary_df.loc[:, ValidationSchema.unchanged_car] = (
        auxiliary_df[RawSchema.vehi] == VEHI.car.value
    ) & (~auxiliary_df[ValidationSchema.bus_recoded])
    # Create aggregation of # changed vs. # unchanges buses/cars grouped by
    # cport (work location)
    groupby_df = auxiliary_df[
        [
            ValidationSchema.bus_recoded,
            ValidationSchema.unchanged_bus,
            ValidationSchema.unchanged_car,
            RawSchema.cport,
            RawSchema.date,
        ]
    ]
    validation_df = (
        groupby_df.groupby(
            by=[RawSchema.date, RawSchema.cport], dropna=False, as_index=False
        ).sum()
    ).astype(
        {
            ValidationSchema.bus_recoded: "Int64",
            ValidationSchema.unchanged_bus: "Int64",
            ValidationSchema.unchanged_car: "Int64",
        }
    )
    # Re-format the date column
    validation_df[RawSchema.date] = groupby_df[RawSchema.date].str.replace("/", "-")

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
