import pandas as pd

from config.api import DataSource, Stage
from config.api import (
    WorkLocationsTransAction,
    WorkLocationsAction,
    WorkLocationsTransportation,
)

from modules.utils.loaders import Loader
from modules.utils.data_manipulation import work_locations_recode

from datasource.ipil_hwy.schema import RawSchema, CleanSchema, ValidationSchema
from datasource.work_locations_trans.schema import ReferenceSchema as TransSchema
from datasource.work_locations_action.schema import ReferenceSchema as ActionSchema
from datasource.work_locations_trans_action.schema import (
    ReferenceSchema as TransActionSchema,
)
from datasource.work_locations_trans_action.dim import ACTION


def ipil_hwy_010(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove records from the ipil_hwy raw data that cannot be matched to the work location
    reference file, or for which the file indicates that they are not accepted until
    they can be reviewed.

    Args:
        df:
            A pandas dataframe with unacceptable work locations
    Returns:
        df: 
            A pandas dataframe with unacceptable work locations removed
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display removed records
    """

    wl_trans = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans,
        WorkLocationsTransportation.work_locations_trans__ipil_hwy,
    )
    wl_trans = TransSchema(wl_trans)

    wl_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_action,
        WorkLocationsAction.work_locations_action__ipil_hwy,
    )
    wl_action = ActionSchema(wl_action)

    wl_trans_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__ipil_hwy,
    )
    wl_trans_action = TransActionSchema(wl_trans_action)

    # Add any columns you need to add before calling the helper function
    # For ipil_hwy there is the water_flag and orig_vehi columns we need to add.
    df.loc[:, CleanSchema.water_flag] = pd.NA
    # Keep track of the original schema.vehi.name column value - this is used in a
    # validation in the next stage.
    df["orig_vehi"] = df[CleanSchema.vehi]
    work_location_column = CleanSchema.cport

    df, auxiliary_df = work_locations_recode(
        df,
        wl_trans,
        wl_action,
        wl_trans_action,
        work_location_column,
        TransSchema,
        ActionSchema,
        TransActionSchema,
        ACTION,
    )

    df = df.drop(
        [
            "orig_vehi",
            "__trans__",
            ActionSchema.action,
            TransActionSchema.work_location,
            TransActionSchema.transportation_type,
        ],
        axis=1,
    )

    # Re-check and re-coerce since we added a column
    df = RawSchema(df)

    return df, auxiliary_df


def ipil_hwy_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate the unexpected work locations or modes of transportation for IPIL Highway,
    and display a summary of recoded values.

    Args:
        df:
            A pandas dataframe with unacceptable work locations removed
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """
    # Recode rejected values to vehicle type "X"
    auxiliary_df.loc[
        auxiliary_df[TransActionSchema.action] == ACTION.X.value, CleanSchema.vehi,
    ] = ACTION.X.value
    # If water_flag is not null, replace the vehi column value to the water flag column value
    auxiliary_df.loc[
        ~auxiliary_df[CleanSchema.water_flag].isna(), CleanSchema.vehi
    ] = auxiliary_df.loc[
        ~auxiliary_df[CleanSchema.water_flag].isna(), CleanSchema.water_flag,
    ]
    # Filter on only the variables we want to keep in the validation
    auxiliary_df[ValidationSchema.count] = 0
    auxiliary_df = auxiliary_df[
        [
            CleanSchema.vehi,
            "orig_vehi",
            CleanSchema.cport,
            CleanSchema.date,
            CleanSchema.province,
            CleanSchema.country,
            ValidationSchema.count,
        ]
    ]
    # Do the group by
    validation_df = (
        auxiliary_df.groupby(
            by=[
                CleanSchema.vehi,
                "orig_vehi",
                CleanSchema.cport,
                CleanSchema.date,
                CleanSchema.province,
                CleanSchema.country,
            ],
            dropna=False,
            as_index=False,
        ).count()
    ).astype(
        {
            # val_output_sch.cport.name: "Int64",
            "count": "Int64"
        }
    )
    # Reformat the date column
    validation_df[CleanSchema.date] = validation_df[CleanSchema.date].str.replace(
        "/", "-"
    )
    # Rename the columns
    validation_df.rename(
        columns={
            CleanSchema.vehi: ValidationSchema.to_vehi,
            "orig_vehi": ValidationSchema.from_vehi,
        },
        inplace=True,
    )
    # Order validation_df
    validation_df = validation_df[
        [
            CleanSchema.date,
            CleanSchema.cport,
            CleanSchema.province,
            CleanSchema.country,
            ValidationSchema.from_vehi,
            ValidationSchema.to_vehi,
            ValidationSchema.count,
        ]
    ]

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    # Return validation df and output
    return validation_df

