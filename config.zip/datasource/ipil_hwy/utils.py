"""
A general utilities module for the ipil_hwy dataset.
"""
from typing import List
from config.api import AutoEnum
from datetime import datetime, timedelta

import pandas as pd

from datasource.travellers.schema import TransformedSchema
from datasource.travellers.dim import PURPOSE9, PURPOSE4


def get_total_passengers(total_df: pd.DataFrame, schema: "Tuplify") -> pd.DataFrame:
    """
    Given a dataframe, returns the same dataframe with a "total_passengers"
    column.
    """
    total_df.loc[:, "total_passengers"] = total_df[
        [
            schema.cdsd,
            schema.cd1d,
            schema.cd2d,
            schema.ussd,
            schema.us1d,
            schema.us2d,
            schema.osd,
            schema.o1d,
            schema.o2d,
        ]
    ].sum(axis=1)
    return total_df


def unix_timestamp_from_sin_and_date(sin: int, date: str) -> int:
    """
    Returns a unix timestamp (number of seconds since 00:00:00 UTC Jan 1, 1970).
    This provides a single column that can be used to sort all rows on a single
    time dimension. Also allows for nearest neighbour merge to take the
    absolute difference using the timestamp directly.

    Args:
        sin:
            An int indicating the number of seconds that have elapsed since
            the start of the day.
        date:
            A string of the form "YYYY/MM/DD" indicating the date of the
            record.
    Returns:
        The unix timestamp (int) of the combination of date and time of day.
    """
    # Get hours minutes seconds from sin
    hr_min_sec = str(timedelta(seconds=sin))
    # Convert entire date and time into a single string
    date_time_string = date + " " + hr_min_sec
    # Create a datetime instance from this string
    #  TODO: Remove this try-catch block when it is no longer needed
    try:
        date_time_obj = datetime.strptime(date_time_string, "%Y/%m/%d %H:%M:%S")
        # Convert to unix timestamp
        # (i.e. seconds since Unix Epoch 1970/01/01 00:00:00)
        return (date_time_obj - datetime(1970, 1, 1)).total_seconds()
    except:
        return None


def group_travellers(row: pd.Series, traveller_cols: List) -> pd.Series:
    """
    Creates a new column that contains a list of values for each of the
    traveller columns. This is a setup function for
    modules.utils.data_manipulation.explode

    Args:
        row: a row of a pandas dataframe.
        travellers_cols:
            a list of the traveller columns that need to be grouped.
    Returns: a pandas series containing the appropriate totals and
             traveller type columns.
    """
    row["passengers_total"] = [
        row[col_name] for col_name in traveller_cols if row[col_name] > 0
    ]
    row["traveller_col"] = [
        col_name for col_name in traveller_cols if row[col_name] > 0
    ]
    # Apply a priority order to traveller type from left to right. This
    # is used to break ties when assigning a bus passenger to CREW. Note
    # that the order is reversed.
    row["bus_priority"] = [
        len(traveller_cols) - idx
        for idx, col_name in enumerate(traveller_cols)
        if row[col_name] > 0
    ]
    return row


def split_buses(row: pd.Series) -> pd.Series:
    """
    Splits the appropriate bus row into two rows where N-1 travellers are coded
    as "VISIT" for purpose of trip and 1 is coded as "CREW".

    Args:
        row: a row of a pandas dataframe.

    Returns: a pandas dataframe that has correctly split the two quantities.
    """
    row["passengers_total"] = [1, int(row["passengers_total"]) - 1]
    row[TransformedSchema.purpose9] = [PURPOSE9.crew.value, PURPOSE9.visit.value]
    row[TransformedSchema.purpose4] = [PURPOSE4.crew.value, PURPOSE4.visit.value]
    return row


def df_groupby(
    df: pd.DataFrame, groupby_set: List, aggregation_column: str, aggregation: List
) -> pd.DataFrame:
    """
    The VALIDATION test case ipil_hwy_v010ensures that the Overall Daily Volume
    Summary for IPIL-Hwy can be produced correctly.

    Args:
        df:
            a pandas dataframe containing the ipil_hwy records for a given
            month.
        groupby_set:
            A python list containing which columns the groupby should be
            applied to.
        aggregation_column:
            A python string indicating which column to use for the sum.
        aggregation:
            A python list specifying one or more accepted aggregation methods
            in pandas.
    Returns:
        a pandas dataframe containing a summary of volumes by date.
    """
    # Keep only the subset of columns that the group by will be applied to
    df = df[groupby_set + [aggregation_column]]
    # Group by groupby_set and Aggregate on aggregation
    df = df.groupby(groupby_set, dropna=False, as_index=False).agg(aggregation)
    # Ungroup the aggregated index
    df = df.reset_index()
    # Flatten the hierarchical column index created by groupby()/agg()
    df.columns = list(map("".join, df.columns.values))

    df = df.fillna(pd.NA)
    return df


def dataframe_diff(
    pre_op_input: pd.DataFrame,
    post_op_input: pd.DataFrame,
    groupby_set: List,
    aggregation_column: str,
    aggregation: List,
) -> pd.DataFrame:
    """
    A validation that calculates the rows that were dropped between a "before"
    dataframe and an "after" dataframe.

    Args:
        pre_op_input:
            A pandas dataframe containing the data before an operation was run
            (e.g. the dataframe before certain rows were dropped by running a
            function on the dataframe).
        post_op_input:
            A pandas dataframe containing the data after the operation  was run
            (e.g. the dataframe after duplicates were removed).
        groupby_set:
            A python list containing which columns the groupby should be
            applied to.
        aggregation_column:
            A python string indicating which column to use for the sum.
        aggregation:
            A python list specifying one or more accepted aggregation methods
            in pandas.
    Returns:
        A 2-tuple of integers containing (1) the number of rows removed and
        (2) the difference of column sums between the two dataframes (e.g.
        difference in the total number of travellers between the pre-operation
        and post-operation dataframes).
    """
    # Do a left merge to identify which rows belong to the first dataframe but
    # not the second.
    tmp = pd.merge(
        pre_op_input,
        post_op_input,
        left_index=True,
        right_index=True,
        how="left",
        indicator=True,
        suffixes=(None, "_y"),
    )
    # Identify which rows were only present in the left dataframe
    df = tmp[tmp["_merge"] == "left_only"]
    # Call df_groupby with the appropriate parameters
    df = df_groupby(
        input=df,
        groupby_set=groupby_set,
        aggregation_column=aggregation_column,
        aggregation=aggregation,
    )
    return df


def overfull_vehicle_validation(
    auxiliary_df: pd.DataFrame, df: pd.DataFrame, schema: "Tuplify",
) -> pd.DataFrame:
    """
    Implements the validation associated with overfull vehicles.

    Args:
        TODO
    """
    orig_df = df.copy()

    # Create UID for the dataframe prior to imputation
    auxiliary_df["uid"] = (
        auxiliary_df[schema.date].apply(str)
        + auxiliary_df[schema.sin].apply(str)
        + auxiliary_df[schema.cport].apply(str)
        + auxiliary_df[schema.lane].apply(str)
    )
    # Create UID for the dataframe after imputation
    orig_df["uid"] = (
        orig_df[schema.date].apply(str)
        + orig_df[schema.sin].apply(str)
        + orig_df[schema.cport].apply(str)
        + orig_df[schema.lane].apply(str)
    )
    auxiliary_df = get_total_passengers(auxiliary_df, schema)
    orig_df = get_total_passengers(orig_df, schema)
    # If auxiliary_df["uid"] and df["uid"] are the same and the total passengers
    # are different, there must have been an imputation.
    mask = (orig_df["uid"] == auxiliary_df["uid"]) & (
        auxiliary_df["total_passengers"] != orig_df["total_passengers"]
    )
    # Get the groupby df
    groupby_df = orig_df[mask][
        [schema.date, schema.cport, schema.country, schema.vehi,]
    ]
    groupby_df["count"] = 0
    groupby_df = (
        groupby_df.groupby(
            by=[schema.date, schema.cport, schema.country, schema.vehi,],
            dropna=False,
            as_index=False,
        ).count()
    ).astype({"count": "Int64"})

    orig_df = orig_df.drop(["total_passengers", "uid"], axis=1)

    return groupby_df


def overfull_vehicle_br(
    df: pd.DataFrame, mask: pd.Series, mask_compliment: pd.Series, schema: "Tuplify"
):
    """
    Implements the business rule associated with overfull vehicles.

    This business rule is relevant for ipil_hwy 130,140,150.

    Args:
        TODO
    """
    # Partition all commercial trucks into two sets: (left) those with more
    # than 4 passengers and (right) those with 4 or fewer passengers. This step
    # avoids the scenario where the nearest neighbour is also in violation.
    left = df[mask].copy()
    right = df[mask_compliment]
    # Pandas resets the index on merge, so keep a copy of which indices were
    # selected with the above criteria.
    left.loc[:, "copy_index"] = left.index
    # Perform a nearest neighbour merge on timestamp and criteria required.
    # Setting the index to "copy_index" so pandas knows how to update the input
    # dataframe downstream.
    values_to_update = pd.merge_asof(
        left,
        right,
        on="unix_timestamp",
        direction="nearest",
        by=[schema.cport, schema.country],
    ).set_index("copy_index")
    # If any values were not successfully updated (i.e. there are values of
    # total_passengers_y that are NaN), fallback to only conditioning on country
    # and vehicle type
    if values_to_update["total_passengers_y"].isnull().values.any():
        # Create a left frame that gets all entries with null values for
        # total_passengers_y
        left2 = left.loc[
            values_to_update[values_to_update["total_passengers_y"].isnull()].index
        ]
        # Copy index before merge
        left2.loc[:, "copy_index"] = left2.index
        # Drop any null values in values_to_update since these will be accounted
        # for by values_to_update_fallback
        values_to_update = values_to_update[
            ~values_to_update["total_passengers_y"].isnull()
        ]
        # Merge left2 with right, but now only using schema.country.name as a condition.
        values_to_update_fallback = pd.merge_asof(
            left2,
            right,
            on="unix_timestamp",
            direction="nearest",
            by=[schema.country, schema.province],
        ).set_index("copy_index")
        if values_to_update_fallback["total_passengers_y"].isnull().values.any():
            # Create a left frame that gets all entries with null values for
            # total_passengers_y
            left3 = input.loc[
                values_to_update_fallback[
                    values_to_update_fallback["total_passengers_y"].isnull()
                ].index
            ]
            # Copy index before merge
            left3.loc[:, "copy_index"] = left3.index
            # Drop null values
            values_to_update_fallback = values_to_update_fallback[
                ~values_to_update_fallback["total_passengers_y"].isnull()
            ]
            # Merge left3 with right without any conditions
            values_to_update_fallback_2 = pd.merge_asof(
                left3, right, on="unix_timestamp", direction="nearest"
            ).set_index("copy_index")
    if "values_to_update_fallback" in locals():
        values_to_update = pd.concat([values_to_update, values_to_update_fallback])
    if "values_to_update_fallback_2" in locals():
        values_to_update = pd.concat([values_to_update, values_to_update_fallback_2])
    # Sort indices in both tables
    df = df.sort_index()
    values_to_update = values_to_update.sort_index()
    # Perform the donor imputation using the nearest neighbour values from
    # 'total_passengers_y' in the values_to_update dataframe.
    df.loc[
        mask,
        [
            schema.cdsd,
            schema.cd1d,
            schema.cd2d,
            schema.ussd,
            schema.us1d,
            schema.us2d,
            schema.osd,
            schema.o1d,
            schema.o2d,
        ],
    ] = values_to_update[
        [
            "cdsd_y",
            "cd1d_y",
            "cd2d_y",
            "ussd_y",
            "us1d_y",
            "us2d_y",
            "osd_y",
            "o1d_y",
            "o2d_y",
        ]
    ].values
    # TODO: Do we want to sort the dataframes in a default way to avoid
    # unecessary and repetitive sorting operations.
    df = df.sort_index()
    df = df.drop(["total_passengers"], axis=1)

    return df


class RemovalReasons(AutoEnum):
    duplicate = "duplicate"
    invalid_province = "invalid_province"
    missing_date = "missing_date"
    zero_travellers = "zero_travellers"
