"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        WORK_LOCATIONS_TRANS file which defines how to determine each mode of
        transportation for a given data source.
"""

import pandera as pa
from pandera.typing import Series


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the WORK_LOCATIONS_TRANS reference file.
    """

    transportation_type: Series[pa.String] = pa.Field(
        description="Mode of transportation",
        coerce=True,
    )
    query: Series[pa.String] = pa.Field(
        description="Query to extract specified mode",
        coerce=True,
    )
    desc_en: Series[pa.String] = pa.Field(
        description="Description in English",
        coerce=True,
        nullable=True,
    )
    desc_fr: Series[pa.String] = pa.Field(
        description="Description in French",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.transportation_type, ReferenceSchema.query]
