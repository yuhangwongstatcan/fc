"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        FIXED PROPORTIONS reference file which defines the fixed proportions
        for user-defined imputation rules in the manual entry.
"""
import pandera as pa
from pandera.typing import Series

from datasource.common.types import SafeIntToStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the FIXED_PROPORTIONS reference file.
    """

    rule_id: Series[pa.String] = pa.Field(
        description="Unique ID for a fixed rule.", coerce=True,
    )
    value: Series[SafeIntToStringType] = pa.Field(
        description="The variable value that the proportion applies to.", coerce=True,
    )
    proportion: Series[pa.Float64] = pa.Field(
        description="Proportion of travellers defined to be assigned to the corresponding category.",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.rule_id, ReferenceSchema.value]