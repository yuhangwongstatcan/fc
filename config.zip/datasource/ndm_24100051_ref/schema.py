"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for the NDM_24100051_REF reference file.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.schema import NDMReferenceCommonSchema


class ReferenceSchema(NDMReferenceCommonSchema):
    """
    Schema for the NDM_24100051_REF reference file.
    """

    dim1: Series[pa.String] = pa.Field(
        description="Geography: Canada and major provinces (1-5)",
        coerce=True,
    )
    dim2: Series[pa.String] = pa.Field(
        description="Countries (1-89)",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.vector]
