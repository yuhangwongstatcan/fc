"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for the NDM_ADJUSTED data source.
"""

import pandera as pa
from pandera.typing import Series


class AggregatedSchema(pa.SchemaModel):
    """
    Schema for the NDM_ADJUSTED aggregate files.
    """

    reference_period: Series[pa.String] = pa.Field(
        description="Date of the monthly data for the NDM tables, the format is YYYY-MM-DD.",
        coerce=True,
    )
    vector: Series[pa.String] = pa.Field(
        description="Format v12345, provided by Dissemination.",
        coerce=True,
        nullable=True,
    )
    ndm_value: Series[pa.INT64] = pa.Field(
        description="Total for specific vector.",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [AggregatedSchema.reference_period, AggregatedSchema.vector]


SORT_NDM_ADJUSTED = [
    AggregatedSchema.reference_period,
    AggregatedSchema.vector,
]
