#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import shutil
from os.path import join
from datetime import datetime
import tempfile
from typing import Generator, List, Tuple

import numpy as np
import pandas as pd

from modules.s3client import S3Client
from modules.utils.loaders import Loader

from config.api import S3Location
from config.api import DataSource
from config.api import Stage
from config.api import S3

from config.models import NdmSaConfig

from modules.utils.data_manipulation import upload_files

from datasource.ndm_adjusted.schema import (
    AggregatedSchema as AdjustedSchema,
    SORT_NDM_ADJUSTED,
)
from datasource.sa_out.schema import AggregatedSchema as SAOutSchema
from datasource.ndm_sa.schema import ReferenceSchema as NDMSchema


def ndm_sa_rounding_generator() -> Generator[Tuple[List, str], None, None]:
    """A generator that iterates through all of the ndm_sa rounding groups
       that have to be rounded such that their sums equals their expected
       total exactly. This method has to iterate through many specific cases
       that can only be described through hand-crafted configuration (i.e.
       there is no pattern here; we have to use configuraiton that specifies
       all of the groups that need to sum correctly).

    Yields:
        Generator[Tuple[List, List], None, None]: Yields a tuple containing a list and a string.
    """
    # Load the configuration object
    ndm_sa_config = NdmSaConfig.factory()
    # 1.
    for dd in ndm_sa_config.dd:
        yield [f"{dd}ACTOTO", f"{dd}CATOTO", f"{dd}OTTOTO"], f"{dd}TOTOTO"
    # 2.
    for WWWW in ndm_sa_config.WWWW:
        yield [f"{dd}{WWWW}" for dd in ndm_sa_config.dd], f"00{WWWW}"


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """

    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """
    # Get ndm_sa table
    ndm_sa = Loader.get(Stage.REFERENCE, DataSource.ndm_sa, None)

    # 1. Download files to temporary folder
    sa_rk_out = client.get_CSV(location).sort_values(SAOutSchema.DATE)
    # Note for maintainers: the reason the code below is commented out is due to
    # work in progress around rounding the NDM adjusted data. Please see issue #362
    # in Gitlab for more information about this feature if it is ever required.
    # At present, however, we just take a simple rounding policy and accept small
    # rounding errors.

    # round_correct = 0
    # round_incorrect = 0
    # for group, total in ndm_sa_rounding_generator():
    #     for date in sa_rk_out[sa_rk_out_sch.date.name].unique()[0:1]:
    #         # Round all of the seasonally adjusted values.
    #         GROUP_MASK = (sa_rk_out[sa_rk_out_sch.series.name].isin(group)) & (
    #             sa_rk_out[sa_rk_out_sch.date.name] == date
    #         )
    #         TOTAL_MASK = (sa_rk_out[sa_rk_out_sch.series.name] == total) & (
    #             sa_rk_out[sa_rk_out_sch.date.name] == date
    #         )
    #         in_group_selection = set(sa_rk_out[GROUP_MASK]["SERIES"])
    #         should_be_in_group_selection = set(group)
    #         missing_group_selection = should_be_in_group_selection - in_group_selection
    #         # Cast the seasonal adjustment data to int
    #         sa_rk_out = largest_remainder_rounding_pandas(
    #             sa_rk_out, GROUP_MASK, TOTAL_MASK, sa_rk_out_sch.value.name,
    #         )
    #         # if (
    #         #         sa_rk_out[GROUP_MASK]["VALUE"].sum()
    #         #         > sa_rk_out[TOTAL_MASK]["VALUE"].sum()
    #         #     ):
    #         #         print(f"GROUP SUM IS:\t{sa_rk_out[GROUP_MASK]['VALUE'].sum()}")
    #         #         print(f"TOTAL SUM IS:\t{sa_rk_out[TOTAL_MASK]['VALUE'].sum()}")
    #         #         print(f"GROUP WAS:\t{group}")
    #         #         print(f"Total series is:\t{total}")
    #         #         round_incorrect = round_incorrect + 1
    #         #         continue
    #         if int(sa_rk_out[GROUP_MASK]["VALUE"].sum()) == int(
    #             sa_rk_out[TOTAL_MASK]["VALUE"]
    #         ):
    #             round_correct = round_correct + 1
    #         else:
    #             print(f"GROUP NOT EQUAL TOTAL:\t{group}\t{total}")
    #             round_incorrect = round_incorrect + 1

    # Unpivot ndm_sa so series that map to more than one ndm vector get
    # assigned to their own row.
    ndm_sa[NDMSchema.vectors_out] = ndm_sa[NDMSchema.vectors_out].str.split(",")
    ndm_sa = ndm_sa.explode(NDMSchema.vectors_out)

    # Merge sa_rk_out with ndm_sa["series", "vectors_out"] to get the ndm_adjusted vectors that
    # are derrived from the ndm seasonally adjusted series.
    ndm_adj = pd.merge(
        left=sa_rk_out,
        right=ndm_sa[[NDMSchema.series, NDMSchema.vectors_out]],
        how="left",
        left_on=SAOutSchema.SERIES,
        right_on=NDMSchema.series,
    )
    # Get the subset of columns for the output tables
    ndm_adj = ndm_adj[[SAOutSchema.DATE, NDMSchema.vectors_out, SAOutSchema.VALUE,]]
    # Add the "01" for days in reference_period
    ndm_adj[SAOutSchema.DATE] = ndm_adj[SAOutSchema.DATE].astype("str")
    ndm_adj[SAOutSchema.DATE] = ndm_adj[SAOutSchema.DATE] + "01"

    # Make the ndm_adj data integer rather than float.
    ndm_adj[SAOutSchema.VALUE] = np.floor(ndm_adj[SAOutSchema.VALUE])

    # Rename the columns to match ndm_adj
    ndm_adj.columns = list(AdjustedSchema.to_schema().columns.keys())

    # Set to store local files
    localnames = set([])

    # Group by date and write
    tmpdir = tempfile.mkdtemp()
    gdf = ndm_adj.groupby([AdjustedSchema.reference_period])

    for date in gdf.groups:
        _df = gdf.get_group(date)
        df_date = datetime.strptime(str(date), "%Y%m%d")
        year = int(df_date.year)
        month = int(df_date.month)
        day = int(df_date.day)
        filename = S3.get_s3_basename(
            Stage.AGGREGATED, DataSource.ndm_adjusted, year, month, day
        )
        localname = join(tmpdir, filename)
        localnames.add(localname)
        _df.to_csv(localname, index=False, header=None)

    # Move the ndm_adjusted files to the appropriate S3 Locations
    upload_files(
        client,
        list(localnames),
        Stage.AGGREGATED,
        DataSource.ndm_adjusted,
        AdjustedSchema,
        SORT_NDM_ADJUSTED,
        fallback_on_conflicts=False,
        fallback_on_historical=True,
    )
    shutil.rmtree(tmpdir)
    return True
