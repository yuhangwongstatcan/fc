"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        WORK_LOCATIONS_ACTION file which defines how to execute the specified
        action for a given data source and mode of transportation.
"""

import pandera as pa
from pandera.typing import Series


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the WORK_LOCATIONS_ACTION reference file.
    """

    action: Series[pa.String] = pa.Field(
        description="Action to be executed for the port and mode of transportation",
        coerce=True,
    )
    column: Series[pa.String] = pa.Field(
        description="Column in which recode action will occur",
        coerce=True,
    )
    value: Series[pa.String] = pa.Field(
        description="Value which the affected column should be coded to",
        coerce=True,
    )
    desc_en: Series[pa.String] = pa.Field(
        description="Description in English",
        coerce=True,
        nullable=True,
    )
    desc_fr: Series[pa.String] = pa.Field(
        description="Description in French",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.action, ReferenceSchema.column]
