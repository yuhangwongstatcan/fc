"""
    Program: dim.py

    Author: Nicole Vingerhoeds, nicole.vingerhoeds@statcan.gc.ca
            Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Create enumerable classes of dimension variables and their possible values
        to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""
from enum import auto
from config.api import AutoEnum


class DURATION2(AutoEnum):
    same_day = "1"
    overnight = "2"


class FROM(AutoEnum):
    canada = "CANADA"
    other_country_direct = "OTHER COUNTRY DIRECT / AUTRE PAYS DIRECT"
    other_country_via_us = "OTHER COUNTRY VIA U.S. / AUTRE PAYS VIA LES É.-U."
    us_only = "U.S. ONLY / É.-U. SEULEMENT"


class MODE(AutoEnum):
    air = "AIR"
    marine = "MARINE"


class TRANS_TYPE(AutoEnum):
    commercial = "C"
    military = "M"
    private = "P"
    ferry = "F"


class TRAV_CHAR(AutoEnum):
    crew = auto()
    passenger = auto()
    passenger_ovn = auto()
    passenger_ovs = auto()
    passenger_sdy = auto()
    passenger_usa = auto()
