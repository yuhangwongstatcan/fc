"""
Implements the e63_020 business rule
"""
import pandas as pd

from datasource.e63.schema import RawSchema, ValidationSchema, E63_V020_COLUMNS
from datasource.e63.dim import MODE, FROM, TRANS_TYPE


def e63_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Recode variables used to determine E63 transportation type based on auxiliary information.

    Args:
        input:
            A pandas dataframe with invalid or blank transportation type
    Returns:
        A pandas dataframe with edited transportation type
    """
    df_working = df.copy()
    df_working.loc[:, RawSchema.notes] = df_working.loc[:, RawSchema.notes].str.upper()
    df_working.loc[:, RawSchema.report_number] = df_working.loc[
        :, RawSchema.report_number
    ].str.upper()

    # Filter for rows that match business logic conditions
    TRC_invalid_mask = (
        (df_working[RawSchema.trc] == "X")
        | (df_working[RawSchema.notes].fillna("").isin(["TRC", "CANPASS"]))
        | (
            df_working[RawSchema.report_number]
            .fillna("")
            .str.slice(stop=4)
            .str.contains(
                df_working[RawSchema.date].fillna("").str.slice(stop=4).tolist()[0]
            )
        )
    )

    coasting_highseas_fishing_mask = (
        df_working[RawSchema.mode] == MODE.marine.value
    ) & (df_working[RawSchema.coasting] == "X")

    canada_coasting_mask = (df_working[RawSchema.mode] == MODE.marine.value) & (
        df_working[RawSchema.from_] == FROM.canada.value
    )

    flight_canada_origin = (df_working[RawSchema.mode] == MODE.air.value) & (
        df_working[RawSchema.from_] == FROM.canada.value
    )

    technical_repair_fuel_mask = (df_working[RawSchema.tech_stop] == "X") & (
        df_working[RawSchema.trans_type] == TRANS_TYPE.commercial.value
    )
    technical_repair_fuel_mask2 = (
        df_working[RawSchema.port].isin(["9121", "10912", "1091290", "10913", "10914"])
    ) & (df_working[RawSchema.notes] == "VARIOUS")

    # Identify which entries will be removed by this business rule
    # NA does not indicate removal
    # These go into the auxiliary df
    removal_mask = (
        TRC_invalid_mask
        | coasting_highseas_fishing_mask
        | canada_coasting_mask
        | flight_canada_origin
        | technical_repair_fuel_mask
        | technical_repair_fuel_mask2
    ).fillna(False)
    auxiliary_df = df[removal_mask]

    # Keep entries that have not been marked for removal
    df = df[~removal_mask]

    return RawSchema(df), auxiliary_df


def e63_v020(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule e63_000

    Args:
        input:
            a pandas dataframe containing records that possibly contain
            invalid column values
    Returns:
        The return value of e63_v000
    """
    if not auxiliary_df.empty:
        # Temporarily make these columns all caps for easy comparison
        auxiliary_df.loc[:, RawSchema.notes] = auxiliary_df.loc[
            :, RawSchema.notes
        ].str.upper()
        auxiliary_df.loc[:, RawSchema.report_number] = auxiliary_df.loc[
            :, RawSchema.report_number
        ].str.upper()

        TRC_invalid_mask = (
            (auxiliary_df[RawSchema.trc] == "X")
            | (auxiliary_df[RawSchema.notes].fillna("").isin(["TRC", "CANPASS"]))
            | (
                auxiliary_df[RawSchema.report_number]
                .fillna("")
                .str.slice(stop=4)
                .str.contains(
                    auxiliary_df[RawSchema.date]
                    .fillna("")
                    .str.slice(stop=4)
                    .tolist()[0]
                )
            )
        )

        validation_df = auxiliary_df[TRC_invalid_mask].copy()
        validation_df[ValidationSchema.removal_reason] = "TRC/CANPASS"

        coasting_highseas_fishing_mask = (
            auxiliary_df[RawSchema.mode] == MODE.marine.value
        ) & (auxiliary_df[RawSchema.coasting] == "X")
        canada_coasting_mask = (auxiliary_df[RawSchema.mode] == MODE.marine.value) & (
            auxiliary_df[RawSchema.from_] == FROM.canada.value
        )
        validation_df = validation_df.append(
            auxiliary_df[coasting_highseas_fishing_mask | canada_coasting_mask]
        )
        validation_df.loc[
            validation_df[ValidationSchema.removal_reason].isnull(),
            ValidationSchema.removal_reason,
        ] = "Coasting/High Seas"

        flight_canada_origin = (auxiliary_df[RawSchema.mode] == MODE.air.value) & (
            auxiliary_df[RawSchema.from_] == FROM.canada.value
        )
        validation_df = validation_df.append(auxiliary_df[flight_canada_origin])
        validation_df.loc[
            validation_df[ValidationSchema.removal_reason].isnull(),
            ValidationSchema.removal_reason,
        ] = "Domestic Flights"

        technical_repair_fuel_mask = (auxiliary_df[RawSchema.tech_stop] == "X") & (
            auxiliary_df[RawSchema.trans_type] == TRANS_TYPE.commercial.value
        )
        technical_repair_fuel_mask2 = (
            auxiliary_df[RawSchema.port].isin(["9121", "10912", "1091290"])
        ) & (auxiliary_df[RawSchema.notes] == "VARIOUS")
        validation_df = validation_df.append(
            auxiliary_df[technical_repair_fuel_mask | technical_repair_fuel_mask2]
        )
        validation_df.loc[
            validation_df[ValidationSchema.removal_reason].isnull(),
            ValidationSchema.removal_reason,
        ] = "Technical/Repair/Fuel Stops"

        # Drop duplicate values from the validation logging into the case where travellers were logged under more than one category
        # This is possible if e.g. a movement was identified as FROM == CANADA, and COASTING set == X
        validation_df.drop_duplicates(
            subset=[
                RawSchema.port,
                RawSchema.mode,
                RawSchema.date,
                RawSchema.report_number,
                RawSchema.from_,
                RawSchema.trans_type,
                RawSchema.country_of_residence,
                RawSchema.trav_char,
            ],
            inplace=True,
        )

        # All references from here should be to ValidationSchema
        validation_df = validation_df.loc[:, E63_V020_COLUMNS]
        validation_df = validation_df.groupby(
            by=[
                ValidationSchema.removal_reason,
                ValidationSchema.port,
                ValidationSchema.date,
            ],
            dropna=False,
            as_index=False,
        )
        validation_df = validation_df[[ValidationSchema.count]].apply(
            lambda x: x.astype("Int64").sum()
        )

        validation_df = validation_df.loc[:, E63_V020_COLUMNS]
        validation_df = validation_df.sort_values(ValidationSchema.removal_reason)
        validation_df = ValidationSchema(validation_df)
    else:
        # If the auxiliary df is empty,
        # return a blank df following the schema
        validationschema_cols = ValidationSchema.to_schema().columns
        validation_df = pd.DataFrame(
            {
                col: pd.Series(dtype=str(validationschema_cols[col].dtype))
                for col in E63_V020_COLUMNS
            }
        )

    return validation_df
