"""
Implements the e63_007 Business Rule
"""
import pandas as pd

from datasource.e63.schema import RawSchema
from datasource.e63.dim import TRANS_TYPE


def e63_007(df: pd.DataFrame) -> pd.DataFrame:
    """
    Recode variables used to determine E63 transportation type based on auxiliary information.

    Args:
        df:
            A pandas dataframe with invalid or blank transportation type
    Returns:
        A pandas dataframe with edited transportation type
    """
    nhl = "NHL"
    military_report = "CF|RR"
    military_notes = [
        "MARINE CORPS",
        "CANADIAN FORCES",
        "CAN FORCE",
        "AIR FORCE",
        "COAST GUARD",
        "AIR NATIONAL GUARD",
        "12 WING",
        "RYAN INTERNATIONAL",
        "AIR SHOW",
    ]
    military_notes_acronym = [
        "USMC",
        "NAVY",
        "USN",
        "ARMY",
        "CF",
        "USAF",
        "CAF",
        "GAF",
        "RAF",
        "USCG",
        "AFB",
        "TUAF",
        "AFSOC",
        "GFD",
        "HERCULES",
    ]
    # Apply masks and recode values accordingly.
    working_df = df.copy()
    working_df[RawSchema.notes] = working_df[RawSchema.notes].str.upper()
    working_df[RawSchema.report_number] = working_df[
        RawSchema.report_number
    ].str.upper()

    working_df.loc[
        working_df[RawSchema.ambulance] == "X", RawSchema.trans_type
    ] = TRANS_TYPE.private.value
    working_df.loc[
        working_df[RawSchema.notes].fillna("").str.contains(nhl), RawSchema.trans_type
    ] = TRANS_TYPE.private.value
    military_flight_mask = (
        (working_df[RawSchema.notes].fillna("").isin(military_notes_acronym))
        | (working_df[RawSchema.notes].fillna("").isin(military_notes))
    ) | (
        working_df[RawSchema.report_number]
        .fillna("")
        .str.slice(stop=2)
        .str.contains(military_report)
    )
    working_df.loc[
        military_flight_mask, RawSchema.trans_type
    ] = TRANS_TYPE.military.value
    military_ships = "HMCS"
    military_ship_notes = ["MARINE CORPS", "COAST GUARD"]
    military_ship_notes_acronym = ["USMC", "NAVY", "USN", "ARMY", "CF", "USCG"]
    military_ship_notes = "|".join([f"{acr}\s" for acr in military_ship_notes])
    military_ship_notes_acronym = "|".join(
        [f"{acr}" for acr in military_ship_notes_acronym]
    )

    military_ship_mask = (
        (working_df[RawSchema.notes].fillna("").str.contains(military_ship_notes))
        | (
            working_df[RawSchema.notes]
            .fillna("")
            .str.contains(military_ship_notes_acronym)
        )
    ) | (working_df[RawSchema.report_number].fillna("").str.contains(military_ships))
    working_df.loc[military_ship_mask, RawSchema.trans_type] = TRANS_TYPE.military.value
    cargo_notes = [
        "CARGO",
        "COURIER",
        "FEDEX",
        "FDX",
        "FX",
        "UPS",
        "DHL",
        "CJT",
        "ADB",
        "ANTONOV",
        "LYC",
        "LYNDEN",
        "CVK",
        "CAVOK",
    ]
    cargo_notes = "|".join([f"{acr}" for acr in cargo_notes])
    working_df.loc[
        working_df[RawSchema.notes].fillna("").str.contains(cargo_notes),
        RawSchema.cargo,
    ] = "X"

    df[RawSchema.cargo] = working_df[RawSchema.cargo]

    ferry_notes = [
        "NORDET",
        "SUROIT",
    ]
    ferry_notes = "|".join([f"{acr}" for acr in ferry_notes])
    working_df.loc[
        working_df[RawSchema.notes].fillna("").str.contains(ferry_notes),
        RawSchema.trans_type,
    ] = TRANS_TYPE.ferry.value

    df[RawSchema.trans_type] = working_df[RawSchema.trans_type]

    # Temporary code to recode certain country codes until use of
    # new E63 template is widespread among ports

    # These country codes were updated in May 2023 to reflect updated
    # continents for these countries, but if older E63 templates are returned
    # then the country code may not be correct

    # British Indian Ocean Territory
    working_df.loc[
        working_df[RawSchema.country_of_residence] == "44086",
        RawSchema.country_of_residence,
    ] = "32086"
    # Christmas Island
    working_df.loc[
        working_df[RawSchema.country_of_residence] == "51162",
        RawSchema.country_of_residence,
    ] = "53162"
    # Cocos Islands
    working_df.loc[
        working_df[RawSchema.country_of_residence] == "51166",
        RawSchema.country_of_residence,
    ] = "53166"
    # Norfolk Island
    working_df.loc[
        working_df[RawSchema.country_of_residence] == "51574",
        RawSchema.country_of_residence,
    ] = "52574"

    df[RawSchema.country_of_residence] = working_df[RawSchema.country_of_residence]

    return RawSchema(df)
