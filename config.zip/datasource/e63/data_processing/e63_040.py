"""
Implements the e63_040 business rule
"""
from typing import Dict, List
import pandas as pd
import numpy as np
import datetime
import pandera as pa

from datasource.e63.schema import RawSchema, RAWSCHEMA_COLUMNS, E_63_040_GROUPBY_COLUMNS
from datasource.travellers.dim import COUNTRY_OF_RESIDENCE


def create_imputation_dataframe(
    df: pd.DataFrame, num_unknown_passengers: int, seed: int, schema: pa.SchemaModel
) -> pd.DataFrame:
    # Reset the random seed for every group
    np.random.seed(seed)
    imputation_df = pd.DataFrame(
        {
            "random_number": np.random.uniform(0, 1, num_unknown_passengers),
            schema.country_of_residence: ["" for i in range(0, num_unknown_passengers)],
        }
    )

    # Use the generated intervals and the uniform random numbers to provide
    # a country assignment.
    for _, row in df.iterrows():
        # Assign country_of_residence based on the random number and bounds
        imputation_df.loc[
            (imputation_df["random_number"] >= row["lower_bound"])
            & (imputation_df["random_number"] < row["upper_bound"]),
            schema.country_of_residence,
        ] = row[schema.country_of_residence]

    # COUNT(count) GROUP BY country_of_residence to get the number of extra
    # travellers to allocate to each country code.
    imputation_df = imputation_df.groupby(
        schema.country_of_residence, as_index=False
    ).count()
    imputation_df.columns = [schema.country_of_residence, "extra_travellers"]
    return imputation_df.astype(
        {
            schema.country_of_residence: pd.StringDtype(),
            "extra_travellers": pd.Int64Dtype(),
        }
    )


def add_interval_bounds(df: pd.DataFrame, schema: pa.SchemaModel) -> pd.DataFrame:
    unknown_mask = (
        df[schema.country_of_residence] != COUNTRY_OF_RESIDENCE.overseas.value
    )
    df.loc[unknown_mask, "proportion"] = df.loc[unknown_mask, "count"] / int(
        df.loc[unknown_mask, "count"].sum()
    )

    # Generate lower/upper bounds based on these proportions
    df.loc[unknown_mask, "lower_bound"] = (
        df.loc[unknown_mask, "proportion"].cumsum().shift(fill_value=0)
    )
    df.loc[unknown_mask, "upper_bound"] = df.loc[unknown_mask, "proportion"].cumsum()
    return df


def impute_countries(
    x: pd.DataFrame, seed: int, schema: pa.SchemaModel
) -> pd.DataFrame:
    # Only consider rows where country_code != 99998
    COUNTRY_UNKNOWN = (
        x[schema.country_of_residence] == COUNTRY_OF_RESIDENCE.overseas.value
    )

    # If there are no records with country unknown, return x as there is no
    # imputation required. Additionally, if *only* unknown countries are found,
    # also return x because there are no other records in the imputation group
    # that could be used as donors.
    if not COUNTRY_UNKNOWN.any() or COUNTRY_UNKNOWN.all():
        return x[RAWSCHEMA_COLUMNS]

    # Keep track of the number of unknown passengers, and drop that row
    # from the table (the unknown passengers will be redistributed across
    # the remaining passengers).
    NUM_UNKNOWN = x.loc[COUNTRY_UNKNOWN, "count"].sum()

    # Generate the within-group proportion
    x = add_interval_bounds(x, schema)

    # Generate the imputation dataframe
    imputation_df = create_imputation_dataframe(x, NUM_UNKNOWN, seed, schema)

    # Merge the imputation_df back to x using country_of_residence as the
    # merge key.
    x["merge_key"] = 1
    imputation_df["merge_key"] = 1
    to_impute = pd.merge(
        x.loc[COUNTRY_UNKNOWN, :],
        imputation_df,
        how="left",
        on="merge_key",
    )
    to_impute["country_of_residence"] = to_impute["country_of_residence_y"]
    to_impute["count"] = to_impute["extra_travellers"]
    to_impute = to_impute[RAWSCHEMA_COLUMNS]
    x = pd.concat([to_impute, x.loc[~COUNTRY_UNKNOWN, :]])

    # Since we possibly create true duplicates with the logic above, we need
    # to re-aggregate on all columns except `count` to prevent duplicate rows
    # from being created.
    x = x[RAWSCHEMA_COLUMNS]

    x = x.groupby(by=E_63_040_GROUPBY_COLUMNS, dropna=False, as_index=False).sum()
    # Return the dataframe with only the original schema columns
    return x


def recursive_donor_imputation(
    df: pd.DataFrame,
    cols: Dict[str, List[str]],
    recursion_counter: int,
    recursion_max: int,
    schema: pa.SchemaModel,
) -> pd.DataFrame:
    """Carry out recursive donor imputations specified by a subset of columns (cols).

    Args:
        df (pd.DataFrame): [description]
        cols (Dict[int]): [description]
    """
    # Check if we've hit the max of our recursion depth.
    if recursion_counter > recursion_max:
        return df[RAWSCHEMA_COLUMNS]

    # If there are no more countries of residence to impute, return
    if not (
        df[schema.country_of_residence] == COUNTRY_OF_RESIDENCE.overseas.value
    ).any():
        return df[RAWSCHEMA_COLUMNS]

    # Load unconsidered countries
    UNCONSIDERED_COUNTRIES = [
        COUNTRY_OF_RESIDENCE.canada.value,
        COUNTRY_OF_RESIDENCE.united_states.value,
    ]

    # Random seed
    current_date = datetime.datetime.strptime(df[schema.date].iloc[0], "%Y-%m-%d")
    SEED = int(str(current_date.year) + f"{current_date.month:02d}")

    # 1. Generate the imputed values for non Canada / non US travellers.
    tmp = (
        df.loc[~(df[schema.country_of_residence].isin(UNCONSIDERED_COUNTRIES)), :]
        .groupby(by=cols[recursion_counter], as_index=False, dropna=False)
        .apply(impute_countries, seed=SEED, schema=schema)
    )

    # 2. APPEND tmp with the rows that were not imputed
    df = pd.concat(
        [
            tmp,
            df.loc[(df[schema.country_of_residence].isin(UNCONSIDERED_COUNTRIES)), :],
        ]
    ).reset_index(drop=True)

    # 3. Check if any further imputation is required, if yes carry out another
    # recursive call and increment the recursion counter.
    return recursive_donor_imputation(
        df, cols, recursion_counter + 1, recursion_max, schema
    )


def e63_040(df: pd.DataFrame) -> pd.DataFrame:
    """Assign a country of residence to passengers/crew whose country of residence is coded as "other".

    Args:
        df: pd.DataFrame
            A Pandas dataframe with records whose country of residence is coded as "other"

    Returns:
        A Pandas dataframe with country of residence imputed for "other" records
    """

    # Set up recursion conditions
    COLS = {
        0: [
            RawSchema.date,
            RawSchema.port,
            RawSchema.report_number,
            RawSchema.trav_char,
        ],
        1: [
            RawSchema.date,
            RawSchema.port,
            RawSchema.mode,
            RawSchema.trav_char,
        ],
        2: ["month", RawSchema.port, RawSchema.trav_char],
        3: ["month", RawSchema.mode, RawSchema.trav_char],
    }

    # Create month column in case it is required as part of the
    df = RawSchema(df)
    df["month"] = df[RawSchema.date].str.split("-", expand=True)[1]
    RECURSION_MAX = len(COLS.keys()) - 1
    df = recursive_donor_imputation(df, COLS, 0, RECURSION_MAX, RawSchema)
    return RawSchema(df.fillna(pd.NA))
