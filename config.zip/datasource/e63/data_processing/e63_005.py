"""
Implements the e63_005 business rule
"""
import pandas as pd

from config.api import DataSource

from datasource.e63.schema import RawSchema, RAWSCHEMA_COLUMNS
from datasource.work_locations_trans_action.schema import ReferenceSchema as WLTASchema

from modules.utils.loaders import Loader

from config.api import WorkLocationsTransAction
from config.api import Stage


def e63_005(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure that all port codes from the E63 raw data are 5 digits.

    Args:
        input:
            A pandas dataframe with port codes that are not 5 digits
    Returns:
        A pandas dataframe where all port codes are five digits
    """
    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__e63,
    )
    work_locations = WLTASchema(work_locations)
    work_locations = work_locations.rename(columns={"work_location": "port"})

    df["is_invalid"] = df[RawSchema.port].str.len() == 3
    left = df[df["is_invalid"]]
    right = work_locations
    # Conditional on being a valid port, the digit portion is everything from the second
    # character position onward (inclusive)
    right["port_sub"] = right["port"].astype(str).str[2:].copy()
    # Keep only relevant columns for illustration purposes
    left = left[[RawSchema.port]].copy()
    right = right[["port", "port_sub"]].copy()
    # Left join on date, wloc, and flight/flight digits for left/right tables respectively
    left.loc[:, "copy_index"] = left.index
    values_to_update = pd.merge(
        left, right, left_on=[RawSchema.port], right_on=["port_sub"], how="left"
    ).set_index("copy_index")
    values_to_update = values_to_update[
        ~values_to_update.index.duplicated(keep="first")
    ]
    # Update port from matched values
    df.loc[df["is_invalid"], [RawSchema.port]] = values_to_update[
        ["port_y"]
    ].values.astype("str")

    return RawSchema(df[RAWSCHEMA_COLUMNS])
