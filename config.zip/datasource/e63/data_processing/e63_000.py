"""
Implements the e63_000 business rule
"""
import pandas as pd
from modules.utils.data_manipulation import validate_dimensions

from datasource.e63.schema import RawSchema, ValidationSchema

from config.api import DataSource


def e63_v000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule e63_000

    Args:
        input:
            a pandas dataframe containing records that possibly contain
            invalid dimension column values
    Returns:
        A pandas dataframe with validated dimension columns
    """
    cname_loc = RawSchema.port
    cname_date = RawSchema.date

    validation_df = validate_dimensions(
        df,
        RawSchema,
        ValidationSchema,
        cname_loc,
        cname_date,
        DataSource.e63,
    )

    return ValidationSchema(validation_df)
