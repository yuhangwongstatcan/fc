"""
Implements the e63_060 business rule
"""
import pandas as pd

# Travellers imports
from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    DURATION3,
    DURATION5,
    PURPOSE4,
    PURPOSE9,
    DATA_SOURCE,
    VEHICLE_TYPE,
    TRAVELLER_TYPE,
    PLATE_REGION,
    PLATE_COUNTRY,
    DAY,
    COUNTRY_OF_RESIDENCE,
)

# Rename dims that exist in both travellers and E63
from datasource.travellers.dim import MODE as TRAVELLERS_MODE
from datasource.travellers.dim import DURATION2 as TRAVELLERS_DURATION2

# E63 imports
from datasource.e63.schema import CleanSchema
from datasource.e63.dim import FROM, TRANS_TYPE, TRAV_CHAR
from datasource.e63.dim import MODE as E63_MODE


def e63_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Bryan Southwell - `bryan.southwell.brown@canada.ca`

    **Created On:** May, 2021

    **Description:**

    Performs the business logic that transforms cleaned E63 data into E63's contribution
    to the travellers table.

    Args:
        input: pd.DataFrame

    Returns:
        pd.DataFrame:
            A dataframe containing E63's contribution to the travellers table.
    """
    # Load in country values
    CAN = COUNTRY_OF_RESIDENCE.canada.value
    USA = COUNTRY_OF_RESIDENCE.united_states.value

    # 1. Add a data source column and set it to PIK
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.E63.value

    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        CleanSchema.date
    ].str.split("-", expand=True)
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
    ]
    df[TransformedSchema.month] = df[TransformedSchema.month].replace(
        {r"0(\d)": r"\1"}, regex=True
    )
    df[TransformedSchema.day] = df[TransformedSchema.day].replace(
        {r"0(\d)": r"\1"}, regex=True
    )

    df[TransformedSchema.work_location] = df[CleanSchema.port]
    df[TransformedSchema.port] = df[CleanSchema.port]

    # For the purposes of booleans correctly working on the cargo column, fill NAs with empty strings
    df[CleanSchema.cargo] = df[CleanSchema.cargo].fillna("")

    df.loc[
        df[CleanSchema.mode] == E63_MODE.air.value, TransformedSchema.vehicle_type
    ] = VEHICLE_TYPE.commercial_aircraft.value
    df.loc[
        (df[CleanSchema.mode] == E63_MODE.air.value) & (df[CleanSchema.cargo] == "X"),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.cargo_aircraft.value
    df.loc[
        (df[CleanSchema.mode] == E63_MODE.air.value)
        & (
            df[CleanSchema.trans_type].isin(
                [TRANS_TYPE.military.value, TRANS_TYPE.private.value]
            )
        ),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.private_aircraft.value
    df.loc[
        (df[CleanSchema.mode] == E63_MODE.marine.value)
        & (df[CleanSchema.trans_type] == TRANS_TYPE.commercial.value)
        & (df[CleanSchema.cargo] != "X"),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.cruise_ship.value
    df.loc[
        (df[CleanSchema.mode] == E63_MODE.marine.value)
        & (df[CleanSchema.cargo] == "X"),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.cargo_ship.value
    df.loc[
        (df[CleanSchema.mode] == E63_MODE.marine.value)
        & (df[CleanSchema.trans_type] == TRANS_TYPE.ferry.value)
        & (df[CleanSchema.cargo] != "X"),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.ferry_unknown.value
    df.loc[
        (df[CleanSchema.mode] == E63_MODE.marine.value)
        & (
            df[CleanSchema.trans_type].isin(
                [TRANS_TYPE.military.value, TRANS_TYPE.private.value]
            )
        )
        & (df[CleanSchema.cargo] != "X"),
        TransformedSchema.vehicle_type,
    ] = VEHICLE_TYPE.private_boat.value
    # The two lines below must be done after vehicle type assignment otherwise conditions on mode column will fail
    df.loc[
        df[CleanSchema.mode] == E63_MODE.air.value, TransformedSchema.mode
    ] = TRAVELLERS_MODE.air.value
    df.loc[
        df[CleanSchema.mode] == E63_MODE.marine.value, TransformedSchema.mode
    ] = TRAVELLERS_MODE.water.value

    df[TransformedSchema.plate_country] = PLATE_COUNTRY.not_available.value
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value

    arrive_mask1 = df[CleanSchema.from_] == FROM.other_country_via_us.value
    arrive_mask2 = (df[CleanSchema.from_] == FROM.other_country_direct.value) & (
        df[CleanSchema.trav_char] != TRAV_CHAR.passenger_usa.value
    )
    arrive_mask3 = (df[CleanSchema.from_] == FROM.other_country_direct.value) & (
        df[CleanSchema.trav_char] == TRAV_CHAR.passenger_usa.value
    )
    arrive_mask4 = (
        (df[CleanSchema.from_] == FROM.us_only.value)
        & (df[CleanSchema.country_of_residence].isin([CAN, USA]))
        & (df[CleanSchema.trav_char] != TRAV_CHAR.passenger_ovs.value)
    )
    arrive_mask5 = (df[CleanSchema.from_] == FROM.us_only.value) & (
        (~df[CleanSchema.country_of_residence].isin([CAN, USA]))
        | (df[CleanSchema.trav_char] == TRAV_CHAR.passenger_ovs.value)
    )

    df.loc[
        arrive_mask1, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.ovs_via_us.value
    df.loc[
        arrive_mask2, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.ovs_direct.value
    df.loc[
        arrive_mask3, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.ovs_via_us.value
    df.loc[
        arrive_mask4, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.us_only.value
    df.loc[
        arrive_mask5, [TransformedSchema.arriving_from]
    ] = ARRIVING_FROM.ovs_via_us.value

    purp_mask1 = df[CleanSchema.trans_type] == TRANS_TYPE.military.value
    df.loc[purp_mask1, [TransformedSchema.purpose4, TransformedSchema.purpose9]] = [
        PURPOSE4.other_purpose.value,
        PURPOSE9.military.value,
    ]
    purp_mask2 = df[CleanSchema.trav_char] == TRAV_CHAR.crew.value
    df.loc[
        ~purp_mask1 & purp_mask2,
        [TransformedSchema.purpose4, TransformedSchema.purpose9],
    ] = [
        PURPOSE4.crew.value,
        PURPOSE9.crew.value,
    ]
    df.loc[
        ~purp_mask1 & ~purp_mask2,
        [TransformedSchema.purpose4, TransformedSchema.purpose9],
    ] = [
        PURPOSE4.visit.value,
        PURPOSE9.visit.value,
    ]

    df[TransformedSchema.duration2] = df[CleanSchema.duration2]
    df[TransformedSchema.duration3] = DURATION3.not_available.value
    df[TransformedSchema.duration5] = DURATION5.not_available.value

    travel_mask1 = (df[TransformedSchema.purpose4] == PURPOSE4.other_purpose.value) | (
        (df[TransformedSchema.purpose4] == PURPOSE4.crew.value)
        & (
            df[TransformedSchema.vehicle_type].isin(
                [
                    VEHICLE_TYPE.commercial_aircraft.value,
                    VEHICLE_TYPE.cargo_aircraft.value,
                    VEHICLE_TYPE.cruise_ship.value,
                    VEHICLE_TYPE.cargo_ship.value,
                    VEHICLE_TYPE.ferry_unknown.value,
                ]
            )
        )
    )
    df.loc[
        travel_mask1, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.other_traveller.value

    travel_mask2 = (
        df[TransformedSchema.duration2] == TRAVELLERS_DURATION2.same_day.value
    )
    df.loc[
        ~travel_mask1 & travel_mask2, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.excursionist.value

    travel_mask3 = (
        df[TransformedSchema.duration2] == TRAVELLERS_DURATION2.overnight.value
    )
    df.loc[
        (~travel_mask1 & ~travel_mask2) & travel_mask3, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.tourist.value

    df[TransformedSchema.count_of_entries] = df[CleanSchema.count]
    df = df[TRANSFORMED_COLUMNS]
    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = (
        df.groupby(
            by=TRANSFORMED_GROUPBY,
            dropna=False,
        )
        .sum()
        .reset_index()
    )

    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS
    # Reorder the red columns
    df = df[TRANSFORMED_COLUMNS]
    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]
    # Sort entries from left to right
    df = df.sort_values(
        TRANSFORMED_COLUMNS,
        ascending=True,
    )
    df = TransformedSchema(df)

    return df
