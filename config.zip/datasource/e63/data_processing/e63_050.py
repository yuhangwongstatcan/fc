"""
Implements the e63_050 business rule
"""
import numpy as np
import pandas as pd

from datasource.e63.schema import CleanSchema, CLEANSCHEMA_COLUMNS
from datasource.e63.dim import TRANS_TYPE, TRAV_CHAR, DURATION2
from datasource.travellers.dim import COUNTRY_OF_RESIDENCE


def e63_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute a duration of same-day or overnight for all Canadian and Overseas
    resident passengers and crew, and American crew, on E63 forms.

     Args:
         input:
             A pandas dataframe without duration2
     Returns:
         A pandas dataframe with duration2 values
    """
    USA = COUNTRY_OF_RESIDENCE.united_states.value
    CANADA = COUNTRY_OF_RESIDENCE.canada.value

    df.loc[
        (
            (df[CleanSchema.country_of_residence] == USA)
            & (df[CleanSchema.trav_char] == TRAV_CHAR.passenger_sdy.value)
        )
        | (
            (df[CleanSchema.trans_type] == TRANS_TYPE.ferry.value)
            & (df[CleanSchema.trav_char] == TRAV_CHAR.crew.value)
        ),
        CleanSchema.duration2,
    ] = DURATION2.same_day.value

    df.loc[
        (df[CleanSchema.country_of_residence] == USA)
        & (df[CleanSchema.trav_char] == TRAV_CHAR.passenger_ovn.value),
        CleanSchema.duration2,
    ] = DURATION2.overnight.value

    # Auxiliary_df contains the rows that need to be imputed
    auxiliary_df = df[
        (
            (df[CleanSchema.country_of_residence] != USA)
            & (
                df[CleanSchema.trav_char].isin(
                    [
                        TRAV_CHAR.passenger.value,
                        TRAV_CHAR.passenger_usa.value,
                        TRAV_CHAR.passenger_ovs.value,
                    ]
                )
            )
        )
        | (
            (df[CleanSchema.trav_char] == TRAV_CHAR.crew.value)
            & (df[CleanSchema.trans_type] != TRANS_TYPE.ferry.value)
        )
    ]

    # US_passengers containts the possible donor values
    US_passengers = df[
        df[CleanSchema.trav_char].isin(
            [TRAV_CHAR.passenger_sdy.value, TRAV_CHAR.passenger_ovn.value]
        )
    ][
        [
            CleanSchema.date,
            CleanSchema.port,
            CleanSchema.mode,
            CleanSchema.report_number,
            CleanSchema.count,
            CleanSchema.duration2,
            CleanSchema.trav_char,
        ]
    ]
    US_passengers = US_passengers.groupby(
        by=[
            CleanSchema.date,
            CleanSchema.port,
            CleanSchema.mode,
            CleanSchema.report_number,
            CleanSchema.duration2,
            CleanSchema.trav_char,
        ],
        as_index=False,
    ).sum(CleanSchema.count)
    if not US_passengers.empty:
        if not auxiliary_df.empty:
            # go through the hierarchial breakdowns, starting with the movement match. Any necessary logic to change the match characteristis
            # based on the breakdown logic is done within each if statement. This logic can include dropping or creating columns
            movement_match = pd.merge(
                auxiliary_df,
                US_passengers,
                on=[
                    CleanSchema.date,
                    CleanSchema.port,
                    CleanSchema.report_number,
                ],
                how="left",
            )
            movement_match = movement_match.rename(
                columns={"duration2_y": "duration2", "trav_char_x": "trav_char"}
            )
            first_breakdown = movement_match[movement_match["count_y"].isnull()]
            movement_match = movement_match[~movement_match["count_y"].isnull()]
            US_passengers_sum = US_passengers.copy()
            US_passengers_sum["passenger_sum"] = US_passengers_sum[CleanSchema.count]
            US_passengers_sum = US_passengers_sum.groupby(
                by=[
                    CleanSchema.report_number,
                    CleanSchema.port,
                    CleanSchema.date,
                    CleanSchema.mode,
                ],
                dropna=False,
                as_index=False,
            )
            US_passengers_sum = (
                US_passengers_sum[["passenger_sum"]]
                .apply(lambda x: x.astype("Int64").sum())
                .fillna(pd.NA)
            )
            movement_match = pd.merge(
                movement_match,
                US_passengers_sum,
                on=[
                    CleanSchema.date,
                    CleanSchema.port,
                    CleanSchema.report_number,
                ],
                how="left",
            )

            # In order to calculate proportion, which is US passengers of duration 1 or 2, divided by total US passengers under the matching criteria, US_passengers
            # and US_passengers_sum are separate entities to facilitate the proportion line below.
            movement_match["proportion"] = (
                movement_match["count_y"] / movement_match["passenger_sum"]
            )
            movement_match[CleanSchema.count] = round(
                movement_match["count_x"] * movement_match["proportion"]
            )
            # align to the original count
            if not movement_match.empty:
                tmp = df.columns.drop(["mode","count","duration2"]).to_list()
                tmp.extend(["mode_x","count_x"])

                grp= movement_match.groupby(by=tmp,
                    dropna=False,
                    )
                movement_match["imputed_sum"] = grp["count"].transform("sum")
                idx_max = grp["count"].idxmax()
                movement_match.loc[idx_max,"count"] = movement_match.loc[idx_max,"count"]   +  movement_match.loc[idx_max,"count_x"]  -  movement_match.loc[idx_max,"imputed_sum"]

            movement_match = movement_match[CLEANSCHEMA_COLUMNS]
            
            if not first_breakdown.empty:
                # If there were unmatched unimputed rows leftover from the movement match
                first_breakdown = first_breakdown.drop(
                    columns=[
                        "count_y",
                        "duration2",
                        "duration2_x",
                        "mode_y",
                        "trav_char_y",
                    ]
                )
                first_breakdown = first_breakdown.rename(
                    columns={"count_x": "count", "mode_x": "mode"}
                )
                US_passengers = US_passengers.drop(
                    columns=[CleanSchema.duration2, CleanSchema.report_number]
                )
                US_passengers = US_passengers.groupby(
                    by=[
                        CleanSchema.date,
                        CleanSchema.mode,
                        CleanSchema.port,
                        CleanSchema.trav_char,
                    ],
                    as_index=False,
                ).sum(CleanSchema.count)
                US_passengers_sum = US_passengers_sum.drop(
                    columns=[CleanSchema.report_number]
                )
                US_passengers_sum = US_passengers_sum.groupby(
                    by=[CleanSchema.date, CleanSchema.mode, CleanSchema.port],
                    as_index=False,
                ).sum(CleanSchema.count)
                first_breakdown = pd.merge(
                    first_breakdown,
                    US_passengers,
                    on=[CleanSchema.date, CleanSchema.port, CleanSchema.mode],
                    how="left",
                )
                second_breakdown = first_breakdown[first_breakdown["count_y"].isnull()]
                first_breakdown = first_breakdown[~first_breakdown["count_y"].isnull()]
                first_breakdown = pd.merge(
                    first_breakdown,
                    US_passengers_sum,
                    on=[CleanSchema.date, CleanSchema.port, CleanSchema.mode],
                    how="left",
                )
                first_breakdown["proportion"] = (
                    first_breakdown["count_y"] / first_breakdown["passenger_sum"]
                )
                first_breakdown[CleanSchema.count] = round(
                    first_breakdown["count_x"] * first_breakdown["proportion"]
                )
                # align to the original count
                if not first_breakdown.empty:
                    tmp = df.columns.drop(["trav_char","count","duration2"]).to_list()
                    tmp.extend(["trav_char_x","count_x"])
                    grp= first_breakdown.groupby(by=tmp,
                            dropna=False,
                            )
                    first_breakdown["imputed_sum"] = grp["count"].transform("sum")
                    idx_max = grp["count"].idxmax()
                    first_breakdown.loc[idx_max,"count"] = first_breakdown.loc[idx_max,"count"]   +  first_breakdown.loc[idx_max,"count_x"]  -  first_breakdown.loc[idx_max,"imputed_sum"]
    

                first_breakdown.loc[
                    first_breakdown["trav_char_y"] == TRAV_CHAR.passenger_sdy.value,
                    [CleanSchema.duration2],
                ] = DURATION2.same_day.value
                first_breakdown.loc[
                    first_breakdown["trav_char_y"] == TRAV_CHAR.passenger_ovn.value,
                    [CleanSchema.duration2],
                ] = DURATION2.overnight.value
                first_breakdown = first_breakdown.rename(
                    columns={"trav_char_x": "trav_char"}
                )
                first_breakdown = first_breakdown[CLEANSCHEMA_COLUMNS]
                movement_match = movement_match.append(first_breakdown)
                if not second_breakdown.empty:
                    # If the first breakdown did not impute all rows needing imputation
                    second_breakdown["month"] = second_breakdown[
                        CleanSchema.date
                    ].str.split("-", expand=True)[1]
                    US_passengers["month"] = US_passengers[CleanSchema.date].str.split(
                        "-", expand=True
                    )[1]
                    US_passengers_sum["month"] = US_passengers_sum[
                        CleanSchema.date
                    ].str.split("-", expand=True)[1]
                    US_passengers = US_passengers.drop(columns=[CleanSchema.date])
                    US_passengers = US_passengers.groupby(
                        by=[
                            "month",
                            CleanSchema.mode,
                            CleanSchema.port,
                            CleanSchema.trav_char,
                        ],
                        as_index=False,
                    ).sum(CleanSchema.count)
                    US_passengers_sum = US_passengers_sum.drop(
                        columns=[CleanSchema.date]
                    )
                    US_passengers_sum = US_passengers_sum.groupby(
                        by=["month", CleanSchema.mode, CleanSchema.port],
                        as_index=False,
                    ).sum(CleanSchema.count)
                    second_breakdown = second_breakdown.drop(
                        columns=["count_y", "trav_char_y"]
                    )
                    second_breakdown = second_breakdown.rename(
                        columns={"count_x": "count", "trav_char_x": "trav_char"}
                    )
                    second_breakdown = pd.merge(
                        second_breakdown,
                        US_passengers,
                        on=["month", CleanSchema.mode, CleanSchema.port],
                        how="left",
                    )
                    third_breakdown = second_breakdown[
                        second_breakdown["count_y"].isnull()
                    ]
                    second_breakdown = second_breakdown[
                        ~second_breakdown["count_y"].isnull()
                    ]
                    second_breakdown = pd.merge(
                        second_breakdown,
                        US_passengers_sum,
                        on=["month", CleanSchema.mode, CleanSchema.port],
                        how="left",
                    )
                    second_breakdown["proportion"] = (
                        second_breakdown["count_y"] / second_breakdown["passenger_sum"]
                    )
                    second_breakdown[CleanSchema.count] = round(
                        second_breakdown["count_x"] * second_breakdown["proportion"]
                    )
                    # align to the original count
                    if not second_breakdown.empty:
                        tmp = df.columns.drop(["trav_char","count","duration2"]).to_list()
                        tmp.extend(["trav_char_x","count_x"])

                        grp= second_breakdown.groupby(by=tmp,
                            dropna=False,
                            )
                        second_breakdown["imputed_sum"] = grp["count"].transform("sum")
                        idx_max = grp["count"].idxmax()
                        second_breakdown.loc[idx_max,"count"] = second_breakdown.loc[idx_max,"count"]   +  second_breakdown.loc[idx_max,"count_x"]  -  second_breakdown.loc[idx_max,"imputed_sum"]
                        
                    second_breakdown.loc[
                        second_breakdown["trav_char_y"]
                        == TRAV_CHAR.passenger_sdy.value,
                        [CleanSchema.duration2],
                    ] = DURATION2.same_day.value
                    second_breakdown.loc[
                        second_breakdown["trav_char_y"]
                        == TRAV_CHAR.passenger_ovn.value,
                        [CleanSchema.duration2],
                    ] = DURATION2.overnight.value
                    second_breakdown = second_breakdown.rename(
                        columns={"trav_char_x": "trav_char"}
                    )
                    second_breakdown = second_breakdown[CLEANSCHEMA_COLUMNS]
                    movement_match = movement_match.append(second_breakdown)
                    if not third_breakdown.empty:
                        # If the second breakdown did not impute all rows needing imputation
                        third_breakdown = third_breakdown.drop(
                            columns=["count_y", "trav_char_y"]
                        )
                        third_breakdown = third_breakdown.rename(
                            columns={"count_x": "count", "trav_char_x": "trav_char"}
                        )
                        US_passengers = US_passengers.drop(columns=[CleanSchema.port])
                        US_passengers = US_passengers.groupby(
                            by=["month", CleanSchema.mode, CleanSchema.trav_char],
                            as_index=False,
                        ).sum(CleanSchema.count)
                        US_passengers_sum = US_passengers_sum.drop(
                            columns=[CleanSchema.port]
                        )
                        US_passengers_sum = US_passengers_sum.groupby(
                            by=["month", CleanSchema.mode], as_index=False
                        ).sum(CleanSchema.count)
                        third_breakdown = pd.merge(
                            third_breakdown,
                            US_passengers,
                            on=["month", CleanSchema.mode],
                            how="left",
                        )
                        third_breakdown = pd.merge(
                            third_breakdown,
                            US_passengers_sum,
                            on=["month", CleanSchema.mode],
                            how="left",
                        )
                        third_breakdown["proportion"] = (
                            third_breakdown["count_y"]
                            / third_breakdown["passenger_sum"]
                        )
                        # if proportion is not null, update count to be count_x * proportion
                        # else assign count <- count_x
                        third_breakdown.loc[
                            ~third_breakdown["proportion"].isnull(),
                            CleanSchema.count,
                        ] = round(
                            third_breakdown.loc[
                                ~third_breakdown["proportion"].isnull(), "count_x"
                            ]
                            * third_breakdown.loc[
                                ~third_breakdown["proportion"].isnull(), "proportion"
                            ]
                        )
                        third_breakdown.loc[
                            third_breakdown["proportion"].isnull(), 
                            CleanSchema.count,
                            ] = third_breakdown.loc[
                                third_breakdown["proportion"].isnull(), 
                                "count_x"]

                        if not third_breakdown.empty:
                            tmp = df.columns.drop(["trav_char","count","duration2"]).to_list()
                            tmp.extend(["trav_char_x","count_x"])

                            grp= third_breakdown.groupby(by=tmp,
                                dropna=False,
                                )
                            third_breakdown["imputed_sum"] = grp["count"].transform("sum")
                            idx_max = grp["count"].idxmax()
                            third_breakdown.loc[idx_max,"count"] = third_breakdown.loc[idx_max,"count"]   +  third_breakdown.loc[idx_max,"count_x"]  -  third_breakdown.loc[idx_max,"imputed_sum"]
                        
                        third_breakdown.loc[
                            third_breakdown["trav_char_y"]
                            == TRAV_CHAR.passenger_sdy.value,
                            [CleanSchema.duration2],
                        ] = DURATION2.same_day.value
                        third_breakdown.loc[
                            third_breakdown["trav_char_y"]
                            == TRAV_CHAR.passenger_ovn.value,
                            [CleanSchema.duration2],
                        ] = DURATION2.overnight.value
                        third_breakdown = third_breakdown.rename(
                            columns={"trav_char_x": "trav_char"}
                        )
                        third_breakdown = third_breakdown[CLEANSCHEMA_COLUMNS]
                        movement_match = movement_match.append(third_breakdown)

        # Remove the rows that were to be imputed
        df = df[~df[CleanSchema.duration2].isnull()]
        # Append the imputed rows back in
        df = df.append(movement_match)
        df[CleanSchema.count] = df[CleanSchema.count].astype("Int64")
        try:
            df[CleanSchema.country_of_residence] = (
                df[CleanSchema.country_of_residence].astype(int).astype("Int64")
            )
        except:
            print("error: empty country_of_residence column")
            edf = df[df["country_of_residence"].isnull()]
            print(edf.head(5))
            raise

    # Edge case: if, after carrying out the above imputation procedure, there are
    # still rows where duration2 was not imputed, set 50% of travellers to have
    # duration2 = 1 and 50% of travellers to have duration2 = 2.
    if df[CleanSchema.duration2].isna().any():
        # Since we are doing this imputation row-by-row, we need to ensure that the
        # division of the original counts happens in a way that preserves the
        # original count. Failure to account for this rounding may change the total
        # count.
        imputed_dfs = []
        for _, row in df[df[CleanSchema.duration2].isna()].iterrows():
            tmp = pd.DataFrame([row.values], columns=row.index)
            PRE_ROUNDING_TOTAL = tmp[CleanSchema.count].squeeze()
            tmp = pd.concat([tmp] * 2).reset_index(drop=True)
            tmp.loc[0, CleanSchema.duration2] = DURATION2.same_day.value
            tmp.loc[0, CleanSchema.count] = np.round(
                tmp.loc[0, CleanSchema.count] * 0.5
            ).astype("Int64")
            tmp.loc[1, CleanSchema.duration2] = DURATION2.overnight.value
            tmp.loc[1, CleanSchema.count] = (
                PRE_ROUNDING_TOTAL - tmp.loc[0, CleanSchema.count]
            )
            imputed_dfs.append(tmp)
                                
        # Get rid of the previous records where duration2.isna() and
        # replace them with the imputed records.
        df = df[~df[CleanSchema.duration2].isna()]
        df = pd.concat([df, pd.concat(imputed_dfs)]).reset_index(drop=True)
    return CleanSchema(df.fillna(pd.NA))
