"""
Implements the e63_030 business rule
"""
import pandas as pd

from datasource.e63.schema import RawSchema
from datasource.e63.dim import MODE


def e63_030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Recode any ports from the E63 raw data which should be
    reported differently based on the Frontier Counts list of ports.

    Args:
        input:
            A pandas dataframe with ports needing to be recoded
    Returns:
        A pandas dataframe with recoded ports
    """

    # Recode this port
    df.loc[
        (df[RawSchema.port] == "10912") & (df[RawSchema.mode] == MODE.marine.value),
        RawSchema.port,
    ] = "10910"

    return RawSchema(df)
