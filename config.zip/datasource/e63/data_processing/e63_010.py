"""
Implements the e63_010 business rule
"""
import pandas as pd

from config.api import DataSource

from config.api import Stage

from modules.utils.loaders import Loader

from datasource.e63.schema import (
    RawSchema,
    ValidationSchema,
    RAWSCHEMA_COLUMNS,
    E63_V010_COLUMNS,
)
from datasource.work_locations_action.schema import ReferenceSchema as ActionSchema
from datasource.work_locations_trans.schema import ReferenceSchema as TransSchema
from datasource.work_locations_trans_action.schema import (
    ReferenceSchema as TransActionSchema,
)
from datasource.work_locations_trans_action.dim import ACTION

from config.api import WorkLocationsTransAction
from config.api import WorkLocationsAction
from config.api import WorkLocationsTransportation

from modules.utils.data_manipulation import work_locations_recode


def e63_010(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes entries with a missing date.

    Args:
        df:
            A pandas dataframe with null dates present
    Returns:
        a pandas dataframe with all records containing empty dates removed
    """

    wl_trans = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans,
        WorkLocationsTransportation.work_locations_trans__e63,
    )
    wl_trans = TransSchema(wl_trans)

    wl_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_action,
        WorkLocationsAction.work_locations_action__e63,
    )
    wl_action = ActionSchema(wl_action)

    wl_trans_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__e63,
    )
    wl_trans_action = TransActionSchema(wl_trans_action)

    # Copy input so it is not updated in place
    df_copy = df.copy()

    work_location_column = RawSchema.port

    # Recode the work locations
    df, auxiliary_df = work_locations_recode(
        df_copy,
        wl_trans,
        wl_action,
        wl_trans_action,
        work_location_column,
        TransSchema,
        ActionSchema,
        TransActionSchema,
        ACTION,
    )
    # Resubset df to removing working columns added from work_locations_recode
    return RawSchema(df[RAWSCHEMA_COLUMNS]), auxiliary_df


def e63_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule e63_010

    Args:
        input:
            a pandas dataframe containing records that possibly contain
            invalid work locations
    Returns:
        The return value of e63_v000
    """
    if not auxiliary_df.empty:
        validation_df = auxiliary_df.groupby(
            by=[
                ValidationSchema.port,
                ValidationSchema.date,
                ValidationSchema.mode,
                ValidationSchema.trans_type,
                ValidationSchema.cargo,
                ValidationSchema.action,
            ],
            dropna=False,
            as_index=False,
        )
        validation_df = validation_df[[ValidationSchema.count]].apply(
            lambda x: x.astype("Int64").sum()
        )
        validation_df = validation_df[E63_V010_COLUMNS]
        validation_df = validation_df.sort_values(ValidationSchema.count).fillna(pd.NA)
        validation_df = ValidationSchema(validation_df)
    else:
        # If the auxiliary df is empty,
        # return a blank df following the schema
        validationschema_cols = ValidationSchema.to_schema().columns
        validation_df = pd.DataFrame(
            {
                col: pd.Series(dtype=str(validationschema_cols[col].dtype))
                for col in E63_V010_COLUMNS
            }
        )

    return validation_df
