"""
**Author(s)**

-Bryan Southwell - `bryan.southwell@canada.ca`
- Tristan Garry - `tristan.garry@statcan.gc.ca`

**Created On:** July 2021
                May 2023

**Description:**

The pipeline definitions for the E63 data source. Two pipelines are defined in this
module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`

"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID
from modules.pipeline import validation_writer

from config.api import Stage
from config.api import DataSource
from config.api import S3

from datasource.e63.schema import RawSchema, CleanSchema
from datasource.e63.data_processing import *


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the E63 datasource
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data file
        df = Loader.query(
            Stage.RAW, datasource=self.datasource, year=self.year, month=self.month
        )
        df = RawSchema(df)

        # Do first validation against the raw schema
        print("   1.Starting processing e63_000")
        validation_df = e63_v000(df)
        validation_writer(validation_df, e63_v000, self.datasource, self.date)
        logging.info("Finished processing e63_000")
        print("   1.Finished processing e63_000")

        print("   2.Starting processing e63_005")
        df = e63_005(df)
        logging.info("Finished processing e63_005")
        print("   2.Finished processing e63_005")

        print("   3.Starting processing e63_007")
        df = e63_007(df)
        logging.info("Finished processing e63_007")
        print("   3.Finished processing e63_007")

        print("   4.Starting processing e63_010")
        df, auxiliary_df = e63_010(df)
        validation_df = e63_v010(df, auxiliary_df)
        validation_writer(validation_df, e63_v010, self.datasource, self.date)
        logging.info("Finished processing e63_010")
        print("   4.Finished processing e63_010")

        print("   5.Starting processing e63_020")
        df, auxiliary_df = e63_020(df)
        validation_df = e63_v020(df, auxiliary_df)
        validation_writer(validation_df, e63_v020, self.datasource, self.date)
        logging.info("Finished processing e63_020")
        print("   5.Finished processing e63_020")

        print("   6.Starting processing e63_030")
        df = e63_030(df)
        logging.info("Finished processing e63_030")
        print("   6.Finished processing e63_030")

        print("   7.Starting processing e63_040")
        df = e63_040(df)
        logging.info("Finished processing e63_040")
        print("   7.Finished processing e63_040")

        print("   8.Starting processing e63_050")
        df = e63_050(df)
        logging.info("Finished processing e63_050")
        print("   8.Finished processing e63_050")

        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        e63_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[self.datasource.value] = e63_clean
        logging.info("Finished processing E63 RAW -> CLEAN pipeline")
        print("Finished processing E63 RAW -> CLEAN pipeline")


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the E63 datasource
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()
        # Get the initial pandas data frame
        basename = S3.get_s3_basename(
            Stage.CLEAN,
            datasource=self.datasource,
            year=self.year,
            month=self.month,
            day=self.day,
        )
        df = Loader.get(Stage.CLEAN, datasource=self.datasource, basename=basename)
        df = CleanSchema(df)

        # Perform the tranformation to get the vehicles table
        print("Starting processing e63_060")
        travellers = e63_060(df)
        logging.info("Finished processing e63_060")
        print("Finished processing e63_060")

        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.travellers.value] = travellers_output
        logging.info("Finished processing E63 CLEAN -> TRANSFORMED pipeline")
        print("Finished processing E63 CLEAN -> TRANSFORMED pipeline")
