#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import re
import tempfile
import shutil
import glob
import warnings
import pandas as pd
import numpy as np
from datetime import datetime
from os.path import join
from pandas.core.frame import DataFrame
from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage
from config.api import S3
from config.argo import ArgoStatusCodes
from modules.utils.schema import tuplify
from modules.utils.data_manipulation import upload_files
from modules.utils.datasource_loader_helpers import InvalidDateError, InvalidPortError

from datasource.e63.schema import RawSchema, RAWSCHEMA_COLUMNS

# List of columns to sort E63 by for raw
E63_SORT_COLUMNS = RawSchema.get_keys()

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")


def date(string):
    match = re.match("(\d\d\d\d)-(\d\d)-(\d\d)", str(string))
    if match:
        year, month, day = match.groups()
        return f"{year}-{month}-{day}"
    else:
        raise InvalidDateError(string)


def numbers_port(string):
    result = re.sub("[^\d]", "", str(string))
    if result == "":
        raise InvalidPortError(string)
    return result


def copy(string):
    return string


def copy_upper(string):
    return string.upper()


def extract(dx):
    dx = dx.replace(np.nan, 0)
    dx = dx.loc[dx.iloc[:, 0] != 0]
    return dx


def other_extract(dx):
    dx = dx.replace(np.nan, 0)
    dx = dx.loc[dx.iloc[:, 1] != 0]
    dx.iloc[:, 0] = dx.iloc[:, 0].replace("Other", "99998")
    dx.iloc[:, 0] = dx.iloc[:, 0].replace("[^\d]", "", regex=True)
    return dx


def exel_conf():
    return {
        1: {
            "name": "E63",
            "attrs": [
                {"col": 4, "row": 3, "func": numbers_port, "name": "port"},
                {"col": 4, "row": 7, "func": copy_upper, "name": "mode"},
            ],
            "body": {
                "rows": {"start": 13, "end": None},
                "cols": {"start": 1, "end": 22},
                "ffill": 2,
                "attrs": [
                    {"name": "date", "col": 0, "row": 0, "func": date},
                    {"name": "time", "col": 1, "row": 0, "func": copy},
                    {"name": "report_number", "col": 2, "row": 0, "func": copy},
                    {"name": "from", "col": 3, "row": 0, "func": copy},
                    {"name": "trans_type", "col": 14, "row": 0, "func": copy},
                    {"name": "cargo", "col": 15, "row": 0, "func": copy},
                    {"name": "trc", "col": 16, "row": 0, "func": copy},
                    {"name": "coasting", "col": 17, "row": 0, "func": copy},
                    {"name": "ambulance", "col": 18, "row": 0, "func": copy},
                    {"name": "tech_stop", "col": 19, "row": 0, "func": copy},
                    {"name": "notes", "col": 20, "row": 0, "func": copy},
                ],
                "list": [
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 4, "end": 5},
                        "func": extract,
                        "columns": ["count"],
                        "attrs": [
                            {"name": "trav_char", "value": "crew"},
                            {"name": "country_of_residence", "value": "11840"},
                        ],
                    },
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 5, "end": 6},
                        "func": extract,
                        "columns": ["count"],
                        "attrs": [
                            {"name": "trav_char", "value": "passenger_sdy"},
                            {"name": "country_of_residence", "value": "11840"},
                        ],
                    },
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 6, "end": 7},
                        "func": extract,
                        "columns": ["count"],
                        "attrs": [
                            {"name": "trav_char", "value": "passenger_ovn"},
                            {"name": "country_of_residence", "value": "11840"},
                        ],
                    },
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 7, "end": 9},
                        "func": other_extract,
                        "columns": ["country_of_residence", "count"],
                        "attrs": [{"name": "trav_char", "value": "crew"}],
                    },
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 9, "end": 11},
                        "func": other_extract,
                        "columns": ["country_of_residence", "count"],
                        "attrs": [{"name": "trav_char", "value": "passenger"}],
                    },
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 11, "end": 12},
                        "func": extract,
                        "columns": ["count"],
                        "attrs": [
                            {"name": "trav_char", "value": "crew"},
                            {"name": "country_of_residence", "value": "11124"},
                        ],
                    },
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 12, "end": 13},
                        "func": extract,
                        "columns": ["count"],
                        "attrs": [
                            {"name": "trav_char", "value": "passenger_usa"},
                            {"name": "country_of_residence", "value": "11124"},
                        ],
                    },
                    {
                        "rows": {"start": 0, "end": None},
                        "cols": {"start": 13, "end": 14},
                        "func": extract,
                        "columns": ["count"],
                        "attrs": [
                            {"name": "trav_char", "value": "passenger_ovs"},
                            {"name": "country_of_residence", "value": "11124"},
                        ],
                    },
                ],
            },
        }
    }


def read_excel(filename: str, conf: dict) -> dict[DataFrame]:
    """
    Uses a configuration to extract DataFrames from excel sheets.
    """
    schema = RAWSCHEMA_COLUMNS

    conf = tuplify(conf)
    bcnf = conf.body

    # Trim all leading and tailing spaces when reading in the Excel file, except for colum "date", "time", and "report_number":
    # The data type of these three columns do not support str.strip method we specify in the covnerters
    attr_cols = [attr.col+1 for attr in bcnf.attrs if attr.name not in ["date","time","report_number"]]
    converters={col: str.strip for col in attr_cols}
    # sheet = pd.read_excel(filename, sheet_name=conf.name, engine="openpyxl",converters=converters)
    sheet = pd.read_excel(filename, sheet_name=conf.name, engine="openpyxl",na_values='')

    body = sheet.iloc[bcnf.rows.start : bcnf.rows.end, bcnf.cols.start : bcnf.cols.end]
    body = body.rename(columns={col: idx for idx, col in enumerate(body.columns)})
    body = body.replace(r"^ +| +$", r'', regex=True)
    # Trim all leading and tailing spaces in the "date" column 
    # mask_date = body.iloc[:,0].apply(type) == str
    # if any(mask_date):
    #     tmp = body[mask_date]
    #     tmp = pd.concat([tmp,tmp.iloc[:1]]) # Duplicate the first row in case there is only one row in tmp and the next line will fail 
    #     tmp[0] = pd.to_datetime(tmp[0].str.strip(), format='%Y-%m-%d') # Remove leading and tailing spaces and convert to datetime type
    #     tmp = tmp.iloc[1:, :]  # Remove the duplicated first row
    #     body[mask_date] = tmp
    
    # # Trim all leading and tailing spaces in the "report_number" column 
    # mask_report = body.iloc[:,2].apply(type) == str
    # if any(mask_report):
    #     tmp = body[mask_report]
    #     tmp = pd.concat([tmp,tmp.iloc[:1]]) # Duplicate the first row in case there is only one row in tmp and the next line will fail
    #     tmp[2] = tmp[2].str.strip() # Remove leading and tailing spaces 
    #     tmp = tmp.iloc[1:, :] # Remove the duplicated first row
    #     body[mask_report] = tmp
    
    body = body.mask(body == '') # replace all empty string value with NaN

    body.loc[:, bcnf.ffill] = body.loc[:, bcnf.ffill].ffill(axis=0)
    groups = body.groupby(bcnf.ffill)
    movements = {movement: groups.get_group(movement) for movement in groups.groups}
    data = pd.DataFrame(columns=schema)
    for movement, _df in movements.items():
        travellers = pd.DataFrame(columns=schema)
        for idx, ls in enumerate(bcnf.list):
            subdf = _df.iloc[ls.rows.start : ls.rows.end, ls.cols.start : ls.cols.end]
            subdf = ls.func(subdf)
            subdf.columns = ls.columns
            for attr in ls.attrs:
                subdf[attr.name] = attr.value
            travellers = pd.concat((travellers, subdf), axis=0, ignore_index=True)
        for attr in bcnf.attrs:
            try:
                travellers[attr.name] = attr.func(_df.iloc[attr.row, attr.col])
            except:
                print(" e63 loader error attr:", attr)
                raise
        data = pd.concat((data, travellers), axis=0, ignore_index=True)
    for attr in conf.attrs:
        data[attr.name] = attr.func(sheet.iloc[attr.row, attr.col])
    return data


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load pik data from the momentary S3Location.
    This is the loader entry point for the pik datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """
    downloaddir = client.get_dir(location)

    e63_folder = tempfile.mkdtemp()

    data = pd.DataFrame(columns=RAWSCHEMA_COLUMNS)
    for f in glob.glob(join(downloaddir, "*.xlsx")):
        try:
            print("e63 reading file: ", f)
            tmp = read_excel(f, exel_conf()[1])
            data = pd.concat((data, tmp), axis=0, ignore_index=True)
        except:
            # Return false if any file was not processed successfully
            import traceback as tb

            print("Error reading e63 file: ", f)
            fname = f.replace(downloaddir, "")
            fname = fname.replace("/", "")
            dst = S3.get_error_location(DataSource.e63, fname)
            src = S3.obj_to_loc(Stage.INBOX.value.bucket, "inbox/" + fname)
            print("Moving to error location:", dst)
            client.mv_loc(src, dst)
            tb.print_exc()
            print("Exit on error.")
            ArgoStatusCodes.exit_error_location()
            return False

    gdf = data.groupby(RawSchema.date)
    dfs = {_date: gdf.get_group(_date) for _date in gdf.groups}

    date_pattern = re.compile("(\d{4})-(\d{2})-(\d{2})")
    localnames = []
    for _date, _df in dfs.items():
        match = date_pattern.match(_date)
        if match:
            year, month, day = match.groups()
            filename = join(
                e63_folder, S3.get_s3_basename(stage, DataSource.e63, year, month, day)
            )
            localnames.append(filename)
            _df.to_csv(filename, mode="a", index=False, header=None)

    upload_files(
        client,
        localnames,
        stage,
        DataSource.e63,
        RawSchema,
        E63_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )

    shutil.rmtree(downloaddir)
    shutil.rmtree(e63_folder)
    return True
