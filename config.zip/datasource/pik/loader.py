#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import tempfile
import shutil
import pathlib

from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage

from modules.utils.data_manipulation import process_files
from modules.utils.data_manipulation import upload_files

from datasource.pik.schema import RawSchema

# List of columns to sort PIK by for raw
PIK_SORT_COLUMNS = RawSchema.get_keys()

def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load pik data from the momentary S3Location.
    This is the loader entry point for the pik datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """

    downloaddir = client.get_dir(location)

    files = sorted([f.as_posix() for f in pathlib.Path(downloaddir).rglob("*.txt")])
    tmpdir = tempfile.mkdtemp()

    # Get the index position of the date column. Headers are labelled as index at this point
    date_position = list(RawSchema.to_schema().columns.keys()).index(RawSchema.date)

    processed = process_files(
        files,  # List with full filenames of files to process
        tmpdir,  # Temporary directory to store the output
        stage,
        DataSource.pik,
        date_position,  # Column name of the date field
        "(\d{4})-(\d{2})-(\d{2})",  # Regular expression of the date column, allowing you to capture year,month,day
        "|",  # CSV separator
        None,
    )  # Header
    if not processed:
        return False
    upload_files(
        client,
        processed,
        stage,
        DataSource.pik,
        RawSchema,
        PIK_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )

    print(f"Removing: {location.bucket} {location.prefix}")
    shutil.rmtree(downloaddir)
    shutil.rmtree(tmpdir)
    return True


if __name__ == "__main__":
    pass
