import pandas as pd

from datasource.pik.schema import RawSchema, ValidationSchema
from datasource.pik.dim import CREW, PURPIMM


def pik_v080(df: pd.DataFrame) -> pd.DataFrame:
    """
    Flag any records where a traveller is identified as both a 
    crew member and an immigrant.

    Args:
        df: A pandas dataframe that could have records with both crew and immigrant flagged.

    Returns:
        df:
            A copy of the input dataframe since no processing is done.

        validation_df:
            Validation file summarizing conflicting crew and immigrant flags.
    """

    if not df.empty:

        validation_df = df[
            [RawSchema.date, RawSchema.wloc, RawSchema.purpimm, RawSchema.crew]
        ].copy()

        # Records where crew and immigration flags are in conflict
        validation_df.loc[:, ValidationSchema.count_conflicts] = (
            validation_df[RawSchema.purpimm] == PURPIMM.immigrate.value
        ) & (validation_df[RawSchema.crew] == CREW.crew_member.value)

        # All crew records
        validation_df.loc[:, ValidationSchema.count_crew] = (
            validation_df[RawSchema.crew] == CREW.crew_member.value
        )

        # All immigration records
        validation_df.loc[:, ValidationSchema.count_imm] = (
            validation_df[RawSchema.purpimm] == PURPIMM.immigrate.value
        )

        validation_df = validation_df.groupby(
            by=[RawSchema.date, RawSchema.wloc], dropna=False, as_index=False
        )
        validation_df = validation_df[
            [
                ValidationSchema.count_imm,
                ValidationSchema.count_conflicts,
                ValidationSchema.count_crew,
            ]
        ].apply(lambda x: x.astype(int).sum())

        validation_df = validation_df[
            [
                RawSchema.date,
                RawSchema.wloc,
                ValidationSchema.count_conflicts,
                ValidationSchema.count_imm,
                ValidationSchema.count_crew,
            ]
        ]

    else:
        validation_df = pd.DataFrame(
            columns=[
                RawSchema.date,
                RawSchema.wloc,
                ValidationSchema.count_conflicts,
                ValidationSchema.count_imm,
                ValidationSchema.count_crew,
            ]
        )

    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return df, validation_df
