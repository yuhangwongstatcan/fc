"""
Implements the pik_10 Business Rule
"""
import pandas as pd

from config.api import DataSource

from modules.utils.data_manipulation import validate_dimensions

from datasource.pik.schema import RawSchema, ValidationSchema


def pik_000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Strip whitespace from certain variables and send raw file for dimension validation.

    Args:
        df:
            A pandas dataframe with the raw PIK data read directly from Azure blob storage.
    Returns:
        df:
            A pandas dataframe with whitespace removed from certain variables.

        auxiliary_df:
            A copy of the dataframe to be used in the dimension validation.
    """

    df[RawSchema.rescntry] = df[RawSchema.rescntry].str.strip()
    df[RawSchema.travellercitizenship] = df[RawSchema.travellercitizenship].str.strip()

    auxiliary_df = df.copy()

    return df, auxiliary_df


def pik_v000(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate the dimension variables to find unexpected values.

    Args:
        auxiliary_df:
            A pandas dataframe of records that possibly contain
            unexpected dimension values.

    Returns:
        df:
            Copy of the input dataframe since no processing is done.

        validation_df:
            Validation file summarizing the unexpected values which will be used in dashboards.
    """

    # Declare which column from input are for : "location" and "date"
    cname_loc = RawSchema.wloc
    cname_date = RawSchema.date

    validation_df = validate_dimensions(
        auxiliary_df, RawSchema, ValidationSchema, cname_loc, cname_date, DataSource.pik
    )

    # Need to ignore pd.NA for `durofabsn`
    IGNORE_NA_DUROFABSN = ~(
        (validation_df[ValidationSchema.variable] == "durofabsn")
        & (validation_df[ValidationSchema.unexpected_value].isna())
    )
    EXCLUDE_LANG = validation_df[ValidationSchema.variable] != "lang"
    EXCLUDE_RESPROVSTATE = validation_df[ValidationSchema.variable] != "resprovstate"
    validation_df = validation_df[
        IGNORE_NA_DUROFABSN & EXCLUDE_LANG & EXCLUDE_RESPROVSTATE
    ]

    # Check and coerce the validation schema as required
    validation_df = ValidationSchema(validation_df)

    return validation_df
