import pandas as pd

from config.api import Stage, DataSource
from modules.utils.loaders import Loader

from datasource.pik.schema import CleanSchema, ValidationSchema
from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)

from datasource.pik.dim import (
    ARRIVINGFROM,
    RESCNTRY,
    DUROFABSN,
    CREW,
    PURPSTUDY,
    PURPVISIT,
    PURPWORK,
    PURPIMM,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    COUNTRY_OF_RESIDENCE,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    DATA_SOURCE,
)
from datasource.common.dim import MODE, VEHICLE_TYPE, PLATE_COUNTRY, PLATE_REGION

from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema


def pik_110(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Bryan Southwell - `bryan.southwell.brown@canada.ca`

    **Created On:** May, 2021

    **Description:**

    Performs the business logic that transforms cleaned PIK data into PIK's contribution
    to the travellers table.

    Args:
        df:
            A pandas dataframe that has had all business logic up to the CLEAN data applied.

    Returns:
        travellers:
            A pandas dataframe containing PIK's contribution to the travellers table.

        auxiliary_df:
            A pandas dataframe to be used in the validation summarizing purpose of trip as work.
    """

    work_locations = Loader.get(Stage.REFERENCE, DataSource.work_locations, None)
    work_locations = WorkLocationsSchema(work_locations)

    if not df.empty:
        # 1. Add a data source column and set it to PIK
        df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.PIK.value

        df[
            [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
        ] = df[CleanSchema.date].str.split("-", expand=True)
        df[
            [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
        ] = df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]]
        df[TransformedSchema.month] = df[TransformedSchema.month].replace(
            {r"0(\d)": r"\1"}, regex=True
        )
        df[TransformedSchema.day] = df[TransformedSchema.day].replace(
            {r"0(\d)": r"\1"}, regex=True
        )

        df.loc[:, CleanSchema.wloc] = df[CleanSchema.wloc]
        df = pd.merge(
            df,
            (
                work_locations[
                    [WorkLocationsSchema.work_location, WorkLocationsSchema.port,]
                ]
            ),
            left_on=CleanSchema.wloc,
            right_on=WorkLocationsSchema.work_location,
            how="left",
        )

        df.loc[:, TransformedSchema.port] = df[WorkLocationsSchema.port]

        df[TransformedSchema.mode] = MODE.air.value
        df[TransformedSchema.vehicle_type] = VEHICLE_TYPE.commercial_aircraft.value
        df[TransformedSchema.plate_country] = PLATE_COUNTRY.not_available.value
        df[TransformedSchema.plate_region] = PLATE_REGION.NA.value

        df.loc[
            df[CleanSchema.arrivingfrom] == ARRIVINGFROM.us_only.value,
            [TransformedSchema.arriving_from],
        ] = ARRIVING_FROM.us_only.value
        df.loc[
            df[CleanSchema.arrivingfrom] == ARRIVINGFROM.ovs_direct.value,
            [TransformedSchema.arriving_from],
        ] = ARRIVING_FROM.ovs_direct.value
        df.loc[
            df[CleanSchema.arrivingfrom] == ARRIVINGFROM.ovs_via.value,
            [TransformedSchema.arriving_from],
        ] = ARRIVING_FROM.ovs_via_us.value
        # If `arrivingfrom` does not match 1, 2, or 3, apply the value arriving_from.v_9
        df.loc[
            ~df[CleanSchema.arrivingfrom].isin(
                [
                    ARRIVINGFROM.us_only.value,
                    ARRIVINGFROM.ovs_direct.value,
                    ARRIVINGFROM.ovs_via.value,
                ]
            ),
            [TransformedSchema.arriving_from],
        ] = ARRIVING_FROM.not_available.value

        purp_mask1 = df[CleanSchema.purpimm] == PURPIMM.immigrate.value
        df.loc[purp_mask1, [TransformedSchema.purpose4, TransformedSchema.purpose9]] = [
            PURPOSE4.other_purpose.value,
            PURPOSE9.immigration.value,
        ]
        purp_mask2 = df[CleanSchema.crew] == CREW.crew_member.value
        df.loc[
            ~purp_mask1 & purp_mask2,
            [TransformedSchema.purpose4, TransformedSchema.purpose9],
        ] = [
            PURPOSE4.crew.value,
            PURPOSE9.crew.value,
        ]
        purp_mask3 = df[CleanSchema.purpwork] == PURPWORK.work.value
        df.loc[
            (~purp_mask1 & ~purp_mask2) & purp_mask3,
            [TransformedSchema.purpose4, TransformedSchema.purpose9],
        ] = [
            PURPOSE4.work.value,
            PURPOSE9.work.value,
        ]
        purp_mask4 = df[CleanSchema.purpstudy] == PURPSTUDY.study.value
        df.loc[
            (~purp_mask1 & ~purp_mask2 & ~purp_mask3) & purp_mask4,
            [TransformedSchema.purpose4, TransformedSchema.purpose9],
        ] = [
            PURPOSE4.visit.value,
            PURPOSE9.study.value,
        ]
        purp_mask5 = (df[CleanSchema.purpvisit] == PURPVISIT.visit.value) & (
            df[CleanSchema.purpstudy] != PURPSTUDY.study.value
        ) | (
            (df[CleanSchema.purpimm] == PURPIMM.not_immigrate.value)
            & (df[CleanSchema.crew] == CREW.passenger.value)
            & (df[CleanSchema.purpwork] == PURPWORK.not_work.value)
            & (df[CleanSchema.purpstudy] == PURPSTUDY.not_study.value)
            & (df[CleanSchema.purpvisit] == PURPVISIT.not_visit.value)
        )

        df.loc[
            (~purp_mask1 & ~purp_mask2 & ~purp_mask3 & ~purp_mask4) & purp_mask5,
            [TransformedSchema.purpose4, TransformedSchema.purpose9],
        ] = [
            PURPOSE4.visit.value,
            PURPOSE9.visit.value,
        ]

        # If none of the above conditions are satisfied, then assign purpose9=19 and
        # purpose4=1 as default values.
        df.loc[
            ~(purp_mask1 | purp_mask2 | purp_mask3 | purp_mask4 | purp_mask5),
            [TransformedSchema.purpose4, TransformedSchema.purpose9],
        ] = [
            PURPOSE4.visit.value,
            PURPOSE9.visit.value,
        ]

        mask1 = (df[CleanSchema.rescntry] == RESCNTRY.CAN.value) & (
            df[CleanSchema.durofabsn] == DUROFABSN.same_day.value
        )
        mask2 = (df[CleanSchema.rescntry] == RESCNTRY.CAN.value) & (
            df[CleanSchema.durofabsn] == DUROFABSN.one_two_days.value
        )
        mask3 = (df[CleanSchema.rescntry] == RESCNTRY.CAN.value) & (
            df[CleanSchema.durofabsn] == DUROFABSN.three_seven_days.value
        )
        mask4 = (df[CleanSchema.rescntry] == RESCNTRY.CAN.value) & (
            df[CleanSchema.durofabsn] == DUROFABSN.eight_plus_days.value
        )
        mask5 = (
            (df[CleanSchema.rescntry] == RESCNTRY.CAN.value)
            & (df[CleanSchema.durofabsn].isnull())
            & (pd.to_numeric(df[CleanSchema.durationofstay]) >= 365)
        )

        df.loc[
            mask1,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.same_day.value,
            DURATION3.same_day.value,
            DURATION5.same_day.value,
        ]

        df.loc[
            mask2,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.one_night.value,
            DURATION5.one_two_nights.value,
        ]

        df.loc[
            mask3,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.two_or_more_nights.value,
            DURATION5.three_seven_nights.value,
        ]

        df.loc[
            mask4,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.two_or_more_nights.value,
            DURATION5.eight_plus_nights.value,
        ]

        df.loc[
            mask5,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.two_or_more_nights.value,
            DURATION5.over_one_year.value,
        ]

        mask6 = (df[CleanSchema.rescntry] != RESCNTRY.CAN.value) & (
            pd.to_numeric(df[CleanSchema.durationofstay]) == 0
        )
        mask7 = (df[CleanSchema.rescntry] != RESCNTRY.CAN.value) & (
            pd.to_numeric(df[CleanSchema.durationofstay]) == 1
        )
        mask8 = (df[CleanSchema.rescntry] != RESCNTRY.CAN.value) & (
            pd.to_numeric(df[CleanSchema.durationofstay]) == 2
        )
        mask9 = (df[CleanSchema.rescntry] != RESCNTRY.CAN.value) & (
            pd.to_numeric(df[CleanSchema.durationofstay]).between(3, 7, inclusive=True)
        )
        mask10 = (df[CleanSchema.rescntry] != RESCNTRY.CAN.value) & (
            pd.to_numeric(df[CleanSchema.durationofstay]) >= 8
        )
        mask11 = (
            (df[CleanSchema.purpimm] == PURPIMM.immigrate.value)
            & (df[CleanSchema.durationofstay].isnull())
            & (df[CleanSchema.durofabsn].isnull())
        )

        df.loc[
            mask6,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.same_day.value,
            DURATION3.same_day.value,
            DURATION5.same_day.value,
        ]

        df.loc[
            mask7,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.one_night.value,
            DURATION5.one_two_nights.value,
        ]

        df.loc[
            mask8,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.two_or_more_nights.value,
            DURATION5.one_two_nights.value,
        ]

        df.loc[
            mask9,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.two_or_more_nights.value,
            DURATION5.three_seven_nights.value,
        ]

        df.loc[
            mask10,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.overnight.value,
            DURATION3.two_or_more_nights.value,
            DURATION5.eight_plus_nights.value,
        ]

        df.loc[
            mask11,
            [
                TransformedSchema.duration2,
                TransformedSchema.duration3,
                TransformedSchema.duration5,
            ],
        ] = [
            DURATION2.not_available.value,
            DURATION3.not_available.value,
            DURATION5.not_available.value,
        ]

        mask12 = (df[TransformedSchema.purpose4] != PURPOSE4.visit.value) | (
            df[TransformedSchema.duration5] == DURATION5.over_one_year.value
        )
        df.loc[
            mask12, TransformedSchema.traveller_type
        ] = TRAVELLER_TYPE.other_traveller.value

        mask13 = (df[TransformedSchema.purpose4] == PURPOSE4.visit.value) & (
            df[TransformedSchema.duration2] == DURATION2.same_day.value
        )
        df.loc[
            ~mask12 & mask13, TransformedSchema.traveller_type
        ] = TRAVELLER_TYPE.excursionist.value

        mask14 = (df[TransformedSchema.purpose4] == PURPOSE4.visit.value) & (
            df[TransformedSchema.duration2] == DURATION2.overnight.value
        )
        df.loc[
            (~mask12 & ~mask13) & mask14, TransformedSchema.traveller_type
        ] = TRAVELLER_TYPE.tourist.value

        df.loc[:, TransformedSchema.count_of_entries] = 1
        df = df[TRANSFORMED_COLUMNS]

        # This performs a large COUNT(1) GROUP BY all columns operation.
        df = (
            df.groupby(by=TRANSFORMED_GROUPBY, dropna=False,).count().reset_index()
        ).fillna(pd.NA)

        # Reorder the re-named columns
        df = df[TRANSFORMED_COLUMNS]

        df = TransformedSchema(df)
        # Drop all entries that are == 0
        df = df[df[TransformedSchema.count_of_entries] > 0]
        # Sort entries from left to right
        travellers = df.sort_values(TRANSFORMED_COLUMNS, ascending=True,)

    else:
        travellers = pd.DataFrame(columns=TRANSFORMED_COLUMNS)

    auxiliary_df = travellers.copy()

    return travellers, auxiliary_df


def pik_v110(travellers: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Create a summary of travellers who declare their purpose of trip as work.
    
    Args:
        travellers:
            A pandas dataframe with the PIK contribution to the aggregated travellers data.

        auxiliary_df:
            A copy of the travellers file for use in the validation.

    Returns:
        validation_df:
            A summary of travellers who declare their purpose of trip as work, for
            use in the validation dashboards.
    """
    if not auxiliary_df.empty:
        validation_df = auxiliary_df
        MONTH = validation_df[TransformedSchema.month].apply(lambda x: f"{int(x):02d}")
        DAY = validation_df[TransformedSchema.day].apply(lambda x: f"{int(x):02d}")
        validation_df[CleanSchema.date] = (
            validation_df[TransformedSchema.year] + "-" + MONTH + "-" + DAY
        )

        mask = (validation_df[TransformedSchema.purpose4] == PURPOSE4.work.value) & (
            validation_df[TransformedSchema.purpose9] == PURPOSE9.work.value
        )
        validation_df.loc[mask, ValidationSchema.workers] = 1
        validation_df.loc[~mask, ValidationSchema.workers] = 0

        mask2 = (
            validation_df[TransformedSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.canada.value
        )
        mask3 = (
            validation_df[TransformedSchema.country_of_residence]
            == COUNTRY_OF_RESIDENCE.united_states.value
        )
        validation_df.loc[mask2, ValidationSchema.residency_group] = "Canada"
        validation_df.loc[
            mask3, ValidationSchema.residency_group
        ] = "United States of America"
        validation_df.loc[
            ~mask2 & ~mask3, ValidationSchema.residency_group
        ] = "Overseas"

        validation_df = validation_df[
            [
                ValidationSchema.residency_group,
                CleanSchema.date,
                TransformedSchema.port,
                ValidationSchema.workers,
                TransformedSchema.count_of_entries,
            ]
        ]
        validation_df = validation_df.groupby(
            by=[ValidationSchema.residency_group, TransformedSchema.port],
            dropna=False,
            as_index=False,
        )
        validation_df = validation_df[
            [ValidationSchema.workers, TransformedSchema.count_of_entries]
        ].apply(lambda x: x.astype(int).sum())
        validation_df.insert(1, CleanSchema.date, "")

        # Derive the date from the year/month/day column of the first row (all dates
        # are the same for a given processing month)
        YEAR = auxiliary_df[TransformedSchema.year][0]
        MONTH = int(auxiliary_df[TransformedSchema.month][0])
        DAY = int(auxiliary_df[TransformedSchema.day][0])
        OUT_DATE = f"{YEAR}-{MONTH:02d}-{DAY:02d}"
        validation_df[CleanSchema.date] = OUT_DATE

        validation_df.rename(
            columns={TransformedSchema.count_of_entries: ValidationSchema.travellers},
            inplace=True,
        )

    else:
        validation_df = pd.DataFrame(
            columns=[
                ValidationSchema.residency_group,
                CleanSchema.date,
                TransformedSchema.port,
                ValidationSchema.workers,
                ValidationSchema.travellers,
            ]
        )

    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
