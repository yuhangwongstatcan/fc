import pandas as pd

from datasource.pik.schema import RawSchema, ValidationSchema
from datasource.pik.dim import RESCNTRY, PURPIMM


def pik_070(df: pd.DataFrame) -> pd.DataFrame:
    """
    Make edits to duration and country of residence based on tourism concepts

    Args:
        df:
            A pandas dataframe which has not been adjusted for tourism concepts.
    Returns:
        df:
            A pandas dataframe with meaningless duration of stays set to blank and 
            country changed to CAN if duration of stay >=365.

        auxiliary_df:
            A pandas dataframe summarizing the edits for use in the validation dashboards.
    """
    # Immigrants
    mask1 = df[RawSchema.purpimm] == PURPIMM.immigrate.value
    # Long duration travellers of a year or more
    mask2 = pd.to_numeric(df[RawSchema.durationofstay]) >= 365

    # Edit meaningless duration of stay values
    df.loc[mask1, [RawSchema.durationofstay, RawSchema.durofabsn]] = pd.NA
    df.loc[mask2, RawSchema.rescntry] = RESCNTRY.CAN.value
    auxiliary_df = df[mask1 | mask2].copy()

    return df, auxiliary_df


def pik_v070(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Create a summary of edits done to country of residence and duration in order
    to respect tourism concepts.

    Args:
        df:
            A pandas dataframe that has had the edits done already.

        auxiliary_df:
            A subset of the pandas dataframe with just records that were edited.

    Returns:
        validation_df:
            Validation file summarizing the edits done to the PIK data to respect
            tourism concepts, for use in the validation dashboards.
    """

    if not auxiliary_df.empty:

        auxiliary_df.loc[
            auxiliary_df[RawSchema.purpimm] == PURPIMM.immigrate.value,
            ValidationSchema.edit,
        ] = "Remove Duration for Immigrants"
        auxiliary_df.loc[
            pd.to_numeric(auxiliary_df[RawSchema.durationofstay]) >= 365,
            ValidationSchema.edit,
        ] = "Recode Long-Term Visitors"
        # Add count column
        auxiliary_df[ValidationSchema.count] = 1
        groupby_df = auxiliary_df[
            [
                ValidationSchema.edit,
                RawSchema.date,
                RawSchema.wloc,
                ValidationSchema.count,
            ]
        ].copy()
        validation_df = groupby_df.groupby(
            by=[ValidationSchema.edit, RawSchema.date, RawSchema.wloc],
            dropna=False,
            as_index=False,
        ).count()

    else:
        validation_df = pd.DataFrame(
            columns=[
                ValidationSchema.edit,
                RawSchema.date,
                RawSchema.wloc,
                ValidationSchema.count,
            ]
        )

    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
