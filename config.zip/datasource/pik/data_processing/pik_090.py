import pandas as pd

from config.api import Stage, DataSource, Mapping

from modules.utils.loaders import Loader

from datasource.pik.schema import RawSchema, ValidationSchema
from datasource.pik.dim import PURPIMM

from datasource.mapping.schema import ReferenceSchema as MappingSchema

from datasource.travellers.dim import COUNTRY_OF_RESIDENCE


def pik_090(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add the Frontier Counts country code to the PIK clean data, do any necessary editing based on country codes.

    Args:
        df:
            A pandas dataframe without FC country codes and unedited country codes.

    Returns:
        df:
            A pandas dataframe with the country codes added and edited.
    """
    # Using country mapping file to obtain the country codes and values so that they're not hard coded
    country_df = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__pik__raw__rescntry__pik__clean__country_of_residence,
    )

    # Ensure that the country mapping file adheres to the defined schema
    country_df = MappingSchema(country_df)

    country_df = country_df.rename(
        columns={
            MappingSchema.key: RawSchema.rescntry,
            MappingSchema.value: RawSchema.country_of_residence,
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)

    df = pd.merge(df, country_df, on=[RawSchema.rescntry], how="left").fillna(pd.NA)

    # Edit country of residence code for immigrants
    df.loc[
        df[RawSchema.purpimm] == PURPIMM.immigrate.value, RawSchema.country_of_residence
    ] = COUNTRY_OF_RESIDENCE.not_applicable.value
    # Get mask for codes that could not be matched
    mask = df[RawSchema.country_of_residence].isnull()
    # define output and auxiliary dataframe
    auxiliary_df = df[mask]
    df = df[~mask]

    return df, auxiliary_df


def pik_v090(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Flag any countries in the PIK data that could not be matched using the mapping file.

    Args:
        df: A pandas dataframe of records with matched countries.

        auxiliary_df:
            A pandas dataframe of records with unmatched countries.
    Returns:
        validation_df:
            Validation file summarizing the unmatched countries for use in the
            validation dashboards.
    """

    auxiliary_df[ValidationSchema.count] = 1
    groupby_df = auxiliary_df[
        [RawSchema.rescntry, RawSchema.date, RawSchema.wloc, ValidationSchema.count]
    ]
    validation_df = groupby_df.groupby(
        by=[RawSchema.rescntry, RawSchema.date, RawSchema.wloc],
        dropna=False,
        as_index=False,
    ).count()
    removal_reason = "Unmatched Countries"
    validation_df.insert(0, ValidationSchema.country_code_type, removal_reason)

    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
