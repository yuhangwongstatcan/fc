import pandas as pd

from datasource.pik.data_processing import RawSchema, ValidationSchema
from datasource.pik.dim import DOCTYPE

# Load codes that flag invalid or test kiosk sessions
surnames = ["VISDEC", "RESDEC"]
first_names = [
    "ONE",
    "TWO",
    "THREE",
    "FOUR",
    "FIVE",
    "SIX",
    "SEVEN",
    "EIGHT",
    "NINE",
    "TEN",
]
kiosk = "TEST"


def pik_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove PIK records for various reasons:
        - Surname field identifies a test case
        - First name field identifies a test case
        - Kiosk session ID identifies a test case
        - Key variables are blank (country of residence / arriving from)
        - Duplicates

    Args:
        df:
            A pandas dataframe with erroneous surname, first name, kiosk data
    Returns:
        df:
            A pandas dataframe with all records containing erroneous surname, first name, kiosk data removed
    """

    subset = [
        RawSchema.kiosk_ssn_id,
        RawSchema.lname,
        RawSchema.fname,
        RawSchema.gender,
        RawSchema.dob,
    ]
    DUPLICATE_EXISTS = df.duplicated(subset=subset, keep=False)
    FNAME_LNAME_NOT_NULL = (~df[RawSchema.fname].isna()) & (~df[RawSchema.lname].isna())
    duplicate_mask = DUPLICATE_EXISTS & FNAME_LNAME_NOT_NULL
    if any(duplicate_mask):
        # If there are duplicates on the columns defined in subset (from documentation),
        # If the duplicate is caused by multiple ID types (doctype) keep the record where
        # doctype = 13 or 40 (passport) instead of the record with doctype 29 (permanent resident card).
        # If the duplicates have the same doctype, keep the first record.
        df["count"] = 0
        df["is_dtype_29"] = pd.to_numeric(
            df[RawSchema.doctype] == DOCTYPE.pr_card.value
        )
        groupby_df = (
            df[duplicate_mask]
            .groupby(by=subset, as_index=False, dropna=False)
            .agg({"count": "count", "is_dtype_29": "sum"})
        )
        groupby_df["keep29"] = groupby_df["count"] == groupby_df["is_dtype_29"]

        df = pd.merge(df, groupby_df[subset + ["keep29"]], on=subset, how="left")

        is_dtype_29 = df["is_dtype_29"].copy()
        keep29 = df["keep29"]
        keep29 = keep29.fillna(False)
        s1 = df[(duplicate_mask) & ((~is_dtype_29) | (keep29))].copy()
        s2 = df[(duplicate_mask) & ((is_dtype_29) & ~(keep29))].copy()
        s3 = df[~duplicate_mask].copy()
        not_keep_s1 = s1.duplicated(subset=subset, keep="first")
        s11 = s1[~not_keep_s1].copy()
        s12 = s1[not_keep_s1].copy()
        keep = pd.concat([s3, s11]).reset_index()
        discard = pd.concat([s2, s12]).reset_index()

        df = keep.copy().drop(["index", "count", "is_dtype_29", "keep29"], axis=1)
        auxiliary_df = discard[df.columns.values.tolist()].copy()
        auxiliary_df["is_duplicate"] = True

    else:
        auxiliary_df = pd.DataFrame(columns=df.columns.values.tolist())

    # Create mask for rows where last name, first name, or kiosk id is not acceptable
    invalid_mask = (
        (df[RawSchema.lname].isin(surnames))
        | (df[RawSchema.kiosk_ssn_id].fillna("").str.contains(kiosk))
        | (df[RawSchema.kioskdttm].isnull())
        | (df[RawSchema.fname].isin(first_names))
        | (df[RawSchema.kiosk_ssn_id].isnull())
        | (df[RawSchema.arrivingfrom].isnull())
        | (df[RawSchema.rescntry].isnull())
    )

    tmp = df[invalid_mask].copy()
    tmp["is_duplicate"] = False
    df = df[~invalid_mask]

    auxiliary_df = auxiliary_df.append(tmp)

    return df, auxiliary_df


def pik_v020(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Summarize the PIK records that were removed for various reasons.

    Args:
        df:
            A pandas dataframe with invalid PIK records removed for
            various reasons.
        auxiliary_df:
            A pandas dataframe with the removed records.
    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """

    # Add removal reason column
    auxiliary_df[ValidationSchema.removal_reason] = pd.NA
    # Get removal reasons
    auxiliary_df.loc[
        auxiliary_df["is_duplicate"] == True, ValidationSchema.removal_reason
    ] = "Duplicates"
    auxiliary_df.loc[
        (auxiliary_df[RawSchema.fname].isin(first_names)),
        ValidationSchema.removal_reason,
    ] = "Test Records"
    auxiliary_df.loc[
        auxiliary_df[RawSchema.kiosk_ssn_id].fillna("").str.contains(kiosk),
        ValidationSchema.removal_reason,
    ] = "Test Records"
    auxiliary_df.loc[
        auxiliary_df[RawSchema.lname].isin(surnames), ValidationSchema.removal_reason
    ] = "Test Records"
    auxiliary_df.loc[
        auxiliary_df[RawSchema.kioskdttm].isnull(), ValidationSchema.removal_reason
    ] = "Missing KIOSKDTTM"
    auxiliary_df.loc[
        auxiliary_df[RawSchema.kiosk_ssn_id].isnull(), ValidationSchema.removal_reason
    ] = "Missing KIOSK_SSN_ID"
    auxiliary_df.loc[
        auxiliary_df[RawSchema.arrivingfrom].isnull(), ValidationSchema.removal_reason
    ] = "Missing ARRIVINGFROM"
    auxiliary_df.loc[
        auxiliary_df[RawSchema.rescntry].isnull(), ValidationSchema.removal_reason
    ] = "Missing RESCNTRY"

    # Add count column
    auxiliary_df[ValidationSchema.count] = 1
    # Get groupby df
    groupby_df = auxiliary_df[
        [
            ValidationSchema.removal_reason,
            RawSchema.date,
            RawSchema.wloc,
            ValidationSchema.count,
        ]
    ]
    validation_df = (
        groupby_df.groupby(
            by=[ValidationSchema.removal_reason, RawSchema.date, RawSchema.wloc],
            dropna=False,
            as_index=False,
        ).count()
    ).astype(
        {
            # v_sch.wloc.name: "Int64",
            ValidationSchema.count: "Int64"
        }
    )
    validation_df[RawSchema.date] = validation_df[RawSchema.date].ffill()

    # Make sure that the validation output adheres to the schema definition
    validation_df = ValidationSchema(validation_df)

    return validation_df
