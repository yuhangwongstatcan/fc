import pandas as pd

from datasource.pik.schema import RawSchema, ValidationSchema
from datasource.pik.dim import PURPSTUDY, PURPVISIT, PURPWORK, PURPIMM, DOC_COUNTRY


def pik_v050(df: pd.DataFrame) -> pd.DataFrame:
    """
    Provide a summary of unexpected kiosk flows, where travellers were asked
    questions that we would not expect based on their characteristics.

    Args:
        df: A pandas dataframe that has had invalid and test records removed.

    Returns:
        df:
            A copy of the input dataframe since no processing is done.

        validation_df:
            Validation file summarizing unexpected kiosk flows.

    """

    validation_df = df[
        [
            RawSchema.kiosk_ssn_id,
            RawSchema.doctype,
            RawSchema.doc_country,
            RawSchema.travellercitizenship,
            RawSchema.rescntry,
            RawSchema.date,
            RawSchema.wloc,
            RawSchema.numtrvlr,
            RawSchema.durationofstay,
            RawSchema.durofabsn,
            RawSchema.purpstudy,
            RawSchema.purpvisit,
            RawSchema.purpwork,
            RawSchema.purpimm,
        ]
    ].copy()
    validation_df[ValidationSchema.count] = 1

    # Canadian-issued document with duration of stay
    # if doc_country = "CAN" and durationofstay is not missing
    CanadianDocument_with_DurationofStay = (
        validation_df[
            (~(validation_df[RawSchema.durationofstay]).isnull())
            & (validation_df[RawSchema.doc_country] == DOC_COUNTRY.canada.value)
        ]
        .groupby(by=[RawSchema.date, RawSchema.wloc], dropna=False, as_index=False)
        .count()[[RawSchema.date, RawSchema.wloc, ValidationSchema.count]]
    )
    CanadianDocument_with_DurationofStay.insert(
        loc=0,
        column=ValidationSchema.unexpected_flow,
        value="Canadian Document with Duration of Stay",
    )

    # Canadian-resident traveller without a duration of absence
    # if (rescntry = "CAN" and (doc_country = "CAN" or (doc_country = OTH" and purpimm = 0)) and durofabsn is missing)
    CanadianResident_without_DurationofAbsence = validation_df[
        (validation_df[RawSchema.rescntry] == DOC_COUNTRY.canada.value)
        & (
            (validation_df[RawSchema.doc_country] == DOC_COUNTRY.canada.value)
            | (
                (
                    validation_df[RawSchema.doc_country]
                    == DOC_COUNTRY.other_country.value
                )
                & (validation_df[RawSchema.purpimm] == PURPIMM.not_immigrate.value)
            )
        )
        & ((validation_df[RawSchema.durofabsn]).isnull())
    ]

    CanadianResident_without_DurationofAbsence = CanadianResident_without_DurationofAbsence.groupby(
        by=[RawSchema.date, RawSchema.wloc], dropna=False, as_index=False
    ).count()[
        [RawSchema.date, RawSchema.wloc, ValidationSchema.count]
    ]
    CanadianResident_without_DurationofAbsence.insert(
        loc=0,
        column=ValidationSchema.unexpected_flow,
        value="Canadian Resident without Duration of Absence",
    )

    # Foreign-issued document without duration of stay
    # if (doc_country = "OTH") and (durationofstay is missing) and (purpimm = 0)
    ForeignDocument_without_DurationofStay = (
        validation_df[
            ((validation_df[RawSchema.durationofstay]).isnull())
            & (validation_df[RawSchema.doc_country] == DOC_COUNTRY.other_country.value)
            & (validation_df[RawSchema.purpimm] == PURPIMM.not_immigrate.value)
        ]
        .groupby(by=[RawSchema.date, RawSchema.wloc], dropna=False, as_index=False)
        .count()[[RawSchema.date, RawSchema.wloc, ValidationSchema.count]]
    )
    ForeignDocument_without_DurationofStay.insert(
        loc=0,
        column=ValidationSchema.unexpected_flow,
        value="Foreign Document without Duration of Stay",
    )

    # Foreign resident traveller with duration of absence
    # if (rescntry != "CAN" and (doc_country = "CAN" or (doc_country = "OTH" and purpimm = 0) and durofabsn is not missing))
    ForeignResident_with_DurationofAbsence = (
        validation_df[
            (
                (validation_df[RawSchema.doc_country] == DOC_COUNTRY.canada.value)
                | (
                    (
                        validation_df[RawSchema.doc_country]
                        == DOC_COUNTRY.other_country.value
                    )
                    & (validation_df[RawSchema.purpimm] == PURPIMM.not_immigrate.value)
                )
                & (~(validation_df[RawSchema.durofabsn]).isnull())
            )
            & (validation_df[RawSchema.rescntry] != DOC_COUNTRY.canada.value)
        ]
        .groupby(by=[RawSchema.date, RawSchema.wloc], dropna=False, as_index=False)
        .count()[[RawSchema.date, RawSchema.wloc, ValidationSchema.count]]
    )
    ForeignResident_with_DurationofAbsence.insert(
        loc=0,
        column=ValidationSchema.unexpected_flow,
        value="Foreign Resident with Duration of Absence",
    )

    # Canadian-issued document with purpose of trip declared
    # if purpimm = 1 and (durationofstay is not missing or durofabsn is not missing)
    Canadian_Document_with_Purpose_of_Trip = (
        validation_df[
            (validation_df[RawSchema.doc_country] == DOC_COUNTRY.canada.value)
            & (
                ((validation_df[RawSchema.purpimm]) == PURPIMM.immigrate.value)
                | (validation_df[RawSchema.purpstudy] == PURPSTUDY.study.value)
                | (validation_df[RawSchema.purpvisit] == PURPVISIT.visit.value)
                | (validation_df[RawSchema.purpwork] == PURPWORK.work.value)
            )
        ]
        .groupby(by=[RawSchema.date, RawSchema.wloc], dropna=False, as_index=False)
        .count()[[RawSchema.date, RawSchema.wloc, ValidationSchema.count]]
    )
    Canadian_Document_with_Purpose_of_Trip.insert(
        loc=0,
        column=ValidationSchema.unexpected_flow,
        value="Canadian Document with Purpose of Trip",
    )

    validation_df = pd.concat(
        [
            CanadianDocument_with_DurationofStay,
            CanadianResident_without_DurationofAbsence,
            ForeignDocument_without_DurationofStay,
            ForeignResident_with_DurationofAbsence,
            Canadian_Document_with_Purpose_of_Trip,
        ]
    )[
        [
            ValidationSchema.unexpected_flow,
            RawSchema.date,
            RawSchema.wloc,
            ValidationSchema.count,
        ]
    ]
    validation_df.reset_index(inplace=True)
    validation_df = validation_df.drop(columns=["index"])
    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return df, validation_df
