import pandas as pd

from datasource.pik.schema import RawSchema
from datasource.pik.schema import RAW_COLUMNS


def pik_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    Imputes entries where flight is only digits, no airline characters (ie 985 instead dof AC985)

    Args:
        df:
            A pandas dataframe where flight column may have rows with only digits
    Returns:
        df:
            A pandas dataframe where incomplete flight codes have had their codes imputed.
    """
    df = df.copy()
    # We drop blank flight values (i.e. do not try and impute these)
    removed = df.loc[df[RawSchema.flight].isnull(), :]
    df = df.dropna(subset=[RawSchema.flight])
    # Any flight that contains only digits is invalid (any flight that contains at least one
    # non-digit character is valid)
    df.loc[:, "is_invalid"] = df[RawSchema.flight].str.isdigit()
    # The left dataframe is the table with values that need to be imputed
    left = df[df["is_invalid"]]
    # The right dataframe is the table with candidate donor values
    right = df[~df["is_invalid"]]
    # Conditional on being a valid flight number, the digit portion is everything from the second
    # character position onward (inclusive)
    right.loc[:, "flight_digits"] = df[RawSchema.flight].str[2:].copy()
    # Give a UID to each row to preserve each row of left table in case of duplicates.
    left.loc[:, "uid"] = range(0, len(left))
    left = pd.merge(
        left,
        right[[RawSchema.date, RawSchema.wloc, RawSchema.flight, "flight_digits"]],
        left_on=[RawSchema.date, RawSchema.wloc, RawSchema.flight],
        right_on=[RawSchema.date, RawSchema.wloc, "flight_digits"],
        how="left",
    )
    left = left.drop_duplicates()
    left.loc[~left[f"{RawSchema.flight}_y"].isna(), f"{RawSchema.flight}_x"] = left[
        f"{RawSchema.flight}_y"
    ]
    left = left.drop(columns=[f"{RawSchema.flight}_y", "uid"])
    left = left.rename(columns={f"{RawSchema.flight}_x": RawSchema.flight})
    df = pd.concat([left, right, removed])

    df = df[RAW_COLUMNS]

    return df
