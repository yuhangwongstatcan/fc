import pandas as pd

from config.api import Stage, DataSource
from config.api import WorkLocationsTransAction

from modules.utils.loaders import Loader

from datasource.pik.schema import RawSchema, ValidationSchema

from datasource.work_locations_trans_action.schema import (
    ReferenceSchema as TransActionSchema,
)
from datasource.work_locations_trans_action.dim import ACTION


def pik_010(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove PIK records which are not accepted or from unknown work locations

    Args:
        df:
            A pandas dataframe with not accepted or unknown work locations present
    Returns:
        df:
            A pandas dataframe with all records containing not accepted or unknown 
            work locations removed
    """
    # Load accepted and known work locations df
    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__pik,
    )

    # Ensure that the work locations trans action file matches the schema
    work_locations = TransActionSchema(work_locations)

    # Obtain mask of all records in input that conform with work locations acceptability
    invalid_mask = (
        ~(
            df[RawSchema.wloc].isin(
                work_locations[
                    work_locations[TransActionSchema.action] == ACTION.accept.value
                ][TransActionSchema.work_location].values
            )
        )
        | (df[RawSchema.wloc].isnull())
        | (
            df[RawSchema.wloc].isin(
                work_locations[
                    work_locations[TransActionSchema.transportation_type] != "pik__111"
                ][TransActionSchema.work_location].values
            )
        )
    )
    # Apply mask
    auxiliary_df = df[invalid_mask].copy()
    df = df[~invalid_mask].reset_index(drop=True)

    return df, auxiliary_df


def pik_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate the unexpected work locations or modes of transportation for PIK.

    Args:
        df:
            A pandas dataframe with unacceptable work locations removed.
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """
    auxiliary_df[ValidationSchema.count] = 0
    auxiliary_df = auxiliary_df[
        [RawSchema.date, RawSchema.wloc, ValidationSchema.count]
    ]
    validation_df = auxiliary_df.groupby(
        by=[RawSchema.date, RawSchema.wloc], dropna=False, as_index=False
    ).count()

    # Make sure that the validation output adheres to the schema definition
    validation_df = ValidationSchema(validation_df)

    return validation_df

