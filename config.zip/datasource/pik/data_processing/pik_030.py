import pandas as pd

from datasource.pik.schema import RawSchema, ValidationSchema


def pik_v030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create a daily volume summary to validate PIK data.

    Args:
        df: A pandas dataframe that has had invalid and test records removed.
        
    Returns:
        df:
            A copy of the input dataframe since no processing is done.

        validation_df:
            Validation file summarizing the PIK traveller volumes by day.
    """

    validation_df = (
        df.groupby(
            by=[RawSchema.date, RawSchema.wloc, RawSchema.crew],
            dropna=False,
            as_index=False,
        ).count()
    ).astype(
        {
            #        schema_out.wloc.name: "Int64",
            RawSchema.kiosk_ssn_id: "Int64"
        }
    )
    validation_df.rename(
        columns={RawSchema.kiosk_ssn_id: ValidationSchema.count}, inplace=True
    )

    validation_df = validation_df[
        [RawSchema.date, RawSchema.wloc, RawSchema.crew, ValidationSchema.count]
    ]

    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return df, validation_df
