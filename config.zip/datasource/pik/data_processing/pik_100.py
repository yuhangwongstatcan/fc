import pandas as pd

from datasource.pik.schema import CleanSchema, ValidationSchema, CLEAN_COLUMNS
from datasource.pik.dim import RESCNTRY, PURPIMM


def pik_100(df: pd.DataFrame) -> pd.DataFrame:
    """
    Imputes entries where duration of absence and duration of stay may be missing but based on
    traveller information those values should exist.

    Args:
        df:
            A pandas dataframe where duration of absence or duration of stay may be missing.

    Returns:
        df:
            A pandas dataframe where missing durofabsn and durationofstay have had their values imputed.
        
        auxiliary_df:
            A pandas dataframe which can be used to summarize the duration imputation for validation.
    """
    auxiliary_df = df.copy()

    # Create mask for donor candidates and imputation candidates
    mask = (
        (df[CleanSchema.purpimm] == PURPIMM.not_immigrate.value)
        & (df[CleanSchema.rescntry] == RESCNTRY.CAN.value)
        & (
            (df[CleanSchema.durationofstay] < 365)
            | (df[CleanSchema.durationofstay].isnull())
        )
        & (df[CleanSchema.durofabsn].isnull())
    )

    df[CleanSchema.kioskdttm] = pd.to_datetime(df[CleanSchema.kioskdttm])
    df = df.sort_values(CleanSchema.kioskdttm)
    left = df[mask].copy()
    right = df[~mask].dropna(subset=[CleanSchema.durofabsn])

    # Pandas resets the index on merge, so keep a copy of which indices were
    # selected with the above criteria.
    left.loc[:, "copy_index"] = left.index
    values_to_update = pd.merge_asof(
        left,
        right,
        on=CleanSchema.kioskdttm,
        direction="nearest",
        by=[CleanSchema.wloc, CleanSchema.flight],
    ).set_index("copy_index")

    # If matching on work location and flight failed, try matching only on work location
    if values_to_update["durofabsn_y"].isnull().values.any():
        # Create a left frame that gets all entries with null values for
        # total_passengers_y
        left2 = left.loc[
            values_to_update[values_to_update["durofabsn_y"].isnull()].index
        ]
        # Copy index before merge
        left2.loc[:, "copy_index"] = left2.index
        # Drop any null values in values_to_update since these will be
        # accounted for by values_to_update_fallback
        values_to_update = values_to_update[~values_to_update["durofabsn_y"].isnull()]
        # Merge left2 with right, but now only using work location as a condition.
        values_to_update_fallback = pd.merge_asof(
            left2,
            right,
            on=CleanSchema.kioskdttm,
            direction="nearest",
            by=[CleanSchema.wloc],
        ).set_index("copy_index")

    if "values_to_update_fallback" in locals():
        values_to_update = pd.concat([values_to_update, values_to_update_fallback])
    # Replace missing values with their donors
    df.loc[mask, [CleanSchema.durofabsn],] = values_to_update[["durofabsn_y",]].values
    # Create mask for donor candidates and imputation candidates

    # Now do it again for people that are rescntry!=CAN, they should have duration of stay filled out if purpimm=0
    # Add group column based on rescntry value
    df["group"] = df[CleanSchema.rescntry]
    mask3 = (df[CleanSchema.rescntry] != RESCNTRY.USA.value) & (
        df[CleanSchema.rescntry] != RESCNTRY.CAN.value
    )
    df.loc[df[CleanSchema.rescntry] == RESCNTRY.USA.value, "group"] = RESCNTRY.USA.value

    df.loc[mask3, "group"] = "OVS"
    mask2 = (
        (df[CleanSchema.purpimm] == PURPIMM.not_immigrate.value)
        & (df[CleanSchema.rescntry] != RESCNTRY.CAN.value)
        & ((df[CleanSchema.durationofstay].isnull()))
    )
    left = df[mask2].copy()
    if not left.empty:
        right = df[~mask2].dropna(subset=[CleanSchema.durationofstay])
        # Do the merge
        left.loc[:, "copy_index"] = left.index
        values_to_update2 = pd.merge_asof(
            left,
            right,
            on=CleanSchema.kioskdttm,
            direction="nearest",
            by=["group", CleanSchema.wloc, CleanSchema.flight],
        ).set_index("copy_index")
        # If matching on group, work location, and flight failed, match on only work location
        if values_to_update2["durationofstay_y"].isnull().values.any():
            # Create a left frame that gets all entries with null values for
            # total_passengers_y
            left3 = left.loc[
                values_to_update2[values_to_update2["durationofstay_y"].isnull()].index
            ]
            # Copy index before merge
            left3.loc[:, "copy_index"] = left3.index
            # Drop any null values in values_to_update since these will be
            # accounted for by values_to_update_fallback
            values_to_update2 = values_to_update2[
                ~values_to_update2["durationofstay_y"].isnull()
            ]
            # Merge left2 with right, but now only using work location as a condition.
            values_to_update_fallback2 = pd.merge_asof(
                left3,
                right,
                on=CleanSchema.kioskdttm,
                direction="nearest",
                by=["group", CleanSchema.wloc],
            ).set_index("copy_index")

        if "values_to_update_fallback2" in locals():
            values_to_update2 = pd.concat(
                [values_to_update2, values_to_update_fallback2]
            )
        # Replace missing values with their donors
        df.loc[mask2, CleanSchema.durationofstay] = values_to_update2[
            "durationofstay_y"
        ].values

    # Do not return temporary columns
    df[CleanSchema.kioskdttm] = pd.to_datetime(df[CleanSchema.kioskdttm])
    df = df[CLEAN_COLUMNS].copy()

    # Adding "000" to match format of test expected output
    df[CleanSchema.kioskdttm] = df[CleanSchema.kioskdttm].astype(str) + "000"

    # Check that the output file adheres to the CLEAN schema after all the merges
    # df = CleanSchema(df)

    return df, auxiliary_df


def pik_v100(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Summarize imputation of duration variables that were missing.

    Args:
        df: A pandas dataframe of records with durations fully imputed.

        auxiliary_df:
            A pandas dataframe of records prior to the duration imputation.
    Returns:
        validation_df:
            Validation file summarizing the duration imputation for use in
            the validation dashboards.
    """

    is_can_res = auxiliary_df[CleanSchema.rescntry] == RESCNTRY.CAN.value
    temp_mask = (auxiliary_df[CleanSchema.purpimm] == PURPIMM.not_immigrate.value) & (
        (pd.to_numeric(auxiliary_df[CleanSchema.durationofstay]) < 365)
        | (
            (auxiliary_df[CleanSchema.durationofstay].isnull())
            & (auxiliary_df[CleanSchema.durofabsn].isnull())
        )
    )
    temp_mask2 = (auxiliary_df[CleanSchema.purpimm] == PURPIMM.not_immigrate.value) & (
        auxiliary_df[CleanSchema.durationofstay].isnull()
    )
    temp_mask3 = (auxiliary_df[CleanSchema.purpimm] == PURPIMM.not_immigrate.value) & (
        (pd.to_numeric(auxiliary_df[CleanSchema.durationofstay]) < 365)
        | (
            (auxiliary_df[CleanSchema.durationofstay].isnull())
            & ~(auxiliary_df[CleanSchema.durofabsn].isnull())
        )
    )
    temp_mask4 = (auxiliary_df[CleanSchema.purpimm] == PURPIMM.not_immigrate.value) & ~(
        auxiliary_df[CleanSchema.durationofstay].isnull()
    )
    group1 = is_can_res & temp_mask
    group2 = is_can_res & temp_mask3
    group3 = ~is_can_res & temp_mask2
    group4 = ~is_can_res & temp_mask4

    # mask2 = (pd.to_numeric(auxiliary_df[schema.purpimm.name]) == 0) & (auxiliary_df[schema.rescntry.name] != country.k_CAN.key) & (
    # (auxiliary_df[schema.durationofstay.name].isnull())
    # )

    auxiliary_df.loc[
        group1, [ValidationSchema.traveller_group, ValidationSchema.imputation_status]
    ] = [
        "Canadian Residents",
        "Imputed Durations",
    ]
    auxiliary_df.loc[
        group2, [ValidationSchema.traveller_group, ValidationSchema.imputation_status]
    ] = [
        "Canadian Residents",
        "Valid Durations",
    ]
    auxiliary_df.loc[
        group3, [ValidationSchema.traveller_group, ValidationSchema.imputation_status]
    ] = (
        "Visitors to Canada",
        "Imputed Durations",
    )
    auxiliary_df.loc[
        group4, [ValidationSchema.traveller_group, ValidationSchema.imputation_status]
    ] = [
        "Visitors to Canada",
        "Valid Durations",
    ]
    auxiliary_df[ValidationSchema.count] = 1
    groupby_df = auxiliary_df[
        [
            ValidationSchema.traveller_group,
            ValidationSchema.imputation_status,
            CleanSchema.date,
            CleanSchema.wloc,
            ValidationSchema.count,
        ]
    ]
    groupby_df = groupby_df.groupby(
        by=[
            ValidationSchema.traveller_group,
            ValidationSchema.imputation_status,
            CleanSchema.date,
            CleanSchema.wloc,
        ],
        dropna=False,
        as_index=False,
    ).count()
    validation_df = groupby_df.dropna()

    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return validation_df

