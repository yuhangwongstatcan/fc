import pandas as pd
import numpy as np

import datetime as dt

from datasource.pik.schema import RawSchema, ValidationSchema


def pik_v040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Provide a summary of incidences of periods of more than one hour
    with no travellers at major airports.
    Major airports: 
    - 3961 [Montreal]
    - 4974 [Toronto T3]
    - 7011 [Calgary]
    - 8212 [Vancouver]

    Args:
        df: A pandas dataframe that has had invalid and test records removed.

    Returns:
        df:
            A copy of the input dataframe since no processing is done.

        validation_df:
            Validation file summarizing long traffic gaps at major airports.
    """

    MAJOR_AIRPORTS = ["3961", "4974", "7011", "8212"]

    validation_df = df[df[RawSchema.wloc].isin(MAJOR_AIRPORTS)][
        [RawSchema.date, RawSchema.wloc, RawSchema.kioskdttm, RawSchema.kiosk_ssn_id,]
    ]
    validation_df["kioskdttm_datetimeobj"] = pd.to_datetime(
        validation_df[RawSchema.kioskdttm]
    )

    validation_df = validation_df.sort_values(
        by=[RawSchema.wloc, "kioskdttm_datetimeobj"]
    )

    validation_df["delta"] = (
        validation_df["kioskdttm_datetimeobj"]
        .diff()
        .where(
            validation_df[RawSchema.wloc] == validation_df[RawSchema.wloc].shift(1),
            np.timedelta64(0, "m"),
        )
    )

    validation_df[ValidationSchema.gap_start] = validation_df[
        RawSchema.kioskdttm
    ].shift(1)
    validation_df = validation_df[validation_df["delta"] > np.timedelta64(60, "m")]

    validation_df[ValidationSchema.gap_start] = validation_df[
        ValidationSchema.gap_start
    ].apply(lambda x: x.split()[1][:5])
    validation_df[ValidationSchema.gap_end] = validation_df[RawSchema.kioskdttm].apply(
        lambda x: x.split()[1][:5]
    )

    # Only flag cases where the gap start and gap end are between 7:00 AM and 12:00 AM.
    # It is common to have gaps overnight since flights are only intermittently (or not at all) scheduled to arrive during this time
    fixed_gap_start = dt.time(7, 0, 0)
    fixed_gap_end = dt.time(23, 59, 59)

    VALID_START_MASK = (
        validation_df[ValidationSchema.gap_start].astype("datetime64[ns]").dt.time
        >= fixed_gap_start
    ) & (
        validation_df[ValidationSchema.gap_start].astype("datetime64[ns]").dt.time
        <= fixed_gap_end
    )
    VALID_END_MASK = (
        validation_df[ValidationSchema.gap_end].astype("datetime64[ns]").dt.time
        >= fixed_gap_start
    ) & (
        validation_df[ValidationSchema.gap_end].astype("datetime64[ns]").dt.time
        <= fixed_gap_end
    )

    validation_df = validation_df[VALID_START_MASK & VALID_END_MASK]

    validation_df = validation_df[
        [
            RawSchema.date,
            RawSchema.wloc,
            ValidationSchema.gap_start,
            ValidationSchema.gap_end,
        ]
    ]

    # Ensure that the validation dataframe adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return df, validation_df
