"""
**Author(s)**

    Jacob Doering (jacob.doering@statcan.gc.ca)

**Created On:** March 2023

**Description:**

The pipeline definitions for the PIK data source. 
Two pipelines are defined in this module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`
"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.pipeline import validation_writer
from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID

from config.api import Stage, DataSource, S3

from datasource.pik.data_processing import *
from datasource.pik.schema import RawSchema, CleanSchema

from datasource.travellers.schema import TransformedSchema as TravellersSchema


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the PIK data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data files created by the loader
        df = Loader.query(
            Stage.RAW, datasource=self.datasource, year=self.year, month=self.month
        )

        # Make sure that the df adheres to the raw schema
        df = RawSchema(df)

        # Remove whitespace from certain variables and send to dimension validation
        print("   1.Starting processing pik_000")
        df, auxiliary_df = pik_000(df)
        # VALIDATION: Summary of unexpected values in dimension variables.
        validation_df = pik_v000(df, auxiliary_df)
        validation_writer(validation_df, pik_v000, self.datasource, self.date)
        logging.info("Finished processing pik_000")
        print("   1.Finished processing pik_000")

        # Remove unused data based on unexpected work locations or vehicle types
        print("   2.Starting processing pik_010")
        df, auxiliary_df = pik_010(df)
        # VALIDTION: Check for new or unexpected data / work locations
        validation_df = pik_v010(df, auxiliary_df)
        validation_writer(validation_df, pik_v010, self.datasource, self.date)
        logging.info("Finished processing pik_010")
        print("   2.Finished processing pik_010")

        # Remove PIK records identified as test cases or duplicates
        print("   3.Starting processing pik_020")
        df, auxiliary_df = pik_020(df)
        # VALIDATION: Summarize the removed records by reason
        validation_df = pik_v020(df, auxiliary_df)
        validation_writer(validation_df, pik_v020, self.datasource, self.date)
        logging.info("Finished processing pik_020")
        print("   3.Finished processing pik_020")

        # VALIDATION: PIK daily volume summary
        print("   4.Starting processing pik_030")
        df, validation_df = pik_v030(df)
        validation_writer(validation_df, pik_v030, self.datasource, self.date)
        logging.info("Finished processing pik_030")
        print("   4.Finished processing pik_030")

        # VALIDATION: Summary of large traffic gaps at major PIK airports
        print("   5.Starting processing pik_040")
        df, validation_df = pik_v040(df)
        validation_writer(validation_df, pik_v040, self.datasource, self.date)
        logging.info("Finished processing pik_040")
        print("   5.Finished processing pik_040")

        # VALIDATION: Summary of unexpected kiosk flows
        print("   6.Starting processing pik_050")
        df, validation_df = pik_v050(df)
        validation_writer(validation_df, pik_v050, self.datasource, self.date)
        logging.info("Finished processing pik_050")
        print("   6.Finished processing pik_050")

        # Impute flight company in the case where only digits are present in the flight number
        print("   7.Starting processing pik_060")
        df = pik_060(df)
        logging.info("Finished processing pik_060")
        print("   7.Finished processing pik_060")

        # Edit PIK country of residence and duration to respect tourism concepts
        print("   8.Starting processing pik_070")
        df, auxiliary_df = pik_070(df)
        # VALIDATION: Summary of removed records by reason
        validation_df = pik_v070(df, auxiliary_df)
        validation_writer(validation_df, pik_v070, self.datasource, self.date)
        logging.info("Finished processing pik_070")
        print("   8.Finished processing pik_070")

        # VALIDATION: Summary of records where crew and immigration indicators are in conflict
        print("   9.Starting processing pik_080")
        df, validation_df = pik_v080(df)
        validation_writer(validation_df, pik_v080, self.datasource, self.date)
        logging.info("Finished processing pik_080")
        print("   9.Finished processing pik_080")

        # Add the Frontier Counts country code and edit as required
        print("   10.Starting processing pik_090")
        df, auxiliary_df = pik_090(df)
        # VALIDATION: Summary of unmatched countries
        validation_df = pik_v090(df, auxiliary_df)
        validation_writer(validation_df, pik_v090, self.datasource, self.date)
        logging.info("Finished processing pik_090")
        print("   10.Finished processing pik_090")

        # Impute duration of stay or duration of absence if missing for certain travellers
        print("   11.Starting processing pik_100")
        df, auxiliary_df = pik_100(df)
        # VALIDATION: Summary of imputation for trip duration
        validation_df = pik_v100(df, auxiliary_df)
        validation_writer(validation_df, pik_v100, self.datasource, self.date)
        logging.info("Finished processing pik_100")
        print("   11.Finished processing pik_100")

        # Make sure the output dataframe adheres to the clean schema
        df = CleanSchema(df)

        # print(f"time spent running pik RawClean: {time.time()-t1}")
        # Save outputs to outputs dictionary
        pik_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[self.datasource.value] = pik_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the PIK data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the CLEAN data files
        df = Loader.query(
            Stage.CLEAN, datasource=self.datasource, year=self.year, month=self.month
        )

        # Make sure the input dataframe adheres to the clean schema
        df = CleanSchema(df)

        # Create the PIK contribution to the aggregated travellers table
        print("Starting processing pik_110")
        travellers, auxiliary_df = pik_110(df)
        # VALIDATION: Summary of imputation for trip duration
        validation_df = pik_v110(travellers, auxiliary_df)
        validation_writer(validation_df, pik_v110, self.datasource, self.date)
        logging.info("Finished processing pik_110")
        print("Finished processing pik_110")

        # Make sure that the travellers df adheres to the transformed schema
        travellers = TravellersSchema(travellers)

        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary

        self.outputs[DataSource.travellers.value] = travellers_output
