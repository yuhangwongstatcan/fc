"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the PIK data source.
"""

import pandera as pa
from typing import Optional
from pandera.typing import Series

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.common.types import SafeIntToStringType

from datasource.pik.dim import (
    ARVBY,
    ARRIVINGFROM,
    DUROFABSN,
    GENDER,
    TRAVELLERCITIZENSHIP,
    DOCTYPE,
    RESPROVSTATE,
    RESCNTRY,
    CREW,
    PURPSTUDY,
    PURPVISIT,
    PURPWORK,
    PURPIMM,
    DOC_COUNTRY,
)

# Define as constants any variables that are in both the RAW and CLEAN schema to avoid duplication
COUNTRY_OF_RESIDENCE_FIELD = pa.Field(
    description="Country of residence of arriving traveller",
    str_matches=r"\d{5}",
    nullable=True,
    coerce=True,
)


class RawSchema(FCSchemaModel):
    """
    Schema for PIK RAW data.
    """

    date: Series[pa.String] = pa.Field(
        description="Date of arrival. Note: Derived by the PIK splitter program maintained by IT",
        # Date should be in the format YYYY-MM-DD
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
        nullable=True,
    )
    kioskdttm: Series[pa.String] = pa.Field(
        description="The exact date and time that the traveller's kiosk session began.",
        coerce=True,
        nullable=True,
    )
    kiosk_ssn_id: Series[pa.String] = pa.Field(
        description="The system-generated ID for the kiosk session. The ID is the same for all travellers declaring together.",
        coerce=True,
        nullable=True,
    )
    wloc: Series[SafeIntToStringType] = pa.Field(
        description="CBSA work location code for the airport at which the kiosk declaration took place.",
        str_matches=r"\d{4}",
        coerce=True,
        nullable=True,
    )
    arvby: Series[pa.String] = pa.Field(
        description="The mode of travel used to enter Canada.",
        isin=ARVBY.list(),
        coerce=True,
        raise_warning=True,
    )
    lang: Series[SafeIntToStringType] = pa.Field(
        description="The language used during the kiosk session. Note: Use not permitted for Frontier Counts.",
        coerce=True,
        nullable=True,
    )
    numtrvlr: Series[pa.INT64] = pa.Field(
        description="Number of travellers declaring together as part of the same kiosk session.",
        le=6,
        ge=0,
        coerce=True,
    )
    arrivingfrom: Series[SafeIntToStringType] = pa.Field(
        description="Each kiosk session requires the traveller to declare arriving from U.S. only, overseas direct or via the U.S.",
        isin=ARRIVINGFROM.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    durationofstay: Series[pa.INT64] = pa.Field(
        description="Number of days staying in Canada - declared by foreign nationals residing in or outside Canada.",
        ge=0,
        coerce=True,
        nullable=True,
    )
    durofabsn: Series[SafeIntToStringType] = pa.Field(
        description="Number of days absent from Canada - declared by Canadian residents (citizens and foreign nationals)",
        isin=DUROFABSN.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    lname: Series[pa.String] = pa.Field(
        description="Surname of traveller. Note: use not permitted for Frontier Counts.",
        coerce=True,
        nullable=True,
    )
    fname: Series[pa.String] = pa.Field(
        description="First name of traveller. Note: use not permitted for Frontier Counts.",
        coerce=True,
        nullable=True,
    )
    dob: Series[pa.String] = pa.Field(
        description="Date of birth of traveller.",
        # Date should be in the format YYYY-MM-DD
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
    )
    gender: Series[SafeIntToStringType] = pa.Field(
        description="Gender of traveller",
        isin=GENDER.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    travellercitizenship: Series[pa.String] = pa.Field(
        description="Citizenship of traveller",
        isin=TRAVELLERCITIZENSHIP.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    doctype: Series[SafeIntToStringType] = pa.Field(
        description="Type of document that the traveller presents at the kiosk.",
        isin=DOCTYPE.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    resprovstate: Series[pa.String] = pa.Field(
        description="Province or state in which the traveller resides, if applicable (Optional question).",
        isin=RESPROVSTATE.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    rescntry: Series[pa.String] = pa.Field(
        description="Country in which the traveller resides.",
        isin=RESCNTRY.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    crew: Series[pa.String] = pa.Field(
        description="Indicator variable denoting whether the traveller is a crew member or not.",
        isin=CREW.list(),
        coerce=True,
        raise_warning=True,
    )
    flight: Series[pa.String] = pa.Field(
        description="The flight number generated from Advanced Passenger Information (API), provided by airlines.",
        nullable=True,
        coerce=True,
    )
    purpstudy: Series[SafeIntToStringType] = pa.Field(
        description="Indicator variable denoting whether the purpose of travel was study.",
        isin=PURPSTUDY.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    purpvisit: Series[SafeIntToStringType] = pa.Field(
        description="Indicator variable denoting whether the purpose of travel was a visit.",
        isin=PURPVISIT.list(),
        coerce=True,
        raise_warning=True,
    )
    purpwork: Series[SafeIntToStringType] = pa.Field(
        description="Indicator variable denoting whether the purpose of travel was to work.",
        isin=PURPWORK.list(),
        coerce=True,
        raise_warning=True,
    )
    purpimm: Series[SafeIntToStringType] = pa.Field(
        description="Indicator variable denoting whether the purpose of travel was to immigrate.",
        isin=PURPIMM.list(),
        coerce=True,
        raise_warning=True,
    )
    month: Series[SafeIntToStringType] = pa.Field(
        description="Month of arrival. Note: Derived by the PIK splitter program maintained by IT",
        coerce=True,
        nullable=True,
    )
    day: Series[SafeIntToStringType] = pa.Field(
        description="Day of arrival. Note: Derived by the PIK splitter program maintained by IT",
        coerce=True,
        nullable=True,
    )
    doc_country: Series[pa.String] = pa.Field(
        description="Document-issuing country. Note: Derived by the PIK splitter program maintained by IT.",
        isin=DOC_COUNTRY.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    country_of_residence: Optional[Series[pa.String]] = COUNTRY_OF_RESIDENCE_FIELD

    @staticmethod
    def get_keys():
        return [
            RawSchema.kiosk_ssn_id,
            RawSchema.lname,
            RawSchema.fname,
            RawSchema.dob,
            RawSchema.gender,
        ]


class CleanSchema(RawSchema):
    """
    Schema for PIK CLEAN data.
    """

    country_of_residence: Series[pa.String] = COUNTRY_OF_RESIDENCE_FIELD


# List of all raw schema columns as a list. This is used in the pipeline
# to subset columns in certain business rules
RAW_COLUMNS = list(RawSchema.to_schema().columns.keys())
RAW_COLUMNS.remove(RawSchema.country_of_residence)

# List of all clean schema columns as a list. This is used in the pipeline
# to subset variables in certain business rules
CLEAN_COLUMNS = list(CleanSchema.to_schema().columns.keys())


class ValidationSchema(pa.SchemaModel):
    """
    Schema for variables appearing in validation output but not in RAW or CLEAN PIK data.
    All elements are defined as optional because the schema is used across all validations and
    specific columns may appear in certain validations, but not in others.
    """

    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of a PIK dimension variable with unexpected values.",
        coerce=True,
    )
    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value observed in a PIK dimension variable.",
        coerce=True,
        nullable=True,
    )
    location: Optional[Series[pa.String]] = pa.Field(
        description="Geographical location where an unexpected dimension variable occurred.",
        str_matches=r"\d{4}",
        coerce=True,
    )
    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences for a particular validation entry.",
        ge=0,
        coerce=True,
    )
    removal_reason: Optional[Series[pa.String]] = pa.Field(
        description="Reason that a record was removed from the PIK data.",
        isin=[
            "Duplicates",
            "Test Records",
            "Missing KIOSKDTTM",
            "Missing KIOSK_SSN_ID",
            "Missing ARRIVINGFROM",
            "Missing RESCNTRY",
        ],
        coerce=True,
    )
    gap_start: Optional[Series[pa.String]] = pa.Field(
        description="Time that the traffic gap at a major airport began.",
        coerce=True,
    )
    gap_end: Optional[Series[pa.String]] = pa.Field(
        description="Time that the traffic gap at a major airport ended.",
        coerce=True,
    )
    unexpected_flow: Optional[Series[pa.String]] = pa.Field(
        description="Type of unexpected kiosk flow that was observed in the data.",
        coerce=True,
    )
    edit: Optional[Series[pa.String]] = pa.Field(
        description="Type of edit done to respect tourism concepts.",
        coerce=True,
    )
    count_conflicts: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of cases where crew and immigration status are in conflict.",
        ge=0,
        coerce=True,
    )
    count_crew: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of cases crew indicator is flagged.",
        ge=0,
        coerce=True,
    )
    count_imm: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of cases immigration indicator is flagged.",
        ge=0,
        coerce=True,
    )
    country_code_type: Optional[Series[pa.String]] = pa.Field(
        description="Type of country code mismatch that occurred.",
        coerce=True,
    )
    traveller_group: Optional[Series[pa.String]] = pa.Field(
        description="Grouping of travellers based on whether they are Canadian residents or not.",
        isin=["Canadian Residents", "Visitors to Canada"],
        coerce=True,
    )
    imputation_status: Optional[Series[pa.String]] = pa.Field(
        description="Flag indicating whether the duration was imputed or not.",
        isin=["Valid Durations", "Imputed Durations"],
        coerce=True,
    )
    workers: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of travellers declaring purpose of trip as work.",
        ge=0,
        coerce=True,
    )
    residency_group: Optional[Series[pa.String]] = pa.Field(
        description="Grouping of travellers based on country of residence.",
        isin=["Canada", "United States of America", "Overseas"],
        coerce=True,
    )
    travellers: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of all travellers.",
        ge=0,
        coerce=True,
    )
