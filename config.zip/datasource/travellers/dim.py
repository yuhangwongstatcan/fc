"""
    Program: dim.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Create lists of dimension values for the TRAVELLERS table, and enumerable
        classes to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum

# Importing common dims for ease of use
from datasource.common.dim import (
    DAY,
    MODE,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
    PLATE_REGION,
    DATA_SOURCE,
)


class ARRIVING_FROM(AutoEnum):
    us_only = "1"  # Arriving from the United States only
    ovs_direct = "2"  # Arriving from another country direct
    ovs_via_us = "3"  # Arriving from another country via the United States
    not_available = "9"  # Not available


class COUNTRY_OF_RESIDENCE(AutoEnum):
    canada = "11124"
    united_states = "11840"
    overseas = "99998"
    not_applicable = "99999"


class PURPOSE9(AutoEnum):
    personal = "11"
    business = "12"
    study = "13"
    visit = "19"  # Visit, not otherwise specified
    crew = "21"
    work = "31"
    immigration = "41"
    military = "42"
    other_purpose = "43"
    not_available = "99"


class PURPOSE4(AutoEnum):
    visit = "1"
    crew = "2"
    work = "3"
    other_purpose = "4"
    not_available = "9"


class DURATION2(AutoEnum):
    same_day = "1"
    overnight = "2"
    not_available = "9"


class DURATION3(AutoEnum):
    same_day = "11"
    one_night = "21"
    two_or_more_nights = "22"
    not_available = "99"


class DURATION5(AutoEnum):
    same_day = "11"
    one_two_nights = "21"
    three_seven_nights = "22"
    eight_plus_nights = "23"  # 8-364 nights
    over_one_year = "24"  # 365+ nights
    not_available = "99"


class TRAVELLER_TYPE(AutoEnum):
    excursionist = "1"
    tourist = "2"
    other_traveller = "3"
    not_available = "9"
