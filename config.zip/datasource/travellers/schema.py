"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Define schema models using pandera for schema verification of any
        transformed data sources for TRAVELLERS, as well as the aggregated files
        TRAVELLERS, TRAVELLERS_LEADING and TRAVELLERS_MAIN.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.schema import TravellersVehiclesCommonSchema

from datasource.travellers.dim import (
    ARRIVING_FROM,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    DATA_SOURCE,
)


class AggregatedSchema(TravellersVehiclesCommonSchema):
    """
    Schema for TRAVELLERS_MAIN and TRAVELLER_LEADING.
    """

    arriving_from: Series[pa.String] = pa.Field(
        description="Type of arrival, either U.S. only, overseas direct or via U.S.",
        isin=ARRIVING_FROM.list(),
        coerce=True,
        raise_warning=True,
    )
    country_of_residence: Series[pa.String] = pa.Field(
        description="Country of residence of arriving traveller",
        str_matches=r"\d{5}",
        coerce=True,
    )
    purpose9: Series[pa.String] = pa.Field(
        description="Detailed trip purpose",
        isin=PURPOSE9.list(),
        coerce=True,
        raise_warning=True,
    )
    purpose4: Series[pa.String] = pa.Field(
        description="Aggregated trip purpose",
        isin=PURPOSE4.list(),
        coerce=True,
        raise_warning=True,
    )
    duration2: Series[pa.String] = pa.Field(
        description="Duration of trip, divided into two categories",
        isin=DURATION2.list(),
        coerce=True,
        raise_warning=True,
    )
    duration3: Series[pa.String] = pa.Field(
        description="Duration of trip, divided into three categories",
        isin=DURATION3.list(),
        coerce=True,
        raise_warning=True,
    )
    duration5: Series[pa.String] = pa.Field(
        description="Duration of trip, divided into five categories",
        isin=DURATION5.list(),
        coerce=True,
        raise_warning=True,
    )
    traveller_type: Series[pa.String] = pa.Field(
        description="Traveller type, either excursionist, tourist or other traveller",
        isin=TRAVELLER_TYPE.list(),
        coerce=True,
        raise_warning=True,
    )
    count_of_entries: Series[pa.INT64] = pa.Field(
        description="Count of border crossings", coerce=True,
    )

    @staticmethod
    def get_keys():

        return [
            col for col in AggregatedSchema.to_schema().columns.keys()
            if col != AggregatedSchema.count_of_entries
        ]



class TransformedSchema(AggregatedSchema):
    """
    Schema for all transformed TRAVELLERS file and the aggregated TRAVELLERS file.
    """

    work_location: Series[pa.String] = pa.Field(
        description="Canada Border Services Agency work location of border crossing",
        nullable=True,
        coerce=True,
    )
    data_source: Series[pa.String] = pa.Field(
        description="Canada Border Services Agency data source",
        isin=DATA_SOURCE.list(),
        coerce=True,
        raise_warning=True,
    )
    count_of_entries: Series[pa.INT64] = pa.Field(
        description="Count of border crossings", coerce=True,
    )
    @staticmethod
    def get_keys():
        return [
            col for col in TransformedSchema.to_schema().columns.keys()
            if col != TransformedSchema.count_of_entries
        ]


# Define a series of lists that can be used across numerous data sources for
# TRANSFORMED or AGGREGATED data to subset, group by, sort and order columns

# TRANSFORMED columns for subset, reorder or sort
TRANSFORMED_COLUMNS = [
    TransformedSchema.year,
    TransformedSchema.month,
    TransformedSchema.day,
    TransformedSchema.port,
    TransformedSchema.mode,
    TransformedSchema.vehicle_type,
    TransformedSchema.plate_country,
    TransformedSchema.plate_region,
    TransformedSchema.arriving_from,
    TransformedSchema.country_of_residence,
    TransformedSchema.purpose9,
    TransformedSchema.purpose4,
    TransformedSchema.duration2,
    TransformedSchema.duration3,
    TransformedSchema.duration5,
    TransformedSchema.traveller_type,
    TransformedSchema.work_location,
    TransformedSchema.data_source,
    TransformedSchema.count_of_entries,
]

# TRANSFORMED columns for groupby (numeric count of entries excluded)
TRANSFORMED_GROUPBY = TRANSFORMED_COLUMNS.copy()
TRANSFORMED_GROUPBY.remove(TransformedSchema.count_of_entries)

# TRAVELLERS columns for subset, reorder or sort
TRAVELLERS_COLUMNS = TRANSFORMED_COLUMNS.copy()
TRAVELLERS_COLUMNS.remove(TransformedSchema.work_location)
TRAVELLERS_COLUMNS.remove(TransformedSchema.data_source)

# TRAVELLERS columns for groupby (numeric count of entries excluded)
TRAVELLERS_GROUPBY = TRAVELLERS_COLUMNS.copy()
TRAVELLERS_GROUPBY.remove(TransformedSchema.count_of_entries)

