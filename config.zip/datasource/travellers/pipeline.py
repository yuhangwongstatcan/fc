from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput
from modules.utils.uid import PipelineUID

from modules.utils.loaders import Loader

from config.api import DataSource, Stage, S3

from datasource.travellers.schema import TransformedSchema, AggregatedSchema
from datasource.travellers.data_processing import *


class PipelineTransformedAggregated(BasePipeline):
    """
    Runs the TRANSFORMED -> AGGREGATED pipeline for the TRAVELLERS data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Get travellers dataframe
        travellers = Loader.query(
            Stage.TRANSFORMED,
            datasource=self.datasource,
            year=self.year,
            month=self.month,
        )
        # Ensure that the output TRAVELLERS file adheres to the correct schema
        travellers = TransformedSchema(travellers)

        # Create the travellers_main table
        travellers_main = travellers_010(travellers)

        # Create the travellers_leading table (this rule keeps the subset where
        # data source is IPIL_HWY or PIK)
        travellers_leading = travellers_020(travellers)

        # Ensure that the output MAIN and LEADING dataframes adhere to the correct schema
        travellers_main = AggregatedSchema(travellers_main)
        travellers_leading = AggregatedSchema(travellers_leading)

        # Save all of the tables produced to the outputs dictionary
        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.AGGREGATED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.AGGREGATED,
                DataSource.travellers.value,
                self.year,
                self.month,
                self.day,
            ),
        )
        travellers_main_output = PipelineOutput(
            data=travellers_main,
            stage=Stage.AGGREGATED,
            datasource=DataSource.travellers_main,
            basename=S3.get_s3_basename(
                Stage.AGGREGATED,
                DataSource.travellers_main.value,
                self.year,
                self.month,
                self.day,
            ),
        )
        travellers_leading_output = PipelineOutput(
            data=travellers_leading,
            stage=Stage.AGGREGATED,
            datasource=DataSource.travellers_leading,
            basename=S3.get_s3_basename(
                Stage.AGGREGATED,
                DataSource.travellers_leading.value,
                self.year,
                self.month,
                self.day,
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.travellers.value] = travellers_output
        self.outputs[DataSource.travellers_main.value] = travellers_main_output
        self.outputs[DataSource.travellers_leading.value] = travellers_leading_output
