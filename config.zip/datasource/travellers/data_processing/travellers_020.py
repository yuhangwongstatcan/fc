import pandas as pd

from modules.utils.datasource import aggregate_statcan_tables
from modules.utils.datasource import sort_aggregated_tables

from datasource.travellers.schema import (
    TransformedSchema,
    AggregatedSchema,
    TRAVELLERS_COLUMNS,
    TRAVELLERS_GROUPBY,
)

from datasource.common.dim import LEADING_DATASOURCES


def travellers_020(travellers: pd.DataFrame) -> pd.DataFrame:
    """
    Starting from the base travellers table, produces the travellers_leading table.
    Currently, this only includes the ipil_hwy and pik data sources.

    Args:
        travellers:
            The base travellers table.

    Returns:
        travellers_leading:
            The travellers table with analysis variables removed, ports adjusted
            to published port and reaggregated across all remaining variables.
            This table is for the LEADING release and includes only certain data sources.
    """

    # Drop data source column and work location columns and keep only leading datasources
    df = travellers[travellers[TransformedSchema.data_source].isin(LEADING_DATASOURCES)]
    df = df.drop(
        [TransformedSchema.data_source, TransformedSchema.work_location], axis=1
    )

    # Aggregate travellers table
    df = aggregate_statcan_tables(df, AggregatedSchema, TRAVELLERS_GROUPBY)

    # Prepare output
    travellers_leading = sort_aggregated_tables(
        df, AggregatedSchema, TRAVELLERS_COLUMNS
    )

    return travellers_leading
