import pandas as pd

from modules.utils.datasource import aggregate_statcan_tables
from modules.utils.datasource import sort_aggregated_tables

from datasource.travellers.schema import (
    TransformedSchema,
    AggregatedSchema,
    TRAVELLERS_COLUMNS,
    TRAVELLERS_GROUPBY,
)


def travellers_010(travellers: pd.DataFrame) -> pd.DataFrame:
    """
    Starting from the base travellers table, produces the travellers_main table.

    Args:
        travellers:
            The base travellers table.

    Returns:
        travellers_main:
            The travellers table with analysis variables removed, ports adjusted
            to published port and reaggregated across all remaining variables.
            This table is for the MAIN release and includes all data sources.
    """

    # Drop data source column and work location column
    df = travellers.drop(
        [TransformedSchema.data_source, TransformedSchema.work_location], axis=1
    )

    # Aggregate travellers table
    df = aggregate_statcan_tables(df, AggregatedSchema, TRAVELLERS_GROUPBY)

    # Prepare output
    travellers_main = sort_aggregated_tables(df, AggregatedSchema, TRAVELLERS_COLUMNS)

    return travellers_main
