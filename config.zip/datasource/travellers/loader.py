#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""

from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage
from modules.utils.data_manipulation import process_vt_historical_data

from datasource.travellers.schema import TransformedSchema as TravellersSchema


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
  
    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """

    return process_vt_historical_data(
        client, location, stage, DataSource.travellers, TravellersSchema
    )

