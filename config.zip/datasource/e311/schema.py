"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the E311 data source.
"""

import pandera as pa
from typing import Optional
from pandera.typing import Series

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.common.types import (
    SafeIntToStringType,
    Padded1ZeroStringType,
    Padded2ZeroStringType,
    Padded3ZeroStringType,
    Padded4ZeroStringType,
    Padded5ZeroStringType,
)

from datasource.e311.dim import (
    ADDITIONAL_INDICATORS_Q,
    ARRIVING_BY_BOXES,
    ARRIVING_FROM,
    CARGO,
    CREW,
    DID_NOT_FLY,
    IMMIGRATION,
    MILITARY,
    MODE,
    OTHER_NON_VISITORS,
    PRIVATE,
    PURPOSE_OF_TRIP,
    TRAVELLER_FLOW,
    WORKERS,
)

# Define as constants any variables that are in both the RAW and CLEAN schema to avoid duplication
DURATION_OF_ABSENCE_FIELD = pa.Field(
    description="Calculated continuous variable indicating the number of days that a resident was absent from Canada.",
    ge=0,
    coerce=True,
    nullable=True,
)


class RawSchema(FCSchemaModel):
    """
    Schema for E311 RAW data.
    """

    batch_id: Series[Padded5ZeroStringType] = pa.Field(
        description="Identification number for the batch that the card came from.",
        str_matches=r"(\d{5}|\d{6})",
        coerce=True,
    )
    mode: Series[SafeIntToStringType] = pa.Field(
        description="Mode of transportation, extracted from the batch-level information.",
        isin=MODE.list(),
        raise_warning=True,
        coerce=True,
        nullable=True,
    )
    port: Series[Padded2ZeroStringType] = pa.Field(
        description="Port of entry (3 digits) in Canada, extracted from batch.",
        str_matches=r"\d{3}",
        coerce=True,
        nullable=True,
    )
    year: Series[SafeIntToStringType] = pa.Field(
        description="Year of entry in Canada, extracted from batch.",
        str_matches=r"\d{4}",
        coerce=True,
        nullable=True,
    )
    month: Series[Padded1ZeroStringType] = pa.Field(
        description="Month of entry in Canada, extracted from batch.",
        str_matches=r"(\d{1}|\d{2})",
        coerce=True,
        nullable=True,
    )
    doc_num: Series[Padded4ZeroStringType] = pa.Field(
        description="Identification number for the individual document.",
        coerce=True,
        nullable=True,
    )
    traveller_flow: Series[Padded4ZeroStringType] = pa.Field(
        description="Identifier of type of travellers from CBSA office use checkboxes on top of E311 card.",
        isin=TRAVELLER_FLOW.list(),
        raise_warning=True,
        coerce=True,
        nullable=True,
    )
    traveller_count: Series[pa.INT64] = pa.Field(
        description="Count of travellers making their declaration on the same card.",
        ge=0,
        coerce=True,
        nullable=True,
    )
    name1: Series[pa.String] = pa.Field(
        description="Name of the first traveller declaring.",
        coerce=True,
        nullable=True,
    )
    date_of_birth1: Series[SafeIntToStringType] = pa.Field(
        description="Date of birth of the first traveller declaring.",
        coerce=True,
        nullable=True,
    )
    citizenship1: Series[SafeIntToStringType] = pa.Field(
        description="Citizenship of the first traveller declaring.",
        str_matches=r"\d{5}",
        coerce=True,
        nullable=True,
    )
    name2: Series[pa.String] = pa.Field(
        description="Name of the second traveller declaring.",
        coerce=True,
        nullable=True,
    )
    date_of_birth2: Series[SafeIntToStringType] = pa.Field(
        description="Date of birth of the second traveller declaring.",
        coerce=True,
        nullable=True,
    )
    citizenship2: Series[SafeIntToStringType] = pa.Field(
        description="Citizenship of the second traveller declaring.",
        coerce=True,
        nullable=True,
    )
    name3: Series[pa.String] = pa.Field(
        description="Name of the third traveller declaring.",
        coerce=True,
        nullable=True,
    )
    date_of_birth3: Series[SafeIntToStringType] = pa.Field(
        description="Date of birth of the third traveller declaring.",
        coerce=True,
        nullable=True,
    )
    citizenship3: Series[SafeIntToStringType] = pa.Field(
        description="Citizenship of the third traveller declaring.",
        coerce=True,
        nullable=True,
    )
    name4: Series[pa.String] = pa.Field(
        description="Name of the fourth traveller declaring.",
        coerce=True,
        nullable=True,
    )
    date_of_birth4: Series[SafeIntToStringType] = pa.Field(
        description="Date of birth of the fourth traveller declaring.",
        coerce=True,
        nullable=True,
    )
    citizenship4: Series[SafeIntToStringType] = pa.Field(
        description="Citizenship of the fourth traveller declaring.",
        coerce=True,
        nullable=True,
    )
    province_or_state: Series[pa.String] = pa.Field(
        description="Province or state that the traveller(s) reside in.",
        coerce=True,
        nullable=True,
    )
    country_code: Series[SafeIntToStringType] = pa.Field(
        description="Country that the traveller(s) reside in",
        str_matches=r"\d{5}",
        coerce=True,
        nullable=True,
    )
    town_or_city: Series[pa.String] = pa.Field(
        description="City that the traveller(s) reside in.",
        coerce=True,
        nullable=True,
    )
    postal_code: Series[pa.String] = pa.Field(
        description="Postal code that the traveller(s) reside in.",
        coerce=True,
        nullable=True,
    )
    arriving_by_boxes: Series[Padded3ZeroStringType] = pa.Field(
        description="Checkboxes to indicate which mode of transportation was used to enter Canada.",
        isin=ARRIVING_BY_BOXES.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    arriving_by_detail: Series[pa.String] = pa.Field(
        description="Identifier for the transport used to enter Canada, typically flight number, vessel name or train number.",
        coerce=True,
        nullable=True,
    )
    purpose_of_trip: Series[Padded2ZeroStringType] = pa.Field(
        description="Checkboxes to indicate what the main trip purpose was.",
        isin=PURPOSE_OF_TRIP.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    arriving_from: Series[Padded2ZeroStringType] = pa.Field(
        description="Checkboxes to indicate where the traveller(s) are arriving from.",
        isin=ARRIVING_FROM.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    duration_of_stay: Series[pa.INT64] = pa.Field(
        description="Continuous variable indicating the number of days that the visitor will remain in the country.",
        ge=0,
        coerce=True,
        nullable=True,
    )
    depart_date1: Series[SafeIntToStringType] = pa.Field(
        description="Date when the first traveller declaring left Canada.",
        coerce=True,
        nullable=True,
    )
    depart_date2: Series[SafeIntToStringType] = pa.Field(
        description="Date when the second traveller declaring left Canada.",
        coerce=True,
        nullable=True,
    )
    date_of_signature: Series[SafeIntToStringType] = pa.Field(
        description="Date accompanying the signature; used as date of arrival.",
        coerce=True,
        nullable=True,
    )
    agent_stamp: Series[SafeIntToStringType] = pa.Field(
        description="Date on a CBSA agent stamp, if present; used as date of arrival, superseding date of signature.",
        coerce=True,
        nullable=True,
    )
    additional_indicators_q: Series[pa.String] = pa.Field(
        description="Dichtomous variable indicating whether there were relevant notes on the card from a CBSA agent.",
        isin=ADDITIONAL_INDICATORS_Q.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    crew: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten note for crew.",
        isin=CREW.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    immigration: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten note for immigration.",
        isin=IMMIGRATION.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    military: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten note for military.",
        isin=MILITARY.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    other_non_visitors: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten note for another type of non-visitor (e.g. diplomat, refugee)",
        isin=OTHER_NON_VISITORS.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    workers: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten for workers.",
        isin=WORKERS.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    cargo: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten note indicating a cargo movement.",
        isin=CARGO.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    private: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten note indicating a private movement.",
        isin=PRIVATE.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    did_not_fly: Series[SafeIntToStringType] = pa.Field(
        description="Indicator of whether there was a handwritten note indicating the traveller(s) did not actually fly.",
        isin=DID_NOT_FLY.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    reception_datetime: Series[pa.String] = pa.Field(
        description="Date and time at which the Check Inbox pipeline run occurred, moving the record from Inbox to Raw storage.",
        coerce=True,
    )
    duration_of_absence: Optional[Series[pa.INT64]] = DURATION_OF_ABSENCE_FIELD

    @staticmethod
    def get_keys():
        return [
            RawSchema.batch_id,
            RawSchema.year,
            RawSchema.month,
            RawSchema.doc_num,
        ]


class CleanSchema(RawSchema):
    """
    Schema for E311 CLEAN data.
    """

    port: Series[SafeIntToStringType] = pa.Field(
        description="Port of entry (3 digits) in Canada, extracted from batch.",
        str_matches=r"\d{5}",
        coerce=True,
        nullable=True,
    )
    duration_of_absence: Series[pa.INT64] = DURATION_OF_ABSENCE_FIELD


# List of all raw schema columns as a list. This is used in the pipeline
# to subset columns in certain business rules
RAW_COLUMNS = list(RawSchema.to_schema().columns.keys())
RAW_COLUMNS.remove(RawSchema.duration_of_absence)

# List of all clean schema columns as a list. This is used in the pipeline
# to subset variables in certain business rules
CLEAN_COLUMNS = list(CleanSchema.to_schema().columns.keys())


class ValidationSchema(pa.SchemaModel):
    """
    Schema for variables appearing in validation output but not in RAW or CLEAN PIK data.
    All elements are defined as optional because the schema is used across all validations and
    specific columns may appear in certain validations, but not in others.
    """

    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of a E311 dimension variable with unexpected values.",
        coerce=True,
    )
    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value observed in a E311 dimension variable.",
        coerce=True,
        nullable=True,
    )
    location: Optional[Series[pa.String]] = pa.Field(
        description="Geographical location where an unexpected dimension variable occurred.",
        str_matches=r"\d{3}",
        coerce=True,
    )
    date: Optional[Series[pa.String]] = pa.Field(
        description="Date on which an unexpected dimension value occurred.",
        coerce=True,
    )
    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences for a particular validation entry.",
        ge=0,
        coerce=True,
    )
    type: Optional[Series[pa.String]] = pa.Field(
        description="Type of indicator recoding being summarized.",
        coerce=True,
    )
    count_already_coded: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of cards where the indicator variable had already been coded.",
        ge=0,
        coerce=True,
    )
    count_not_coded: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of cards where the indicator variable had not already been coded.",
        ge=0,
        coerce=True,
    )
    removal_reason: Optional[Series[pa.String]] = pa.Field(
        description="Reason for which a record was removed from the E311 raw data.",
        isin=["Missing Critical Information", "Did Not Fly"],
        coerce=True,
    )
    date_of_arrival_correct: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of instances where the date of arrival from the card matched the batch date.",
        ge=0,
        coerce=True,
    )
    date_of_arrival_available: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of instances where any date of arrival was available.",
        ge=0,
        coerce=True,
    )
    edit: Optional[Series[pa.String]] = pa.Field(
        description="Type of edit done to adhere to Frontier Counts or UNWTO conventions.",
        isin=["Remove Duration for Immigrants", "Recode Long-Term Visitors"],
        coerce=True,
    )
