from typing import Dict

import pandas as pd

from datasource.e311.schema import CleanSchema

"""
Author: Souheil

- Souheil Yazji - Souheil.yazji@statcan.gc.ca

Created On: 2021/09/01

Description: 
Impute values in accordance with a set of columns and conditions (specified for each business rule). This is a recursive solution and should end at rec_max.

Args:
    input:
        input: the dataframe with doners and imputable rows
        mask: a condition to select rows requiring imputation. ~mask is all doner rows
        rec_counter: required to track recursion count, should start at 0
        cols: columns dictionary to use for impute logic, should be ordered by priority (highest->lowest)
        impute_target: column to be imputed
        rec_max: length of columns keys -1
Returns:
    a modified dataframe with imputed values
"""


def rec_func(
    input: pd.DataFrame,
    mask: pd.Series,
    rec_counter: int,
    cols: Dict,
    impute_target: str,
    rec_max: int,
):
    if not any(mask):
        return input
    if rec_counter > rec_max:
        input["dist_col"] = range(0, len(input))
        left = input[mask]
        right = input[~mask]
        values_to_update = pd.merge_asof(
            left, right, on="dist_col", direction="nearest"
        )
        input.loc[mask, impute_target] = values_to_update[f"{impute_target}_y"].values
        return input

    input["dist_col"] = range(0, len(input))
    left = input[mask]
    left[CleanSchema.arriving_by_detail] = left[CleanSchema.arriving_by_detail].fillna(
        "0"
    )
    right = input[~mask]

    values_to_update = pd.merge_asof(
        left, right, on="dist_col", direction="nearest", by=cols[rec_counter]
    )
    input.loc[mask, impute_target] = values_to_update[f"{impute_target}_y"].values
    mask = (input[impute_target].isnull()) | (input[impute_target] == "000")

    return rec_func(input, mask, rec_counter + 1, cols, impute_target, rec_max)
