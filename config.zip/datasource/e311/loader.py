#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Aug 26 16:13:20 2021
@authors:  Jinfei Fan
"""
import csv
import itertools
import logging
import os
import re
import tempfile
import shutil
import glob
import warnings
import pandas as pd
import pandera as pa
import numpy as np

from typing import List

from os.path import join
from datetime import datetime
from pandas.core.frame import DataFrame
from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage
from config.api import S3
from config.argo import ArgoStatusCodes
from modules.logger import MinIOLogger

from datasource.e311.schema import RawSchema, RAW_COLUMNS

# List of columns to sort E311 by for raw
E311_SORT_COLUMNS = RawSchema.get_keys()

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

def safe_upload_files(
    client: S3Client,
    files: list,
    stage: Stage,
    datasource: DataSource,
    schema: pa.SchemaModel,
    sort_keys: List,
    fallback_on_conflicts: bool = True,
    fallback_on_historical: bool = False,
):
    """
    The function modules.utils.data_maniputlation.upload_files is shared across
    multiple datasources. The E311 data source contains integers that are padded with
    leading zeros. Unless you explicitly force pandas to treat every column as a
    string, or provide a schema ahead of time, there is no way to stop pandas from
    automatically stripping the leading zeros. The E311 business rules require that
    these leading zeros are preserved.

    This method replaced the upload_files method specifically for E311 and makes a
    "safe" call to pd.read_csv by forcing dtype=str for all columns. Adding this
    logic to the upload_files method would break the existing implementation as
    there is upstream logic that corrects for these mistakes based on the pandas
    parsed type.

    TLDR: this isn't an accidental duplication of existing logic; this is a few
    lines of duplicated code to avoid a regression fault.

    Args:
        client (S3Client): [description]
        files (list): [description]
        stage (Stage): [description]
        datasource (DataSource): [description]
        schema (Schema): [description]
        fallback_on_conflicts (bool, optional): [description]. Defaults to True.
        fallback_on_historical (bool, optional): [description]. Defaults to False.
    """
    # Create the list of true raw variables to be kept by taking out the optional cases
    all_columns = list(schema.to_schema().columns.keys())
    optional_columns = []
    for column in all_columns:
        if schema.to_schema().columns[column].required == False:
            optional_columns.append(column)
    raw_columns = [column for column in all_columns if column not in optional_columns]

    print(f"\tFile Uploaded:")
    for filename in files:
        # Make sure you sort the data and place the headers
        df = pd.read_csv(filename, header=None, dtype=str)
        # Pandas will silently cast the type of any numeric column with a
        # missing value to np.float64. In the context of Frontier Counts,
        # this is **never** the intended behaviour (i.e. we are always
        # counting travellers/vehicles and all of their characteristics are
        # enumerable types or dates).
        df.loc[:, df.dtypes == np.float64] = (
            df.loc[:, df.dtypes == np.float64]
            .astype("Int64")
            .astype("string")
            .astype("object")
        )
        df.columns = raw_columns
        df = df.sort_values(by=sort_keys)
        df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
        df.to_csv(filename, index=False, header=raw_columns, encoding="utf-8")
        # upload to the staging area
        dst = client.upload_file_to_stage(
            filename,
            stage,
            datasource,
            basename=os.path.basename(filename),
            fallback_on_conflicts=fallback_on_conflicts,
            fallback_on_historical=fallback_on_historical,
        )
        print(f"\t\t{dst}")


def read_e311_txt_file(filename: str, reception_datetime) -> dict[DataFrame]:
    """
    Uses a configuration to extract DataFrames from excel sheets.
    """
    lines = []
    rows = []

    # text positions https://gitlab.k8s.cloud.statcan.ca/tourism-tourisme/frontiercounts/frontier-counts/fc-pipeline/-/blob/dev/docs/datasource/e311/overview.md
    # according to the new E311 input fiel convention changes (Dec. 2023)
    # col 12-19 is for day and time, will be skipped
    positions_old = [
        0,
        6,
        7,
        10,
        14,
        16,
        21,
        26,
        27,
        77,
        85,
        90,
        140,
        148,
        153,
        203,
        211,
        216,
        266,
        274,
        279,
        289,
        294,
        344,
        353,
        357,
        407,
        410,
        413,
        416,
        424,
        432,
        440,
        448,
        449,
        450,
        451,
        452,
        453,
        454,
        455,
        456,
        457,
    ]

    positions = [
        0,
        2,
        3,
        6,
        10,
        12,
        20,
        24,
        29,
        30,
        80,
        88,
        93,
        143,
        151,
        156,
        206,
        214,
        219,
        269,
        277,
        282,
        292,
        297,
        347,
        356,
        360,
        410,
        413,
        416,
        419,
        427,
        435,
        443,
        451,
        452,
        453,
        454,
        455,
        456,
        457,
        458,
        459,
        460,
    ]
    # OID occasionally sends files with latin1 encoding, so try to parse UTF-8 (default),
    # then if a UnicodeDecodeError is thrown, try to read the same file with latin-1 encoding.
    is_old = re.search(r"\/\d{6}\.", filename)
    if is_old:
        positions = positions_old

    try:
        with open(filename, "r") as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        logging.warning(f"Error parsing {f}, attempting to read with latin1 encoding.")
        with open(filename, "r", encoding="latin1") as f:
            lines = f.readlines()
    for line in lines:
        row = [
            line[positions[i] : positions[i + 1]] for i in range(0, len(positions) - 1)
        ]

        if not is_old:
            row.pop(5)  # skip day and time (col# 5) under the new convention

        row.append(reception_datetime)
        rows.append(row)

    data = pd.DataFrame(rows, columns=RAW_COLUMNS)
    conditions = [
        data[RawSchema.agent_stamp].str[:6]
        == data[RawSchema.year] + data[RawSchema.month],
        data[RawSchema.date_of_signature].str[:6]
        == data[RawSchema.year] + data[RawSchema.month],
    ]
    outputs = [data[RawSchema.agent_stamp], data[RawSchema.date_of_signature]]
    meta_date = np.select(
        conditions, outputs, data[RawSchema.year] + data[RawSchema.month] + "99"
    )
    data[RawSchema.duration_of_stay] = data[RawSchema.duration_of_stay].str.strip()

    # should leave this commented, as it will prompt clients to re-validate the raw data
    # data["traveller_count"] = data["traveller_count"].str.strip()

    # for col in schema:
    #    data[col] = data[col].str.lstrip('0')
    data["extra_date"] = pd.Series(meta_date, index=data.index)
    # If any invalid date is passed, raise an exception indicating the date is invalid.
    # if (~data["extra_date"].str.match("\d[6]99")).any():
    #    raise ValueError("At least one date is invalid in data.")
    return data


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load pik data from the momentary S3Location.
    This is the loader entry point for the pik datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """
    downloaddir = client.get_dir(location)

    e311_folder = tempfile.mkdtemp()
    reception_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    columns = [col for col in RAW_COLUMNS]  # copy
    columns.append("extra_date")
    data = pd.DataFrame(columns=columns)
    for f in itertools.chain(
        *[glob.glob(join(downloaddir, "*.TXT")), glob.glob(join(downloaddir, "*.txt"))]
    ):
        try:
            tmp = read_e311_txt_file(f, reception_datetime)
            data = pd.concat((data, tmp), axis=0, ignore_index=True)
        except:
            import traceback as tb

            print("Error reading e311 file: ", f)
            fname = f.replace(downloaddir, "")
            fname = fname.replace("/", "")
            dst = S3.get_error_location(DataSource.e311, fname)
            src = S3.obj_to_loc(Stage.INBOX.value.bucket, "inbox/" + fname)
            print("Moving to error location:", dst)
            client.mv_loc(src, dst)
            tb.print_exc()
            print("Exit on error.")
            ArgoStatusCodes.exit_error_location()
            return False

    try:
        gdf = data.groupby("extra_date")
        dfs = {_date: gdf.get_group(_date) for _date in gdf.groups}

        date_pattern = re.compile("(\d{4})(\d{2})(\d{2})")
        localnames = []
        del columns[-2:]
        tracking_volume = pd.DataFrame(
            columns=[RawSchema.port, "size", RawSchema.agent_stamp]
        )

        for _date, _df in dfs.items():
            match = date_pattern.match(_date)
            if match:
                year, month, day = match.groups()
                basename = S3.get_s3_basename(
                    Stage.RAW, DataSource.e311, year, month, day
                )
                s3_filename = S3.get_loc(Stage.RAW, DataSource.e311, basename)
                filename = join(e311_folder, basename)
                print("E311 file: ", filename)
                localnames.append(filename)
                _df.drop("extra_date", axis=1, inplace=True)
                # _df.astype(schema.TYPE.value, copy=False, errors='ignore')
                # _df.convert_dtypes()
                if client.stat_loc(s3_filename):
                    rdata = client.get_CSV(
                        s3_filename,
                        keep_default_na=False,
                        na_values="",
                        dtype=str,
                    )

                    # save to csv and read it - reason to read/write multiple times to disk
                    # is to resolve pandas data type issues, the typing issues are corrected
                    # when pd.read_csv() is called on the file written to disk. These files are
                    # relatively small so the extra disk I/O will not add much time to this loader
                    # script.
                    _df.to_csv(
                        filename, mode="w", index=False, header=None, encoding="utf-8"
                    )
                    xdata = pd.read_csv(filename, header=None, dtype=str)
                    xdata.columns = RAW_COLUMNS
                    xdata = xdata.sort_values(by=E311_SORT_COLUMNS)
                    xdata = xdata.apply(
                        lambda x: x.str.strip() if x.dtype == "object" else x
                    )
                    xdata.to_csv(
                        filename,
                        mode="w",
                        index=False,
                        header=RAW_COLUMNS,
                        quoting=csv.QUOTE_ALL,
                        encoding="utf-8",
                    )
                    xdata = pd.read_csv(
                        filename,
                        keep_default_na=False,
                        na_values="",
                        dtype=str,
                    )

                    rdata = pd.concat((rdata, xdata), axis=0, ignore_index=True)
                    ndata = rdata.drop_duplicates(subset=columns)
                    ndata.to_csv(
                        filename, mode="w", index=False, header=None, encoding="utf-8"
                    )

                    increase_data = pd.concat([xdata, rdata, rdata]).drop_duplicates(
                        keep=False
                    )

                else:
                    _df.to_csv(
                        filename,
                        mode="a",
                        index=False,
                        header=None,
                        quoting=csv.QUOTE_ALL,
                        encoding="utf-8",
                    )
                    increase_data = _df
                groupby_df = (
                    increase_data.groupby(
                        by=[RawSchema.port], dropna=False, as_index=False
                    )
                    .size()
                    .reset_index()
                )
                groupby_df[RawSchema.agent_stamp] = _date
                tracking_volume = pd.concat([tracking_volume, groupby_df])
    except Exception:
        import traceback

        traceback.print_exc()
        return False
    safe_upload_files(
        client,
        localnames,
        Stage.RAW,
        DataSource.e311,
        RawSchema,
        E311_SORT_COLUMNS,
        fallback_on_conflicts=False,
    )
    minio_logger = MinIOLogger()
    minio_logger.log_pandas(
        tracking_volume,
        DataSource.e311,
        validation_name="e311_tracking_volumes",
        date=datetime.today().date(),
    )

    shutil.rmtree(downloaddir)
    shutil.rmtree(e311_folder)
    return True
