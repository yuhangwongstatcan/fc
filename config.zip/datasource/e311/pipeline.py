"""
**Author(s)**

    Jacob Doering (jacob.doering@statcan.gc.ca)

**Created On:** April 2023

**Description:**

The pipeline definitions for the E311 data source. 
Two pipelines are defined in this module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`
"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.pipeline import validation_writer
from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID

from config.api import Stage, DataSource, S3

from datasource.e311.data_processing import *
from datasource.e311.schema import RawSchema, CleanSchema

from datasource.travellers.schema import TransformedSchema as TravellersSchema


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the E311 data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data files created by the loader
        df = Loader.query(
            Stage.RAW, datasource=self.datasource, year=self.year, month=self.month
        )

        # Make sure that the df adheres to the raw schema
        df = RawSchema(df)

        # Do some preprocessing of variables and send to dimension validation
        print("   1.Starting processing e311_000")
        df, auxiliary_df = e311_000(df)
        # VALIDATION: Summary of unexpected values in dimension variables.
        validation_df = e311_v000(df, auxiliary_df)
        validation_writer(validation_df, e311_v000, self.datasource, self.date)
        logging.info("Finished processing e311_000")
        print("   1.Finished processing e311_000")

        # Remove records for cards that were received after the cutoff date
        print("   2.Starting processing e311_003")
        df = e311_003(df)
        logging.info("Finished processing e311_003")
        print("   2.Finished processing e311_003")

        # Ensure that all port values in the dataframe have five digits
        print("   3.Starting processing e311_005")
        df = e311_005(df)
        logging.info("Finished processing e311_005")
        print("   3.Finished processing e311_005")

        # Recode certain indicator variables based on auxiliary information
        print("   4.Starting processing e311_007")
        df, auxiliary_df = e311_007(df)
        # VALIDATION: Summary of recoding based on auxiliary information.
        validation_df = e311_v007(df, auxiliary_df)
        validation_writer(validation_df, e311_v007, self.datasource, self.date)
        logging.info("Finished processing e311_007")
        print("   4.Finished processing e311_007")

        # Remove unused data based on unexpected ports or modes of transportation
        print("   5.Starting processing e311_010")
        df, auxiliary_df = e311_010(df)
        # VALIDTION: Check for new or unexpected data / work locations
        validation_df = e311_v010(df, auxiliary_df)
        validation_writer(validation_df, e311_v010, self.datasource, self.date)
        logging.info("Finished processing e311_010")
        print("   5.Finished processing e311_010")

        # VALIDATION: Daily volume summary of E311 travellers
        print("   6.Starting processing e311_015")
        df, validation_df = e311_v015(df)
        validation_writer(validation_df, e311_v015, self.datasource, self.date)
        logging.info("Finished processing e311_015")
        print("   6.Finished processing e311_015")

        # Update dates on the cards to use the most accurate date
        print("   7.Starting processing e311_020")
        df = e311_020(df)
        logging.info("Finished processing e311_020")
        print("   7.Finished processing e311_020")

        # Remove invalid or out of scope E311 raw records
        print("   8.Starting processing e311_030")
        df, auxiliary_df = e311_030(df)
        # VALIDTION: Summarize removed records
        validation_df = e311_v030(df, auxiliary_df)
        validation_writer(validation_df, e311_v030, self.datasource, self.date)
        logging.info("Finished processing e311_030")
        print("   8.Finished processing e311_030")

        # Update travellers' country of residence using the points system to
        # determine Canadian residents or visitors to Canada
        print("   9.Starting processing e311_040")
        df = e311_040(df)
        logging.info("Finished processing e311_040")
        print("   9.Finished processing e311_040")

        # Update travellers' country of residence based on dates
        print("   10.Starting processing e311_050")
        df = e311_050(df)
        logging.info("Finished processing e311_050")
        print("   10.Finished processing e311_050")

        # Update dates for Canadian resident travellers and calculate duration of absence
        print("   11.Starting processing e311_060")
        df = e311_060(df)
        logging.info("Finished processing e311_060")
        print("   11.Finished processing e311_060")

        # VALIDATION: Summary of cases where the dates reported on the E311 card
        # do not match the dates coming from the batching
        print("   12.Starting processing e311_065")
        df, validation_df = e311_v065(df)
        validation_writer(validation_df, e311_v065, self.datasource, self.date)
        logging.info("Finished processing e311_065")
        print("   12.Finished processing e311_065")

        # Impute arriving from in cases where it was not declared by the traveller(s)
        print("   13.Starting processing e311_070")
        df = e311_070(df)
        logging.info("Finished processing e311_070")
        print("   13.Finished processing e311_070")

        # Impute duration of stay in cases where it was not declared by the traveller(s)
        print("   14.Starting processing e311_080")
        df = e311_080(df)
        logging.info("Finished processing e311_080")
        print("   14.Finished processing e311_080")

        # Impute duration of absence in cases where it was not declared by the traveller(s)
        print("   15.Starting processing e311_090")
        df = e311_090(df)
        logging.info("Finished processing e311_090")
        print("   15.Finished processing e311_090")

        # Perform some edits for Frontier Counts and UNWTO conventions on duration of stay
        # and country of residence
        print("   16.Starting processing e311_100")
        df, auxiliary_df = e311_100(df)
        # VALIDTION: Summarize edits done to adhere to FC and UNWTO conventions
        validation_df = e311_v100(df, auxiliary_df)
        validation_writer(validation_df, e311_v100, self.datasource, self.date)
        logging.info("Finished processing e311_100")
        print("   16.Finished processing e311_100")

        # Make sure the output dataframe adheres to the clean schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        e311_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[self.datasource.value] = e311_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the E311 data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the CLEAN data files
        df = Loader.query(
            Stage.CLEAN, datasource=self.datasource, year=self.year, month=self.month
        )
        #df = df.loc[0:128,]
        # Make sure the input dataframe adheres to the clean schema
        df = CleanSchema(df)

        # Create the E311 contribution to the aggregated travellers table
        print("Starting processing e311_110")
        travellers_df = e311_110(df)
        logging.info("Finished processing e311_110")
        print("Finished processing e311_110")

        # Make sure that the travellers df adheres to the transformed schema
        travellers_df = TravellersSchema(travellers_df)

        # Save travellers outputs to dictionary
        travellers_output = PipelineOutput(
            data=travellers_df,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.travellers.value] = travellers_output
