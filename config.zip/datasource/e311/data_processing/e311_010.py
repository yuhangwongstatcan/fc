import pandas as pd
import datetime

from modules.utils.data_manipulation import work_locations_recode
from modules.utils.loaders import Loader

from config.api import (
    DataSource,
    Stage,
    WorkLocationsAction,
    WorkLocationsTransAction,
    WorkLocationsTransportation,
)

from datasource.e311.schema import RawSchema, RAW_COLUMNS, ValidationSchema

from datasource.work_locations_trans.schema import ReferenceSchema as TransSchema
from datasource.work_locations_action.schema import ReferenceSchema as ActionSchema
from datasource.work_locations_trans_action.schema import (
    ReferenceSchema as TransActionSchema,
)
from datasource.work_locations_trans_action.dim import ACTION


def e311_010(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove E311 records from unexpected ports or with unexpected transportation types

    Args:
        df:
            A pandas dataframe with invalid or blank transportation type or ports.

    Returns:
        df:
            A pandas dataframe with all records containing invalid or blank
            transportation types or ports either removed or recoded.
    """

    wl_trans = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans,
        WorkLocationsTransportation.work_locations_trans__e311,
    )
    wl_trans = TransSchema(wl_trans)

    wl_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_action,
        WorkLocationsAction.work_locations_action__e311,
    )
    wl_action = ActionSchema(wl_action)

    wl_trans_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__e311,
    )
    wl_trans_action = TransActionSchema(wl_trans_action)

    # Add any columns you need to add before calling the helper function
    # non needed

    df, auxiliary_df = work_locations_recode(
        df,
        wl_trans,
        wl_action,
        wl_trans_action,
        RawSchema.port,
        TransSchema,
        ActionSchema,
        TransActionSchema,
        ACTION,
    )

    df = df[RAW_COLUMNS]

    # Ensure that the output dataframe still adheres to the schema
    df = RawSchema(df)

    return df, auxiliary_df


def e311_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Summary of unexpected data (port and/or transportation type) received on E311 cards.

    Args:
        df:
            A pandas dataframe with unacceptable ports or modes of transportation either
            removed or recoded.

        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected ports or modes of transportation.

    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """
    groupby_arr = [
        RawSchema.mode,
        RawSchema.port,
        RawSchema.cargo,
        RawSchema.private,
        RawSchema.military,
        TransActionSchema.action,
    ]
    validation_df = (
        auxiliary_df.groupby(groupby_arr)
        .size()
        .reset_index(name=ValidationSchema.count)
    )

    # Declare "date" based on the input data; but only do this if the validation
    # is non-empty. Otherwise it will erroneously create a row declaring that
    # all fields are missing.
    if not validation_df.empty:
        # Extract date from df
        val_year = int(df[RawSchema.year].mode())
        val_month = int(df[RawSchema.month].mode())

        VAL_DATE = datetime.date(year=val_year, month=val_month, day=1).strftime(
            "%Y-%m-%d"
        )

        # Add validation date to validation df
        validation_df[ValidationSchema.date] = VAL_DATE

        # arrange df per output schema, correct types
        validation_df = validation_df[
            [
                ValidationSchema.date,
                RawSchema.port,
                RawSchema.mode,
                RawSchema.cargo,
                RawSchema.private,
                RawSchema.military,
                TransActionSchema.action,
                ValidationSchema.count,
            ]
        ]
    # validation[val_schema_out.port.name] = pd.to_numeric(validation[val_schema_out.port.name]).astype('Int64')
    else:
        validation_df = pd.DataFrame(
            columns=[
                ValidationSchema.date,
                RawSchema.port,
                RawSchema.mode,
                RawSchema.cargo,
                RawSchema.private,
                RawSchema.military,
                TransActionSchema.action,
                ValidationSchema.count,
            ]
        )

    # Check schema against the validation schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
