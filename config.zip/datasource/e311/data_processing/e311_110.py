import numpy as np
import pandas as pd

from datasource.e311.schema import CleanSchema
from datasource.e311.dim import (
    MODE as E311_MODE,
    COUNTRY_CODE,
    ARRIVING_FROM as E311_AF,
    PURPOSE_OF_TRIP,
    CREW,
    IMMIGRATION,
    MILITARY,
    OTHER_NON_VISITORS,
    WORKERS,
    CARGO,
    PRIVATE,
)

from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    DATA_SOURCE,
)
from datasource.common.dim import MODE, VEHICLE_TYPE, PLATE_COUNTRY, PLATE_REGION


def e311_110(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
    Generate the E311 contribution to the TRAVELLERS table in the correct schema.

    Args:
        df:
            A pandas dataframe that has had all E311 business logic applied up to
            and including the CLEAN data output.

    Returns:
        traveller_df:
            The E311 contribution to the aggregated TRAVELLERS table in the
            common schema.
    """

    # -- Time and Location Variables -- #
    df["batch_date"] = pd.to_datetime(
        df[CleanSchema.date_of_signature], infer_datetime_format=True, errors="coerce",
    )  # used for day
    # year is 1:1, skip
    # extracted month
    df["ext_month"] = pd.to_numeric(df[CleanSchema.month])
    # day
    df[TransformedSchema.day] = df["batch_date"].dt.day.astype("Int64").fillna(99)
    # dt.fn converts column type to float64 (doesn't really make sense because will never have fractional months/years)
    date_cond = (
        df["batch_date"].dt.month == df[CleanSchema.month].astype("float64")
    ) & (df["batch_date"].dt.year == df[CleanSchema.year].astype("float64"))
    df.loc[~date_cond, TransformedSchema.day] = 99
    # port is 1:1

    # -- Itinerary Variables -- #
    # extracted mode
    mode_cond = [
        (
            (df[CleanSchema.mode] == E311_MODE.air.value)
            | (df[CleanSchema.mode] == E311_MODE.military_air.value)
            | (df[CleanSchema.mode] == E311_MODE.private_air.value)
        ),
        df[CleanSchema.mode] == E311_MODE.marine.value,
        (
            (df[CleanSchema.mode] == E311_MODE.bus.value)
            | (df[CleanSchema.mode] == E311_MODE.train.value)
        ),
    ]
    mode_choices = [MODE.air.value, MODE.water.value, MODE.land.value]

    # Cast to bool type so that np.select works
    mode_cond = [item.astype(bool) for item in mode_cond]
    df["ext_mode"] = np.select(mode_cond, mode_choices)

    # vehicle type
    veh_type_cond = [
        (
            (df[CleanSchema.mode] == E311_MODE.air.value)
            & (df[CleanSchema.cargo] == CARGO.cargo.value)
        ),
        (
            (
                (df[CleanSchema.mode] == E311_MODE.air.value)
                & (
                    (df[CleanSchema.military] == MILITARY.military.value)
                    | (df[CleanSchema.private] == PRIVATE.private.value)
                )
            )
            | (df[CleanSchema.mode] == E311_MODE.military_air.value)
            | (df[CleanSchema.mode] == E311_MODE.private_air.value)
        ),
        (df[CleanSchema.mode] == E311_MODE.air.value),
        (
            (df[CleanSchema.mode] == E311_MODE.marine.value)
            & (df[CleanSchema.cargo] == CARGO.cargo.value)
        ),
        (
            (df[CleanSchema.mode] == E311_MODE.marine.value)
            & (
                (df[CleanSchema.military] == MILITARY.military.value)
                | (df[CleanSchema.private] == PRIVATE.private.value)
            )
        ),
        (df[CleanSchema.mode] == E311_MODE.marine.value),
        ((df[CleanSchema.mode] == E311_MODE.train.value)),
        ((df[CleanSchema.mode] == E311_MODE.bus.value)),
    ]
    vt_choices = [
        VEHICLE_TYPE.cargo_aircraft.value,
        VEHICLE_TYPE.private_aircraft.value,
        VEHICLE_TYPE.commercial_aircraft.value,
        VEHICLE_TYPE.cargo_ship.value,
        VEHICLE_TYPE.private_boat.value,
        VEHICLE_TYPE.cruise_ship.value,
        VEHICLE_TYPE.train.value,
        VEHICLE_TYPE.bus.value,
    ]

    # Cast to bool type so that np.select works
    veh_type_cond = [item.astype(bool) for item in veh_type_cond]
    df[TransformedSchema.vehicle_type] = np.select(veh_type_cond, vt_choices)

    # plates
    df[TransformedSchema.plate_country] = PLATE_COUNTRY.not_available.value
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value

    # arriving_from
    arriving_from_first_case = [
        E311_AF.us_only_ovs_direct.value,
        E311_AF.us_only_ovs_via.value,
        E311_AF.ovs_direct_and_via.value,
        E311_AF.all_selected.value,
    ]
    LAND_DIRECT_MASK = ((df[CleanSchema.mode] == E311_MODE.train.value) | (
        df[CleanSchema.mode] == E311_MODE.bus.value
    )) & (df[CleanSchema.arriving_from] == E311_AF.ovs_direct.value)

    LAND_MASK = (df[CleanSchema.mode] == E311_MODE.train.value) | (
        df[CleanSchema.mode] == E311_MODE.bus.value
    )
    OVERSEAS_MASK = ~df[CleanSchema.country_code].isin(
        [COUNTRY_CODE.canada.value, COUNTRY_CODE.united_states.value]
    )
    US_ONLY_MASK = df[CleanSchema.arriving_from] == E311_AF.us_only.value
    pat = "|".join(arriving_from_first_case)
    arr_from_cond = [
        df[CleanSchema.arriving_from].str.contains(pat, case=True, na=False),
        LAND_DIRECT_MASK,
        LAND_MASK & OVERSEAS_MASK & US_ONLY_MASK,
        ((df[CleanSchema.arriving_from] == E311_AF.us_only.value)),
        ((df[CleanSchema.arriving_from] == E311_AF.ovs_direct.value)),
        ((df[CleanSchema.arriving_from] == E311_AF.ovs_via_us.value)),
    ]
    arr_from_choices = [
        ARRIVING_FROM.ovs_via_us.value,
        ARRIVING_FROM.ovs_via_us.value,
        ARRIVING_FROM.ovs_via_us.value,
        ARRIVING_FROM.us_only.value,
        ARRIVING_FROM.ovs_direct.value,
        ARRIVING_FROM.ovs_via_us.value,
    ]

    # Cast to bool type so that np.select works
    arr_from_cond = [item.astype(bool) for item in arr_from_cond]
    df[TransformedSchema.arriving_from] = np.select(arr_from_cond, arr_from_choices)

    # -- Country of Residence -- #
    df[TransformedSchema.country_of_residence] = df[CleanSchema.country_code]

    # -- Trip Purpose Variable -- #
    imm_cond = df[CleanSchema.immigration] == IMMIGRATION.immigration.value
    df.loc[imm_cond, [TransformedSchema.purpose9, TransformedSchema.purpose4]] = [
        PURPOSE9.immigration.value,
        PURPOSE4.other_purpose.value,
    ]

    mili_cond = (df[CleanSchema.military] == MILITARY.military.value) | (
        df[CleanSchema.mode] == E311_MODE.military_air.value
    )
    df.loc[
        ~imm_cond & mili_cond, [TransformedSchema.purpose9, TransformedSchema.purpose4]
    ] = [
        PURPOSE9.military.value,
        PURPOSE4.other_purpose.value,
    ]

    non_tour_cond = (
        df[CleanSchema.other_non_visitors] == OTHER_NON_VISITORS.other.value
    ) | (df.traveller_flow.str.contains("5", case=False, na=False))
    df.loc[
        (~mili_cond & ~imm_cond) & non_tour_cond,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [
        PURPOSE9.other_purpose.value,
        PURPOSE4.other_purpose.value,
    ]

    crew_cond = (df[CleanSchema.crew] == CREW.crew.value) | (
        df.traveller_flow.str.contains("4", case=False, na=False)
    )
    df.loc[
        (~imm_cond & ~mili_cond & ~non_tour_cond) & crew_cond,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [PURPOSE9.crew.value, PURPOSE4.crew.value]

    worker_cond = df[CleanSchema.workers] == WORKERS.workers.value
    df.loc[
        (~imm_cond & ~mili_cond & ~non_tour_cond & ~crew_cond) & worker_cond,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [PURPOSE9.work.value, PURPOSE4.work.value]

    study_cond = df[CleanSchema.purpose_of_trip].str.contains("1", case=False, na=False)
    df.loc[
        (~imm_cond & ~mili_cond & ~non_tour_cond & ~crew_cond & ~worker_cond)
        & study_cond,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [PURPOSE9.study.value, PURPOSE4.visit.value]

    business_cond = df[CleanSchema.purpose_of_trip].str.contains(
        "3", case=False, na=False
    )
    df.loc[
        (
            ~imm_cond
            & ~mili_cond
            & ~non_tour_cond
            & ~crew_cond
            & ~worker_cond
            & ~study_cond
        )
        & business_cond,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [PURPOSE9.business.value, PURPOSE4.visit.value]

    personal_cond = df[CleanSchema.purpose_of_trip] == PURPOSE_OF_TRIP.personal.value
    df.loc[
        (
            ~imm_cond
            & ~mili_cond
            & ~non_tour_cond
            & ~crew_cond
            & ~worker_cond
            & ~study_cond
            & ~business_cond
        )
        & personal_cond,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [PURPOSE9.personal.value, PURPOSE4.visit.value]

    no_indicated_purpose_cond = (
        ~(df.traveller_flow.str.contains("[45]", case=False, na=False))
        & (df[CleanSchema.crew] == CREW.no_crew.value)
        & (df[CleanSchema.immigration] == IMMIGRATION.no_immigration.value)
        & (df[CleanSchema.military] == MILITARY.no_military.value)
        & (df[CleanSchema.other_non_visitors] == OTHER_NON_VISITORS.no_other.value)
        & (df[CleanSchema.workers] == WORKERS.no_workers.value)
        & (df[CleanSchema.purpose_of_trip] == PURPOSE_OF_TRIP.no_selection.value)
    )
    df.loc[
        no_indicated_purpose_cond,
        [TransformedSchema.purpose9, TransformedSchema.purpose4],
    ] = [
        PURPOSE9.visit.value,
        PURPOSE4.visit.value,
    ]

    # -- Trip Duration and Traveller Type Variables -- #
    # Canadian Residents country_code == 11124
    df.loc[
        (df[CleanSchema.country_code] == COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_absence] == 0),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [DURATION2.same_day.value, DURATION3.same_day.value, DURATION5.same_day.value]

    df.loc[
        (df[CleanSchema.country_code] == COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_absence] == 1),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.one_night.value,
        DURATION5.one_two_nights.value,
    ]

    df.loc[
        (df[CleanSchema.country_code] == COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_absence] == 2),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.one_two_nights.value,
    ]

    df.loc[
        (df[CleanSchema.country_code] == COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_absence].between(3, 7, inclusive=True)),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.three_seven_nights.value,
    ]

    df.loc[
        (df[CleanSchema.country_code] == COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_absence].between(7, 364, inclusive=True)),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.eight_plus_nights.value,
    ]

    df.loc[
        (df[CleanSchema.country_code] == COUNTRY_CODE.canada.value)
        & (
            (df[CleanSchema.duration_of_absence] >= 365)
            | (df[CleanSchema.duration_of_stay] >= 365)
        ),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.over_one_year.value,
    ]

    # Foreign Residents country_code != 11124
    df.loc[
        (df[CleanSchema.country_code] != COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_stay] == 0),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [DURATION2.same_day.value, DURATION3.same_day.value, DURATION5.same_day.value]

    df.loc[
        (df[CleanSchema.country_code] != COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_stay] == 1),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.one_night.value,
        DURATION5.one_two_nights.value,
    ]

    df.loc[
        (df[CleanSchema.country_code] != COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_stay] == 2),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.one_two_nights.value,
    ]

    df.loc[
        (df[CleanSchema.country_code] != COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_stay].between(3, 7, inclusive=True)),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.three_seven_nights.value,
    ]

    df.loc[
        (df[CleanSchema.country_code] != COUNTRY_CODE.canada.value)
        & (df[CleanSchema.duration_of_stay] >= 8),
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.overnight.value,
        DURATION3.two_or_more_nights.value,
        DURATION5.eight_plus_nights.value,
    ]

    NO_IMPUTATION_REQUIRED = (
        (
            df[CleanSchema.traveller_flow].str.contains("4")
            | df[CleanSchema.traveller_flow].str.contains("5")
        )
        | (df[CleanSchema.crew] == CREW.crew.value)
        | (df[CleanSchema.immigration] == IMMIGRATION.immigration.value)
        | (df[CleanSchema.military] == MILITARY.military.value)
        | (df[CleanSchema.other_non_visitors] == OTHER_NON_VISITORS.other.value)
        | (df[CleanSchema.workers] == WORKERS.workers.value)
    )

    other_traveller_cond = (
        NO_IMPUTATION_REQUIRED
        & (df[CleanSchema.duration_of_stay].isna())
        & (df[CleanSchema.duration_of_absence].isna())
    )

    df.loc[
        other_traveller_cond,
        [
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
        ],
    ] = [
        DURATION2.not_available.value,
        DURATION3.not_available.value,
        DURATION5.not_available.value,
    ]

    # Traveller_type
    other_traveller_cond = (
        (
            df[TransformedSchema.purpose4].isin(
                [PURPOSE4.work.value, PURPOSE4.other_purpose.value]
            )
        )
        | (
            (df[TransformedSchema.purpose4] == PURPOSE4.crew.value)
            & (
                ~df[TransformedSchema.vehicle_type].isin(
                    [
                        VEHICLE_TYPE.private_aircraft.value,
                        VEHICLE_TYPE.private_boat.value,
                    ]
                )
            )
        )
        | (df[TransformedSchema.duration5] == DURATION5.over_one_year.value)
    )
    df.loc[
        other_traveller_cond, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.other_traveller.value

    excursionist = df[TransformedSchema.duration2] == DURATION2.same_day.value
    df.loc[
        ~other_traveller_cond & excursionist, TransformedSchema.traveller_type
    ] = TRAVELLER_TYPE.excursionist.value

    tourist = df[TransformedSchema.duration2] == DURATION2.overnight.value
    df.loc[
        ~other_traveller_cond & tourist, TransformedSchema.traveller_type,
    ] = TRAVELLER_TYPE.tourist.value

    # -- Analysis Variables -- #
    # work locations
    df[TransformedSchema.work_location] = df[CleanSchema.port]

    # data source
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.E311.value

    df.loc[:, TransformedSchema.count_of_entries] = 1
    travellers_df = df[
        [
            TransformedSchema.year,
            "ext_month",
            TransformedSchema.day,
            TransformedSchema.port,
            "ext_mode",
            TransformedSchema.vehicle_type,
            TransformedSchema.plate_country,
            TransformedSchema.plate_region,
            TransformedSchema.arriving_from,
            TransformedSchema.country_of_residence,
            TransformedSchema.purpose9,
            TransformedSchema.purpose4,
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
            TransformedSchema.traveller_type,
            TransformedSchema.work_location,
            TransformedSchema.data_source,
            TransformedSchema.count_of_entries,
            CleanSchema.traveller_count,
        ]
    ]

    travellers_df[TransformedSchema.month] = travellers_df["ext_month"]
    travellers_df[TransformedSchema.mode] = travellers_df["ext_mode"]

    # This performs a large COUNT(1) GROUP BY all columns operation
    travellers_df = (
        travellers_df.groupby(by=TRANSFORMED_GROUPBY, dropna=False,).sum().reset_index()
    ).fillna(pd.NA)

    travellers_df[TransformedSchema.count_of_entries] = travellers_df[
        CleanSchema.traveller_count
    ]
    travellers_df = travellers_df[TRANSFORMED_COLUMNS]

    return travellers_df
