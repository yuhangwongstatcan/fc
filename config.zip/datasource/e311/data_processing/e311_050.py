import pandas as pd

from datasource.e311.schema import RawSchema, RAW_COLUMNS


def e311_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
        Correction for E311 country of residence based on dates

    Args:
        df:
            A pandas dataframe that has the original countries of residence, not
            updated for dates.

    Returns:
        df:
            A pandas dataframe with countries of residence updated.
    """

    df["depart_date"] = pd.to_datetime(
        df[RawSchema.depart_date1], infer_datetime_format=True, errors="coerce"
    )
    df["year_num"] = pd.to_numeric(df[RawSchema.year])
    df["month_num"] = pd.to_numeric(df[RawSchema.month])

    df.loc[
        (
            (df["depart_date"].dt.year > df["year_num"])  # (depart year > year OR
            | (
                (df["depart_date"].dt.year == df["year_num"])
                & (df["depart_date"].dt.month > df["month_num"])
            )
        )  # depart year == year & depart month > month)
        & (df[RawSchema.country_code] == "11124")
        & (df[RawSchema.citizenship1] != "99999"),
        RawSchema.country_code,
    ] = df[
        RawSchema.citizenship1
    ]  # AND country code == 11124

    df = df[RAW_COLUMNS]

    # Ensure that the dataframe still adheres to the schema after the merges
    df = RawSchema(df)

    return df
