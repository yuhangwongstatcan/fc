import pandas as pd

from config.api import Stage, DataSource

from modules.utils.loaders import Loader

from datasource.e311.schema import RawSchema, RAW_COLUMNS
from datasource.e311_cutoff_dates.schema import ReferenceSchema as CutoffSchema


def e311_003(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

        Jacob Doering (jacob.doering@statcan.gc.ca)

    **Created On: December 29, 2021**

    **Description:**
    Remove any records with reception dates that are after the established cutoff date
    for accepting E311 declaration cards.

    Args:
        df:
            A pandas dataframe having all received cards, before and after the established cutoff date

    Returns:
        df:
            A pandas dataframe with only cards received on or before the established cutoff date
    """
    # Read in the E311 cutoff dates reference file and ensure that it adheres to the schema
    e311_cutoff = Loader.get(Stage.REFERENCE, DataSource.e311_cutoff_dates, None)
    e311_cutoff = CutoffSchema(e311_cutoff)

    e311_cutoff[CutoffSchema.cutoff_date] = pd.to_datetime(
        e311_cutoff[CutoffSchema.cutoff_date]
    )

    # Merge the input e311 data with the reference file of cutoff dates
    df[RawSchema.reception_datetime] = pd.to_datetime(df[RawSchema.reception_datetime])
    add_cutoff_date = pd.merge(
        left=df, right=e311_cutoff, on=[RawSchema.year, RawSchema.month], how="left"
    ).fillna(pd.NA)

    # Pull reception date out of date time for comparison purpose
    add_cutoff_date["reception_date"] = add_cutoff_date[
        RawSchema.reception_datetime
    ].dt.date

    # Create mask to identify accepted cards:
    #   - On or before the cutoff date
    #   - Not present in the e311 cutoff file, so accept by default
    accepted_e311_mask = (
        add_cutoff_date["reception_date"] <= add_cutoff_date[CutoffSchema.cutoff_date]
    ) | (add_cutoff_date[CutoffSchema.cutoff_date].isnull() == True)

    # Add in a "patch" mask to allow very specific delinquent cases to be passed as valid,
    # even if their received date is after cutoff.
    # The case below is to include Vancouver train travellers from October and November 2022
    # which were received in February 2023. These cards were delivered very late to StatCan, but
    # needed to be included in the official statistics afterwards
    tmp_e311_mask = (
        (add_cutoff_date["port"] == "809")
        & (add_cutoff_date["mode"] == "4")
        & (add_cutoff_date["year"] == "2022")
        & ((add_cutoff_date["month"] == "10") | (add_cutoff_date["month"] == "11"))
        & (add_cutoff_date["reception_datetime"].dt.year == 2023)
        & (add_cutoff_date["reception_datetime"].dt.month == 2)
    )

    for_output = add_cutoff_date[accepted_e311_mask | tmp_e311_mask]
    for_output[RawSchema.reception_datetime] = pd.to_datetime(
        for_output[RawSchema.reception_datetime]
    ).dt.strftime("%Y-%m-%d %H:%M:%S")

    # Keep only required columns
    df = for_output[RAW_COLUMNS]

    # Ensure that the dataframe still adheres to the schema
    df = RawSchema(df)

    return df
