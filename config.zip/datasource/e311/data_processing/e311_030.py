import pandas as pd

from datasource.e311.schema import RawSchema, RAW_COLUMNS, ValidationSchema
from datasource.e311.dim import DID_NOT_FLY


def e311_030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
    Remove records from the E311 raw data that are out of scope for the Frontier Counts program or are invalid.

    Args:
        df:
            A pandas dataframe that still potentially contains invalid or out of scope records.

    Returns:
        df:
            A pandas dataframe with the invalid and out of scope records removed.

        auxiliary_df:
            A pandas dataframe of removed records to be passed to the validation.
    """

    # Country_code may contain arbitrary spaces which will not register as pd.NA.
    # As a workaround, we remove spaces and cast any occurances of '' to pd.NA.
    INVALID_MASK = (
        (df[RawSchema.year].isna())
        | (df[RawSchema.month].isna())
        | (df[RawSchema.port].isna())
        | (df[RawSchema.mode].isna())
        | (df[RawSchema.country_code].str.strip().replace("", pd.NA).isna())
        | (df[RawSchema.country_code] == "99999")
        | (df[RawSchema.country_code] == 99999)
        | (df[RawSchema.did_not_fly] == DID_NOT_FLY.did_not_fly.value)
    )

    auxiliary_df = df[INVALID_MASK]
    df = df[~INVALID_MASK]

    df = df[RAW_COLUMNS]

    return df, auxiliary_df


def e311_v030(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Summarize the removed invalid and out of scope records.

    Args:
        df:
            A pandas dataframe with the invalid and out of scope records removed.

        auxiliary_df:
            A pandas dataframe containing the invalid and out of scope records.

    Returns:
        validation_df:
            A summary of records that were removed from the E311 raw data for various reaons.
    """
    # Declare "date"
    auxiliary_df["day"] = "1"
    auxiliary_df[ValidationSchema.date] = pd.to_datetime(
        auxiliary_df[[RawSchema.year, RawSchema.month, "day"]], errors="coerce",
    ).dt.date

    # Critical Data Missing count
    critical_cond = (
        (auxiliary_df[RawSchema.year].isnull())
        | (auxiliary_df[RawSchema.month].isnull())
        | (auxiliary_df[RawSchema.port].isnull())
        | (auxiliary_df[RawSchema.mode].isnull())
        | (auxiliary_df[RawSchema.country_code].isnull())
        | (auxiliary_df[RawSchema.country_code].str.strip() == "")
        | (auxiliary_df[RawSchema.country_code] == "99999")
    )

    groupby_arr = [RawSchema.port, ValidationSchema.date]
    crit_df = auxiliary_df.loc[critical_cond][groupby_arr]
    crit_df = (
        crit_df.groupby(groupby_arr).size().reset_index(name=ValidationSchema.count)
    )
    crit_df[ValidationSchema.removal_reason] = "Missing Critical Information"

    # Did Not Fly count
    did_not_fly_cond = (
        auxiliary_df[RawSchema.did_not_fly] == DID_NOT_FLY.did_not_fly.value
    )
    dnf_df = auxiliary_df.loc[did_not_fly_cond][groupby_arr]
    dnf_df = dnf_df.groupby(groupby_arr).size().reset_index(name=ValidationSchema.count)
    dnf_df[ValidationSchema.removal_reason] = "Did Not Fly"

    # Concat both dataframes, ignore their individual indexes, select column order per output schema, handle some typing
    validation_df = pd.concat([crit_df, dnf_df], ignore_index=True)[
        [
            ValidationSchema.removal_reason,
            ValidationSchema.date,
            RawSchema.port,
            ValidationSchema.count,
        ]
    ]

    # Ensure that the validation output adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return validation_df
