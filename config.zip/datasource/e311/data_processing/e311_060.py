import pandas as pd

from datasource.e311.schema import CleanSchema, CLEAN_COLUMNS


def e311_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
        Correct dates and calculate duration for Canadian resident travellers, and remove unnecessary durations

    Args:
        df:
            A pandas datafrane where the dates and durations for Canadian residents have
            not yet been adjusted.

    Returns:
        df:
            A pandas dataframe with date and durations for Canadian residents modified
            as required.
    """

    df["depart_date"] = pd.to_datetime(
        df.depart_date1, infer_datetime_format=True, errors="coerce"
    )
    df["sig_date"] = pd.to_datetime(
        df.date_of_signature, infer_datetime_format=True, errors="coerce"
    )

    # -- Correct Inversed Dates --#
    cond = (df["depart_date"] > df["sig_date"]) & (
        df[CleanSchema.country_code] == "11124"
    )  # depart date > date_of_signature AND country code == 11124

    df.loc[cond, [CleanSchema.depart_date1, CleanSchema.date_of_signature]] = df.loc[
        cond, [CleanSchema.date_of_signature, CleanSchema.depart_date1]
    ].values

    # -- Calculate Duration of Absence --#
    df[CleanSchema.duration_of_absence] = 0
    df[["depart_date", "sig_date"]] = df[
        [CleanSchema.depart_date1, CleanSchema.date_of_signature]
    ].apply(pd.to_datetime, errors="coerce")
    df[["sig_date", "depart_date"]] = df[["sig_date", "depart_date"]].convert_dtypes()

    if not df.empty:
        df[CleanSchema.duration_of_absence] = (
            df["sig_date"] - df["depart_date"]
        ).dt.days

    # -- Remove unwanted durations --#
    cond2 = [
        (df[CleanSchema.country_code] == "11124")
        & (df[CleanSchema.duration_of_stay].isnull() == False),
        (df[CleanSchema.country_code] != "11124")
        & (df[CleanSchema.duration_of_absence].isnull() == False),
    ]

    df.loc[cond2[0], CleanSchema.duration_of_stay] = pd.NA
    df.loc[cond2[1], CleanSchema.duration_of_absence] = pd.NA

    df = df[CLEAN_COLUMNS]

    # Ensure that the dataframe adheres to the CLEAN schema with
    # the addition of the duration of absence column
    df = CleanSchema(df)

    return df
