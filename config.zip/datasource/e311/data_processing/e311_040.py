import pandas as pd

from datasource.e311.schema import RawSchema, RAW_COLUMNS


def e311_040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author: Souheil

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
        Update travellers' country of residence by using the "points" system of auxiliary
        information from E311 cards to determine resident/visitor status.

    Args:
        df:
            A pandas dataframe with the original, unedited country of residence.

    Returns:
        df:
            A pandas dataframe in which the countries of residence have been updated
            as applicable based on the points system.
    """

    df["points_resident"] = 0
    df["points_visitor"] = 0

    # -- Points System -- #
    # Traveller_flow
    df.loc[
        (df.traveller_flow.str.contains("1", case=False, na=False)), "points_resident",
    ] += 1  # case traveller_flow contains '1'
    df.loc[
        (df.traveller_flow.str.contains("[23]", case=False, na=False)),
        "points_visitor",
    ] += 1  # case traveller_flow contains '2' or contains '3'

    # Home Address
    df.loc[
        df.country_code == "11124", "points_resident"
    ] += 2  # If country_code = 11124
    df.loc[
        df.country_code != "11124", "points_visitor"
    ] += 2  # if country_code != 11124

    # duration of stay
    df.loc[
        df.duration_of_stay.isnull() == True, "points_resident"
    ] += 1  # duration not present
    df.loc[
        df.duration_of_stay.isnull() == False, "points_visitor"
    ] += 1  # duration present

    # departure_date1
    df["depart_date"] = pd.to_datetime(
        df.depart_date1, infer_datetime_format=True, errors="coerce"
    )
    df["year_num"] = pd.to_numeric(df.year)
    df["month_num"] = pd.to_numeric(df.month)

    df.loc[
        (df.depart_date1.isnull() == False)
        & (
            (df["depart_date"].dt.year < df["year_num"])
            | (
                (df["depart_date"].dt.year == df["year_num"])
                & (df["depart_date"].dt.month <= df["month_num"])
            )
        ),
        "points_resident",
    ] += 1  # departure day present and not in future
    # Note that depart_date1 could be a string with many blank spaces, in which case we want to consider it to be null as well.
    df.loc[
        ((df.depart_date1.isnull()) | (df.depart_date1.str.strip() == "")),
        "points_visitor",
    ] += 1  # departure day not present

    # -- Update country of residence -- #
    RESIDENT_MASK = (df["points_resident"] > df["points_visitor"]) | (
        (df["points_resident"] == df["points_visitor"]) & (df.country_code == "11124")
    ) & (df.country_code != "11124")
    VISITOR_MASK = (
        (
            (
                (df["points_resident"] < df["points_visitor"])
                | (df["points_resident"] == df["points_visitor"])
                & (df.country_code != "11124")
                & (df.citizenship1 != "11124")
            )
        )
        & (df.country_code == "11124")
        & (df.citizenship1 != "99999")
    )

    # Update residency to Canada as needed
    df.loc[RESIDENT_MASK, RawSchema.country_code] = "11124"
    # Update residency to foreign as needed
    df.loc[VISITOR_MASK, RawSchema.country_code] = df[RawSchema.citizenship1]

    df = df[RAW_COLUMNS]

    # Ensure that the dataframe still adheres to the schema after the merges
    df = RawSchema(df)

    return df
