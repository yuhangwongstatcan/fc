import pandas as pd

from datasource.e311.schema import CleanSchema, ValidationSchema


def e311_v065(df: pd.DataFrame) -> pd.DataFrame:
    """
    Check for cases where the date from the signature box or the CBSA agent stamp do not match
    with the month and year coming from the batching of the scanned cards.

    Args:
        df:
            A pandas dataframe containing all records processed to this point.

    Returns:
        df:
            A copy of the input dataframe since no processing is done.
            
        validation_df:
            A summary of records where the date from the signature box or agent stamp do not
            match the batch month and year, for use in the validation dashboards.
    """
    mod_df = df.copy()

    # Only produce a validation if the incoming dataframe is not empty
    if not mod_df.empty:
        # Declare "date"
        mod_df["day"] = "1"
        mod_df[ValidationSchema.date] = pd.to_datetime(
            mod_df[[CleanSchema.year, CleanSchema.month, "day"]], errors="coerce",
        ).dt.date

        # error = coerce allows invalid dates to be imputed to NA
        mod_df[["stamp_date", "sig_date"]] = mod_df[
            [CleanSchema.agent_stamp, CleanSchema.date_of_signature]
        ].apply(func=pd.to_datetime, errors="coerce")

        not_null_cond = (mod_df["stamp_date"].isnull() == False) | (
            mod_df["sig_date"].isnull() == False
        )

        # per business rule, only want rows where stamp_date or sig_date columns are not null
        tmp = mod_df.loc[not_null_cond, :]

        correctness_mask = (
            (tmp["stamp_date"].dt.month == tmp[CleanSchema.month].astype("int64"))
            & (tmp["stamp_date"].dt.year == tmp[CleanSchema.year].astype("int64"))
        ) | (
            (tmp["sig_date"].dt.month == tmp[CleanSchema.month].astype("int64"))
            & (tmp["sig_date"].dt.year == tmp[CleanSchema.year].astype("int64"))
        )
        groupby_arr = [CleanSchema.port, ValidationSchema.date]
        # create a df containing rows with "correct" dates
        correct_df = tmp.loc[
            correctness_mask, [ValidationSchema.date, CleanSchema.port]
        ]
        correct_df = (
            correct_df.groupby(groupby_arr)
            .size()
            .reset_index(name=ValidationSchema.date_of_arrival_correct)
        )
        # create a df containing rows with "available" dates, which includes correct dates
        available_df = tmp.loc[:, [ValidationSchema.date, CleanSchema.port]]
        available_df = (
            available_df.groupby(groupby_arr)
            .size()
            .reset_index(name=ValidationSchema.date_of_arrival_available)
        )

        # merge the correct and available dfs, reset indexes, select only output schema columns
        # correct typing to match expected output
        validation_df = pd.merge(
            left=available_df, right=correct_df, on=groupby_arr
        ).reset_index()[
            [
                ValidationSchema.date,
                CleanSchema.port,
                ValidationSchema.date_of_arrival_correct,
                ValidationSchema.date_of_arrival_available,
            ]
        ]
        # validation[val_schema_out.port.name] = pd.to_numeric(validation[val_schema_out.port.name]).astype('Int64')
    else:
        validation_df = pd.DataFrame(
            columns=[
                ValidationSchema.date,
                CleanSchema.port,
                ValidationSchema.date_of_arrival_correct,
                ValidationSchema.date_of_arrival_available,
            ]
        )

    # Ensure that the validation output adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return df, validation_df
