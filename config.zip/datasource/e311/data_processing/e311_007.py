import pandas as pd

from datasource.e311.schema import RawSchema, RAW_COLUMNS, ValidationSchema
from datasource.e311.dim import MODE, CARGO, MILITARY, PRIVATE


def e311_007(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**
    - Souheil Yazji        - Souheil.yazji@canada.ca

    **Created On:** 

    **Description:**
    Recode variables used to determine E311 transportation type based on auxiliary information.

    Args:
        df:
            A pandas dataframe with invalid or blank transportation type.

    Returns:
        df:
            A pandas dataframe with edited transportation type.

        auxiliary_df:
            A pandas dataframe with the edits for use in the validation.
    """
    # Dataframe to be used in the validation
    auxiliary_df = df.copy()

    ## Update Mode ##
    # remove leading zeros then select first digit
    df["arriving_by_mode"] = df[RawSchema.arriving_by_boxes].str.lstrip("0").str[0]

    # Update mode to air if indicated by arriving by boxes and not air already
    AIR_MASK = (
        (df["arriving_by_mode"] == "1")
        & (df[RawSchema.mode] != MODE.air.value)
        & (df[RawSchema.mode] != MODE.military_air.value)
        & (df[RawSchema.mode] != MODE.private_air.value)
    )
    df.loc[AIR_MASK, RawSchema.mode] = MODE.air.value

    # Update mode to train if indicated by arriving by boxes and not train already
    TRAIN_MASK = (df["arriving_by_mode"] == "2") & (
        df[RawSchema.mode] != MODE.train.value
    )
    df.loc[TRAIN_MASK, RawSchema.mode] = MODE.train.value

    # Update mode to marine if indicated by arriving by boxes and not marine already
    MARINE_MASK = (df["arriving_by_mode"] == "3") & (
        df[RawSchema.mode] != MODE.marine.value
    )
    df.loc[MARINE_MASK, RawSchema.mode] = MODE.marine.value

    # Update mode to bus if indicated by arriving by boxes and not bus already
    BUS_MASK = (df["arriving_by_mode"] == "4") & (df[RawSchema.mode] != MODE.bus.value)
    df.loc[BUS_MASK, RawSchema.mode] = MODE.bus.value

    ## Update Cargo ##
    cargo_details = [
        "UPS",
        "5X",
        "CJT",
        "CARGO",
        "W8",
        "ADB",
        "ANTONOV",
        "FDX",
        "FX",
        "FEDEX",
        "LYC",
        "LYNDEN",
        "L2",
        "CVK",
        "CAVOK",
    ]
    pat = "|".join(cargo_details)  # if any "cargo_details" contained
    df.loc[
        df[RawSchema.arriving_by_detail].str.contains(pat, case=False, na=False),
        RawSchema.cargo,
    ] = CARGO.cargo.value

    ## Update Military based on keywords from arriving_by_detail ##
    military_details = ["CF", "FORCE", "HERCULES", "RR", "RAF", "CAF", "GAF"]
    pat = "|".join(military_details)  # if any "military_details" contained
    df.loc[
        df[RawSchema.arriving_by_detail].str.contains(pat, case=False, na=False),
        RawSchema.military,
    ] = MILITARY.military.value

    ## Update Military based on mode = 3 ##
    df.loc[
        df[RawSchema.mode] == MODE.military_air.value, RawSchema.military
    ] = MILITARY.military.value

    ## Update Private based on mode = 6 ##
    df.loc[
        df[RawSchema.mode] == MODE.private_air.value, RawSchema.private
    ] = PRIVATE.private.value

    # retain original schema columns only
    df = df[RAW_COLUMNS]

    return df, auxiliary_df


def e311_v007(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule e311_v007.

    Args:
        auxiliary_df:
            A pandas dataframe containing records that may have been recoded.

    Returns:
        validation_df:
            A summary of E311 cards that were recoded to cargo or military based
            on auxiliary information, but were not already noted as such by the 
            indicator variables.
    """
    # Create Date column since E311 doesn't have one
    auxiliary_df["day"] = "1"
    auxiliary_df[ValidationSchema.date] = pd.to_datetime(
        auxiliary_df[[RawSchema.year, RawSchema.month, "day"]], errors="coerce",
    ).dt.date

    # Conditionals for Cargo
    cargo_details = [
        "UPS",
        "5X",
        "CJT",
        "CARGO",
        "W8",
        "ADB",
        "ANTONOV",
        "FDX",
        "FX",
        "FEDEX",
        "LYC",
        "LYNDEN",
        "L2",
        "CVK",
        "CAVOK",
    ]
    cargo_pat = "|".join(cargo_details)  # if any "cargo_details" contained
    cargo_loc_cond = auxiliary_df[RawSchema.arriving_by_detail].str.contains(
        cargo_pat, case=False, na=False
    )
    groupby_arr_cargo = [
        RawSchema.port,
        ValidationSchema.date,
        RawSchema.cargo,
    ]

    # create df with counts on groupby_arr
    cargo_df = (
        auxiliary_df.loc[cargo_loc_cond]
        .groupby(groupby_arr_cargo, as_index=False)
        .size()
    )

    # create count_already_coded/count_not_coded columns
    cargo_df.loc[
        (cargo_df[RawSchema.cargo]) == CARGO.cargo.value,
        ValidationSchema.count_already_coded,
    ] = cargo_df.loc[(cargo_df[RawSchema.cargo] == CARGO.cargo.value), "size"]
    cargo_df.loc[
        (cargo_df[RawSchema.cargo]) == CARGO.no_cargo.value,
        ValidationSchema.count_not_coded,
    ] = cargo_df.loc[(cargo_df[RawSchema.cargo] == CARGO.no_cargo.value), "size"]

    # remove unneeded columns, prep for concat
    cargo_col_list = list(cargo_df.columns)
    cargo_col_list.remove("size")
    cargo_col_list.remove(RawSchema.cargo)
    cargo_df = cargo_df[cargo_col_list]

    # aggregate on port and date
    cargo_df = cargo_df.groupby(
        by=[RawSchema.port, ValidationSchema.date], as_index=False, dropna=False,
    ).agg(
        {
            ValidationSchema.count_already_coded: "sum",
            ValidationSchema.count_not_coded: "sum",
        }
    )
    cargo_df[ValidationSchema.type] = RawSchema.cargo

    # Conitionals for Military
    mili_details = ["CF", "FORCE", "HERCULES", "RR", "RAF", "CAF", "GAF"]
    mili_pat = "|".join(mili_details)  # if any "mili_details" contained
    mili_loc_cond = auxiliary_df[RawSchema.arriving_by_detail].str.contains(
        mili_pat, case=False, na=False
    )
    groupby_arr_mili = [
        RawSchema.port,
        ValidationSchema.date,
        RawSchema.military,
    ]

    # create df with counts on groupby_arr
    mili_df = (
        auxiliary_df.loc[mili_loc_cond].groupby(groupby_arr_mili, as_index=False).size()
    )

    # create count_already_coded/count_not_coded columns
    mili_df.loc[
        mili_df[RawSchema.military] == MILITARY.military.value,
        ValidationSchema.count_already_coded,
    ] = mili_df.loc[mili_df[RawSchema.military] == MILITARY.military.value, "size"]
    mili_df.loc[
        mili_df[RawSchema.military] == MILITARY.no_military.value,
        ValidationSchema.count_not_coded,
    ] = mili_df.loc[mili_df[RawSchema.military] == MILITARY.no_military.value, "size"]

    # remove unneeded columns, prep for concat
    mili_col_list = list(mili_df.columns)
    mili_col_list.remove("size")
    mili_col_list.remove(RawSchema.military)
    mili_df = mili_df[mili_col_list]

    # aggregate on port and date
    mili_df = mili_df.groupby(
        by=[RawSchema.port, ValidationSchema.date], as_index=False, dropna=False,
    ).agg(
        {
            ValidationSchema.count_already_coded: "sum",
            ValidationSchema.count_not_coded: "sum",
        }
    )
    mili_df[ValidationSchema.type] = RawSchema.military

    # Concat both dataframes, ignore their individual indexes, select column order per output schema, handle some typing
    validation_df = pd.concat([cargo_df, mili_df], ignore_index=True)[
        [
            ValidationSchema.type,
            ValidationSchema.date,
            RawSchema.port,
            ValidationSchema.count_already_coded,
            ValidationSchema.count_not_coded,
        ]
    ]

    # Ensure that the validation output adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return validation_df

