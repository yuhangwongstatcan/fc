import pandas as pd

from datasource.e311.utils import rec_func
from datasource.e311.schema import CleanSchema, CLEAN_COLUMNS
from datasource.e311.dim import ARRIVING_FROM, COUNTRY_CODE


def e311_070(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
    Impute an arriving from value for any E311 cards where it was not declared by the traveller.

    Args:
        df:
            A pandas dataframe which may have missing arriving from values
            that need to be imputed.

    Returns:
        df:
            A pandas dataframe that has any missing arriving from values imputed.
    """
    cols = {
        0: [CleanSchema.arriving_by_detail],
        1: ["residency_group", CleanSchema.port],
        2: [CleanSchema.port],
        3: [CleanSchema.country_code],
    }
    rec_max = len(cols.keys()) - 1
    mask = (df[CleanSchema.arriving_from].isnull() == True) | (
        df[CleanSchema.arriving_from] == ARRIVING_FROM.no_selection.value
    )

    if not df.empty:
        df.loc[~mask, "orig_val"] = 1
        impute_target = CleanSchema.arriving_from

        df.loc[
            df[CleanSchema.country_code] == COUNTRY_CODE.united_states.value,
            "residency_group",
        ] = "United States"
        df.loc[
            df[CleanSchema.country_code].isin(
                [COUNTRY_CODE.canada.value, COUNTRY_CODE.united_states.value]
            )
            == False,
            "residency_group",
        ] = "Overseas"

        df = rec_func(df, mask, 0, cols, impute_target, rec_max)

    df = df[CLEAN_COLUMNS]

    # Ensure that the dataframe still adheres to the schema after the merges
    df = CleanSchema(df)

    return df
