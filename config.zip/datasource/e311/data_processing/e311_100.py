import pandas as pd

from datasource.e311.schema import CleanSchema, CLEAN_COLUMNS, ValidationSchema
from datasource.e311.dim import COUNTRY_CODE, IMMIGRATION


def e311_100(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description: 
    Apply Frontier Counts and UNWTO conventions to the E311 data for duration and country of residence.

    Args:
        df:
            A pandas dataframe that has not yet had the Frontier Counts and UNWTO
            conventions applied for duration and country of residence.
            
    Returns:
        df:
            A pandas dataframe with the Frontier Counts and UNWTO conventions for
            duration and country of residence applied.

        auxiliary_df:
            A pandas dataframe containing information about the conventions applied
            for use in the validation to produce dashboard input files.
    """

    auxiliary_df = df.copy()

    # -- Duration and Country of Residence for Immigrants -- #
    cond = df[CleanSchema.immigration] == IMMIGRATION.immigration.value
    df.loc[
        cond,
        [
            CleanSchema.duration_of_stay,
            CleanSchema.duration_of_absence,
            CleanSchema.country_code,
        ],
    ] = [pd.NA, pd.NA, COUNTRY_CODE.not_applicable.value]

    # -- Long-Duration Travellers -- #
    long_dist_cond = (df[CleanSchema.country_code] != COUNTRY_CODE.canada.value) & (
        df[CleanSchema.duration_of_stay] >= 365
    )
    df.loc[long_dist_cond, CleanSchema.country_code] = COUNTRY_CODE.canada.value

    df = df[CLEAN_COLUMNS]

    # Converting arriving_by_detail to all lowercase
    df[CleanSchema.arriving_by_detail] = df[CleanSchema.arriving_by_detail].str.upper()

    return df, auxiliary_df


def e311_v100(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Summarize the number of edits done to adhere to Frontier Counts and UNWTO conventions
    for duration of stay and country of residence.

    Args:
        auxiliary_df:
            A pandas dataframe containing E311 records that have potentially been edited
            to adhere to the conventions of Frontier Counts and UNWTO.

    Returns:
        validation_df:
            A summary of the edits done to adhere to the conventions for duration of stay
            and country of residence, for use in the validation dashboards.
    """
    # Declare "date"
    auxiliary_df["day"] = "1"
    auxiliary_df[ValidationSchema.date] = pd.to_datetime(
        auxiliary_df[[CleanSchema.year, CleanSchema.month, "day"]], errors="coerce",
    ).dt.date

    groupby_arr = [CleanSchema.port, ValidationSchema.date]

    # Remove Duration for Immigrants
    immi_mask = (
        auxiliary_df[CleanSchema.immigration] == IMMIGRATION.immigration.value
    ) & (
        (auxiliary_df[CleanSchema.duration_of_stay].isnull != True)
        | (auxiliary_df[CleanSchema.duration_of_absence].isnull != True)
    )
    immi_df = auxiliary_df.loc[immi_mask, groupby_arr]
    immi_df = (
        immi_df.groupby(groupby_arr).size().reset_index(name=ValidationSchema.count)
    )
    immi_df[ValidationSchema.edit] = "Remove Duration for Immigrants"

    # Recode Long-Term Visitors
    long_term_mask = (
        ~immi_mask
        & (auxiliary_df[CleanSchema.duration_of_stay] >= 365)
        & (auxiliary_df[CleanSchema.country_code] != COUNTRY_CODE.canada.value)
    )
    long_term_df = auxiliary_df.loc[long_term_mask, groupby_arr]
    long_term_df = (
        long_term_df.groupby(groupby_arr)
        .size()
        .reset_index(name=ValidationSchema.count)
    )
    long_term_df[ValidationSchema.edit] = "Recode Long-Term Visitors"

    # Concat both dataframes, ignore their individual indexes, select column order per output schema, handle some typing
    validation_df = pd.concat([immi_df, long_term_df], ignore_index=True)[
        [
            ValidationSchema.edit,
            ValidationSchema.date,
            CleanSchema.port,
            ValidationSchema.count,
        ]
    ]

    # Ensure that the validation output adheres to the schema definition
    validation_df = ValidationSchema(validation_df)

    return validation_df
