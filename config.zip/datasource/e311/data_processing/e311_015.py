import pandas as pd

from datasource.e311.schema import RawSchema, ValidationSchema


def e311_v015(df: pd.DataFrame) -> pd.DataFrame:
    """
    Daily volume summary of travellers from E311 cards.

    Args:
        df:
            A pandas dataframe containing e311 records after initial processing steps.

    Returns:
        df:
            A copy of the input dataframe because no processing is done.

        validation_df:
            A count of travellers by date from E311 cards to be used in dashboards.
    """
    mod_df = df.copy()

    # Create new 'date' column
    mod_df[ValidationSchema.date] = pd.to_datetime(
        mod_df[RawSchema.date_of_signature], infer_datetime_format=True, errors="coerce"
    )

    # Dating condition
    condition = (
        (mod_df[ValidationSchema.date].isnull() == True)
        | (
            mod_df[ValidationSchema.date].dt.month
            != mod_df[RawSchema.month].astype("int64")
        )
        | (
            mod_df[ValidationSchema.date].dt.year
            != mod_df[RawSchema.year].astype("int64")
        )
    )
    mod_df["day"] = "99"
    # pd.to_datetime infers hhmmss:... if invalid number is inserted, in this case 99 for day, cast to str to avoid
    mod_df[ValidationSchema.date] = mod_df[ValidationSchema.date].astype("str")
    mod_df.loc[condition, ValidationSchema.date] = (
        mod_df[RawSchema.year] + "-" + mod_df[RawSchema.month] + "-" + mod_df["day"]
    )

    # group by criteria
    groupby_arr = [RawSchema.port, ValidationSchema.date, RawSchema.mode]
    validation_df = mod_df.groupby(groupby_arr, as_index=False, dropna=False).agg(
        {RawSchema.traveller_count: "sum"}  # sum traveller counts
    )
    validation_df.rename(
        columns={RawSchema.traveller_count: ValidationSchema.count}, inplace=True
    )  # rename traveller counts to counts per schemas
    # Sort by descending counts
    validation_df = validation_df[
        [ValidationSchema.date, RawSchema.port, RawSchema.mode, ValidationSchema.count]
    ].sort_values(ValidationSchema.count, ascending=False)

    # Ensure that the validation output file adheres to the schema
    validation_df = ValidationSchema(validation_df)

    return df, validation_df

