import pandas as pd
import numpy as np

from datasource.e311.utils import rec_func
from datasource.e311.schema import CleanSchema, CLEAN_COLUMNS
from datasource.e311.dim import (
    MODE,
    COUNTRY_CODE,
    CREW,
    IMMIGRATION,
    MILITARY,
    OTHER_NON_VISITORS,
    WORKERS,
    CARGO,
    PRIVATE,
)

from datasource.common.dim import VEHICLE_TYPE


def e311_080(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
    Impute a duration of stay for any E311 cards where it was not declared by the visitor.

    Args:
        df:
            A pandas dataframe which has potentially missing duration of stay values.

    Returns:
        df:
            A pandas dataframe which has had duration of stay imputed as necessary.
    """

    # vehicle type
    veh_type_cond = [
        (
            (df[CleanSchema.mode] == MODE.air.value)
            & (df[CleanSchema.cargo] == CARGO.cargo.value)
        ).astype(bool),
        (
            (
                (df[CleanSchema.mode] == MODE.air.value)
                & (
                    (df[CleanSchema.military] == MILITARY.military.value)
                    | (df[CleanSchema.private] == PRIVATE.private.value)
                )
            )
            | (df[CleanSchema.mode] == MODE.military_air.value)
            | (df[CleanSchema.mode] == MODE.private_air.value)
        ).astype(bool),
        (df[CleanSchema.mode] == MODE.air.value).astype(bool),
        (
            (df[CleanSchema.mode] == MODE.marine.value)
            & (df[CleanSchema.cargo] == CARGO.cargo.value)
        ).astype(bool),
        (
            (df[CleanSchema.mode] == MODE.marine.value)
            & (
                (df[CleanSchema.military] == MILITARY.military.value)
                | (df[CleanSchema.private] == PRIVATE.private.value)
            )
        ).astype(bool),
        (df[CleanSchema.mode] == MODE.marine.value).astype(bool),
        ((df[CleanSchema.mode] == MODE.train.value)).astype(bool),
        ((df[CleanSchema.mode] == MODE.bus.value)).astype(bool),
    ]
    vt_choices = [
        VEHICLE_TYPE.cargo_aircraft.value,
        VEHICLE_TYPE.private_aircraft.value,
        VEHICLE_TYPE.commercial_aircraft.value,
        VEHICLE_TYPE.cargo_ship.value,
        VEHICLE_TYPE.private_boat.value,
        VEHICLE_TYPE.cruise_ship.value,
        VEHICLE_TYPE.train.value,
        VEHICLE_TYPE.bus.value,
    ]
    df["vehicle_type"] = np.select(veh_type_cond, vt_choices)

    cols = {
        0: [CleanSchema.arriving_by_detail],
        1: ["residency_group", CleanSchema.port],
        2: [CleanSchema.port],
        3: [CleanSchema.country_code],
    }
    rec_max = len(cols.keys()) - 1
    mask = df[CleanSchema.duration_of_stay].isnull() == True

    # acquire subset to apply rec_func to
    universe_mask = (df[CleanSchema.country_code] != COUNTRY_CODE.canada.value) & ~(
        (
            df[CleanSchema.traveller_flow].str.contains("[4]", case=False, na=False)
            & ~df["vehicle_type"].isin(
                [VEHICLE_TYPE.private_aircraft.value, VEHICLE_TYPE.private_boat.value]
            )
        )
        | (df[CleanSchema.traveller_flow].str.contains("[5]", case=False, na=False))
        | (
            (df[CleanSchema.crew] == CREW.crew.value)
            & ~df["vehicle_type"].isin(
                [VEHICLE_TYPE.private_aircraft.value, VEHICLE_TYPE.private_boat.value]
            )
        )
        | (df[CleanSchema.immigration] == IMMIGRATION.immigration.value)
        | (df[CleanSchema.military] == MILITARY.military.value)
        | (df[CleanSchema.other_non_visitors] == OTHER_NON_VISITORS.other.value)
        | (df[CleanSchema.workers] == WORKERS.workers.value)
    )

    imp_df = df.loc[universe_mask]
    impute_target = CleanSchema.duration_of_stay

    # Do not attempt to impute a duration of stay if there are no records in df
    if not imp_df.empty:
        imp_df.loc[
            imp_df[CleanSchema.country_code] == COUNTRY_CODE.united_states.value,
            "residency_group",
        ] = "United States"
        imp_df.loc[
            ~imp_df[CleanSchema.country_code].isin(
                [COUNTRY_CODE.canada.value, COUNTRY_CODE.united_states.value]
            ),
            "residency_group",
        ] = "Overseas"

        imp_df = rec_func(imp_df, mask, 0, cols, impute_target, rec_max=rec_max)

        df.loc[universe_mask, impute_target] = imp_df[impute_target]

    df = df[CLEAN_COLUMNS]

    # Ensure that the dataframe still adheres to the schema after the merges
    df = CleanSchema(df)

    return df
