import pandas as pd

from config.api import DataSource
from modules.utils.data_manipulation import validate_dimensions

from datasource.e311.schema import RawSchema, ValidationSchema


def e311_000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author:

    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
    
        Performs preprocessing on E311 data.

    Args:
        df:
            Input file read from the RAW data.

    Returns:
        df:
            A pandas dataframe containing the preprocessed records.
        
        auxiliary_df:
            A pandas dataframe for use in the validation.
    """

    df[RawSchema.arriving_by_detail] = df[RawSchema.arriving_by_detail].str.upper()
    auxiliary_df = df.copy()

    return df, auxiliary_df


def e311_v000(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation to check unexpected values in dimension variables.

    Args:
        auxiliary_df:
            A pandas dataframe containing records that possibly 
            contain unexpected e311 values.

    Returns:
        validation_df:
            A summary of the unexpected dimension variables values
            for use in the validation dashboards.
    """
    # Declare which column from input are for : "location" and "date"
    auxiliary_df["day"] = "1"
    auxiliary_df[ValidationSchema.date] = pd.to_datetime(
        auxiliary_df[[RawSchema.year, RawSchema.month, "day"]], errors="coerce"
    ).dt.date
    cname_loc = RawSchema.port
    cname_date = ValidationSchema.date

    # Null fields should be replaced with invalid value,, use string 'Null' as place holder
    auxiliary_df.loc[
        auxiliary_df[RawSchema.traveller_flow].isnull(), RawSchema.traveller_flow,
    ] = "Null"

    # call helper function to validate dims
    validation_df = validate_dimensions(
        auxiliary_df,
        RawSchema,
        ValidationSchema,
        cname_loc,
        cname_date,
        DataSource.e311,
    )

    # replace "Null" back with pd.NA
    validation_df.loc[
        validation_df[ValidationSchema.unexpected_value] == "Null",
        ValidationSchema.unexpected_value,
    ] = pd.NA

    validation_df = validation_df[
        [
            ValidationSchema.variable,
            ValidationSchema.unexpected_value,
            ValidationSchema.date,
            ValidationSchema.location,
            ValidationSchema.count,
        ]
    ]

    # Check and coerce the validation schema as required
    validation_df = ValidationSchema(validation_df)

    return validation_df
