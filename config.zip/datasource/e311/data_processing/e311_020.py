import pandas as pd
import numpy as np

from datasource.e311.schema import RawSchema, RAW_COLUMNS


def e311_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Author: 
    - Souheil Yazji - Souheil.yazji@statcan.gc.ca

    Created On: 2021/09/01

    Description:
    Ensure that the most accurate arrival date is used in E311 data.

    Args:
        df:
            A pandas dataframe that may have slightly less accurate dates used.

    Returns:
        df:
            A pandas dataframe with modified date_of_signature column.
    """

    df["stamp_date"] = pd.to_datetime(
        df[RawSchema.agent_stamp], infer_datetime_format=True, errors="coerce"
    )
    df["batch_date"] = pd.to_datetime(
        df[RawSchema.date_of_signature], infer_datetime_format=True, errors="coerce"
    )

    condition = [
        (
            (df["stamp_date"].isnull() == False)
            & (df["stamp_date"].dt.month == df["batch_date"].dt.month)
            & (df["stamp_date"].dt.year == df["batch_date"].dt.year)
        )
    ]

    df[RawSchema.date_of_signature] = np.select(
        condition, [df[RawSchema.agent_stamp]], default=df[RawSchema.date_of_signature]
    )

    df = df[RAW_COLUMNS]

    # Ensure that the dataframe still adheres to the schema after the merges
    df = RawSchema(df)

    return df
