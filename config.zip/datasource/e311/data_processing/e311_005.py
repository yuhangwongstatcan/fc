import pandas as pd

from config.api import Stage, DataSource

from modules.utils.loaders import Loader

from datasource.e311.schema import RawSchema, RAW_COLUMNS
from datasource.ports.schema import ReferenceSchema as PortsSchema


def e311_005(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**
    - Souheil Yazji        - Souheil.yazji@canada.ca

    **Created On:**

    **Description:**
    Ensure that all port codes from the e311 raw data are five digits.

    Args:
        df:
            A pandas dataframe with port codes that are not five digits.

    Returns:
        df:
            A pandas dataframe where all port codes are five digits.
    """
    # Read in the reference file for the ports and ensure it adheres to the schema
    ports = Loader.get(Stage.REFERENCE, DataSource.ports, None)
    ports = PortsSchema(ports)

    # Pad ports with length < 3
    df.loc[df[RawSchema.port].str.len() == 1, RawSchema.port] = (
        "00" + df[df[RawSchema.port].str.len() == 1][RawSchema.port]
    )
    df.loc[df[RawSchema.port].str.len() == 2, RawSchema.port] = (
        "0" + df[df[RawSchema.port].str.len() == 1][RawSchema.port]
    )
    df["is_invalid"] = df[RawSchema.port].str.len() == 3

    # The left dataframe is the table with values that need to be imputed
    left = df[df["is_invalid"]]
    # The right dataframe is the table with candidate donor values
    right = ports
    # the digit portion is everything from the second character position onward (inclusive)
    right["port_sub"] = right["port"].str[2:].copy()
    # Keep only relevant columns for illustration purposes
    left = left[[RawSchema.port]].copy()
    right = right[["port", "port_sub"]].copy()

    # Left join on 3 digit port number of both port reference table and data source ports column, use 5 digit from port reference to update data source
    left.loc[:, "copy_index"] = left.index
    values_to_update = pd.merge(
        left, right, left_on=[RawSchema.port], right_on=["port_sub"], how="left"
    ).set_index("copy_index")

    values_to_update.loc[
        values_to_update["port_y"].isnull(), "port_y"
    ] = values_to_update["port_x"]

    df.loc[df["is_invalid"], [RawSchema.port]] = values_to_update[
        [
            "port_y",
        ]
    ].values

    # select only columns from original schema (removes "is_invalid")
    df = df[RAW_COLUMNS]

    # Ensure that the dataframe still adheres to the schema after the merges
    df = RawSchema(df)

    return df
