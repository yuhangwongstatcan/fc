"""
    Program: dim.py

    Author: Jacob Doering (jacob.doering@statcan.gc.ca)

    Created: April 2023

    Purpose:
        Create enumerable classes of dimension variables and their possible values
        to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class ADDITIONAL_INDICATORS_Q(AutoEnum):
    yes = "Y"  # Indicator that there were relevant handwritten notes on the card
    no = "N"  # Indicator that there were no relevant handwritten notes on the card


class ARRIVING_BY_BOXES(AutoEnum):
    no_selection = "0000"  # No arriving by boxes selected
    hwy_only = "0004"  # Arriving by highway
    marine_only = "0030"  # Arriving by marine
    marine_hwy = "0034"  # Arriving by marine and highway
    rail_only = "0200"  # Arriving by rail
    rail_hwy = "0204"  # Arriving by rail and highway
    rail_marine = "0230"  # Arriving by rail and marine
    all_but_air = "0234"  # Arriving by rail, marine and highway
    air_only = "1000"  # Arriving by air
    air_hwy = "1004"  # Arriving by air and highway
    air_marine = "1030"  # Arriving by air and marine
    all_but_rail = "1034"  # Arriving by air, marine and highway
    air_rail = "1200"  # Arriving by air and rail
    all_but_marine = "1204"  # Arriving by air, rail and highway
    all_but_hwy = "1230"  # Arriving by air, rail and marine
    all_modes_selected = "1234"  # Arriving by air, rail, marine and highway


class ARRIVING_FROM(AutoEnum):
    no_selection = "000"  # No arriving from boxes selected
    ovs_via_us = "003"  # Arriving from Overseas via U.S.
    ovs_direct = "020"  # Arriving from Overseas Direct
    ovs_direct_and_via = "023"  # Arriving from Overseas Direct and Overseas via U.S.
    us_only = "100"  # Arriving from U.S. Only
    us_only_ovs_via = "103"  # Arriving from U.S. Only and Overseas via U.S.
    us_only_ovs_direct = "120"  # Arriving from U.S. Only and Overseas Direct
    all_selected = "123"  # All arriving from checkboxes marked


class CARGO(AutoEnum):
    no_cargo = "0"  # Handwritten note by CBSA officer indicating a cargo movement is not present
    cargo = (
        "6"  # Handwritten note by CBSA officer indicating a cargo movement is present
    )


class COUNTRY_CODE(AutoEnum):
    canada = "11124"
    united_states = "11840"
    not_applicable = "99999"


class CREW(AutoEnum):
    no_crew = "0"  # Handwritten note by CBSA officer indicating crew is not present
    crew = "1"  # Handwritten note by CBSA officer indicating crew is present


class DID_NOT_FLY(AutoEnum):
    no_did_not_fly = (
        "0"  # Handwritten note by CBSA officer indicating did not fly is not present
    )
    did_not_fly = (
        "8"  # Handwritten note by CBSA officer indicating did not fly is present
    )


class IMMIGRATION(AutoEnum):
    no_immigration = (
        "0"  # Handwritten note by CBSA officer indicating immigration is not present
    )
    immigration = (
        "2"  # Handwritten note by CBSA officer indicating immigration is present
    )


class MILITARY(AutoEnum):
    no_military = (
        "0"  # Handwritten note by CBSA officer indicating military is not present
    )
    military = "3"  # Handwritten note by CBSA officer indicating military is present


class MODE(AutoEnum):
    air = "1"
    marine = "2"
    military_air = "3"
    train = "4"
    bus = "5"
    private_air = "6"
    did_not_fly = "8"


class OTHER_NON_VISITORS(AutoEnum):
    no_other = "0"  # Handwritten note by CBSA officer indicating other non-visitors is not present
    other = (
        "4"  # Handwritten note by CBSA officer indicating other non-visitors is present
    )


class PRIVATE(AutoEnum):
    no_private = "0"  # Handwritten note by CBSA officer indicating a private movement is not present
    private = (
        "7"  # Handwritten note by CBSA officer indicating a private movement is present
    )


class PURPOSE_OF_TRIP(AutoEnum):
    no_selection = "000"  # No purpose of trip boxes selected
    business = "003"  # Purpose of trip is business
    personal = "020"  # Purpose of trip is personal
    personal_business = "023"  # Purpose of trip is personal and business
    study = "100"  # Purpose of trip is study
    study_business = "103"  # Purpose of trip is study and business
    study_personal = "120"  # Purpose of trip is study and personal
    all_selected = "123"  # Purpose of trip is study, personal and business


class TRAVELLER_FLOW(AutoEnum):
    no_selection = "00000"  # No traveller flow indicated
    other = "00005"  # Other type of traveller
    crew = "00040"  # Crew member
    crew_other = "00045"  # Crew member and other type of traveller markings
    ovs_resident = "00300"  # Overseas resident
    ovs_other = "00305"  # Overseas resident and other type of traveller markings
    ovs_crew = "00340"  # Overseas resident and crew member markings
    ovs_crew_other = (
        "00345"  # Overseas resident, crew member and other type of traveller markings
    )
    usa_resident = "02000"  # American resident
    usa_other = "02005"  # American resident and other type of traveller markings
    usa_crew = "02040"  # American resident and crew member markings
    usa_crew_other = (
        "02045"  # American resident, crew member and other type of traveller markings"
    )
    usa_ovs = "02300"  # American and Overseas resident markings
    usa_ovs_other = "02305"  # American resident, Overseas resident and other type of traveller markings
    usa_ovs_crew = (
        "02340"  # American resident, Overseas resident and crew member markings
    )
    all_but_can = "02345"  # American resident, Overseas resident, crew member and other type of traveller markings
    can_resident = "10000"  # Canadian resident
    can_other = "10005"  # Canadian resident and other type of traveller markings
    can_crew = "10040"  # Canadian resident and crew member markings
    can_crew_other = (
        "10045"  # Canadian resident, crew member and other type of traveller markings
    )
    can_ovs = "10300"  # Canadian and Overseas resident markings
    can_ovs_other = "10305"  # Canadian resident, Overseas resident and other type of traveller markings
    can_ovs_crew = (
        "10340"  # Canadian resident, Overseas resident and crew member markings
    )
    all_but_usa = "10345"  # Canadian resident, Overseas resident, crew member and other type of traveller markings
    can_usa = "12000"  # Canadian and American resident markings
    can_usa_other = "12005"  # Canadian resident, American resident and other type of traveller markings
    can_usa_crew = (
        "12040"  # Canadian resident, American resident and crew member markings
    )
    all_but_ovs = "12045"  # Canadian resident, American resident, crew member and other type of traveller markings
    can_usa_ovs = "12300"  # Canadian, American and Overseas resident markings
    all_but_crew = "12305"  # Canadian resident, American resident, Overseas resident and other type of traveller markings
    all_but_other = "12340"  # Canadian resident, American resident, Overseas resident and crew member markings
    all_selected = "12345"  # All checkboxes for traveller flow marked


class WORKERS(AutoEnum):
    no_workers = (
        "0"  # Handwritten note by CBSA officer indicating workers is not present
    )
    workers = "5"  # Handwritten note by CBSA officer indicating workers is present

