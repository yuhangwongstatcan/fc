"""
    Program: schema.py

    Author: Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

    Created: Dec 2025

    Purpose:
        Define schema models using pandera for schema verification of the
        nghh_imputation file
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.types import SafeIntToStringType

WLOC_FIELD = pa.Field(
    description="Work location four-digit code",
    str_matches=r"\d{4}",
    nullable=False,
    coerce=True,
)

class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the nghh_imputation reference file.
    """
    wloc: Series[SafeIntToStringType] = WLOC_FIELD

    variable: Series[pa.String] = pa.Field(
        description="A string used to split nghh_imputation records into Stage 1 and Stage 2. Each Stage 1 variable has a corresponding value",
        coerce=True,
    )
    value: Series[SafeIntToStringType] = pa.Field(
        description="A corresponding value to the Stage 1 record's variables",
        coerce=True,
        nullable=True,
    )
    source: Series[pa.String] = pa.Field(
        description="Canada Border Services Agency data source",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [col for col in ReferenceSchema.to_schema().columns.keys()]
