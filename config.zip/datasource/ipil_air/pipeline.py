"""
**Author(s)**

    Fang Wang (fang.wang@statcan.gc.ca)

**Created:** May 2025

**Description:**

The pipeline definitions for the ipil_air data source.
Two pipelines are defined in this module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`
"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID
from modules.pipeline import validation_writer

from config.api import Stage
from config.api import DataSource
from config.api import S3

from datasource.ipil_air.data_processing import *
from datasource.ipil_air.schema import RawSchema, CleanSchema
from datasource.ipil_air.dim import *

from datasource.vehicles.schema import TransformedSchema as VehiclesSchema
from datasource.travellers.schema import TransformedSchema as TravellersSchema


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the IPIL Air data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data file created by the loader
        df = Loader.query(Stage.RAW, self.datasource, year=self.year, month=self.month)

        # Make sure that the df adheres to the raw schema
        df = RawSchema(df)

        # VALIDATION: Check for unexpected values in dimension variables
        print("   1.Starting processing ipil_air_000")
        df, auxiliary_df = ipil_air_000(df)
        validation_df = ipil_air_v000(df, auxiliary_df)
        validation_writer(validation_df, ipil_air_v000, self.datasource, self.date)
        logging.info("Finished processing ipil_air_000")
        print("   1.Finished processing ipil_air_000")

        print("   2.Starting processing ipil_air_005")
        df, auxiliary_df = ipil_air_005(df)
        # VALIDTION: Check the imputed mode
        validation_df = ipil_air_v005(df, auxiliary_df)
        validation_writer(validation_df, ipil_air_v005, self.datasource, self.date)
        logging.info("Finished processing ipil_air_005")
        print("   2.Finished processing ipil_air_005")

        # Remove unused data based on unexpected work locations
        print("   3.Starting processing ipil_air_010")
        df, auxiliary_df = ipil_air_010(df)
        # VALIDTION: Check for new or unexpected data / work locations
        validation_df = ipil_air_v010(df, auxiliary_df)
        validation_writer(validation_df, ipil_air_v010, self.datasource, self.date)
        logging.info("Finished processing ipil_air_010")
        print("   3.Finished processing ipil_air_010")

        df = ipil_air_020(df)

        # Impute country of residence for IPIL Air travellers with unknown citizenship
        print("   4.Starting processing ipil_air_030")
        df, auxiliary_df = ipil_air_030(df)
        # Summary of the imputation for country of residence for use in the validation dashboards
        validation_df = ipil_air_v030(df, auxiliary_df)
        validation_writer(validation_df, ipil_air_v030, self.datasource, self.date)
        logging.info("Finished processing ipil_air_030")
        print("   4.Finished processing ipil_air_030")

        # Impute trip duration, trip purpose and arriving from for IPIL Air travellers
        df = ipil_air_040(df)

        # Make sure the output dataframe adheres to the clean schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        ipil_air_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=DataSource.ipil_air,
            basename=S3.get_s3_basename(
                Stage.CLEAN, DataSource.ipil_air, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.ipil_air.value] = ipil_air_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the IPIL Air data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        df = Loader.query(
            Stage.CLEAN, self.datasource, year=self.year, month=self.month
        )

        # Make sure that the input df adheres to the clean schema
        df = CleanSchema(df)

        # Perform the tranformation to get the vehicles table
        travellers = ipil_air_050(df)

        # Make sure that the travellers df adheres to the transformed schema
        travellers = TravellersSchema(travellers)

        # Save travellers outputs to dictionary
        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, DataSource.ipil_air, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.travellers.value] = travellers_output
