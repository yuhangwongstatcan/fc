"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** May 2025

**Description:**
Implements the ipil_air_010 business rule and validation
"""
import pandas as pd

from config.api import DataSource

from config.api import Stage

from modules.utils.loaders import Loader

from datasource.ipil_air.schema import RawSchema, ValidationSchema, ipil_air_000_COLUMNS, ipil_air_V010_COLUMNS
from datasource.work_locations_action.schema import ReferenceSchema as ActionSchema
from datasource.work_locations_trans.schema import ReferenceSchema as TransSchema
from datasource.work_locations_trans_action.schema import ReferenceSchema as TransActionSchema
from datasource.work_locations_trans_action.dim import ACTION

from config.api import WorkLocationsTransAction
from config.api import WorkLocationsAction
from config.api import WorkLocationsTransportation

from modules.utils.data_manipulation import work_locations_recode


def ipil_air_010(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Use work location to recode vehicle type that are not permitted at certain work locations 
    and remove records with unexpected work location/transportion types.

    Args:
        df:
            A pandas dataframe with non-permitted work locations present
    Returns:
        a pandas dataframe with all records recoded work locations
    """
    # Setup for work locations recode inputs
    wl_trans = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans,
        WorkLocationsTransportation.work_locations_trans__ipil_air,
    )
    # #change the "Mode" to "mode" in the query column to match the df columns
    # wl_trans['query'] = wl_trans['query'].astype(str) 
    # wl_trans['query'] = wl_trans['query'].str.replace(r'^M', 'm', regex=True)

    wl_trans = TransSchema(wl_trans)

    wl_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_action,
        WorkLocationsAction.work_locations_action__ipil_air,
    )
    wl_action = ActionSchema(wl_action)

    wl_trans_action = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__ipil_air,
    )
    wl_trans_action = TransActionSchema(wl_trans_action)
    
    # Copy input so it is not updated in place
    df_copy = df.copy()

    work_location_column = RawSchema.wloc
    
    # Recode the work locations
    df, auxiliary_df = work_locations_recode(
        df_copy,
        wl_trans,
        wl_action,
        wl_trans_action,
        work_location_column,
        TransSchema,
        ActionSchema,
        TransActionSchema,
        ACTION,
    )
    # Resubset df to removing working columns added from work_locations_recode
    df = RawSchema(df[ipil_air_000_COLUMNS])
    return df, auxiliary_df


def ipil_air_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Summary of Unexpected Work Locations or Transportation Types or Rejected Data received on ipil_air_010

    Args:
        df:
            A pandas dataframe with unmatchable or unaccepted work locations removed
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """
    auxiliary_df = auxiliary_df.rename(
            columns={RawSchema.date_of_entry: ValidationSchema.date}
            )

    auxiliary_df = auxiliary_df[~auxiliary_df["action"].str.startswith("R")]

    auxiliary_df[ValidationSchema.work_location_issue_type] = auxiliary_df['work_location'].apply(
        lambda val: 'Unexpected WLOC or Mode' if pd.isna(val) else 'Rejected Data'
        )

    if not auxiliary_df.empty:
        # Group by non-counts columns to get the sum of counts in each invalid record group
        validation_df = auxiliary_df.groupby(
            by=[
                ValidationSchema.date,
                ValidationSchema.wloc,
                ValidationSchema.wloc_name ,
                ValidationSchema.mode,
                ValidationSchema.work_location_issue_type,
            ],
            dropna=False,
            as_index=False,
        )
        validation_df = validation_df[[ValidationSchema.count_of_travellers]].apply(
            lambda x: x.astype("Int64").sum()
        )

        # Subset to expected output columns 
        validation_df = validation_df[ipil_air_V010_COLUMNS]
        validation_df = validation_df.sort_values(
            [ValidationSchema.count_of_travellers,ValidationSchema.work_location_issue_type]
            )
        validation_df = ValidationSchema(validation_df)
    else:
        # If the auxiliary df is empty,
        # return a blank df following the expected output schema
        validationschema_cols = ValidationSchema.to_schema().columns
        validation_df = pd.DataFrame({col: pd.Series(dtype=str(validationschema_cols[col].dtype)) \
                                      for col in ipil_air_V010_COLUMNS})
    return ValidationSchema(validation_df)
