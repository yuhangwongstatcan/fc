"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** May 2025

**Description:**
Implements the ipil_air_040 business rule
"""
import logging
import pandas as pd
import numpy as np
from datetime import datetime

from config.api import DataSource
from config.api import Stage
from config.api import WorkLocationsTransAction
from config.api import S3
from modules.utils.loaders import Loader

from datasource.ipil_air.schema import RawSchema, CleanSchema, ipil_air_040_COLUMNS, ipil_air_040_groupby_COLUMNS
from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema
from datasource.work_locations_trans_action.schema import ReferenceSchema as WorkLocationsTransActionSchema
from datasource.travellers.schema import TransformedSchema

from datasource.ipil_air.dim import (
    MODE,
    VEHICLE_TYPE,
    REGION_OF_RESIDENCE,
    CITIZENSHIP_CODE,
    DURATION2,
    PURPOSE4,
    ARRIVING_FROM,
)


def ipil_air_040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute trip duration, trip purpose and arriving from for IPIL Air travellers

    Args:
        df:
            A pandas dataframe without trip duration, trip purpose and arriving from.

    Returns:
        df:
            A pandas dataframe which has trip duration, trip purpose and arriving from assigned to
            each record.
    """
    # Mapping function to add the region_of_residence column
    def map_country_of_residence_to_region_of_residence(value):
        if value == '11124':
            return REGION_OF_RESIDENCE.canada.value
        elif value == '11840':
            return REGION_OF_RESIDENCE.united_states.value
        elif value not in ['11124', '11840', '99999']:
            return REGION_OF_RESIDENCE.overseas.value

    # Create new column 'region_of_residence'
    df[CleanSchema.region_of_residence] = (
        df[RawSchema.country_of_residence].apply(map_country_of_residence_to_region_of_residence)
    )

    #Load historic data to use as a reference for distributions
    year, month, _ = df[RawSchema.date_of_entry].iloc[0].split("-")
    year = int(year)
    month = int(month) 
    
    basename = S3.get_s3_basename(Stage.AGGREGATED, DataSource.travellers, 2024, month, 1)
    historical_data = Loader.get(Stage.AGGREGATED, DataSource.travellers, basename)
    historical_data = TransformedSchema(historical_data)
    historical_data['region_of_residence'] = (
        historical_data[
            TransformedSchema.country_of_residence
            ].apply(map_country_of_residence_to_region_of_residence)
    )

    # Merge ipil_air input with the work_locations table to get the port
    # corresponding to each work location, and replace the port_of_entry with port
    work_locations = Loader.get(Stage.REFERENCE, DataSource.work_locations, None)
    work_locations = WorkLocationsSchema(work_locations)

    df = pd.merge(
        df,
        work_locations[[WorkLocationsSchema.port, WorkLocationsSchema.work_location]],
        left_on=RawSchema.wloc,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )

    # Re-coerce the schema after the pd.merge
    df = RawSchema(df)

    # Extract the list of PIK ports of entry
    work_locations__pik = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__pik,
    )
    work_locations__pik = WorkLocationsTransActionSchema(work_locations__pik)

    pik_port_of_entry = pd.merge(
        work_locations__pik,
        work_locations[[WorkLocationsSchema.port, WorkLocationsSchema.work_location]],
        left_on=WorkLocationsTransActionSchema.work_location,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )

    pik_port_of_entry = pik_port_of_entry[WorkLocationsSchema.port]

    
    ###########################################
    # Mapping dictionary to add the vehicle_type column
    mapping_mode_to_vehicle_type = {
        MODE.air.value: VEHICLE_TYPE.commercial_aircraft.value,
        MODE.land.value: VEHICLE_TYPE.bus.value,
        MODE.rail.value: VEHICLE_TYPE.train.value,
        MODE.marine.value: VEHICLE_TYPE.ferry.value
    }
    #################################################
    # Create new column 'vehicle_type' 
    df[CleanSchema.vehicle_type] = df[RawSchema.mode].map(mapping_mode_to_vehicle_type)

    #################################################
    # Adjustment for a few points of entry that are special cases for vehicle type
    # 1. Marine data considered as private boats for the ports of Quai Richelieu and Sandpoint Lake instead of ferry.
    df.loc[
        ((df[RawSchema.wloc].isin(['3514', '4115'])) &
        (df[RawSchema.mode] == MODE.marine.value)), CleanSchema.vehicle_type
        ] = VEHICLE_TYPE.private_boats.value
    
    # 2. Land data considered as pedestrians for the Abbotsford-Huntingdon ports (Commercial and Travellers) instead of bus
    df.loc[
        ((df[RawSchema.wloc].isin(['8171', '8173'])) & 
        (df[RawSchema.mode] == MODE.land.value)), CleanSchema.vehicle_type
        ] = VEHICLE_TYPE.pedestrians.value

    # 3. Rainbow Bridge(wloc 4272, mapped port number 35421): use the proportions from the 2024 aggregated `travellers` data
    joint_distribution_hist_vehicle_type = (
        historical_data.loc[
            historical_data[TransformedSchema.vehicle_type].isin(
                [VEHICLE_TYPE.bus.value, VEHICLE_TYPE.pedestrians.value]
                )]
        .groupby([TransformedSchema.vehicle_type, TransformedSchema.port,
        'region_of_residence'], as_index=False)[TransformedSchema.count_of_entries]
        .sum()
    )

    df_POE = df.loc[
        df[CleanSchema.port] == '35421'
        ]

    df_non_POE = df.loc[
        df[CleanSchema.port] != '35421'
        ]

    if not df_POE.empty:
        df_POE = df_POE.drop('vehicle_type', axis=1)
        output_rows = []    
        for group_tuple, group in df_POE.groupby([CleanSchema.port, CleanSchema.region_of_residence]):
            tmp_port, tmp_region_of_residence = group_tuple
            
            # Preserve the original columns for the count adjustment section 
            orig_cols = list(group.columns)

            ref_slice = joint_distribution_hist_vehicle_type[
                (joint_distribution_hist_vehicle_type[TransformedSchema.port] == '35421') & 
                (joint_distribution_hist_vehicle_type['region_of_residence'] == tmp_region_of_residence)
            ]
            
            if ref_slice.empty:
                ref_slice = joint_distribution_hist_vehicle_type[
                (joint_distribution_hist_vehicle_type['region_of_residence'] == tmp_region_of_residence)
            ]

            joint_dist = (
                ref_slice
                .groupby([TransformedSchema.vehicle_type], as_index=False)[
                TransformedSchema.count_of_entries].sum()
            )
            
            joint_dist['proportion'] = joint_dist[TransformedSchema.count_of_entries] / joint_dist[TransformedSchema.count_of_entries].sum()

            # Cross-merge
            group['_tmp_key'] = 1
            joint_dist['_tmp_key'] = 1
            joint_dist.drop(columns=['count_of_entries'], inplace=True)
            group_merged = pd.merge(group, joint_dist, on='_tmp_key').drop(columns='_tmp_key')

            # Apply proportion to split count
            group_merged['count'] = group_merged[CleanSchema.count_of_travellers] * group_merged['proportion']

            # Note that the counts need to be adjusted to respect the original total.
            #This is done by adding the count difference to the last split category.
            group_merged['count'] = np.round(group_merged['count']).astype(int)
            group_merged = group_merged.loc[group_merged['count']!=0]
            #Since all the splited count_of_travellers are the same for a orig_cols group, we pick the first count_of_travellers
            orig_count = group_merged.groupby(orig_cols)[CleanSchema.count_of_travellers].first()
            new_count = group_merged.groupby(orig_cols)['count'].sum()
            adjustment = (orig_count - new_count).astype(int)

            # Find the largest split category in each group
            adjust_rows = (
                group_merged.groupby(orig_cols)['count']
                .idxmax()
            )
            # Apply adjustment
            for key, idx in adjust_rows.items():
                adjustment_value = adjustment.loc[key]
                current_count = group_merged.loc[idx, 'count']

                new_count = current_count + adjustment_value

                group_merged.loc[idx, 'count'] = new_count
            
            if (group_merged['count'] < 0).any():
                logging.info("Although the adjustment is done on the largest count, in rare cases, the count column might still become negative.")
            
            group_merged[CleanSchema.count_of_travellers] = group_merged['count']
            group_merged.drop(columns=['proportion', 'count'], inplace=True)

            output_rows.append(group_merged)

        df_POE = pd.concat(output_rows, ignore_index=True)
        df = pd.concat([df_POE, df_non_POE], ignore_index=True)
    
    #########################################################
    #The stateless and refugee cases
    #  (country_of_residence still = 99999 after ipil_air_030 and
    #  with citizenship_code in ("XA","XXB", "XXC")) can be coded directly as:
    #  duration2 = 9 (Duration not available)
    #  purpose4 = 4 (Other purpose)
    #  arriving_from = 2 (Direct from another country)
    stateless_mask = (df[CleanSchema.citizenship_code].isin(
        [CITIZENSHIP_CODE.XA.value, CITIZENSHIP_CODE.XXB.value, CITIZENSHIP_CODE.XXC.value,])
        ) & (df[CleanSchema.country_of_residence] == '99999')
    stateless_df = df[stateless_mask]
    stateless_df[CleanSchema.duration2] = DURATION2.not_available.value
    stateless_df[CleanSchema.purpose4] = PURPOSE4.other_purpose.value
    stateless_df[CleanSchema.arriving_from] = ARRIVING_FROM.overseas_direct.value
    stateless_df = CleanSchema(stateless_df)

    # Small counts in the ipil_air data uniformly coded directly to the most popular category for the port, mode and 
    # region_of_residence from the travellers file.
    low_count_df = df[(~stateless_mask) & (df[RawSchema.count_of_travellers] <= 5)]
    if low_count_df.empty:
        new_cols = [RawSchema.duration2, RawSchema.purpose4, RawSchema.arriving_from]
        low_count_df[new_cols] = pd.DataFrame([[pd.NA]*len(new_cols)], index=[0]).iloc[0:0]
    if not low_count_df.empty:
        key = [RawSchema.port, RawSchema.vehicle_type, RawSchema.region_of_residence]
        # Count how often each (p,q) occurs within each (x,y,z)
        counts = (
            historical_data
                .groupby(key + [TransformedSchema.duration2, 
                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                    ], dropna=False
                )[TransformedSchema.count_of_entries]
                .sum()
                .reset_index()
        )
        # For each (x,y,z), keep the (p,q) with the largest count
        # Tie-breaker here: highest n, then smallest p, then smallest q (you can change)
        impute_map = (
            counts
                .sort_values(key + [TransformedSchema.count_of_entries, TransformedSchema.duration2, 
                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                    ], ascending=[True, True, True, False, True, True, True])
                .drop_duplicates(subset=key, keep="first")
                .drop(columns=TransformedSchema.count_of_entries)
        )
        low_count_df = low_count_df.merge(impute_map, on=key, how="left")
        temp_low_count_df = low_count_df[~low_count_df[[RawSchema.duration2, 
            RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]
        if low_count_df[[RawSchema.duration2, 
                RawSchema.purpose4, RawSchema.arriving_from]].isna().any().any():
                low_count_df = low_count_df[low_count_df[[RawSchema.duration2, 
                    RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]
                low_count_df = low_count_df.drop(columns=["duration2", "purpose4", "arriving_from"])
                key = [RawSchema.vehicle_type, RawSchema.region_of_residence]
                # Count how often each (vehicle_type,region_of_residence) occurs within each (duration2,purpose4,arriving_from)
                counts = (
                    historical_data
                        .groupby(key + [TransformedSchema.duration2, 
                            TransformedSchema.purpose4, TransformedSchema.arriving_from
                            ], dropna=False
                        )[TransformedSchema.count_of_entries]
                        .sum()
                        .reset_index()
                )
                # For each (duration2,purpose4,arriving_from), keep the (vehicle_type,region_of_residence) with the largest count
                impute_map = (
                    counts
                        .sort_values(key + [TransformedSchema.count_of_entries, TransformedSchema.duration2, 
                            TransformedSchema.purpose4, TransformedSchema.arriving_from
                            ], ascending=[True, True, False, True, True, True])
                        .drop_duplicates(subset=key, keep="first")
                        .drop(columns=TransformedSchema.count_of_entries)
                )
                low_count_df = low_count_df.merge(impute_map, on=key, how="left")
                #tmp_rows_to_imput = pd.concat([tmp_rows_to_imput, rows_to_impute[~rows_to_impute["proportion"].isnull()]], axis=0)
                temp_low_count_df = pd.concat([temp_low_count_df,low_count_df[~low_count_df[[RawSchema.duration2, 
                    RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]])
                if low_count_df[[RawSchema.duration2, 
                    RawSchema.purpose4, RawSchema.arriving_from]].isna().any().any():
                        low_count_df = low_count_df[low_count_df[[RawSchema.duration2, 
                            RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]
                        low_count_df = low_count_df.drop(columns=["duration2", "purpose4", "arriving_from"])
                        key = [RawSchema.vehicle_type]
                        # Count how often each (vehicle_type,region_of_residence) occurs within each (duration2,purpose4,arriving_from)
                        counts = (
                            historical_data
                                .groupby(key + [TransformedSchema.duration2, 
                                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                                    ], dropna=False
                                )[TransformedSchema.count_of_entries]
                                .sum()
                                .reset_index()
                        )
                        # For each (duration2,purpose4,arriving_from), keep the (vehicle_type,region_of_residence) with the largest count
                        impute_map = (
                            counts
                                .sort_values(key + [TransformedSchema.count_of_entries, TransformedSchema.duration2, 
                                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                                    ], ascending=[True, False, True, True, True])
                                .drop_duplicates(subset=key, keep="first")
                                .drop(columns=TransformedSchema.count_of_entries)
                        )
                        low_count_df = low_count_df.merge(impute_map, on=key, how="left")
                        temp_low_count_df = pd.concat([low_count_df, temp_low_count_df], axis=0)
    
        low_count_df = temp_low_count_df
    low_count_df = CleanSchema(low_count_df)
    

    impute_df = df[(df[CleanSchema.count_of_travellers] > 5) & (~stateless_mask)]


    #  ___   _   _____   ___   _ 
    # |   \ | | |  _  | |   \ | |
    # | |\ \| | | |_| | | |\ \| |
    # |_| \___| |_____| |_| \___|
    #  ____ ___ _  __
    # |  _ \_ _| |/ /
    # | |_) | || ' /
    # |  __/| || . \
    # |_|  |___|_|\_\

    mask_pik = impute_df[RawSchema.port].isin(pik_port_of_entry)
    df_non_pik = impute_df[~mask_pik].copy()
    df_pik = impute_df[mask_pik].copy()

    joint_distribution_hist = (
        historical_data
        .groupby([TransformedSchema.duration2, TransformedSchema.purpose4, 
        TransformedSchema.arriving_from ,TransformedSchema.port, TransformedSchema.vehicle_type, 
        'region_of_residence',], as_index=False)[TransformedSchema.count_of_entries]
        .sum()
    )

    if not df_non_pik.empty:
        output_rows = []
        
        for group_tuple, group in df_non_pik.groupby([CleanSchema.port, CleanSchema.vehicle_type, 
            CleanSchema.region_of_residence,]):
            tmp_port, tmp_vehicle_type, tmp_region_of_residence = group_tuple
            
            # Preserve the original columns for the count adjustment section 
            orig_cols = list(group.columns)

            ref_slice = joint_distribution_hist[
                (joint_distribution_hist[TransformedSchema.port] == tmp_port) & 
                (joint_distribution_hist[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                (joint_distribution_hist['region_of_residence'] == tmp_region_of_residence)
            ]
            
            if ref_slice.empty:
                ref_slice = joint_distribution_hist[  
                (joint_distribution_hist[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                (joint_distribution_hist['region_of_residence'] == tmp_region_of_residence)
            ]

            joint_dist = (
                ref_slice
                .groupby([TransformedSchema.duration2, TransformedSchema.purpose4, 
            TransformedSchema.arriving_from], as_index=False)[TransformedSchema.count_of_entries]
                .sum()
            )
            
            joint_dist['proportion'] = joint_dist[TransformedSchema.count_of_entries] / joint_dist[TransformedSchema.count_of_entries].sum()

            # Cross-merge
            group['_tmp_key'] = 1
            joint_dist['_tmp_key'] = 1
            joint_dist.drop(columns=['count_of_entries'], inplace=True)
            group_merged = pd.merge(group, joint_dist, on='_tmp_key').drop(columns='_tmp_key')

            # Apply proportion to split count
            group_merged['count'] = group_merged[CleanSchema.count_of_travellers] * group_merged['proportion']

            # Note that the counts need to be adjusted to respect the original total.
            #This is done by adding the count difference to the last split category.
            group_merged['count'] = np.round(group_merged['count']).astype(int)
            group_merged = group_merged.loc[group_merged['count']!=0]
            #Since all the splited count_of_travellers are the same for a orig_cols group, we pick the first count_of_travellers
            orig_count = group_merged.groupby(orig_cols)[CleanSchema.count_of_travellers].first()
            new_count = group_merged.groupby(orig_cols)['count'].sum()
            adjustment = (orig_count - new_count).astype(int)

            # Find the largest split category in each group
            adjust_rows = (
                group_merged.groupby(orig_cols)['count']
                .idxmax()
            )
            # Apply adjustment
            for key, idx in adjust_rows.items():
                adjustment_value = adjustment.loc[key]
                current_count = group_merged.loc[idx, 'count']

                new_count = current_count + adjustment_value

                group_merged.loc[idx, 'count'] = new_count
            
            if (group_merged['count'] < 0).any():
                logging.info("Although the adjustment is done on the largest count, in rare cases, the count column might still become negative.")
            
            group_merged[CleanSchema.count_of_travellers] = group_merged['count']
            group_merged.drop(columns=['proportion', 'count'], inplace=True)
            group_merged = CleanSchema(group_merged)

            output_rows.append(group_merged)

        df_non_pik = pd.concat(output_rows, ignore_index=True)


    #  ____ ___ _  __
    # |  _ \_ _| |/ /
    # | |_) | || ' /
    # |  __/| || . \
    # |_|  |___|_|\_\


    basename = S3.get_s3_basename(Stage.TRANSFORMED, DataSource.pik, year, month, 1)
    pik_work_location = Loader.get(Stage.TRANSFORMED, DataSource.travellers, basename)

    # Check that imported PIK TRANSFORMED file adheres to schema and coerce if not
    pik_work_location = TransformedSchema(pik_work_location)

    # Add region_of_residence to the auxiliary data
    pik_work_location['region_of_residence'] = (
        pik_work_location[RawSchema.country_of_residence].apply(map_country_of_residence_to_region_of_residence)
    )
    
    joint_distribution_pik = (
        pik_work_location
        .groupby([TransformedSchema.duration2, TransformedSchema.purpose4, 
        TransformedSchema.arriving_from, TransformedSchema.port, TransformedSchema.vehicle_type, 
        'region_of_residence',], as_index=False)[TransformedSchema.count_of_entries]
        .sum()
    )

    today = datetime.today()
    cutoff_date = datetime(2028, 1, 1)

    if not df_pik.empty:
        if today < cutoff_date:
            # 50-50 contribution of the proportions from PIK and from the historical data
            output_rows = []
            for group_tuple, group in df_pik.groupby([CleanSchema.port, CleanSchema.vehicle_type, 
                CleanSchema.region_of_residence,]):
                tmp_port, tmp_vehicle_type, tmp_region_of_residence = group_tuple
                
                orig_cols = list(group.columns)

                #Calculate historical proportions
                ref_slice_hist = joint_distribution_hist[
                    (joint_distribution_hist[TransformedSchema.port] == tmp_port) & 
                    (joint_distribution_hist[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                    (joint_distribution_hist['region_of_residence'] == tmp_region_of_residence)
                ]
                
                if ref_slice_hist.empty:
                    ref_slice_hist = joint_distribution_hist[  
                    (joint_distribution_hist[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                    (joint_distribution_hist['region_of_residence'] == tmp_region_of_residence)
                ]

                joint_dist_hist = (
                    ref_slice_hist
                    .groupby([TransformedSchema.duration2, TransformedSchema.purpose4, 
                TransformedSchema.arriving_from], as_index=False)[TransformedSchema.count_of_entries]
                    .sum()
                )
                
                joint_dist_hist['proportion_hist'] = joint_dist_hist[TransformedSchema.count_of_entries] / joint_dist_hist[TransformedSchema.count_of_entries].sum()
                joint_dist_hist.drop(columns=['count_of_entries'], inplace=True)

                #Calculate pik proportions
                ref_slice_pik = joint_distribution_pik[
                    (joint_distribution_pik[TransformedSchema.port] == tmp_port) & 
                    (joint_distribution_pik[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                    (joint_distribution_pik['region_of_residence'] == tmp_region_of_residence)
                ]
                
                if ref_slice_pik.empty:
                    ref_slice_pik = joint_distribution_pik[  
                    (joint_distribution_pik[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                    (joint_distribution_pik['region_of_residence'] == tmp_region_of_residence)
                ]

                joint_dist_pik = (
                    ref_slice_pik
                    .groupby([TransformedSchema.duration2, TransformedSchema.purpose4, 
                TransformedSchema.arriving_from], as_index=False)[TransformedSchema.count_of_entries]
                    .sum()
                )
                
                joint_dist_pik['proportion_pik'] = joint_dist_pik[TransformedSchema.count_of_entries] / joint_dist_pik[TransformedSchema.count_of_entries].sum()
                joint_dist_pik.drop(columns=['count_of_entries'], inplace=True)

                joint_dist = pd.merge(joint_dist_pik, joint_dist_hist, on=[TransformedSchema.duration2, 
                TransformedSchema.purpose4, TransformedSchema.arriving_from], how='outer')
                joint_dist = joint_dist.fillna(0)
                
                # Average proportions from PIK and from the historical data (50-50 contribution)
                joint_dist['proportion'] = (joint_dist['proportion_pik'] + joint_dist['proportion_hist'])/2

                group['_tmp_key'] = 1
                joint_dist['_tmp_key'] = 1
                group_merged = pd.merge(group, joint_dist, on='_tmp_key').drop(columns='_tmp_key')

                group_merged['count'] = group_merged[CleanSchema.count_of_travellers] * group_merged['proportion']

                group_merged['count'] = np.round(group_merged['count']).astype(int)
                group_merged = group_merged.loc[group_merged['count']!=0]
                orig_count = group_merged.groupby(orig_cols)['count_of_travellers'].first()
                new_count = group_merged.groupby(orig_cols)['count'].sum()
                adjustment = (orig_count - new_count).astype(int)
                
                
                # Find the largest split category in each group
                adjust_rows = (
                    group_merged.groupby(orig_cols)['count']
                    .idxmax()
                )
                # Apply adjustment
                for key, idx in adjust_rows.items():
                    adjustment_value = adjustment.loc[key]
                    current_count = group_merged.loc[idx, 'count']

                    new_count = current_count + adjustment_value

                    group_merged.loc[idx, 'count'] = new_count
                    
                if (group_merged['count'] < 0).any():
                    logging.info("Although the adjustment is done on the largest count, in rare cases, the count column might still become negative.")

                group_merged[CleanSchema.count_of_travellers] = group_merged['count']
                group_merged.drop(columns=['proportion', 'count', 'proportion_pik', 'proportion_hist'], inplace=True)
                group_merged = CleanSchema(group_merged)

                output_rows.append(group_merged)

            df_pik = pd.concat(output_rows, ignore_index=True)

        else:
            # The proportions are only resulted from PIK reference data

            output_rows = []
            for group_tuple, group in df_pik.groupby([CleanSchema.port, CleanSchema.vehicle_type, 
                CleanSchema.region_of_residence,]):
                tmp_port, tmp_vehicle_type, tmp_region_of_residence = group_tuple
                
                orig_cols = list(group.columns)

                ref_slice = joint_distribution_pik[
                    (joint_distribution_pik[TransformedSchema.port] == tmp_port) & 
                    (joint_distribution_pik[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                    (joint_distribution_pik['region_of_residence'] == tmp_region_of_residence)
                ]
                
                if ref_slice.empty:
                    ref_slice = joint_distribution_pik[  
                    (joint_distribution_pik[TransformedSchema.vehicle_type] == tmp_vehicle_type) & 
                    (joint_distribution_pik['region_of_residence'] == tmp_region_of_residence)
                ]

                joint_dist = (
                    ref_slice
                    .groupby([TransformedSchema.duration2, TransformedSchema.purpose4, 
                TransformedSchema.arriving_from], as_index=False)[TransformedSchema.count_of_entries]
                    .sum()
                )
                
                joint_dist['proportion'] = joint_dist[TransformedSchema.count_of_entries] / joint_dist[TransformedSchema.count_of_entries].sum()

                group['_tmp_key'] = 1
                joint_dist['_tmp_key'] = 1
                joint_dist.drop(columns=['count_of_entries'], inplace=True)
                group_merged = pd.merge(group, joint_dist, on='_tmp_key').drop(columns='_tmp_key')

                group_merged['count'] = group_merged[CleanSchema.count_of_travellers] * group_merged['proportion']

                group_merged['count'] = np.round(group_merged['count']).astype(int)
                group_merged = group_merged.loc[group_merged['count']!=0]
                orig_count = group_merged.groupby(orig_cols)['count_of_travellers'].first()
                new_count = group_merged.groupby(orig_cols)['count'].sum()
                adjustment = (orig_count - new_count).astype(int)
                
                
                # Find the largest split category in each group
                adjust_rows = (
                    group_merged.groupby(orig_cols)['count']
                    .idxmax()
                )
                # Apply adjustment
                for key, idx in adjust_rows.items():
                    adjustment_value = adjustment.loc[key]
                    current_count = group_merged.loc[idx, 'count']

                    new_count = current_count + adjustment_value

                    group_merged.loc[idx, 'count'] = new_count

                if (group_merged['count'] < 0).any():
                    logging.info("Although the adjustment is done on the largest count, in rare cases, the count column might still become negative.")

                group_merged[CleanSchema.count_of_travellers] = group_merged['count']
                group_merged.drop(columns=['proportion', 'count'], inplace=True)
                group_merged = CleanSchema(group_merged)

                output_rows.append(group_merged)

            df_pik = pd.concat(output_rows, ignore_index=True)

    df = pd.concat([low_count_df, stateless_df, df_non_pik, df_pik], axis=0, ignore_index=True)
    
    ###########################################################
    # Deterministic Imputation Relevant to All Work Locations #
    ###########################################################

    # Overwrite the arriving_from for the non-air travellers
    non_air_mask =df[CleanSchema.mode].isin([MODE.rail.value, MODE.marine.value, MODE.land.value])
    #arriving_from = 1 (U.S. Only) for Canadian and American travellers (country_of_residence in (11124,11840))
    df.loc[ df[CleanSchema.country_of_residence].isin(['11124','11840']) &
         non_air_mask, CleanSchema.arriving_from] = ARRIVING_FROM.us_only.value
    #For non-air travellers (mode = "Land", "Rail" or "Marine"), arriving_from can be coded as:
    #arriving_from = 3 (Overseas via the U.S.) for overseas travellers (country_of_residence not in (11124,11840))
    df.loc[~df[CleanSchema.country_of_residence].isin(['11124','11840']) &
        non_air_mask, CleanSchema.arriving_from] = ARRIVING_FROM.overseas_via_us.value
    
    ########################################################
    # Deterministic Imputation For Specific Work Locations #
    ########################################################
   
    # Set main trip purpose as crew for work locations known to be only serving cargo trains
    train_wloc_mask = df[CleanSchema.wloc].isin(['2310','3090','3180','3331','3540','5021','5022','6021','6025'])
    df.loc[train_wloc_mask & (df[CleanSchema.vehicle_type] == VEHICLE_TYPE.train.value),CleanSchema.purpose4] = PURPOSE4.crew.value

    df = df.sort_values(CleanSchema.date_of_entry)

    df = df.replace({None: pd.NA})

    # in order not to loose a data point using groupby:
    df[ipil_air_040_groupby_COLUMNS] = df[ipil_air_040_groupby_COLUMNS].fillna("")
    df = (
        df
        .groupby(ipil_air_040_groupby_COLUMNS, as_index=False, sort=False)[RawSchema.count_of_travellers]
        .sum()
    )
    
    nullable_columns = [RawSchema.wloc, RawSchema.wloc_name, RawSchema.gender, RawSchema.citizenship_code,
        RawSchema.citizenship_country, RawSchema.country_of_residence, RawSchema.port, 
        RawSchema.region_of_residence, RawSchema.duration2, RawSchema.purpose4, RawSchema.arriving_from]

    #convert the columns that we changed to blank, back to NA
    df[nullable_columns] = df[nullable_columns].replace("", pd.NA)

    df = CleanSchema(df[ipil_air_040_COLUMNS])

    return df