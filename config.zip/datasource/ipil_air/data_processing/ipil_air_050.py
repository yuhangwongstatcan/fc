"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** May 2025

**Description:**
Implements the ipil_air_050 business rule
"""

import pandas as pd

from datasource.ipil_air.schema import CleanSchema
from datasource.ipil_air.dim import (
    VEHICLE_TYPE,
    CITIZENSHIP_CODE,
    ARRIVING_FROM
)

from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)
from datasource.travellers.dim import (
    PLATE_REGION,
    PLATE_COUNTRY,
    MODE,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    DATA_SOURCE,
    COUNTRY_OF_RESIDENCE,
)


def ipil_air_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    Description:
    Generate the IPIL Air contribution to the travellers table in the correct schema.

    Args:
        df:
            A pandas dataframe that has had all IPIL Air business logic applied up to
            and including the CLEAN data output.

    Returns:
        traveller_df:
            The IPIL Air contribution to the travellers table in the correct schema.
    """

    #year, month, day
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        CleanSchema.date_of_entry
    ].str.split("-", expand=True)
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
    ]
    df[TransformedSchema.month] = df[TransformedSchema.month].replace(
        {r"0(\d)": r"\1"}, regex=True
    )
    df[TransformedSchema.day] = df[TransformedSchema.day].replace(
        {r"0(\d)": r"\1"}, regex=True
    )

    #port
    df[TransformedSchema.port] = df[CleanSchema.port]

    #mode
    df.loc[
        df[CleanSchema.vehicle_type]==VEHICLE_TYPE.commercial_aircraft.value, TransformedSchema.mode
        ] = MODE.air.value
    df.loc[
        df[CleanSchema.vehicle_type].isin([
            VEHICLE_TYPE.bus.value, VEHICLE_TYPE.train.value, VEHICLE_TYPE.pedestrians.value
        ]), TransformedSchema.mode] = MODE.land.value
    df.loc[
        df[CleanSchema.vehicle_type].isin([
            VEHICLE_TYPE.ferry.value, VEHICLE_TYPE.private_boats.value
        ]), TransformedSchema.mode] = MODE.water.value

    #vehicle_type
    df[TransformedSchema.vehicle_type] = df[CleanSchema.vehicle_type]

    #plate_country and plate_region
    df[TransformedSchema.plate_country] = PLATE_COUNTRY.not_available.value
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value

    #arriving_from 
    df[TransformedSchema.arriving_from] = df[CleanSchema.arriving_from]

    ipil_air_mode_mask= df[TransformedSchema.mode]==MODE.land.value
    country_of_residence_mask= df[CleanSchema.country_of_residence].isin([
            COUNTRY_OF_RESIDENCE.canada.value, COUNTRY_OF_RESIDENCE.united_states.value
            ])

    df.loc[
        ~country_of_residence_mask & ipil_air_mode_mask, TransformedSchema.arriving_from
        ] = ARRIVING_FROM.overseas_via_us.value

    #country_of_residence  
    df[TransformedSchema.country_of_residence] = df[CleanSchema.country_of_residence]

    #purpose9 and purpose4
    stateless_mask = df[CleanSchema.citizenship_code].isin(
        [CITIZENSHIP_CODE.XA.value, CITIZENSHIP_CODE.XXB.value, CITIZENSHIP_CODE.XXC.value])
    df.loc[stateless_mask, TransformedSchema.purpose9] = PURPOSE9.immigration.value
    df.loc[stateless_mask, TransformedSchema.purpose4] = PURPOSE4.other_purpose.value

    df.loc[~stateless_mask, TransformedSchema.purpose4] = df[CleanSchema.purpose4]

    df.loc[
        (df[TransformedSchema.purpose4]==PURPOSE4.visit.value) 
        & ~stateless_mask, TransformedSchema.purpose9 
        ] = PURPOSE9.visit.value #Visit, not otherwise specified
        
    df.loc[
        (df[TransformedSchema.purpose4]==PURPOSE4.crew.value) & 
        ~stateless_mask, TransformedSchema.purpose9
        ] = PURPOSE9.crew.value #Crew

    df.loc[
        (df[TransformedSchema.purpose4]==PURPOSE4.work.value) & 
        ~stateless_mask, TransformedSchema.purpose9
        ] = PURPOSE9.work.value #Work

    df.loc[
        (df[TransformedSchema.purpose4]==PURPOSE4.other_purpose.value) & 
        ~stateless_mask, TransformedSchema.purpose9
        ] = PURPOSE9.other_purpose.value #Unknown purpose

    #duration2 
    df[TransformedSchema.duration2] = df[CleanSchema.duration2]

    #duration3 and duration5
    df[TransformedSchema.duration3] = DURATION3.not_available.value #Not available
    df[TransformedSchema.duration5] = DURATION5.not_available.value #Not available

    #traveller_type 
    non_tourism_mask = (df[TransformedSchema.purpose4] == PURPOSE4.other_purpose.value) | (
       df[TransformedSchema.purpose4] == PURPOSE4.work.value) | (
          (df[TransformedSchema.purpose4] == PURPOSE4.crew.value) & 
          (df[TransformedSchema.vehicle_type].isin([
              VEHICLE_TYPE.commercial_aircraft.value,VEHICLE_TYPE.bus.value,VEHICLE_TYPE.train.value,VEHICLE_TYPE.ferry.value]))
         )
    df.loc[non_tourism_mask, TransformedSchema.traveller_type] = TRAVELLER_TYPE.other_traveller.value #Other traveller

    df.loc[~non_tourism_mask & 
        (df[TransformedSchema.duration2]==DURATION2.same_day.value), TransformedSchema.traveller_type
        ] = TRAVELLER_TYPE.excursionist.value #Excursionist

    df.loc[~non_tourism_mask & 
        (df[TransformedSchema.duration2]==DURATION2.overnight.value), TransformedSchema.traveller_type
        ] = TRAVELLER_TYPE.tourist.value #Tourist

    #work_location
    df[TransformedSchema.work_location] = df[CleanSchema.wloc]

    #data_source 
    df[TransformedSchema.data_source] = DATA_SOURCE.IPIL_Air.value

    df[TransformedSchema.count_of_entries] = df[CleanSchema.count_of_travellers]
    df = df[TRANSFORMED_COLUMNS]
    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = (
        df.groupby(
            by=TRANSFORMED_GROUPBY,
            dropna=False,
        )
        .sum()
        .reset_index()
    )

    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS
    # Reorder the red columns
    df = df[TRANSFORMED_COLUMNS]
    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]
    # Sort entries from left to right
    df = df.sort_values(
        TRANSFORMED_COLUMNS,
        ascending=True,
    )
    df = TransformedSchema(df)

    return df