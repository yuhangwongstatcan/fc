from datasource.ipil_air.data_processing.ipil_air_000 import *
from datasource.ipil_air.data_processing.ipil_air_005 import *
from datasource.ipil_air.data_processing.ipil_air_010 import *
from datasource.ipil_air.data_processing.ipil_air_020 import *
from datasource.ipil_air.data_processing.ipil_air_030 import *
from datasource.ipil_air.data_processing.ipil_air_040 import *
from datasource.ipil_air.data_processing.ipil_air_050 import *