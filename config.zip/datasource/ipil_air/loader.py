#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday May 1 2025
NGHH loader was added on Friday Dec 19 2025
@authors:  Nika Karimi Jashni
"""
import re
import tempfile
import shutil
import glob
import warnings
import pandas as pd
import numpy as np
from os.path import join
from pandas.core.frame import DataFrame
from modules.s3client import S3Client
from config.api import S3Location
from config.api import DataSource
from config.api import Stage
from config.api import S3
from config.argo import ArgoStatusCodes
from modules.utils.schema import tuplify
from modules.utils.data_manipulation import upload_files

from datasource.ipil_air.schema import RawSchema as IpilAirSchema, RAWSCHEMA_COLUMNS as IPIL_AIR_RAWSCHEMA_COLUMNS
from datasource.nghh.schema import RawSchema as NghhSchema, RAWSCHEMA_COLUMNS as NGHH_RAWSCHEMA_COLUMNS

# List of columns to sort ipil_air by, for raw data
IPIL_Air_SORT_COLUMNS = IpilAirSchema.get_keys()
NGHH_SORT_COLUMNS = NghhSchema.get_keys()


warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

def copy(string):
    return string




def exel_conf():
    return {
        0: {
            "name": "NGHH",
            "body": {
                "rows": {"start": 0, "end": None},
                "cols": {"start": 0, "end": 7},
                "ffill": 1,
                "attrs": [
                        {"name": "port_of_entry", "col": 0, "row": 0, "func": copy},
                        {"name": "date_of_entry", "col": 1, "row": 0, "func": copy},
                        {"name": "citizenship", "col": 2, "row": 0, "func": copy},
                        {"name": "gender", "col": 3, "row": 0, "func": copy},
                        {"name": "count_of_travellers", "col": 4, "row": 0, "func": copy},
                        {"name": "data_source", "col": 5, "row": 0, "func": copy},
                        {"name": "mode", "col": 6, "row": 0, "func": copy},
                    ],
                },
        },
        1: {
            "name": "IPIL Air",
            "body": {
                "rows": {"start": 0, "end": None},
                "cols": {"start": 0, "end": 7},
                "ffill": 1,
                "attrs": [
                        {"name": "port_of_entry", "col": 0, "row": 0, "func": copy},
                        {"name": "date_of_entry", "col": 1, "row": 0, "func": copy},
                        {"name": "citizenship", "col": 2, "row": 0, "func": copy},
                        {"name": "gender", "col": 3, "row": 0, "func": copy},
                        {"name": "count_of_travellers", "col": 4, "row": 0, "func": copy},
                        {"name": "data_source", "col": 5, "row": 0, "func": copy},
                        {"name": "mode", "col": 6, "row": 0, "func": copy},
                    ],
                },
        }
    }


def read_excel(filename: str, conf: dict, datasource:str) -> dict[DataFrame]:
    """
    Uses a configuration to extract DataFrames from excel sheets.
    """
    if datasource=="ipil_air":
        i=1
    elif datasource=="nghh":
        i=0

    
    conf = tuplify(conf[i])
    bcnf = conf.body


    sheet = pd.read_excel(filename, sheet_name=conf.name, engine="openpyxl",na_values='')

    body = sheet.iloc[bcnf.rows.start : bcnf.rows.end, bcnf.cols.start : bcnf.cols.end]

    
    # Trim all leading and tailing spaces
    body = body.replace(r"^ +| +$", r'', regex=True)
    
    body = body.mask(body == '') # replace all empty string value with NaN

    if datasource=="ipil_air":
        data = pd.DataFrame(columns=IPIL_AIR_RAWSCHEMA_COLUMNS)
    elif datasource=="nghh":
        data = pd.DataFrame(columns=NGHH_RAWSCHEMA_COLUMNS)

    
    for attr in bcnf.attrs:
        try:
            data[attr.name] = attr.func(body.iloc[attr.row:, attr.col])
        except:
            print(datasource, " loader error attr: ", attr)
            raise
    
    return data


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load ipil_air data from the momentary S3Location.
    This is the loader entry point for the ipil_air datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """
    downloaddir = client.get_dir(location)

    ipil_air_folder = tempfile.mkdtemp()
    nghh_folder = tempfile.mkdtemp()

    data_ipil_air = pd.DataFrame(columns=IPIL_AIR_RAWSCHEMA_COLUMNS)
    data_nghh = pd.DataFrame(columns=NGHH_RAWSCHEMA_COLUMNS)

    for f in glob.glob(join(downloaddir, "*.xlsx")):
        try:
            print("ipil air reading file: ", f)
            tmp_ipil_air = read_excel(f, exel_conf(), "ipil_air")
            tmp_ipil_air = tmp_ipil_air.dropna(how='all')
            data_ipil_air = pd.concat((data_ipil_air, tmp_ipil_air), axis=0, ignore_index=True)
            print("nghh reading file: ", f)
            tmp_nghh = read_excel(f, exel_conf(), "nghh")
            tmp_nghh = tmp_nghh.dropna(how='all')
            data_nghh = pd.concat((data_nghh, tmp_nghh), axis=0, ignore_index=True)
        except:
            # Return false if any file was not processed successfully
            import traceback as tb

            print("Error reading ipil_air file: ", f)
            fname = f.replace(downloaddir, "")
            fname = fname.replace("/", "")
            dst = S3.get_error_location(DataSource.ipil_air, fname)
            src = S3.obj_to_loc(Stage.INBOX.value.bucket, "inbox/" + fname)
            print("Moving to error location:", dst)
            client.mv_loc(src, dst)
            tb.print_exc()
            print("Exit on error.")
            ArgoStatusCodes.exit_error_location()
            return False

    data_ipil_air["date_of_entry"]=data_ipil_air["date_of_entry"].dt.strftime("%Y-%m-%d")
    data_nghh["date_of_entry"]=data_nghh["date_of_entry"].dt.strftime("%Y-%m-%d")
    data_ipil_air = data_ipil_air.replace(["", "#NAME?"], pd.NA)
    data_nghh = data_nghh.replace(["", "#NAME?"], pd.NA)
    gdf_ipil_air = data_ipil_air.groupby(IpilAirSchema.date_of_entry)
    gdf_nghh = data_nghh.groupby(NghhSchema.date_of_entry)
    dfs_ipil_air = {_date: gdf_ipil_air.get_group(_date) for _date in gdf_ipil_air.groups}
    dfs_nghh = {_date: gdf_nghh.get_group(_date) for _date in gdf_nghh.groups}

    date_pattern = re.compile("(\d{4})-(\d{2})-(\d{2})")
    localnames_ipil_air = []
    localnames_nghh = []
    for _date, _df in dfs_ipil_air.items():
        match = date_pattern.match(_date)
        if match:
            year, month, day = match.groups()
            filename_ipil_air = join(
                ipil_air_folder, S3.get_s3_basename(stage, DataSource.ipil_air, year, month, day)
            )
            localnames_ipil_air.append(filename_ipil_air)
            _df.to_csv(filename_ipil_air, mode="a", index=False, header=None)

    for _date, _df in dfs_nghh.items():
        match = date_pattern.match(_date)
        if match:
            year, month, day = match.groups()
            filename_nghh = join(
                nghh_folder, S3.get_s3_basename(stage, DataSource.nghh, year, month, day)
            )
            localnames_nghh.append(filename_nghh)
            _df.to_csv(filename_nghh, mode="a", index=False, header=None)

    upload_files(
        client,
        localnames_ipil_air,
        stage,
        DataSource.ipil_air,
        IpilAirSchema,
        IPIL_Air_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )

    upload_files(
        client,
        localnames_nghh,
        stage,
        DataSource.nghh,
        NghhSchema,
        NGHH_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )

    shutil.rmtree(downloaddir)
    shutil.rmtree(ipil_air_folder)
    shutil.rmtree(nghh_folder)
    return True
