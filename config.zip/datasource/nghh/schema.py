"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: December 2025

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the NGHH data source, as well as validation outputs.
"""
import pandera as pa
from pandera.typing import Series
from typing import Optional

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.nghh.dim import (
    GENDER,
    MODE,
    VEHICLE_TYPE,
    DATA_SOURCE,
    CITIZENSHIP_CODE,
    CITIZENSHIP,
    REGION_OF_RESIDENCE,
    DURATION2,
    PURPOSE4,
    ARRIVING_FROM,
)

from datasource.common.types import SafeIntToStringType

# Field definitions as constants where they are used in both RAW and CLEAN

WLOC_FIELD = pa.Field(
    description="Work location four-digit code extracted from the port_of_entry variable",
    str_matches=r"\d{4}",
    nullable=False,
    coerce=True,
    raise_warning=True,
)

WLOC_NAME_FIELD = pa.Field(
    description="Work location name extracted from the port_of_entry variable",
    nullable=False,
    coerce=True,
)

CITIZENSHIP_CODE_FIELD = pa.Field(
    description="Traveller citizenship two or three-letter code extracted from the citizenship variable",
    str_matches=r"[A-Z]{2}|[A-Z]{3}",
    isin=CITIZENSHIP_CODE.list(),
    coerce=True,
    nullable=True,
    raise_warning=True,
)

CITIZENSHIP_COUNTRY_FIELD = pa.Field(
    description="Traveller citizenship country name extracted from the citizenship variable",
    nullable=True,
    coerce=True,
)

COUNTRY_OF_RESIDENCE_FIELD = pa.Field(
    description="The country code corresponding to the country of residence for the travellers",
    str_matches=r"\d{5}",
    nullable=True,
    coerce=True,
)

PORT_FIELD = pa.Field(
    description="Code for the CBSA port of entry that the vehicle passed through",
    str_matches=r"\d{5}",
    coerce=True,
)

VEHICLE_TYPE_FIELD = pa.Field(
    description="Recoded Frontier Counts vehicle type",
    isin=VEHICLE_TYPE.list(),
    coerce=True,
    nullable=False,
    raise_warning=True,
)

REGION_OF_RESIDENCE_FIELD = pa.Field(
    description="Aggregated region of residence of travellers - either Canada, U.S. or overseas",
    isin=REGION_OF_RESIDENCE.list(),
    coerce=True,
    nullable=True,
    raise_warning=True,
)

DURATION2_FIELD = pa.Field(
    description="Trip duration of the travellers, either same-day or overnight",
    isin=DURATION2.list(),
    coerce=True,
    raise_warning=True,
)

PURPOSE4_FIELD = pa.Field(
    description="Trip purpose of the travellers, either visit, crew, work or other non-tourism purpose",
    isin=PURPOSE4.list(),
    coerce=True,
    raise_warning=True,
)

ARRIVING_FROM_FIELD = pa.Field(
    description="Arriving from for the travellers, either U.S. only, overseas direct or overseas via the U.S.",
    isin=ARRIVING_FROM.list(),
    coerce=True,
    raise_warning=True,
)



class RawSchema(FCSchemaModel):
    """
    Schema for the NGHH RAW data.
    """

    # port_of_entry is replaced in nghh_000 by wloc and wloc_name
    port_of_entry: Series[pa.String] = pa.Field(
        description="Port of entry, including four-digit CBSA work location code and name",
        str_matches=r"\d{4}\s-\s.*",
        coerce=True,
        nullable=False,
        raise_warning=True,
    )
    wloc: Optional[Series[SafeIntToStringType]] = WLOC_FIELD
    wloc_name: Optional[Series[pa.String]] = WLOC_NAME_FIELD

    date_of_entry: Series[pa.String] = pa.Field(
        description="Date of entry",
        # Date should be in the format YYYY-MM-DD
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
        nullable=False,
        raise_warning=True,
    )

    # citizenship is replaced in nghh_000 by citizenship_code and citizenship_country
    citizenship: Series[pa.String] = pa.Field(
        description="Traveller citizenship, including two or three-letter code and country name",
        str_matches=r"([A-Z]{2}|[A-Z]{3})\s-\s.*",
        isin=CITIZENSHIP.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    citizenship_code: Optional[Series[pa.String]] = CITIZENSHIP_CODE_FIELD
    citizenship_country: Optional[Series[pa.String]] = CITIZENSHIP_COUNTRY_FIELD
    
    gender: Series[pa.String] = pa.Field(
        description="Gender of traveller",
        isin=GENDER.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    count_of_travellers: Series[pa.INT64] = pa.Field(
        description="Number of travellers",
        ge=0,
        nullable=False,
        coerce=True,
    )
    data_source: Series[pa.String] = pa.Field(
        description="CBSA data source providing the information",
        isin=DATA_SOURCE.list(),
        coerce=True,
        nullable=False,
        raise_warning=True,
    )
    mode: Series[pa.String] = pa.Field(
        description="Mode of transportation used to enter Canada",
        isin=MODE.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
       
    country_of_residence: Optional[
        Series[SafeIntToStringType]
    ] = COUNTRY_OF_RESIDENCE_FIELD
    port: Optional[Series[SafeIntToStringType]] = PORT_FIELD

    vehicle_type: Optional[Series[pa.String]] = VEHICLE_TYPE_FIELD
    region_of_residence: Optional[Series[pa.String]] = REGION_OF_RESIDENCE_FIELD
    duration2: Optional[Series[pa.String]] = DURATION2_FIELD
    purpose4: Optional[Series[pa.String]] = PURPOSE4_FIELD
    arriving_from: Optional[Series[pa.String]] = ARRIVING_FROM_FIELD

    @staticmethod
    def get_keys():
        return [
            RawSchema.port_of_entry,
            RawSchema.date_of_entry,
            RawSchema.citizenship,
            RawSchema.gender,
            RawSchema.data_source,
            RawSchema.mode,
        ]


class CleanSchema(RawSchema):
    """
    Schema for the NGHH CLEAN data.
    """

    wloc: Series[SafeIntToStringType] = WLOC_FIELD
    wloc_name: Series[pa.String] = WLOC_NAME_FIELD

    date_of_entry: Series[pa.String] = pa.Field(
        description="Date of entry",
        # Date should be in the format YYYY-MM-DD
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
        nullable=False,
        raise_warning=True,
    )

    citizenship_code: Series[pa.String] = CITIZENSHIP_CODE_FIELD
    citizenship_country: Series[pa.String] = CITIZENSHIP_COUNTRY_FIELD
    
    gender: Series[pa.String] = pa.Field(
        description="Gender of traveller",
        isin=GENDER.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    count_of_travellers: Series[pa.INT64] = pa.Field(
        description="Number of travellers",
        ge=0,
        nullable=False,
        coerce=True,
    )
    data_source: Series[pa.String] = pa.Field(
        description="CBSA data source providing the information",
        isin=DATA_SOURCE.list(),
        coerce=True,
        nullable=False,
        raise_warning=True,
    )
    mode: Series[pa.String] = pa.Field(
        description="Mode of transportation used to enter Canada",
        isin=MODE.list(),
        coerce=True,
        nullable=False,
        raise_warning=True,
    )
       
    country_of_residence: Series[SafeIntToStringType]= COUNTRY_OF_RESIDENCE_FIELD
    port: Series[SafeIntToStringType] = PORT_FIELD

    vehicle_type: Series[pa.String] = VEHICLE_TYPE_FIELD
    region_of_residence: Series[pa.String] = REGION_OF_RESIDENCE_FIELD
    duration2: Series[pa.String] = DURATION2_FIELD
    purpose4: Series[pa.String] = PURPOSE4_FIELD
    arriving_from: Series[pa.String] = ARRIVING_FROM_FIELD



class ValidationSchema(pa.SchemaModel):
    """
    Schema for variables appearing in validation output but not in RAW or CLEAN IPIL Highway data.
    All elements are defined as optional because the schema is used across all validations and
    specific columns may appear in certain validations, but not in others.
    """

    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of a dimension variable with unexpected values.",
        coerce=True,
    )
    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value of dimension variable.",
        coerce=True,
        nullable=True,
    )
    location: Optional[Series[pa.String]] = pa.Field(
        description="Geographical location where an unexpected dimension variable occurred.",
        str_matches=r"\d{4}",
        coerce=True,
    )
    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences of a particular validation case.",
        ge=0,
        coerce=True,
    )
    count_of_travellers: Optional[Series[pa.INT64]] = pa.Field(
        description="Number of travellers",
        ge=0,
        coerce=True,
    )
    wloc: Optional[Series[pa.String]] = WLOC_FIELD
    wloc_name: Optional[Series[pa.String]] = WLOC_NAME_FIELD
    mode: Optional[Series[pa.String]] = pa.Field(
        description="Mode of transportation used to enter Canada",
        isin=MODE.list(),
        coerce=True,
        nullable=True,
        raise_warning=True,
    )
    work_location_issue_type: Optional[Series[pa.String]] = pa.Field(
        description="Type of data availability issue that caused a work location to be flagged.",
        isin=[
            "Unexpected WLOC or Mode",
            "Rejected Data",
        ],
        coerce=True,
        raise_warning=True
    )
    country_of_residence: Optional[
        Series[SafeIntToStringType]
    ] = COUNTRY_OF_RESIDENCE_FIELD
    unknown_citizenship: Optional[Series[pa.String]] = pa.Field(
        description="Category of unknown citizenship for the imputed countries",
        isin=[
            "Blank",
            "United Nations",
            "Unspecified",
            "European Union",
        ],
        coerce=True,
        raise_warning=True
    )
    date: Optional[Series[pa.String]] = pa.Field(
        description="Date of entry",
        # Date should be in the format YYYY-MM-DD
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
        nullable=False,
        raise_warning=True,
    )

RAWSCHEMA_COLUMNS = [
    col
    for col in RawSchema.to_schema().columns.keys()
    if RawSchema.to_schema().columns[col].required
]
nghh_000_COLUMNS = [
    RawSchema.port_of_entry,
    RawSchema.wloc,
    RawSchema.wloc_name,
    RawSchema.date_of_entry,
    RawSchema.citizenship, 
    RawSchema.citizenship_code, 
    RawSchema.citizenship_country,
    RawSchema.gender,
    RawSchema.count_of_travellers,
    RawSchema.data_source,
    RawSchema.mode]
nghh_v010_COLUMNS = [
    ValidationSchema.date,
    ValidationSchema.work_location_issue_type,
    ValidationSchema.wloc,
    ValidationSchema.wloc_name,
    ValidationSchema.mode,
    ValidationSchema.count_of_travellers,
    'ipil_mob_count'
]
nghh_020_groupby_COLUMNS = list(
    dict.fromkeys([c for c in nghh_000_COLUMNS if c != RawSchema.count_of_travellers])
)
nghh_020_COLUMNS = nghh_000_COLUMNS
nghh_030_COLUMNS = [*nghh_000_COLUMNS, RawSchema.country_of_residence]
nghh_050_COLUMNS = [
    *nghh_030_COLUMNS, RawSchema.port, RawSchema.vehicle_type,
    RawSchema.region_of_residence, RawSchema.duration2, RawSchema.purpose4, 
    RawSchema.arriving_from
    ]
nghh_050_groupby_COLUMNS = list(
    dict.fromkeys([c for c in nghh_050_COLUMNS if c != RawSchema.count_of_travellers])
)
CLEANSCHEMA_COLUMNS = [col for col in CleanSchema.to_schema().columns.keys()]
