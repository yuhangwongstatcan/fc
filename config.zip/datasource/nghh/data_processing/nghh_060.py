"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_060 business rule
"""
import pandas as pd
import numpy as np

from config.api import DataSource
from config.api import Stage
from config.api import S3
from modules.utils.loaders import Loader

from datasource.nghh.schema import CleanSchema, CLEANSCHEMA_COLUMNS
from datasource.travellers.schema import TransformedSchema as TravellersSchema
from datasource.vehicles.schema import TransformedSchema as VehiclesSchema

from datasource.nghh.dim import VEHICLE_TYPE as NGHH_VEHICLE_TYPE
from datasource.common.dim import VEHICLE_TYPE as COMMON_VEHICLE_TYPE, DATA_SOURCE as COMMON_DATA_SOURCE

def nghh_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    Determine number of vehicles in NGHH, as well as the licence plate country for the imputed vehicles.
    
    Args:
        df:
            A pandas dataframe without number of vehicles and the licence plate country.

    Returns:
        df:
            A pandas dataframe with imputed number of vehicles and the licence plate country
    """

    # extract the year and month
    year, month, _ = df[CleanSchema.date_of_entry].iloc[0].split("-")
    year = int(year)
    month = int(month) 
    # Extract the records from vehicles and travellers data
    basename = S3.get_s3_basename(
        Stage.AGGREGATED, DataSource.vehicles, year, month, 1
    )
    ipil_hwy_vehicles_table = Loader.get(
        Stage.AGGREGATED, DataSource.vehicles, basename
    )
    ipil_hwy_vehicles_table = VehiclesSchema(ipil_hwy_vehicles_table)

    ipil_hwy_travellers_table = Loader.get(
        Stage.AGGREGATED, DataSource.travellers, basename
    )
    ipil_hwy_travellers_table = TravellersSchema(ipil_hwy_travellers_table)
    # Get Canadian Travellers by work location
    canadian_travellers = (
        df.loc[
            (df[CleanSchema.country_of_residence] == "11124"),
            [CleanSchema.count_of_travellers, CleanSchema.wloc, CleanSchema.vehicle_type],
        ]
        .groupby(by=[CleanSchema.wloc, CleanSchema.vehicle_type], as_index=False)
        .sum(CleanSchema.count_of_travellers)
    ).rename(columns={CleanSchema.count_of_travellers: "canadian_count"})

    # Get American Travellers by work location
    american_travellers = (
        df.loc[
            (df[CleanSchema.country_of_residence] == "11840"),
            [CleanSchema.count_of_travellers, CleanSchema.wloc, CleanSchema.vehicle_type],
        ]
        .groupby(by=[CleanSchema.wloc, CleanSchema.vehicle_type], as_index=False)
        .sum(CleanSchema.count_of_travellers)
    ).rename(columns={CleanSchema.count_of_travellers: "american_count"})

    # Merge in calculated travellers
    df = pd.merge(
        df, canadian_travellers, on=[CleanSchema.wloc, CleanSchema.vehicle_type], how="left"
    )
    df = pd.merge(
        df, american_travellers, on=[CleanSchema.wloc, CleanSchema.vehicle_type], how="left"
    )

    df[["canadian_count", "american_count"]].fillna(0)


    # Get totals for Canada, American, and travellers in order to calculate the proportion as described in the documentation
    rows_to_impute = df[
        df[CleanSchema.vehicle_type].isin(
            [NGHH_VEHICLE_TYPE.automobile.value, NGHH_VEHICLE_TYPE.motorcycle.value, NGHH_VEHICLE_TYPE.other_land_vehicle.value, NGHH_VEHICLE_TYPE.truck.value]
        )
    ]
    # Filter the vehicles data for the IPIL_HWY datasource and land vehicles.
    ipil_hwy_vehicles_table = ipil_hwy_vehicles_table[
        (
            (ipil_hwy_vehicles_table[VehiclesSchema.vehicle_type].isin(
                [COMMON_VEHICLE_TYPE.automobile.value, COMMON_VEHICLE_TYPE.motorcycle.value, COMMON_VEHICLE_TYPE.other_land_vehicle.value, COMMON_VEHICLE_TYPE.truck.value]
            )) & (ipil_hwy_vehicles_table[VehiclesSchema.data_source] == COMMON_DATA_SOURCE.IPIL_Highway.value)
        )
    ]
    # Filter the travellers data for the IPIL_HWY datasource and land travellers.
    ipil_hwy_travellers_table = ipil_hwy_travellers_table[
        (
            (ipil_hwy_travellers_table[TravellersSchema.vehicle_type].isin(
                [COMMON_VEHICLE_TYPE.automobile.value, COMMON_VEHICLE_TYPE.motorcycle.value, COMMON_VEHICLE_TYPE.other_land_vehicle.value, COMMON_VEHICLE_TYPE.truck.value]
            )) & (ipil_hwy_travellers_table[TravellersSchema.data_source] == COMMON_DATA_SOURCE.IPIL_Highway.value)
        )
    ]

    # Sum entries by vehicle and work location
    sum_vehicles = ipil_hwy_vehicles_table.groupby(
        by=[VehiclesSchema.work_location, VehiclesSchema.vehicle_type, VehiclesSchema.port],
        dropna=False,
        as_index=False,
    )
    sum_vehicles = sum_vehicles[[VehiclesSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    ).rename(columns={VehiclesSchema.count_of_entries: 'sum_vehicles'})
    sum_travellers = ipil_hwy_travellers_table.groupby(
        by=[TravellersSchema.work_location, TravellersSchema.vehicle_type, TravellersSchema.port],
        dropna=False,
        as_index=False,
    )
    sum_travellers = sum_travellers[[VehiclesSchema.count_of_entries]].apply(
        lambda x: x.astype("Int64").sum()
    ).rename(columns={VehiclesSchema.count_of_entries: 'sum_travellers'})

    # group by GROUPBY_COLS (then drop everything else)
    GROUPBY_COLS = [
        CleanSchema.date_of_entry,
        CleanSchema.wloc,
        CleanSchema.wloc_name,
        CleanSchema.port_of_entry,
        CleanSchema.port,
        CleanSchema.mode,
        CleanSchema.vehicle_type,
        CleanSchema.data_source,
    ]
    rows_to_impute = (
        rows_to_impute[
            GROUPBY_COLS + [CleanSchema.count_of_travellers, "canadian_count", "american_count"]
        ]
        .groupby(by=GROUPBY_COLS, as_index=False)
        .sum()
    )

    # Every row in this new table gets date_of_entry as the first of the month being processed and gender as "VEHICLE"
    rows_to_impute[CleanSchema.gender] = "VEHICLE"
    rows_to_impute[CleanSchema.date_of_entry] = f"{year:04d}-{month:02d}-01"
    rows_to_impute[CleanSchema.duration2] = pd.NA
    # country and country_of_residence just gets coded to "Canada" or
    # "United States of America" then use the corresponding country of residence code
    # then merge with proportion after so its between [0,1]
    rows_to_impute["country"] = "11124,11840"
    rows_to_impute["country"] = rows_to_impute[
        "country"
    ].str.split(",")
    rows_to_impute = rows_to_impute.explode("country")
    # Fill country_of_residence
    rows_to_impute[CleanSchema.country_of_residence] = pd.NA

    proportion = sum_vehicles.merge(sum_travellers, on=[VehiclesSchema.work_location, VehiclesSchema.vehicle_type], how='inner')
    proportion['proportion'] = proportion['sum_vehicles'] / proportion['sum_travellers']
    proportion = proportion.drop(columns=['sum_vehicles', 'sum_travellers'])
    rows_to_impute = pd.merge(
        rows_to_impute,
        proportion,
        left_on=[CleanSchema.vehicle_type, CleanSchema.wloc],
        right_on=[CleanSchema.vehicle_type, "work_location"],
        how="left",
    )
    tmp_rows_to_imput = rows_to_impute[~rows_to_impute["proportion"].isnull()]
    # If rows to impute contains rows that require a proportion, use the
    # province, not just the port.
    if rows_to_impute["proportion"].isnull().any():
        rows_to_impute = rows_to_impute[rows_to_impute["proportion"].isnull()]
        # Recompute sum_vehicles/sum_travellers at province level
        rows_to_impute["province"] = rows_to_impute[CleanSchema.port].str[0:2]
        sum_vehicles["province"] = sum_vehicles[VehiclesSchema.port].str[0:2]
        sum_vehicles.drop(columns=VehiclesSchema.port)
        sum_vehicles = sum_vehicles.groupby(
            by=["province", VehiclesSchema.vehicle_type], as_index=False
        ).sum("sum_vehicles")
        sum_travellers["province"] = sum_travellers[VehiclesSchema.port].str[0:2]
        sum_travellers.drop(columns=VehiclesSchema.port)
        sum_travellers = sum_travellers.groupby(
            by=["province", VehiclesSchema.vehicle_type], as_index=False
        ).sum("sum_travellers")
        # Recalculate proportions
        proportion = sum_vehicles.merge(sum_travellers, on=["province", VehiclesSchema.vehicle_type], how='inner')
        proportion['proportion'] = proportion['sum_vehicles'] / proportion['sum_travellers']
        proportion = proportion.drop(columns=['sum_vehicles', 'sum_travellers'])
        rows_to_impute = pd.merge(
            rows_to_impute,
            proportion,
            on=[CleanSchema.vehicle_type, "province"],
            how="left",
        )
        rows_to_impute.loc[
            (rows_to_impute["proportion_x"].isna()), "proportion_x"
        ] = rows_to_impute.loc[(rows_to_impute["proportion_x"].isna()), "proportion_y"]
        rows_to_impute = rows_to_impute.rename(columns={"proportion_x": "proportion"})
        rows_to_impute = rows_to_impute.drop(columns=["proportion_y"])
        # If we still have records that need to be imputed, consider all of
        # Canada in the aggregation
        tmp_rows_to_imput = pd.concat([tmp_rows_to_imput, rows_to_impute[~rows_to_impute["proportion"].isnull()]], axis=0)
        if rows_to_impute["proportion"].isnull().any():
            rows_to_impute = rows_to_impute[rows_to_impute["proportion"].isnull()]
            sum_vehicles = sum_vehicles.drop(columns=["province"])
            sum_vehicles = sum_vehicles.groupby(
                by=[VehiclesSchema.vehicle_type], as_index=False
            ).sum("sum_vehicles")
            sum_travellers = sum_travellers.drop(columns=["province"])
            sum_travellers = sum_travellers.groupby(
                by=[VehiclesSchema.vehicle_type], as_index=False
            ).sum("sum_travellers")
            proportion = sum_vehicles.merge(sum_travellers, on=[VehiclesSchema.vehicle_type], how='inner')
            proportion['proportion'] = proportion['sum_vehicles'] / proportion['sum_travellers']
            proportion = proportion.drop(columns=['sum_vehicles', 'sum_travellers'])
            rows_to_impute = pd.merge(
                rows_to_impute, proportion, on=[CleanSchema.vehicle_type], how="left"
            )
            rows_to_impute.loc[
                (rows_to_impute["proportion_x"].isna()), "proportion_x"
            ] = rows_to_impute.loc[
                (rows_to_impute["proportion_x"].isna()), "proportion_y"
            ]
            rows_to_impute = rows_to_impute.rename(
                columns={"proportion_x": "proportion"}
            )
            rows_to_impute = rows_to_impute.drop(columns=["proportion_y"])
            
            tmp_rows_to_imput = pd.concat([tmp_rows_to_imput, rows_to_impute], axis=0)
            
    rows_to_impute = tmp_rows_to_imput
    # Use the proportion to calculated the for Canada and US residence VEHICLE
    CANADA = (rows_to_impute["country"] == "11124")
    USA = (rows_to_impute["country"] == "11840")
    rows_to_impute["tmp_count_of_travellers"] = rows_to_impute["count_of_travellers"]
    rows_to_impute.loc[CANADA, CleanSchema.count_of_travellers] = np.round(
        (rows_to_impute.loc[CANADA, "canadian_count"])
        / (
            rows_to_impute.loc[CANADA, "canadian_count"]
            + rows_to_impute.loc[CANADA, "american_count"]
        )
        * np.ceil(
            rows_to_impute.loc[CANADA, "proportion"]
            * rows_to_impute.loc[CANADA, "tmp_count_of_travellers"]
        )
    )
    rows_to_impute.loc[USA, CleanSchema.count_of_travellers,] = np.round(
        (rows_to_impute.loc[USA, "american_count"])
        / (
            rows_to_impute.loc[USA, "canadian_count"]
            + rows_to_impute.loc[USA, "american_count"]
        )
        * np.ceil(
            rows_to_impute.loc[USA, "proportion"] * rows_to_impute.loc[USA, "tmp_count_of_travellers"]
        )
    )

    # if BOTH Canadian and american counts are NA
    mask_both_na = rows_to_impute[CleanSchema.count_of_travellers].isnull()

    # 50/50 split, extra 1 goes to CANADA if odd
    rows_to_impute.loc[CANADA & mask_both_na, CleanSchema.count_of_travellers] = np.round(
        np.ceil(
            rows_to_impute.loc[CANADA & mask_both_na, "proportion"]
            * rows_to_impute.loc[CANADA & mask_both_na, "tmp_count_of_travellers"]
        ) // 2 + np.ceil(
            rows_to_impute.loc[CANADA & mask_both_na, "proportion"]
            * rows_to_impute.loc[CANADA & mask_both_na, "tmp_count_of_travellers"]
        ) % 2 
    )
    rows_to_impute.loc[USA & mask_both_na, CleanSchema.count_of_travellers,] = np.round(
        np.ceil(
            rows_to_impute.loc[USA & mask_both_na, "proportion"] 
            * rows_to_impute.loc[USA & mask_both_na, "tmp_count_of_travellers"]
        ) //2
    )

    rows_to_impute[CleanSchema.country_of_residence] = rows_to_impute["country"]
    rows_to_impute[[CleanSchema.citizenship, CleanSchema.citizenship_code, CleanSchema.citizenship_country, CleanSchema.region_of_residence]] = pd.NA
    rows_to_impute[[CleanSchema.duration2, CleanSchema.purpose4, CleanSchema.arriving_from]] = 9
    rows_to_impute = rows_to_impute[CLEANSCHEMA_COLUMNS]
    # Append the VEHICLE rows to input
    df = pd.concat([df, rows_to_impute], axis=0, ignore_index=True)

    df = CleanSchema(df)

    df = df[df[CleanSchema.count_of_travellers] > 0]
    df = df[CLEANSCHEMA_COLUMNS]


    return df