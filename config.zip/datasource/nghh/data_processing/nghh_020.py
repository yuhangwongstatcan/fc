"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_020 business rule and validation
"""
import pandas as pd
import numpy as np

from config.api import DataSource
from config.api import Stage
from config.api import S3

from modules.utils.loaders import Loader

from datasource.nghh.schema import RawSchema, nghh_020_COLUMNS, nghh_020_groupby_COLUMNS
from datasource.ipil_hwy.schema import CleanSchema as ipil_hwy_schema


def nghh_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Lower the NGHH volumes at work locations where some (or all) of the travellers are also recorded in the IPIL Highway
    data that is received from CBSA in order to avoid double-counting.

    Args:
        df:
            A pandas dataframe with records that are captured in ipil_hwy as well
    Returns:
        a pandas dataframe with no ecords that are captured in ipil_hwy
    """
    year, month, _ = df[RawSchema.date_of_entry].iloc[0].split("-")
    year = int(year)
    month = int(month)
    
    # Exclude rail travellers from the IPIL Highway mobile lane adjustment
    sub_rail = df.loc[df['mode'] == "Rail"]
    df = df.loc[df['mode'] != "Rail"]
    
    if not df.empty:
        basename = S3.get_s3_basename(Stage.CLEAN, DataSource.ipil_hwy, year, month, 1)
        ipil_hwy_data = Loader.get(Stage.CLEAN, DataSource.ipil_hwy, basename)
        # Sum of travellers passing through IPIL Highway lanes designated as mobile, by work location
        ipil_hwy_mob = ipil_hwy_data[ipil_hwy_data[ipil_hwy_schema.lane].str[:3] == 'MOB']
        ipil_hwy_mob['ipil_mob_count'] = ipil_hwy_mob[[
            ipil_hwy_schema.cdsd, ipil_hwy_schema.cd1d, ipil_hwy_schema.cd2d,
                ipil_hwy_schema.ussd, ipil_hwy_schema.us1d, ipil_hwy_schema.us2d,
                ipil_hwy_schema.osd, ipil_hwy_schema.o1d, ipil_hwy_schema.o2d
            ]].sum(axis=1)
        ipil_hwy_mob = (
            ipil_hwy_mob
            .groupby(ipil_hwy_schema.cport, as_index=False)['ipil_mob_count']
            .sum()
        )
        df_by_wloc = (
            df
            .groupby(RawSchema.wloc, as_index=False)[RawSchema.count_of_travellers]
            .sum()
        )

        df_by_wloc = df_by_wloc.merge(
                ipil_hwy_mob, 
                left_on=RawSchema.wloc,
                right_on=ipil_hwy_mob[ipil_hwy_schema.cport].astype(str),
                how='left'
            )

        df_by_wloc['ipil_mob_count'] = df_by_wloc['ipil_mob_count'].fillna(0)

        df_by_wloc['diff'] = df_by_wloc[RawSchema.count_of_travellers] - df_by_wloc['ipil_mob_count']
        df_by_wloc.drop(columns='count_of_travellers', inplace=True)
        df = df.merge(
                df_by_wloc, 
                on=RawSchema.wloc,
                how='left'
            )
        df = df[df['diff'] > 0]
    
        #explode the df to contain one traveller for each row
        df = df.loc[df.index.repeat(df[RawSchema.count_of_travellers])].copy()
        df[RawSchema.count_of_travellers] = 1

        #seed variable
        year, month, _ = df[RawSchema.date_of_entry].iloc[0].split("-")
        seed = int(year + month)
        rng=np.random.default_rng(seed)
        df['random_number'] = rng.random(len(df))
        df = df.sort_values(
            by=[RawSchema.wloc, 'random_number'],
            ascending=[True, True]
        )
        # pos: position within each wloc
        pos = df.groupby(RawSchema.wloc).cumcount()
        df = df.loc[pos >= df['ipil_mob_count']]
        #in order not to loose a data point when doing groupby:
        df[nghh_020_groupby_COLUMNS] = df[nghh_020_groupby_COLUMNS].fillna("")
        df = df.sort_index()
        df = (
            df
            .groupby(nghh_020_groupby_COLUMNS, as_index=False, sort=False)[RawSchema.count_of_travellers]
            .sum()
        )

        #convert the columns that we changed to blank, back to NA
        df[nghh_020_groupby_COLUMNS] = df[nghh_020_groupby_COLUMNS].replace("", pd.NA)
        df = RawSchema(df[nghh_020_COLUMNS])
    
    sub_rail = RawSchema(sub_rail[nghh_020_COLUMNS])
    df = pd.concat([df,sub_rail])
    
    return df