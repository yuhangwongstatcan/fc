"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_005 business rule and validation
"""
import pandas as pd
import logging

from datasource.nghh.schema import RawSchema, ValidationSchema

def nghh_005(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add the Frontier Counts mode to the nghh raw data with
    potential missing values, using the most frequent mode for 
    the same port.

    Args:
        df:
            A pandas dataframe with missing values for mode
    Returns:
        df:
            A pandas dataframe with non-missing FC mode

        auxiliary_df:
            A pandas dataframe where mode was missing and imputed
    """

    # For donor data only use rows where mode is not missing
    notna_df = df[~df[RawSchema.mode].isna()]

    # Group by wloc and mode, sum 'count_of_entry'
    sum_counts = (
        notna_df
        .groupby([RawSchema.wloc, RawSchema.mode], as_index=False)[RawSchema.count_of_travellers]
        .sum()
    )

    # For each wloc, find the mode with the highest count sum
    max_count_lookup = (
        sum_counts
        .sort_values(RawSchema.count_of_travellers, ascending=False)
        .drop_duplicates(subset=[RawSchema.wloc])  # keep the top mode per wloc
        .rename(columns={'mode': 'impute_mode'})[[RawSchema.wloc, 'impute_mode']]
    )

    # Merge mode back into original df
    df = df.merge(max_count_lookup, on=RawSchema.wloc, how='left')

    # Track missing values before imputation
    df['imputed'] = df[RawSchema.mode].isna()

    # Fill missing mode with group mode
    df[RawSchema.mode] = df[RawSchema.mode].fillna(df['impute_mode'])

    auxiliary_df = df[df['imputed']]
    # Drop the helper columns
    df = df.drop(columns=['impute_mode','imputed'])
    auxiliary_df = auxiliary_df.drop(columns=['impute_mode','imputed'])

    #if any unemputed left, remove temporarily and the production team
    #  will handle it in the validation report and add it back.
    df = df[~df[RawSchema.mode].isna()]
    
    return df, auxiliary_df


def nghh_v005(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule nghh_005

    Args:
        input:
            a pandas dataframe containing records that had an imputation 
            for the mode column
    Returns:
        A summary of the imputation for mode for use in the
        validation dashboards.
    """

    validation_df = auxiliary_df.rename(
        columns={RawSchema.date_of_entry: ValidationSchema.date}
        )

    validation_df = validation_df[
        [
            ValidationSchema.date,
            ValidationSchema.wloc,
            ValidationSchema.wloc_name,
            ValidationSchema.mode,
            ValidationSchema.count_of_travellers,
        ]
    ]
    validation_df = validation_df.groupby(
        by=[
            ValidationSchema.date,
            ValidationSchema.wloc,
            ValidationSchema.wloc_name,
            ValidationSchema.mode,
        ],
        dropna=False,
        as_index=False,
    ).sum(ValidationSchema.count_of_travellers)
    
    if df[ValidationSchema.mode].isna().any():
        logging.info("The imputation of mode column failed due to the lack of donor data with the same wloc!")
        print("The imputation of mode column failed due to the lack of donor data with the same wloc!")


    return ValidationSchema(validation_df)