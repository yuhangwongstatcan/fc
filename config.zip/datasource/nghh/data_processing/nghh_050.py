"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_050 business rule
"""
import logging
import pandas as pd
import numpy as np
from datetime import datetime

from config.api import DataSource
from config.api import Stage
from config.api import WorkLocationsTransAction
from config.api import S3
from modules.utils.loaders import Loader

from datasource.nghh.schema import RawSchema, nghh_050_groupby_COLUMNS, nghh_050_COLUMNS
from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema
from datasource.travellers.schema import TransformedSchema
from datasource.nghh_imputation.schema import ReferenceSchema as nghhImputationSchema

from datasource.nghh.dim import (
    MODE,
    VEHICLE_TYPE,
    REGION_OF_RESIDENCE,
    CITIZENSHIP_CODE,
    DURATION2,
    PURPOSE4,
    ARRIVING_FROM,
)


def nghh_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute vehicle type, trip duration, trip purpose and arriving from for NGHH travellers

    Args:
        df:
            A pandas dataframe without vehicle type, trip duration, trip purpose and arriving from.

    Returns:
        df:
            A pandas dataframe which has vehicle type, trip duration, trip purpose and arriving from assigned to
            each record.
    """
    #####################################
    # Calculating Reference Proportions #
    #####################################
    # Merge nghh input with the work_locations table to get the port
    # corresponding to each work location, and replace the port_of_entry with port
    work_locations = Loader.get(Stage.REFERENCE, DataSource.work_locations, None)
    work_locations = WorkLocationsSchema(work_locations)
    df = pd.merge(
        df,
        work_locations[[WorkLocationsSchema.port, WorkLocationsSchema.work_location]],
        left_on=RawSchema.wloc,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )
    # Re-coerce the schema after the pd.merge
    df = RawSchema(df)

    # Mapping function to add the region_of_residence column
    def map_country_of_residence_to_region_of_residence(value):
        if value == '11124':
            return REGION_OF_RESIDENCE.canada.value
        elif value == '11840':
            return REGION_OF_RESIDENCE.united_states.value
        elif value not in ['11124', '11840']:
            return REGION_OF_RESIDENCE.overseas.value
    # Create new column 'region_of_residence'
    df[RawSchema.region_of_residence] = (
        df[RawSchema.country_of_residence].apply(map_country_of_residence_to_region_of_residence)
    )

    #Load traveller 2024 and 2025 data to use as a reference for distributions
    year, month, _ = df[RawSchema.date_of_entry].iloc[0].split("-")
    year = int(year)
    month = int(month) 
    basename_2024 = S3.get_s3_basename(Stage.AGGREGATED, DataSource.travellers, 2024, month, 1)
    travellers_2024 = Loader.get(Stage.AGGREGATED, DataSource.travellers, basename_2024)
    basename_2025 = S3.get_s3_basename(Stage.AGGREGATED, DataSource.travellers, 2025, month, 1)
    travellers_2025 = Loader.get(Stage.AGGREGATED, DataSource.travellers, basename_2025)
    travellers_data = pd.concat([travellers_2024, travellers_2025], axis=0, ignore_index=True)
    travellers_data = TransformedSchema(travellers_data)
    travellers_data = travellers_data[travellers_data[TransformedSchema.country_of_residence] != '99999']
    travellers_data['region_of_residence'] = (
        travellers_data[
            TransformedSchema.country_of_residence
            ].apply(map_country_of_residence_to_region_of_residence)
    )
    
    # Convert the numeric mode column of reference file to the string mode
    travellers_data[RawSchema.mode] = np.select(
        [
            travellers_data[TransformedSchema.mode].eq("1"),
            travellers_data[TransformedSchema.mode].eq("2") & travellers_data[TransformedSchema.vehicle_type].ne("216"),
            travellers_data[TransformedSchema.vehicle_type].eq("216"),
            travellers_data[TransformedSchema.mode].eq("3")
        ],
        [MODE.air.value, MODE.land.value, MODE.rail.value, MODE.marine.value],
        default=np.nan
    )

    nghh_imputation = Loader.get(Stage.REFERENCE, DataSource.nghh_imputation, None)
    nghh_imputation = nghhImputationSchema(nghh_imputation)
    nghh_imputation_ref_prop = nghh_imputation[nghh_imputation["variable"] == "ALL"]
    df = df.merge(nghh_imputation_ref_prop, on=RawSchema.wloc, how="left")

    # Small counts in the nghh data uniformly coded directly to the most popular category for the port, mode and 
    # region_of_residence from the travellers file.
    low_count_df = df[(df[RawSchema.count_of_travellers] <= 5)]
    if low_count_df.empty:
        new_cols = [RawSchema.duration2, RawSchema.purpose4, RawSchema.arriving_from]
        low_count_df[new_cols] = pd.DataFrame([[pd.NA]*len(new_cols)], index=[0]).iloc[0:0]
    if not low_count_df.empty:
        key = [RawSchema.port, RawSchema.mode, RawSchema.region_of_residence]
        # Count how often each (p,q) occurs within each (x,y,z)
        counts = (
            travellers_data
                .groupby(key + [TransformedSchema.vehicle_type, TransformedSchema.duration2, 
                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                    ], dropna=False
                )[TransformedSchema.count_of_entries]
                .sum()
                .reset_index()
        )
        # For each (x,y,z), keep the (p,q) with the largest count
        # Tie-breaker here: highest n, then smallest p, then smallest q (you can change)
        impute_map = (
            counts
                .sort_values(key + [TransformedSchema.count_of_entries, TransformedSchema.vehicle_type, TransformedSchema.duration2, 
                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                    ], ascending=[True, True, True, False, True, True, True, True])
                .drop_duplicates(subset=key, keep="first")
                .drop(columns=TransformedSchema.count_of_entries)
        )
        low_count_df = low_count_df.merge(impute_map, on=key, how="left")
        temp_low_count_df = low_count_df[~low_count_df[[RawSchema.vehicle_type, RawSchema.duration2, 
            RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]
        if low_count_df[[RawSchema.vehicle_type, RawSchema.duration2, 
                RawSchema.purpose4, RawSchema.arriving_from]].isna().any().any():
                low_count_df = low_count_df[low_count_df[[RawSchema.vehicle_type, RawSchema.duration2, 
                    RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]
                low_count_df = low_count_df.drop(columns=["vehicle_type", "duration2", "purpose4", "arriving_from"])
                key = [RawSchema.mode, RawSchema.region_of_residence]
                # Count how often each (mode,region_of_residence) occurs within each (vehicle_type,duration2,purpose4,arriving_from)
                counts = (
                    travellers_data
                        .groupby(key + [TransformedSchema.vehicle_type, TransformedSchema.duration2, 
                            TransformedSchema.purpose4, TransformedSchema.arriving_from
                            ], dropna=False
                        )[TransformedSchema.count_of_entries]
                        .sum()
                        .reset_index()
                )
                # For each (vehicle_type,duration2,purpose4,arriving_from), keep the (mode,region_of_residence) with the largest count
                impute_map = (
                    counts
                        .sort_values(key + [TransformedSchema.count_of_entries, TransformedSchema.vehicle_type, TransformedSchema.duration2, 
                            TransformedSchema.purpose4, TransformedSchema.arriving_from
                            ], ascending=[True, True, False, True, True, True, True])
                        .drop_duplicates(subset=key, keep="first")
                        .drop(columns=TransformedSchema.count_of_entries)
                )
                low_count_df = low_count_df.merge(impute_map, on=key, how="left")
                #tmp_rows_to_imput = pd.concat([tmp_rows_to_imput, rows_to_impute[~rows_to_impute["proportion"].isnull()]], axis=0)
                temp_low_count_df = pd.concat([temp_low_count_df,low_count_df[~low_count_df[[RawSchema.vehicle_type, 
                RawSchema.duration2, RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]])
                if low_count_df[[RawSchema.vehicle_type, RawSchema.duration2, 
                    RawSchema.purpose4, RawSchema.arriving_from]].isna().any().any():
                        low_count_df = low_count_df[low_count_df[[RawSchema.vehicle_type, RawSchema.duration2, 
                            RawSchema.purpose4, RawSchema.arriving_from]].isna().any(axis=1)]
                        low_count_df = low_count_df.drop(columns=["vehicle_type", "duration2", "purpose4", "arriving_from"])
                        key = [RawSchema.mode]
                        # Count how often each (vehicle_type,region_of_residence) occurs within each (vehicle_type,duration2,purpose4,arriving_from)
                        counts = (
                            historical_data
                                .groupby(key + [RawSchema.vehicle_type, TransformedSchema.duration2, 
                                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                                    ], dropna=False
                                )[TransformedSchema.count_of_entries]
                                .sum()
                                .reset_index()
                        )
                        # For each (duration2,purpose4,arriving_from), keep the (vehicle_type,region_of_residence) with the largest count
                        impute_map = (
                            counts
                                .sort_values(key + [TransformedSchema.count_of_entries, RawSchema.vehicle_type, TransformedSchema.duration2, 
                                    TransformedSchema.purpose4, TransformedSchema.arriving_from
                                    ], ascending=[True, False, True, True, True, True])
                                .drop_duplicates(subset=key, keep="first")
                                .drop(columns=TransformedSchema.count_of_entries)
                        )
                        low_count_df = low_count_df.merge(impute_map, on=key, how="left")
                        temp_low_count_df = pd.concat([low_count_df, temp_low_count_df], axis=0)
    
        low_count_df = temp_low_count_df
            

    Stage1 = df[(df[RawSchema.count_of_travellers] > 5) & (df["variable"] == "ALL")]
    joint_distribution_stage1 = (
        travellers_data
        .groupby([TransformedSchema.data_source, TransformedSchema.vehicle_type, TransformedSchema.duration2, 
        TransformedSchema.purpose4, TransformedSchema.arriving_from ,TransformedSchema.port, 
        TransformedSchema.mode, 'region_of_residence',], as_index=False)[TransformedSchema.count_of_entries]
        .sum()
    )
    if not Stage1.empty:
        output_rows = []
        
        for group_tuple, group in Stage1.groupby([RawSchema.port, RawSchema.mode, 
            RawSchema.region_of_residence, "source"]):
            tmp_port, tmp_mode, tmp_region_of_residence, tmp_source = group_tuple
            
            # Preserve the original columns for the count adjustment section 
            orig_cols = list(group.columns)
            tmp_source = tmp_source.split(",")
            ref_slice = joint_distribution_stage1[
                (joint_distribution_stage1[TransformedSchema.data_source].isin(tmp_source)) &
                (joint_distribution_stage1[TransformedSchema.port] == tmp_port) & 
                (joint_distribution_stage1[TransformedSchema.mode] == tmp_mode) & 
                (joint_distribution_stage1['region_of_residence'] == tmp_region_of_residence)
            ]
            
            if ref_slice.empty:
                ref_slice = joint_distribution_stage1[
                (joint_distribution_stage1[TransformedSchema.data_source].isin(tmp_source)) &
                (joint_distribution_stage1[TransformedSchema.mode] == tmp_mode) & 
                (joint_distribution_stage1['region_of_residence'] == tmp_region_of_residence)
            ]

            joint_dist = (
                ref_slice
                .groupby([TransformedSchema.vehicle_type, TransformedSchema.duration2, TransformedSchema.purpose4, 
            TransformedSchema.arriving_from], as_index=False)[TransformedSchema.count_of_entries]
                .sum()
            )
            
            joint_dist['proportion'] = joint_dist[TransformedSchema.count_of_entries] / joint_dist[TransformedSchema.count_of_entries].sum()

            # Cross-merge
            group['_tmp_key'] = 1
            joint_dist['_tmp_key'] = 1
            joint_dist.drop(columns=['count_of_entries'], inplace=True)
            group_merged = pd.merge(group, joint_dist, on='_tmp_key').drop(columns='_tmp_key')

            # Apply proportion to split count
            group_merged['count'] = group_merged[RawSchema.count_of_travellers] * group_merged['proportion']

            # Note that the counts need to be adjusted to respect the original total.
            #This is done by adding the count difference to the last split category.
            group_merged['count'] = np.round(group_merged['count']).astype(int)
            group_merged = group_merged.loc[group_merged['count']!=0]
            #Since all the splited count_of_travellers are the same for a orig_cols group, we pick the first count_of_travellers
            orig_count = group_merged.groupby(orig_cols)[RawSchema.count_of_travellers].first()
            new_count = group_merged.groupby(orig_cols)['count'].sum()
            adjustment = (orig_count - new_count).astype(int)

            # Find the largest split category in each group
            adjust_rows = (
                group_merged.groupby(orig_cols)['count']
                .idxmax()
            )
            # Apply adjustment
            for key, idx in adjust_rows.items():
                adjustment_value = adjustment.loc[key]
                current_count = group_merged.loc[idx, 'count']

                new_count = current_count + adjustment_value

                group_merged.loc[idx, 'count'] = new_count
            
            if (group_merged['count'] < 0).any():
                logging.info("Although the adjustment is done on the largest count, in rare cases, the count column might still become negative.")
            
            group_merged[RawSchema.count_of_travellers] = group_merged['count']
            group_merged.drop(columns=['proportion', 'count'], inplace=True)
            group_merged = RawSchema(group_merged)

            output_rows.append(group_merged)

        Stage1 = pd.concat(output_rows, ignore_index=True)


    Stage2 = df[(df[RawSchema.count_of_travellers] > 5) & (df["variable"] != "ALL")]
    joint_distribution_stage2 = (
        travellers_data
        .groupby([TransformedSchema.vehicle_type, TransformedSchema.duration2, 
        TransformedSchema.purpose4, TransformedSchema.arriving_from ,TransformedSchema.port, 
        TransformedSchema.mode, 'region_of_residence',], as_index=False)[TransformedSchema.count_of_entries]
        .sum()
    )
    if not Stage2.empty:
        output_rows = []
        
        for group_tuple, group in Stage2.groupby([RawSchema.port, RawSchema.mode, 
            RawSchema.region_of_residence]):
            tmp_port, tmp_mode, tmp_region_of_residence = group_tuple
            
            # Preserve the original columns for the count adjustment section 
            orig_cols = list(group.columns)

            ref_slice = joint_distribution_stage2[
                (joint_distribution_stage2[TransformedSchema.port] == tmp_port) & 
                (joint_distribution_stage2[TransformedSchema.mode] == tmp_mode) & 
                (joint_distribution_stage2['region_of_residence'] == tmp_region_of_residence)
            ]
            
            if ref_slice.empty:
                ref_slice = joint_distribution_stage2[  
                (joint_distribution_stage2[TransformedSchema.mode] == tmp_mode) & 
                (joint_distribution_stage2['region_of_residence'] == tmp_region_of_residence)
            ]

            joint_dist = (
                ref_slice
                .groupby([TransformedSchema.vehicle_type, TransformedSchema.duration2, TransformedSchema.purpose4, 
            TransformedSchema.arriving_from], as_index=False)[TransformedSchema.count_of_entries]
                .sum()
            )
            
            joint_dist['proportion'] = joint_dist[TransformedSchema.count_of_entries] / joint_dist[TransformedSchema.count_of_entries].sum()

            # Cross-merge
            group['_tmp_key'] = 1
            joint_dist['_tmp_key'] = 1
            joint_dist.drop(columns=['count_of_entries'], inplace=True)
            group_merged = pd.merge(group, joint_dist, on='_tmp_key').drop(columns='_tmp_key')

            # Apply proportion to split count
            group_merged['count'] = group_merged[RawSchema.count_of_travellers] * group_merged['proportion']

            # Note that the counts need to be adjusted to respect the original total.
            #This is done by adding the count difference to the last split category.
            group_merged['count'] = np.round(group_merged['count']).astype(int)
            group_merged = group_merged.loc[group_merged['count']!=0]
            #Since all the splited count_of_travellers are the same for a orig_cols group, we pick the first count_of_travellers
            orig_count = group_merged.groupby(orig_cols)[RawSchema.count_of_travellers].first()
            new_count = group_merged.groupby(orig_cols)['count'].sum()
            adjustment = (orig_count - new_count).astype(int)

            # Find the largest split category in each group
            adjust_rows = (
                group_merged.groupby(orig_cols)['count']
                .idxmax()
            )
            # Apply adjustment
            for key, idx in adjust_rows.items():
                adjustment_value = adjustment.loc[key]
                current_count = group_merged.loc[idx, 'count']

                new_count = current_count + adjustment_value

                group_merged.loc[idx, 'count'] = new_count
            
            if (group_merged['count'] < 0).any():
                logging.info("Although the adjustment is done on the largest count, in rare cases, the count column might still become negative.")
            
            group_merged[RawSchema.count_of_travellers] = group_merged['count']
            group_merged.drop(columns=['proportion', 'count'], inplace=True)
            group_merged = RawSchema(group_merged)

            output_rows.append(group_merged)
            
        Stage2 = pd.concat(output_rows, ignore_index=True)
    
    
    df = pd.concat([low_count_df, Stage1, Stage2], axis=0, ignore_index=True)
    df = df.drop(columns=["variable", "value", "source"])
    df = RawSchema(df)
    ###########################################################
    # Deterministic Imputation Relevant to All Work Locations #
    ###########################################################
    df.loc[
        df[RawSchema.mode] == MODE.rail.value, RawSchema.vehicle_type
        ] = VEHICLE_TYPE.train.value
    
        #The stateless and refugee cases
    #  (country_of_residence still = 99999 after nghh_040 and
    #  with citizenship_code in ("XA","XXB", "XXC")) can be coded directly as:
    #  duration2 = 9 (Duration not available)
    #  purpose4 = 4 (Other purpose)
    #  arriving_from = 2 (Direct from another country)
    stateless_mask = (df[RawSchema.citizenship_code].isin(
        [CITIZENSHIP_CODE.XA.value, CITIZENSHIP_CODE.XXB.value, CITIZENSHIP_CODE.XXC.value,])
        ) & (df[RawSchema.country_of_residence] == '99999')
    df.loc[stateless_mask, RawSchema.duration2] = DURATION2.not_available.value
    df.loc[stateless_mask, RawSchema.purpose4] = PURPOSE4.other_purpose.value
    df.loc[stateless_mask, RawSchema.arriving_from] = ARRIVING_FROM.overseas_direct.value
    
    #For non-air travellers (mode = "Land", "Rail" or "Marine"), arriving_from can be coded as:
    non_air_mask =df[RawSchema.mode].isin([MODE.rail.value, MODE.marine.value, MODE.land.value])
    #arriving_from = 1 (U.S. Only) for Canadian and American travellers (country_of_residence in (11124,11840))
    df.loc[ df[RawSchema.country_of_residence].isin(['11124','11840']) &
         non_air_mask, RawSchema.arriving_from] = ARRIVING_FROM.us_only.value
    #For non-air travellers (mode = "Land", "Rail" or "Marine"), arriving_from can be coded as:
    #arriving_from = 3 (Overseas via the U.S.) for overseas travellers (country_of_residence not in (11124,11840))
    df.loc[~df[RawSchema.country_of_residence].isin(['11124','11840']) &
        non_air_mask, RawSchema.arriving_from] = ARRIVING_FROM.overseas_via_us.value

    ########################################################
    # Deterministic Imputation For Specific Work Locations #
    ########################################################
    nghh_imputation_deterministic = nghh_imputation[nghh_imputation["variable"] != "ALL"]
    updates = nghh_imputation_deterministic.pivot(
        index=nghhImputationSchema.wloc, columns=nghhImputationSchema.variable, values=nghhImputationSchema.value
        )
    df = df.set_index(RawSchema.wloc)
    df.update(updates)
    df = df.reset_index()

    # in order not to loose a data point using groupby:
    df[nghh_050_groupby_COLUMNS] = df[nghh_050_groupby_COLUMNS].fillna("")
    df = (
        df
        .groupby(nghh_050_groupby_COLUMNS, as_index=False, sort=False)[RawSchema.count_of_travellers]
        .sum()
    )
    
    nullable_columns = [RawSchema.wloc, RawSchema.wloc_name, RawSchema.gender, RawSchema.citizenship_code,
        RawSchema.citizenship_country, RawSchema.country_of_residence, RawSchema.port, 
        RawSchema.region_of_residence, RawSchema.duration2, RawSchema.purpose4, RawSchema.arriving_from]

    #convert the columns that we changed to blank, back to NA
    df[nullable_columns] = df[nullable_columns].replace("", pd.NA)

    df = RawSchema(df[nghh_050_COLUMNS])

    return df