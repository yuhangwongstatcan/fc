"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_030 business rule
"""
import pandas as pd

from config.api import Stage
from config.api import Mapping

from modules.utils.loaders import Loader

from datasource.nghh.schema import RawSchema, nghh_030_COLUMNS
from datasource.mapping.schema import ReferenceSchema as MappingSchema

from datetime import datetime


def nghh_030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add the Frontier Counts country of residence to the nghh raw data 
    by linking directly to the nghh mapping reference file.
    

    Args:
        df:
            A pandas dataframe without fc country of residence
    Returns:
        df:
            A pandas dataframe with FC country of residence added

        auxiliary_df:
            A pandas dataframe where country of residence is null
    """
    countries_nghh = pd.DataFrame(
            Loader.get_map_obj(
                Mapping.map__nghh__raw__citizenship_code__nghh__clean__country_of_residence
            )
    )[:-1]

    df = pd.merge(
            df, countries_nghh, left_on=RawSchema.citizenship_code, right_on="key", how="left"
        )


    df = df.rename(columns={MappingSchema.value: RawSchema.country_of_residence})

    
    delete_mask = ~pd.isna(df[RawSchema.citizenship_code]) & pd.isna(df[RawSchema.country_of_residence])

    # Remove any rows that could not be matched with mapping file
    df = df[~delete_mask]

    # Subset and reset data types 
    df = RawSchema(df[nghh_030_COLUMNS])

    return df
