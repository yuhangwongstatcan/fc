"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_040 business rule and validation
"""
from datetime import datetime

import numpy as np
import pandas as pd

from datasource.nghh.schema import RawSchema, ValidationSchema

from datasource.nghh.dim import (
    CITIZENSHIP_CODE,
)


def nghh_040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute country of residence for NGHH travellers with unknown or generic citizenship

    Args:
        df:
            A pandas dataframe with an unknown or generic citizenship.

    Returns:
        df:
            A pandas dataframe which has a country of residence assigned to
            each record.
    """
       
    # Expand the rows with count more than one and citizenship_code in ("","UNA","UNO","XX","EUE","XA", "XXB","XXC")
    expand_mask = ((df[RawSchema.citizenship_code].isin(
        [CITIZENSHIP_CODE.UNA.value,CITIZENSHIP_CODE.UNO.value,CITIZENSHIP_CODE.XX.value,CITIZENSHIP_CODE.XXX.value,CITIZENSHIP_CODE.EUE.value]
        )| df[RawSchema.citizenship_code].isna()) & 
            (df[RawSchema.count_of_travellers] > 1))

    expanded_rows = []

    for i in range(len(df)):
        row = df.iloc[i]
        if expand_mask.iloc[i]:  # If this row should be expanded
            repeat = int(row[RawSchema.count_of_travellers])
            for _ in range(repeat):
                new_row = row.copy()
                new_row[RawSchema.count_of_travellers] = 1  # Set count = 1 for expanded
                expanded_rows.append(new_row)
        else:
            expanded_rows.append(row.copy())  # Keep row as-is

    df = pd.DataFrame(expanded_rows).reset_index(drop=True)
    
    # For every row, assign the row a random number between 0
    # and 1 from a uniform distribution.
    # Set the seed equal to the 
    year, month, _ = df[RawSchema.date_of_entry].iloc[0].split("-")
    seed = int(year + month)
    rng = np.random.default_rng(seed)
    df["random_number"] = rng.random(len(df))

    # Placeholder column to hold the imputation method - this is a transient
    # column that only exists to pass auxiliary data to the validation that
    # calls this function.
    df["imputation_method"] = pd.NA

    #   _____  _   _  _____
    #  |    _|| | | ||    _|
    #  |   |_ | | | ||   |_ 
    #  |    _|| | | ||    _|
    #  |   |_ | |_| ||   |_ 
    #  |_____||_____||_____|
    #
    #If the citizenship_code="EU" and needs imputation, the imputed country_of_residence
    # needs to be in europe. (first digit of country_of_residence = 2))
    EUE_ref_df = df[
        (df[RawSchema.country_of_residence].astype(str).str[0] == '2') & 
        (df[RawSchema.citizenship_code]!= CITIZENSHIP_CODE.EUE.value)
        ]

    target_imputation_df = df[
        df[RawSchema.citizenship_code]==CITIZENSHIP_CODE.EUE.value]
    
    if target_imputation_df.shape[0]:
        for group_tuple, group in EUE_ref_df.groupby(
            [RawSchema.wloc, RawSchema.mode,], as_index=False,
        ):
            # Define the conditions under which nghh records can be imputed by
            # the reference distribution created on the current iteration.
            # Note that `group_tuple` contains the tuple of groupby values for
            # the current iteration. E.g. ('4974', 'Air') would indicate that for
            # the current iteration, we have wloc = 4974 and mode = "Air".
            NGHH_WLOC_MATCH = target_imputation_df[RawSchema.wloc] == group_tuple[0]
            NGHH_MODE_MATCH = target_imputation_df[RawSchema.mode] == group_tuple[1]
            IMPUTATION_TARGET = (NGHH_WLOC_MATCH & NGHH_MODE_MATCH)
            # If there does not exist at least one row in ipil_hwy that is
            # suitable for imputation, skip to the next imputation group.
            if not IMPUTATION_TARGET.any():
                continue
            # For each "outer" group, group by `country_of_residence` and sum
            # on `count_of_travellers `
            imputation_distribution = group.groupby(
                [
                    RawSchema.country_of_residence,
                    RawSchema.wloc,
                    RawSchema.mode,
                ],
                as_index=False,
            ).sum(RawSchema.count_of_travellers )
            # Calculate the proportion of travellers in each country
            imputation_distribution["proportion"] = (
                imputation_distribution[RawSchema.count_of_travellers]
                / imputation_distribution[RawSchema.count_of_travellers].sum()
            )
            # Sort on `country_of_residence`
            imputation_distribution = imputation_distribution.sort_values(
                RawSchema.country_of_residence
            )
            # Generate upper/lower bounds for the imputation distribution so
            # that we can assign a country based on which interval each row's
            # random number falls into.
            imputation_distribution["upper_bound"] = imputation_distribution[
                "proportion"
            ].cumsum()
            imputation_distribution["lower_bound"] = (
                imputation_distribution["proportion"].cumsum().shift(fill_value=0)
            )

            # For each row of the imputation distribution, we need to evaluate
            # which rows of nghh should have the current row's country
            # assigned to them.

            for _, row in imputation_distribution.iterrows():
                # Generate the conditions for the upper/lower bounds of the
                # current row of the imputation distribution.
                GT_LOWER_BOUND = df["random_number"] >= row["lower_bound"]
                LT_UPPER_BOUND = df["random_number"] < row["upper_bound"]
                # Store the imputed value followed by the imputation method
                df.loc[
                    IMPUTATION_TARGET & GT_LOWER_BOUND & LT_UPPER_BOUND,
                    [RawSchema.country_of_residence, "imputation_method",],
                ] = [
                    row[RawSchema.country_of_residence],
                    "Europe",
                ]

    #   _____  _____  _   _  _____  _____
    #  |  _  ||_   _|| | | ||    _||  _  |
    #  | | | |  | |  | |_| ||   |_ | |_| |
    #  | |_| |  | |  |  _  ||    _||    _|
    #  |     |  | |  | | | ||   |_ | |\ \
    #  |_____|  |_|  |_| |_||_____||_| \_\
    #

    mask = (df[RawSchema.citizenship_code].isin([
        CITIZENSHIP_CODE.UNA.value,CITIZENSHIP_CODE.UNO.value,CITIZENSHIP_CODE.XX.value, CITIZENSHIP_CODE.XXX.value,
        CITIZENSHIP_CODE.EUE.value,CITIZENSHIP_CODE.XA.value,CITIZENSHIP_CODE.XXB.value,CITIZENSHIP_CODE.XXC.value
        ])| df[RawSchema.citizenship_code].isna())
    ref_df = df[~mask]
    
    # For each unique combination of `wloc` and `mode`, we want to SUM
    # and GROUP BY country_of_residence, and use the resulting frequency
    # distribution as the imputation distribution for nghh records who match
    # the same `wloc` and `mode`.
    target_imputation_df = df[
        df[RawSchema.citizenship_code].isin([
            CITIZENSHIP_CODE.UNA.value,CITIZENSHIP_CODE.UNO.value,CITIZENSHIP_CODE.XX.value, CITIZENSHIP_CODE.XXX.value])|
        df[RawSchema.citizenship_code].isna()
        ]

    if target_imputation_df.shape[0]:
        for group_tuple, group in ref_df.groupby(
            [RawSchema.wloc, RawSchema.mode], as_index=False,
        ):
            # Define the conditions under which nghh records can be imputed by
            # the reference distribution created on the current iteration.
            # Note that `group_tuple` contains the tuple of groupby values for
            # the current iteration. E.g. ('4974', 'Air') would indicate that for
            # the current iteration, we have wloc = 4974 and mode = "Air".
            NGHH_WLOC_MATCH = target_imputation_df[RawSchema.wloc] == group_tuple[0]
            NGHH_MODE_MATCH = target_imputation_df[RawSchema.mode] == group_tuple[1]
            IMPUTATION_TARGET = (NGHH_WLOC_MATCH & NGHH_MODE_MATCH)
            # If there does not exist at least one row in ipil_hwy that is
            # suitable for imputation, skip to the next imputation group.
            if not IMPUTATION_TARGET.any():
                continue
            # For each "outer" group, group by `country_of_residence` and sum
            # on `count_of_travellers `
            imputation_distribution = group.groupby(
                [
                    RawSchema.country_of_residence,
                    RawSchema.wloc,
                    RawSchema.mode,
                ],
                as_index=False,
            ).sum(RawSchema.count_of_travellers )
            # Calculate the proportion of travellers in each country
            imputation_distribution["proportion"] = (
                imputation_distribution[RawSchema.count_of_travellers]
                / imputation_distribution[RawSchema.count_of_travellers].sum()
            )
            # Sort on `country_of_residence`
            imputation_distribution = imputation_distribution.sort_values(
                RawSchema.country_of_residence
            )
            # Generate upper/lower bounds for the imputation distribution so
            # that we can assign a country based on which interval each row's
            # random number falls into.
            imputation_distribution["upper_bound"] = imputation_distribution[
                "proportion"
            ].cumsum()
            imputation_distribution["lower_bound"] = (
                imputation_distribution["proportion"].cumsum().shift(fill_value=0)
            )

            # For each row of the imputation distribution, we need to evaluate
            # which rows of nghh should have the current row's country
            # assigned to them.

            for _, row in imputation_distribution.iterrows():
                # Generate the conditions for the upper/lower bounds of the
                # current row of the imputation distribution.
                GT_LOWER_BOUND = df["random_number"] >= row["lower_bound"]
                LT_UPPER_BOUND = df["random_number"] < row["upper_bound"]
                # Store the imputed value followed by the imputation method
                df.loc[
                    IMPUTATION_TARGET & GT_LOWER_BOUND & LT_UPPER_BOUND,
                    [RawSchema.country_of_residence, "imputation_method",],
                ] = [
                    row[RawSchema.country_of_residence],
                    "unique_wloc_and_mode", 
                ]

       
    #       _    _     _
    #      / \  | |   | |
    #     / _ \ | |   | |
    #    / ___ \| |___| |___
    #   /_/   \_\_____|_____|

    #   ____    _    _   _    _    ____    _
    #  / ___|  / \  | \ | |  / \  |  _ \  / \
    # | |     / _ \ |  \| | / _ \ | | | |/ _ \
    # | |___ / ___ \| |\  |/ ___ \| |_| / ___ \
    #  \____/_/   \_\_| \_/_/   \_\____/_/   \_\

    # If there are still rows that are not imputed, use data from all of
    # Canada as a reference distribution. If no such match is found, simply
    # assign '99999' as the country_of_residence.

    # Note that some rows may have already been imputed in the previous
    # imputation section. We are running these imputations in order to have
    # highest data quality, so a previous imputation should *not* be
    # overwritten by a subsequent imputation.

    IMPUTATION_TARGET = (
        (df[RawSchema.citizenship_code].isin([
            CITIZENSHIP_CODE.UNA.value,CITIZENSHIP_CODE.UNO.value,CITIZENSHIP_CODE.XX.value,CITIZENSHIP_CODE.XXX.value])&
        df[RawSchema.country_of_residence]== '99999') | (df[RawSchema.country_of_residence].isna())
        )

    if IMPUTATION_TARGET.any():

        imputation_distribution = ref_df.groupby(
            [
                RawSchema.country_of_residence,
            ],
            as_index=False,
        ).sum(RawSchema.count_of_travellers )
        # Calculate the proportion of travellers in each country
        imputation_distribution["proportion"] = (
            imputation_distribution[RawSchema.count_of_travellers]
            / imputation_distribution[RawSchema.count_of_travellers].sum()
        )
        # Sort on `country_of_residence`
        imputation_distribution = imputation_distribution.sort_values(
            RawSchema.country_of_residence
        )
        # Generate upper/lower bounds for the imputation distribution so
        # that we can assign a country based on which interval each row's
        # random number falls into.
        imputation_distribution["upper_bound"] = imputation_distribution[
            "proportion"
        ].cumsum()
        imputation_distribution["lower_bound"] = (
            imputation_distribution["proportion"].cumsum().shift(fill_value=0)
        )

        # For each row of the imputation distribution, we need to evaluate
        # which rows of nghh should have the current row's country
        # assigned to them.

        for _, row in imputation_distribution.iterrows():
            # Generate the conditions for the upper/lower bounds of the
            # current row of the imputation distribution.
            GT_LOWER_BOUND = df["random_number"] >= row["lower_bound"]
            LT_UPPER_BOUND = df["random_number"] < row["upper_bound"]
            # Store the imputed value followed by the imputation method
            df.loc[
                IMPUTATION_TARGET & GT_LOWER_BOUND & LT_UPPER_BOUND,
                [RawSchema.country_of_residence, "imputation_method",],
            ] = [
                row[RawSchema.country_of_residence],
                "All_Canada",
            ]

    IMPUTATION_TARGET_EU = (
        df[RawSchema.citizenship_code].isin([CITIZENSHIP_CODE.EUE.value])&
        df[RawSchema.country_of_residence]== '29999'
        )



    if IMPUTATION_TARGET_EU.any():

        imputation_distribution = EUE_ref_df.groupby(
            [
                RawSchema.country_of_residence,
            ],
            as_index=False,
        ).sum(RawSchema.count_of_travellers )
        # Calculate the proportion of travellers in each country
        imputation_distribution["proportion"] = (
            imputation_distribution[RawSchema.count_of_travellers]
            / imputation_distribution[RawSchema.count_of_travellers].sum()
        )
        # Sort on `country_of_residence`
        imputation_distribution = imputation_distribution.sort_values(
            RawSchema.country_of_residence
        )
        # Generate upper/lower bounds for the imputation distribution so
        # that we can assign a country based on which interval each row's
        # random number falls into.
        imputation_distribution["upper_bound"] = imputation_distribution[
            "proportion"
        ].cumsum()
        imputation_distribution["lower_bound"] = (
            imputation_distribution["proportion"].cumsum().shift(fill_value=0)
        )

        # For each row of the imputation distribution, we need to evaluate
        # which rows of nghh should have the current row's country
        # assigned to them.

        for _, row in imputation_distribution.iterrows():
            # Generate the conditions for the upper/lower bounds of the
            # current row of the imputation distribution.
            GT_LOWER_BOUND = df["random_number"] >= row["lower_bound"]
            LT_UPPER_BOUND = df["random_number"] < row["upper_bound"]
            # Store the imputed value followed by the imputation method
            df.loc[
                IMPUTATION_TARGET_EU & GT_LOWER_BOUND & LT_UPPER_BOUND,
                [RawSchema.country_of_residence, "imputation_method",],
            ] = [
                row[RawSchema.country_of_residence],
                "All_Canada_Eu",
            ]
            

    # Pass an auxiliary df containing the required data for the validation for
    # this function.
    auxiliary_df = df[~df["imputation_method"].isna()]

    df = df.drop(
        [
            "random_number",
            "imputation_method",
        ],
        axis=1,
    )

    auxiliary_df = auxiliary_df.drop(
        [
            "random_number",
            "imputation_method",
        ],
        axis=1,
    )

    return df, auxiliary_df


def nghh_v040(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule nghh_040

    Args:
        input:
            a pandas dataframe containing records that had an imputation 
            for the country_of_residence column
    Returns:
        A summary of the imputation for country of residence for use in the
        validation dashboards.
    """

    mapping_dict = {
        CITIZENSHIP_CODE.UNO.value: 'United Nations', 
        CITIZENSHIP_CODE.UNA.value: 'United Nations', 
        CITIZENSHIP_CODE.XX.value: 'Unspecified', 
        CITIZENSHIP_CODE.XXX.value: 'Unspecified', 
        CITIZENSHIP_CODE.EUE.value: 'European Union'}
    auxiliary_df[ValidationSchema.unknown_citizenship] = auxiliary_df[RawSchema.citizenship_code].map(mapping_dict)
    auxiliary_df.loc[auxiliary_df[RawSchema.citizenship_code].isna(), ValidationSchema.unknown_citizenship] = "Blank"
    validation_df = auxiliary_df.rename(
        columns={RawSchema.date_of_entry: ValidationSchema.date}
        )

    validation_df = validation_df[
        [
            ValidationSchema.date,
            ValidationSchema.unknown_citizenship,
            ValidationSchema.wloc,
            ValidationSchema.wloc_name,
            ValidationSchema.country_of_residence,
            ValidationSchema.count_of_travellers,
        ]
    ]
    validation_df = validation_df.groupby(
        by=[
            ValidationSchema.date,
            ValidationSchema.unknown_citizenship,
            ValidationSchema.wloc,
            ValidationSchema.wloc_name,
            ValidationSchema.country_of_residence,
        ],
        dropna=False,
        as_index=False,
    ).sum(ValidationSchema.count_of_travellers)
    
    return ValidationSchema(validation_df)