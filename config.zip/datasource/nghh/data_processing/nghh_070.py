"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_070 business rule
"""

import pandas as pd

from datasource.nghh.schema import CleanSchema
from datasource.vehicles.schema import (
    TransformedSchema,
    TRANSFORMED_GROUPBY, 
    TRANSFORMED_COLUMNS,
)

from datasource.vehicles.dim import (
    PLATE_REGION,
    PLATE_COUNTRY,
    MODE,
    DATA_SOURCE,
)

def nghh_070(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generate the NGHH contribution to the vehicles table in the correct schema.

    Args:
        df:
            A pandas dataframe 

    Returns:
        df:
            A transformed pandas dataframe 
    """
    # Extract the vehicle-level records (gender = "VEHICLE")
    df = df[df[CleanSchema.gender] == "VEHICLE"]
    # The year, month and day columns are extracted from the date variable.
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        CleanSchema.date_of_entry
    ].str.split("-", expand=True)
    df[TransformedSchema.month] = df[TransformedSchema.month].replace(
        {r"0(\d)": r"\1"}, regex=True
    )
    df[TransformedSchema.day] = df[TransformedSchema.day].replace(
        {r"0(\d)": r"\1"}, regex=True
    )
    # The port column is carried forward from the clean nghh file.
    df[TransformedSchema.port] = df[CleanSchema.port]
    # Mode for vehicles is Land
    df[TransformedSchema.mode] = MODE.land.value
    # The vehicle_type column is carried forward from the clean nghh file.
    df[TransformedSchema.vehicle_type] = df[CleanSchema.vehicle_type]
    df.loc[df[CleanSchema.country_of_residence] == "11124", TransformedSchema.plate_country] = PLATE_COUNTRY.canada.value
    df.loc[df[CleanSchema.country_of_residence] == "11840", TransformedSchema.plate_country] = PLATE_COUNTRY.united_states.value
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value
    df[TransformedSchema.work_location] = df[CleanSchema.wloc]
    df[TransformedSchema.data_source] = DATA_SOURCE.NGHH.value
    # Take the sum of count_of_travellers from the clean nghh file
    df = (df
        .groupby(by=TRANSFORMED_GROUPBY, dropna=False,)[
        CleanSchema.count_of_travellers].sum().reset_index()
        .rename(columns={"count_of_travellers": "count_of_entries"})
    )
    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS
    
    # Reorder the re-named columns
    df = df[TRANSFORMED_COLUMNS]

    # Cast correct type to count of entries
    df.loc[:, TransformedSchema.count_of_entries] = df[
        TransformedSchema.count_of_entries
    ].astype("Int64")

    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]

    # Sort entries from left to right
    df = df.sort_values(TRANSFORMED_COLUMNS, ascending=True,)

    df = TransformedSchema(df)

    return df