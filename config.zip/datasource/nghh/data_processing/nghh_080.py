"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_080 business rule
"""

import pandas as pd

from datasource.nghh.schema import CleanSchema
from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_GROUPBY, 
    TRANSFORMED_COLUMNS,
)

from datasource.nghh.dim import MODE as NGHH_MODE

from datasource.travellers.dim import (
    VEHICLE_TYPE,
    PLATE_REGION,
    PLATE_COUNTRY,
    MODE,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    DATA_SOURCE,
    COUNTRY_OF_RESIDENCE,
)


def nghh_080(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generate the NGHH contribution to the travellers table in the correct schema.
    Args:
        df:
            A pandas dataframe 

    Returns:
        df:
            A transformed pandas dataframe 
    """
    # Extract the vehicle-level records (gender = "VEHICLE")
    df = df[df[CleanSchema.gender] != "VEHICLE"]

    # The year, month and day columns are extracted from the date variable.
    df[[TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]] = df[
        CleanSchema.date_of_entry
    ].str.split("-", expand=True)
    df[TransformedSchema.month] = df[TransformedSchema.month].replace(
        {r"0(\d)": r"\1"}, regex=True
    )
    df[TransformedSchema.day] = df[TransformedSchema.day].replace(
        {r"0(\d)": r"\1"}, regex=True
    )

    # The port column is carried forward from the clean nghh file.
    df[TransformedSchema.port] = df[CleanSchema.port]

    # Mode:
    df.loc[
        df[CleanSchema.mode]==NGHH_MODE.air.value, TransformedSchema.mode
        ] = MODE.air.value
    df.loc[
        df[CleanSchema.mode].isin([
            NGHH_MODE.land.value, NGHH_MODE.rail.value,
        ]), TransformedSchema.mode] = MODE.land.value
    df.loc[
        df[CleanSchema.mode]==NGHH_MODE.marine.value, TransformedSchema.mode
        ] = MODE.water.value
    # The vehicle_type column is carried forward from the clean nghh file.
    df[TransformedSchema.vehicle_type] = df[CleanSchema.vehicle_type]
    # The plate_country and plate_region columns are coded as 9 ("Not applicable") and "NA" ("Not applicable") respectively.
    df[TransformedSchema.plate_country] = PLATE_COUNTRY.not_available.value
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value
    # The arriving_from is carried forward from the clean nghh file.
    df[TransformedSchema.arriving_from] = df[CleanSchema.arriving_from]
    # The country_of_residence is carried forward from the clean nghh file.
    df[TransformedSchema.country_of_residence] = df[CleanSchema.country_of_residence]
    # The purpose9 and purpose4
    df[TransformedSchema.purpose4] = df[CleanSchema.purpose4]
    df.loc[df[TransformedSchema.purpose4] == "1", TransformedSchema.purpose9] = PURPOSE9.visit.value
    df.loc[df[TransformedSchema.purpose4] == "2", TransformedSchema.purpose9] = PURPOSE9.crew.value
    df.loc[df[TransformedSchema.purpose4] == "3", TransformedSchema.purpose9] = PURPOSE9.work.value
    df.loc[df[TransformedSchema.purpose4] == "4", TransformedSchema.purpose9] = PURPOSE9.other_purpose.value
    df.loc[(df[TransformedSchema.purpose4] == "4") & (
        df[CleanSchema.wloc].isin(["4490", "3010"])
        ), TransformedSchema.purpose9] = PURPOSE9.military.value
    df.loc[df[CleanSchema.citizenship_code].isin(["XA", "XXB", "XXC"]), [
        TransformedSchema.purpose9, TransformedSchema.purpose4]] = [
            PURPOSE9.immigration.value, PURPOSE4.other_purpose.value
        ]
    # The duration2 column is copied from the imputed duration2 variable.
    df[TransformedSchema.duration2] = df[CleanSchema.duration2]
    # The duration3 and duration5 columns are coded as 99 ("Not available") and 99 ("Not available") respectively.
    df[TransformedSchema.duration3] = DURATION3.not_available.value
    df[TransformedSchema.duration5] = DURATION5.not_available.value

    # The traveller_type column is derived from other columns, namely PURPOSE4 and VEHICLE_TYPE
    non_tourism_mask = (df[TransformedSchema.purpose4] == PURPOSE4.other_purpose.value) | (
       df[TransformedSchema.purpose4] == PURPOSE4.work.value) | (
          (df[TransformedSchema.purpose4] == PURPOSE4.crew.value) & 
          (df[TransformedSchema.vehicle_type].isin([
              VEHICLE_TYPE.commercial_aircraft.value,
              VEHICLE_TYPE.cargo_aircraft.value,
              VEHICLE_TYPE.truck.value,
              VEHICLE_TYPE.bus.value,
              VEHICLE_TYPE.train.value,
              VEHICLE_TYPE.cruise_ship.value,
              VEHICLE_TYPE.cargo_ship.value,
              VEHICLE_TYPE.ferry_pedestrian.value,
              VEHICLE_TYPE.ferry_private_vehicle.value,
              VEHICLE_TYPE.ferry_unknown.value]))
         )
    df.loc[non_tourism_mask, TransformedSchema.traveller_type] = TRAVELLER_TYPE.other_traveller.value #Other traveller

    df.loc[~non_tourism_mask & 
        (df[TransformedSchema.duration2]==DURATION2.same_day.value), TransformedSchema.traveller_type
        ] = TRAVELLER_TYPE.excursionist.value #Excursionist

    df.loc[~non_tourism_mask & 
        (df[TransformedSchema.duration2]==DURATION2.overnight.value), TransformedSchema.traveller_type
        ] = TRAVELLER_TYPE.tourist.value #Tourist
    
    # The work_location column is copied from the wloc variable.
    df[TransformedSchema.work_location] = df[CleanSchema.wloc]
    # The data_source column is coded as 19 ("NGHH") in all cases for this data source.
    df[TransformedSchema.data_source] = DATA_SOURCE.NGHH.value
    # Take the sum of count_of_travellers from the clean nghh file
    df = (df
        .groupby(by=TRANSFORMED_GROUPBY, dropna=False,)[
        CleanSchema.count_of_travellers].sum().reset_index()
        .rename(columns={"count_of_travellers": "count_of_entries"})
    )
    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS
    
    # Reorder the re-named columns
    df = df[TRANSFORMED_COLUMNS]

    # Cast correct type to count of entries
    df.loc[:, TransformedSchema.count_of_entries] = df[
        TransformedSchema.count_of_entries
    ].astype("Int64")

    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]

    # Sort entries from left to right
    df = df.sort_values(TRANSFORMED_COLUMNS, ascending=True,)

    df = TransformedSchema(df)

    return df