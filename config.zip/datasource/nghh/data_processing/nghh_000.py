"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**
Implements the nghh_000 business rule and validation
"""
import pandas as pd
import numpy as np
import re

from modules.utils.data_manipulation import validate_dimensions

from datasource.nghh.schema import RawSchema, CleanSchema, ValidationSchema, nghh_000_COLUMNS

from config.api import DataSource

def nghh_000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Extract work location and citizenship codes from NGHH data.

    Args:
        df:
            A pandas dataframe
    Returns:
        a pandas dataframe with extracted work location and citizenship codes
    """
    # Process 'port_of_entry' column
    df[RawSchema.wloc] = df[RawSchema.port_of_entry].astype(str).str[:4]
    df[RawSchema.wloc_name] = df[RawSchema.port_of_entry].astype(str).str.split('-', n=1).str[1].str.strip()
    
    # Process 'citizenship' column
    def split_citizenship(value):
        # Handle missing or error-like values
        if pd.isna(value) or value in ["#NAME?", "#Name", "Unknown","-2 - Unknown","-2 - Other", "-2 - #Name?"]:
            return pd.NA, pd.NA

        value = str(value)
        # Split only on the first ' - ' (with optional spaces around dash)
        # Use regex split to allow for whitespace around the dash
        parts = re.split(r'\s*-\s*', value, maxsplit=1)

        if len(parts) == 2:
            return parts[0], parts[1]
        else:
            return parts[0], pd.NA
    
    citizenship_split = df[RawSchema.citizenship].apply(split_citizenship)
    df[RawSchema.citizenship] = df[RawSchema.citizenship].str.rstrip(".")
    df[RawSchema.citizenship_code] = citizenship_split.str[0]
    df[RawSchema.citizenship_country] = citizenship_split.str[1]
    
    df = RawSchema(df[nghh_000_COLUMNS])

    auxiliary_df = df.copy()

    return df, auxiliary_df


def nghh_v000(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule nghh_000:
        Summary of Unexpected Values - NGHH

    Args:
        input:
            a pandas dataframe containing records that possibly contain
            invalid dimension column values
    Returns:
        A pandas dataframe with validated dimension columns
    """
    cname_loc = RawSchema.port_of_entry
    cname_date = RawSchema.date_of_entry

    validation_df = validate_dimensions(
        auxiliary_df,
        RawSchema,
        ValidationSchema,
        cname_loc,
        cname_date,
        DataSource.nghh,
    )

    validation_df = validation_df.rename(
            columns={RawSchema.date_of_entry: ValidationSchema.date}
            )
    
    validation_df = validation_df.replace(["#NAME?", "#Name", "Unknown","-2 - Unknown","-2 - Other", "-2 - #Name?"], pd.NA)
    validation_df = validation_df.dropna()

    return ValidationSchema(validation_df)