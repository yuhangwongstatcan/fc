"""
**Author(s)**

    Nika Karimi Jashni (nika.karimijashni@statcan.gc.ca)

**Created:** Dec 2025

**Description:**

The pipeline definitions for the NGHH data source.
Two pipelines are defined in this module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`
"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID
from modules.pipeline import validation_writer

from config.api import Stage
from config.api import DataSource
from config.api import S3

from datasource.nghh.data_processing import *
from datasource.nghh.schema import RawSchema, CleanSchema
from datasource.nghh.dim import *

from datasource.vehicles.schema import TransformedSchema as VehiclesSchema
from datasource.travellers.schema import TransformedSchema as TravellersSchema


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the NGHH data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data file created by the loader
        df = Loader.query(Stage.RAW, self.datasource, year=self.year, month=self.month)

        # Make sure that the df adheres to the raw schema
        df = RawSchema(df)
        
        # Extract work location and citizenship codes from NGHH data.
        print("   1.Starting processing nghh_000")
        df, auxiliary_df = nghh_000(df)
        # VALIDATION: Summary of Unexpected Values - NGHH
        validation_df = nghh_v000(df, auxiliary_df)
        validation_writer(validation_df, nghh_v000, self.datasource, self.date)
        logging.info("Finished processing nghh_000")
        print("   1.Finished processing nghh_000")

        # Impute mode of transportation for NGHH travellers with unknown mode
        print("   2.Starting processing nghh_005")
        df, auxiliary_df = nghh_005(df)
        # VALIDTION: Summary of NGHH Mode of Transportation Imputation
        validation_df = nghh_v005(df, auxiliary_df)
        validation_writer(validation_df, nghh_v005, self.datasource, self.date)
        logging.info("Finished processing nghh_005")
        print("   2.Finished processing nghh_005")

        # Remove NGHH records with unexpected or unaccepted work locations
        print("   3.Starting processing nghh_010")
        df, auxiliary_df = nghh_010(df)
        # VALIDTION: Summary of NGHH Work Location Issues
        validation_df = nghh_v010(df, auxiliary_df)
        validation_writer(validation_df, nghh_v010, self.datasource, self.date)
        logging.info("Finished processing nghh_010")
        print("   3.Finished processing nghh_010")

        # Adjust NGHH Volumes to Account for IPIL Highway MOB Lanes
        print("   4.Starting processing nghh_020")
        df = nghh_020(df)
        logging.info("Finished processing nghh_020")
        print("   4.Finished processing nghh_020")
        
        # Add Frontier Counts country information to NGHH data
        print("   5.Starting processing nghh_030")
        df = nghh_030(df)
        logging.info("Finished processing nghh_030")
        print("   5.Finished processing nghh_030")

        # Impute country of residence for NGHH travellers with unknown citizenship
        print("   6.Starting processing nghh_040")
        df, auxiliary_df = nghh_040(df)
        # VALIDTION: Summary of NGHH Country Imputation
        validation_df = nghh_v040(df, auxiliary_df)
        validation_writer(validation_df, nghh_v040, self.datasource, self.date)
        logging.info("Finished processing nghh_040")
        print("   6.Finished processing nghh_040")

        # Impute vehicle type, trip duration, trip purpose and arriving from for NGHH travellers
        print("   7.Starting processing nghh_050")
        df = nghh_050(df)
        logging.info("Finished processing nghh_050")
        print("   7.Finished processing nghh_050")

        # Impute number of vehicles in NGHH
        print("   8.Starting processing nghh_060")
        df = nghh_060(df)
        logging.info("Finished processing nghh_060")
        print("   8.Finished processing nghh_060")

        # Make sure the output dataframe adheres to the clean schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        nghh_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=DataSource.nghh,
            basename=S3.get_s3_basename(
                Stage.CLEAN, DataSource.nghh, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.nghh.value] = nghh_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the NGHH data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        df = Loader.query(
            Stage.CLEAN, self.datasource, year=self.year, month=self.month
        )

        # Make sure that the input df adheres to the clean schema
        df = CleanSchema(df)

        # Perform the tranformation to get the vehicles table
        print("   1.Starting processing nghh_070")
        vehicles=nghh_070(df)
        logging.info("Finished processing nghh_070")
        print("   1.Finished processing nghh_070")
        vehicles = VehiclesSchema(vehicles)

        # Perform the tranformation to get the travellers table
        print("   2.Starting processing nghh_080")
        travellers = nghh_080(df)
        logging.info("Finished processing nghh_080")
        print("   2.Finished processing nghh_080")
        # Make sure that the travellers df adheres to the travellers schema
        travellers = TravellersSchema(travellers)

        vehicles_output = PipelineOutput(
            data=vehicles,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.vehicles,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )

        # Save travellers outputs to dictionary
        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, DataSource.nghh, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.vehicles.value] = vehicles_output
        self.outputs[DataSource.travellers.value] = travellers_output
