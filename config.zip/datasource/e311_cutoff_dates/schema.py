"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        E311_CUTOFF_DATES file which defines the date after which E311 data
        will no longer be accepted for each production month.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.types import Padded1ZeroStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the E311_CUTOFF_DATES reference file.
    """

    year: Series[pa.String] = pa.Field(
        description="Year that the cutoff date applies to.",
        coerce=True,
    )
    month: Series[Padded1ZeroStringType] = pa.Field(
        description="Month that the cutoff date applies to.",
        coerce=True,
    )
    cutoff_date: Series[pa.String] = pa.Field(
        description="Date after which E311 cards will no longer be considered in official statistics for the indicated month.",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.year, ReferenceSchema.month]
