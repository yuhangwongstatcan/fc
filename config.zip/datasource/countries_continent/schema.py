"""
    Program: schema.py

    Author: Tristan Garry, tristan.garry@statcan.gc.ca

    Created: July 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        COUNTRIES reference file.
"""
import pandera as pa
from pandera.typing import Series

from datasource.countries.dim import CONTINENT

from datasource.common.types import SafeIntToStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the CONTINENT reference file.
    """

    continent: Series[SafeIntToStringType] = pa.Field(
        description="""A 1-digit code that identifies the continent the country belongs to according to UNWTO's
        classification""",
        isin=CONTINENT.list(),
        coerce=True,
    )
    continent_en: Series[pa.String] = pa.Field(
        description="Name of continent in English according to UNWTO's classification",
        coerce=True,
    )
    continent_fr: Series[pa.String] = pa.Field(
        description="Name of continent in French according to UNWTO's classification",
        coerce=True,
    )
    table_24100055: Series[SafeIntToStringType] = pa.Field(
        description="Continent code in NDM table 55",
        coerce=True,
    )
    table_24100056: Series[SafeIntToStringType] = pa.Field(
        description="Continent code in NDM table 56",
        coerce=True,
    )
