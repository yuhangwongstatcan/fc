"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema 
        verification of the SA_PARAMETERS data source.
"""

import pandera as pa
from pandera.typing import Series


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for SA_PARAMETERS
    """

    YEAR: Series[pa.String] = pa.Field(
        description="Production year",
        coerce=True,
    )
    MONTH: Series[pa.String] = pa.Field(
        description="Production month",
        coerce=True,
    )
    NUM_PERIODS: Series[pa.INT64] = pa.Field(
        description="Number of months that can be revised. Provided by Time Series team.",
        coerce=True,
    )
    FORCE: Series[pa.String] = pa.Field(
        description="Yes or no. Provided by Time Series team.",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [
            ReferenceSchema.YEAR,
            ReferenceSchema.MONTH,
            ReferenceSchema.NUM_PERIODS,
            ReferenceSchema.FORCE,
        ]
