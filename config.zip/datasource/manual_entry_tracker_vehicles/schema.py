"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define the schema model for the MANUAL ENTRY TRACKER VEHICLES reference file.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.dim import VEHICLE_TYPE
from datasource.travellers.dim import DATA_SOURCE

from datasource.common.types import SafeIntToStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Schema model for the manual entry vehicles tracker reference file.
    """

    data_source: Series[SafeIntToStringType] = pa.Field(
        description="Canada Border Services Agency data source",
        isin=DATA_SOURCE.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    port: Series[pa.String] = pa.Field(
        description="Statistics Canada port of the border crossing",
        str_matches=r"\d{5}",
        coerce=True,
    )
    vehicle_type: Series[SafeIntToStringType] = pa.Field(
        description="Vehicle type",
        isin=VEHICLE_TYPE.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [
            ReferenceSchema.data_source,
            ReferenceSchema.port,
            ReferenceSchema.vehicle_type,
        ]
