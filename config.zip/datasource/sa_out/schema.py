"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for the SA_OUT data source.
"""

import pandera as pa
from pandera.typing import Series


class AggregatedSchema(pa.SchemaModel):
    """
    Schema for the SA_OUT aggregate files.
    """

    SERIES: Series[pa.String] = pa.Field(
        description="Name of the series.",
        coerce=True,
    )
    DATE: Series[pa.String] = pa.Field(
        description="Date in format YYYYMM.",
        coerce=True,
    )
    VALUE: Series[pa.INT64] = pa.Field(
        description="Input value for the series.",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [AggregatedSchema.SERIES, AggregatedSchema.DATE]
