"""
    Program: schema.py

    Author: Nika Karimi Jashni, nika.karimijashni@statcan.gc.ca

    Created: February 2025

    Purpose:
        Define schema models using pandera for schema verification of the
        pik_airports reference file.
"""

import pandera as pa
from pandera.typing import Series

from datasource.pik_airports.dim import WLOC

from datasource.common.types import SafeIntToStringType

class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the pik_airports reference file.
    """

    WLOC: Series[SafeIntToStringType] = pa.Field(
        description="Code of airport", isin=WLOC.list(), coerce=True,
    )
    Airport_Name: Series[pa.String] = pa.Field(
        description="Name of airport", coerce=True,
    )
    Province: Series[pa.String] = pa.Field(
        description="Province of airport", coerce=True,
    )
