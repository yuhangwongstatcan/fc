"""
    Program: dim.py

    Author: Nika Karimi Jashni, nika.karimijashni@statcan.gc.ca

    Created: February 2025

    Purpose:
        Create enumerable classes of dimensions for the pik_airports
        files to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class WLOC(AutoEnum):
    Halifax = "7593"
    Jean_Lesage_Airport = "3123"
    Montreal_Pierre_Elliot_Trudeau = "3961"
    Macdonald_Cartier_International_Airport = "4312"
    Toronto_International_Airport_T3 = "4974"
    Toronto_International_Airport_T1 = "4971"
    Toronto_Seaport = "4952"
    Winnipeg = "5102"
    Calgary = "7011"
    Edmonton = "7023"
    Vancouver_Airport = "8212"
    John_C_Munro_Hamilton_International_Airport = "4171"
