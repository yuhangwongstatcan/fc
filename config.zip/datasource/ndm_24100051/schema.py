"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for the NDM_24100051 aggregate files.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.schema import NDMOutputCommonSchema


class AggregatedSchema(NDMOutputCommonSchema):
    """
    Schema for the NDM_24100051 aggregate files.
    """

    dim1: Series[pa.String] = pa.Field(
        description="Geography: Canada and major provinces (1-5)",
        coerce=True,
    )
    dim2: Series[pa.String] = pa.Field(
        description="Countries (1-89)",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [
            AggregatedSchema.ReferencePeriod,
            AggregatedSchema.dim1,
            AggregatedSchema.dim2,
        ]
