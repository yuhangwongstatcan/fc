"""
    Program: schema.py

    Author: Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        COUNTRIES reference file.
"""
import pandas as pd
import pandera as pa
from pandera.typing import Series

from datasource.countries.dim import CONTINENT, REGION, RESIDENCY_GROUP, VTS_COUNTRY11

from datasource.common.types import SafeIntToStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the COUNTRIES reference file.
    """

    country_of_residence: Series[SafeIntToStringType] = pa.Field(
        description="""A 5-digit country of residence code of a traveller, where the first 2-digits are based on the
        region and the last 3 on sccai_country. Country of residence for immigrants will be coded as 99999.""",
        coerce=True,
    )
    country_name_en: Series[pa.String] = pa.Field(
        description="""Name of country in English according to SCCAI (Standard Country Classification and Area of
        Interest)""",
        coerce=True,
    )
    country_name_fr: Series[pa.String] = pa.Field(
        description="Name of country in French according to SCCAI", coerce=True,
    )
    country_start: Series[pa.String] = pa.Field(
        description="Date the country started existing in our data, the format is in Excel date format",
        str_matches=r"^\d+$",
        coerce=True,
    )
    country_end: Series[SafeIntToStringType] = pa.Field(
        description="""Day after the country ceased existing in our data, if applicable, otherwise it will be empty. The
        format is in Excel date format. If the country stopped existing Dec.31, 2010 the end date should be 20110101""",
        coerce=True,
        nullable=True,
    )
    continent: Series[pa.String] = pa.Field(
        description="""A 1-digit code that identifies the continent the country belongs to according to UNWTO's
        classification""",
        isin=CONTINENT.list(),
        coerce=True,
    )
    region: Series[pa.String] = pa.Field(
        description="""A 2-digit code that identifies the region the country belongs to according to UNWTO's
        classifications. The first digit also identifies the continent the country belongs to.""",
        isin=REGION.list(),
        coerce=True,
    )
    sccai_country: Series[pa.String] = pa.Field(
        description="StatCan's country codes can be up to 3-digits long",
        coerce=True,
        nullable=True,
    )
    sccai_country_code: Series[pa.String] = pa.Field(
        description="""StatCan's 5-digit codes, where the first 2-digits are based on SCCAI's sub-regions, which are
        not the same as the ones in this file and the last 3-digits on sccai_country""",
        coerce=True,
        nullable=True,
    )
    residency_group: Series[pa.String] = pa.Field(
        description="""A categorical variable that groups countries into: Canada, United States of America, Overseas
        and Not applicable. Not applicable is only used when the country_of_residence is 99999 (not applicable)""",
        isin=RESIDENCY_GROUP.list(),
        coerce=True,
    )
    table_24100055: Series[pa.String] = pa.Field(
        description="dim2 of table 24100055 that is a country",
        coerce=True,
        nullable=True,
    )
    table_24100056: Series[pa.String] = pa.Field(
        description="dim2 of table 24100056 that is a country",
        coerce=True,
        nullable=True,
    )
    table_24100057: Series[pa.String] = pa.Field(
        description="dim3 of table 24100057 that is a country",
        coerce=True,
        nullable=True,
    )
    table_24100059: Series[pa.String] = pa.Field(
        description="dim3 of table 24100059 that is a country",
        coerce=True,
        nullable=True,
    )
    vts_country11: Series[pa.String] = pa.Field(
        description="A 1 or 2-digit code that identifies the 11 country groupings used by VTS and SAE",
        isin=VTS_COUNTRY11.list(),
        coerce=True,
    )
    notes_en: Series[pa.String] = pa.Field(
        description="Notes in English for our external users, including footnotes to our NDM tables",
        coerce=True,
        nullable=True,
    )
    notes_fr: Series[pa.String] = pa.Field(
        description="Notes in French for our external users, including footnotes to our NDM tables",
        coerce=True,
        nullable=True,
    )
    comments: Series[pa.String] = pa.Field(
        description="Notes in English or French for our internal users",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.country_of_residence]