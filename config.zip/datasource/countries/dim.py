"""
    Program: dim.py

    Author: Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Create enumerable classes of dimension variables and their possible values
        to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class CONTINENT(AutoEnum):
    americas = "1"
    europe = "2"
    africa = "3"
    asia = "4"
    oceania = "5"
    antarctica_and_adjacent_islands = "6"
    not_applicable = "9"


class REGION(AutoEnum):
    north_america = "11"
    central_america = "12"
    caribbean = "13"
    south_america = "14"
    western_europe = "21"
    central_eastern_europe = "22"
    northern_europe = "23"
    southern_europe = "24"
    east_mediterranean_europe = "25"
    western_africa = "31"
    eastern_africa = "32"
    northern_africa = "33"
    central_africa = "34"
    southern_africa = "35"
    middle_east = "41"
    northeast_asia = "42"
    southeast_asia = "43"
    southern_asia = "44"
    australasia = "51"
    melanesia = "52"
    micronesia = "53"
    polynesia = "54"
    antarctica_and_adjacent_islands = "61"
    not_applicable = "99"


class RESIDENCY_GROUP(AutoEnum):
    canada = "1"
    united_states_of_america = "2"
    overseas = "3"
    not_applicable = "9"


class VTS_COUNTRY11(AutoEnum):
    australia = "1"
    china = "2"
    japan = "3"
    korea_south = "4"
    india = "5"
    united_kingdom = "6"
    france = "7"
    germany = "8"
    mexico = "9"
    united_states_of_america = "10"
    other = "11"
    canada = "12"
    not_applicable = "99"
