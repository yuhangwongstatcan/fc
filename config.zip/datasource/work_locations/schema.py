"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        WORK_LOCATIONS reference file.
"""
import pandera as pa

from pandera.typing import Series

from datasource.common.types import SafeIntToStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the WORK_LOCATIONS reference file.
    """

    port: Series[SafeIntToStringType] = pa.Field(
        description="Port of entry",
        str_matches=r"\d{5}",
        coerce=True,
        nullable=True,
    )
    work_location: Series[SafeIntToStringType] = pa.Field(
        description="Work location numeric code",
        nullable=True,
        coerce=True,
    )
    work_location_name_en: Series[pa.String] = pa.Field(
        description="Name of work location in English",
        coerce=True,
    )
    work_location_name_fr: Series[pa.String] = pa.Field(
        description="Name of work location in French",
        coerce=True,
    )
    city: Series[pa.String] = pa.Field(
        description="City of the port of entry",
        coerce=True,
        nullable=True,
    )
    type: Series[pa.String] = pa.Field(
        description="Categorical combinations of Air, Land, Water modes",
        coerce=True,
        nullable=True,
    )
    status: Series[pa.String] = pa.Field(
        description="Categorical variable for port status (open, closed, suspended, test)",
        coerce=True,
        nullable=True,
    )
    notes_en: Series[pa.String] = pa.Field(
        description="Notes about the work location for external users, in English",
        coerce=True,
        nullable=True,
    )
    notes_fr: Series[pa.String] = pa.Field(
        description="Notes about the work location for external users, in French",
        coerce=True,
        nullable=True,
    )
    comments: Series[pa.String] = pa.Field(
        description="Notes about the work location for internal users",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.port]
