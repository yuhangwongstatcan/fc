"""
    Program: dim.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Create enumerable classes of dimensions for the PORTS
        files to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class SGC_CODE(AutoEnum):
    NL = "10"
    PE = "11"
    NS = "12"
    NB = "13"
    QC = "24"
    ON = "35"
    MB = "46"
    SK = "47"
    AB = "48"
    BC = "59"
    YT = "60"
    NT = "61"
    NU = "62"


class TYPE(AutoEnum):
    air = "1"  # Air only
    land = "2"  # Land only
    water = "3"  # Water only
    air_land = "4"  # Air and land only
    air_water = "5"  # Air and water only
    land_water = "6"  # Land and water only
    all_types = "7"  # Air, land and water
    not_applicable = "9"
