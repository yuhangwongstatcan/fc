"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the NEXUS Air data source.
"""
from typing import Optional

import pandera as pa
from pandera.typing import Series

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.nexus_air.dim import CITIZENSHIP, DURATION2

from datasource.common.types import SafeIntToStringType

# Set field definitions as constants when they appear in both RAW and CLEAN
WORK_LOCATION_FIELD = pa.Field(
    description="CBSA work location as mapped from the str wloc name",
    str_matches="\d{4}",
    coerce=True,
    nullable=True,
)
DURATION2_FIELD = pa.Field(
    description="Trip duration of the travellers, either same-day or overnight",
    isin=DURATION2.list(),
    coerce=True,
    raise_warning=True,
)


class RawSchema(FCSchemaModel):
    """
    Schema for NEXUS Air RAW data.
    """

    date: Series[pa.String] = pa.Field(
        description="Reference month",
        # Date should be in the format YYYY-MM-DD
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True,
    )
    wloc: Series[pa.String] = pa.Field(
        description="Arrival airport",
        coerce=True,
    )
    citizenship: Series[pa.String] = pa.Field(
        description="Citizenship of traveller",
        isin=CITIZENSHIP.list(),
        coerce=True,
        raise_warning=True,
    )
    count: Series[pa.Int] = pa.Field(
        description="Count of NEXUS arrivals by air",
        ge=0,
        coerce=True,
    )
    work_location: Optional[Series[SafeIntToStringType]] = WORK_LOCATION_FIELD
    duration2: Optional[Series[pa.String]] = DURATION2_FIELD

    @staticmethod
    def get_keys():
        return [RawSchema.date, RawSchema.wloc, RawSchema.citizenship]


class CleanSchema(RawSchema):
    """
    Schema for NEXUS Air CLEAN data.
    """

    work_location: Series[SafeIntToStringType] = WORK_LOCATION_FIELD
    duration2: Series[pa.String] = DURATION2_FIELD


class ValidationSchema(pa.SchemaModel):
    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of dimension variable with unexpected values.",
        coerce=True,
    )
    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value of dimension variable.",
        coerce=True,
    )
    location: Optional[Series[pa.String]] = pa.Field(
        description="Arrival airport",
        coerce=True,
    )
    count: Optional[Series[pa.Int]] = pa.Field(
        description="Count of occurrences of a particular validation case.",
        ge=0,
        coerce=True,
    )
    work_location_issue_type: Optional[Series[pa.String]] = pa.Field(
        description="Type of data availability issue that caused a work location to be flagged.",
        isin=[
            "Missing Work Locations",
            "Unexpected Work Locations",
            "Zero NEXUS Travellers",
        ],
        coerce=True,
    )
