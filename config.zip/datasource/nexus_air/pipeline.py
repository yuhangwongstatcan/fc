"""
**Author(s)**

    Jacob Doering (jacob.doering@statcan.gc.ca)

**Created:** February 2023

**Description:**

The pipeline definitions for the nexus_air data source. 
Two pipelines are defined in this module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`
"""
import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID
from modules.pipeline import validation_writer

from config.api import Stage, DataSource, S3

from datasource.nexus_air.data_processing import *
from datasource.nexus_air.schema import RawSchema, CleanSchema


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the NEXUS Air data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the RAW data file created by the loader
        df = Loader.query(Stage.RAW, self.datasource, year=self.year, month=self.month)

        # Make sure that the df adheres to the raw schema
        df = RawSchema(df)

        # VALIDATION: Check for unexpected values in dimension variables
        print("   1.Starting processing nexus_air_000")
        df, validation_df = nexus_air_v000(df)
        validation_writer(validation_df, nexus_air_v000, self.datasource, self.date)
        logging.info("Finished processing nexus_air_000")
        print("   1.Finished processing nexus_air_000")

        # Add the CBSA work location codes
        print("   2.Starting processing nexus_air_005")
        df = nexus_air_005(df)
        logging.info("Finished processing nexus_air_005")
        print("   2.Finished processing nexus_air_005")

        # Remove unused data based on unexpected work locations or vehicle types
        print("   3.Starting processing nexus_air_010")
        df, auxiliary_df = nexus_air_010(df)
        # VALIDTION: Check for new or unexpected data / work locations
        validation_df = nexus_air_v010(df, auxiliary_df)
        validation_writer(validation_df, nexus_air_v010, self.datasource, self.date)
        logging.info("Finished processing nexus_air_010")
        print("   3.Finished processing nexus_air_010")

        # Impute citizenship for travellers in the Other category
        print("   4.Starting processing nexus_air_020")
        df = nexus_air_020(df)
        logging.info("Finished processing nexus_air_020")
        print("   4.Finished processing nexus_air_020")

        # Assign duration to NEXUS Air travellers based on proportions from PIK
        print("   5.Starting processing nexus_air_030")
        df = nexus_air_030(df)
        logging.info("Finished processing nexus_air_030")
        print("   5.Finished processing nexus_air_030")

        # Make sure that the output df adheres to the clean schema
        df = CleanSchema(df)

        # print(f"time spent running nexus_air RawClean: {time.time()-t1}")
        # Save outputs to outputs dictionary
        nexus_air_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[self.datasource.value] = nexus_air_clean


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the NEXUS Air data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in the CLEAN data
        df = Loader.query(
            Stage.CLEAN, self.datasource, year=self.year, month=self.month
        )

        # Make sure that the input df adheres to the clean schema
        df = CleanSchema(df)

        # Create the NEXUS Air transformed, which is the NEXUS Air contribution to
        # the aggregated TRAVELLERS file
        print("Starting processing nexus_air_040")
        travellers = nexus_air_040(df)
        logging.info("Finished processing nexus_air_040")
        print("Finished processing nexus_air_040")

        # Make sure that the TRAVELLERS output df adheres to the transformed schema
        travellers = TransformedSchema(travellers)

        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.travellers.value] = travellers_output
