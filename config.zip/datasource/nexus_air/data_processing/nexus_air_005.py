import pandas as pd

from modules.utils.loaders import Loader
from config.api import DataSource, Stage, Mapping

from datasource.nexus_air.schema import CleanSchema
from datasource.mapping.schema import ReferenceSchema as MappingSchema


def nexus_air_005(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add the four digit CBSA work location code to the NEXUS Air input data,
    which will be used with the nexus_air work location reference file to determine
    which data is accepted.

    Args:
        df:
            A pandas dataframe without the four digit CBSA work location code
    Returns:
        df:
            A pandas dataframe that includes the four digit CBSA work location code
    """

    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__nexus_air__raw__wloc__nexus_air__clean__work_location,
    )

    # Send dataframe through the mapping schema and coerce as needed
    work_locations = MappingSchema(work_locations)

    work_locations = work_locations.rename(
        columns={
            MappingSchema.key: CleanSchema.wloc,
            MappingSchema.value: CleanSchema.work_location,
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)

    df = df.reset_index(drop=True)
    df = pd.merge(df, work_locations, on=[CleanSchema.wloc], how="left")

    return df
