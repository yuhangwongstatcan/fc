import pandas as pd

from datasource.nexus_air.dim import CITIZENSHIP
from datasource.nexus_air.schema import CleanSchema, ValidationSchema


def nexus_air_v000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate the dimension variables to find unexpected values.

    Args:
        df:
            A pandas dataframe of records that possibly contain unexpected
            dimension values.
    Returns:
        df:
            Copy of the input dataframe since no processing is done.

        validation_df:
            Validation file summarizing the unexpected values which will be used in dashboards.
    """
    validation_df = df[~df[CleanSchema.citizenship].isin(CITIZENSHIP.list())]
    validation_df.insert(
        loc=0, column=ValidationSchema.variable, value=CleanSchema.citizenship
    )
    validation_df = validation_df.rename(
        columns={
            CleanSchema.wloc: ValidationSchema.location,
            CleanSchema.citizenship: ValidationSchema.unexpected_value,
        }
    )
    validation_df = validation_df.sort_values(ValidationSchema.unexpected_value)
    validation_df = validation_df[
        [
            ValidationSchema.variable,
            ValidationSchema.unexpected_value,
            CleanSchema.date,
            ValidationSchema.location,
            ValidationSchema.count,
        ]
    ]

    return df, validation_df
