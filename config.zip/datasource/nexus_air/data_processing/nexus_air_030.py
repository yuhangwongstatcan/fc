import pandas as pd

from config.api import DataSource

from config.api import Stage
from modules.utils.loaders import Loader
from config.api import S3

from datasource.nexus_air.schema import CleanSchema
from datasource.travellers.schema import TransformedSchema

from datasource.nexus_air.schema import CITIZENSHIP
from datasource.travellers.dim import COUNTRY_OF_RESIDENCE, DURATION2, TRAVELLER_TYPE

def nexus_air_030(df: pd.DataFrame) -> pd.DataFrame:
    """
    Assign a trip duration of same day or overnight to travellers in NEXUS Air.
    Args:
        df:
            A pandas dataframe without trip duration for same day or overnight travellers
    Returns:
        df:
            A pandas dataframe containing trip durations
    """
    year, month, _ = df[CleanSchema.date][0].split("-")
    year = int(year)
    month = int(month)
    basename = S3.get_s3_basename(Stage.TRANSFORMED, DataSource.pik, year, month, 1)
    pik_work_location = Loader.get(Stage.TRANSFORMED, DataSource.travellers, basename)

    # Check that imported PIK TRANSFORMED file adheres to schema and coerce if not
    pik_work_location = TransformedSchema(pik_work_location)

    if pik_work_location.empty:
        raise Exception(
            "The dataframe pik_work_location was expected to contain records, but the dataframe is empty. This issue is caused because upstream PIK data was expected but no PIK data was found."
        )

    # Creating the distributions, in lines 50-81 we are calculating the two bullet points in the documentation of this business
    # rule where it says for each PIK work location, calculate:
    mask1 = (
        pik_work_location[TransformedSchema.traveller_type]
        == TRAVELLER_TYPE.excursionist.value
    ) & (
        pik_work_location[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )
    mask2 = (
        pik_work_location[TransformedSchema.traveller_type]
        == TRAVELLER_TYPE.excursionist.value
    ) & (
        pik_work_location[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.united_states.value
    )
    mask_can = pik_work_location[TransformedSchema.traveller_type].isin(
        [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
    ) & (
        pik_work_location[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )
    mask_us = pik_work_location[TransformedSchema.traveller_type].isin(
        [TRAVELLER_TYPE.excursionist.value, TRAVELLER_TYPE.tourist.value]
    ) & (
        pik_work_location[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.united_states.value
    )

    if not any(mask_can) or not any(mask_us):
        raise Exception(
            "No PIK work location data matched the conditions to create the distribution to carry out the imputation."
        )
    groupby_df_can = pik_work_location[mask1].groupby(
        by=[CleanSchema.work_location], dropna=False, as_index=False
    )
    groupby_df_can = groupby_df_can[[TransformedSchema.count_of_entries]].apply(
        lambda x: x.astype(int).sum()
    )
    groupby_df_us = pik_work_location[mask2].groupby(
        by=[CleanSchema.work_location], dropna=False, as_index=False
    )
    groupby_df_us = groupby_df_us[[TransformedSchema.count_of_entries]].apply(
        lambda x: x.astype(int).sum()
    )
    groupby_can = pik_work_location[mask_can].groupby(
        by=[CleanSchema.work_location], dropna=False, as_index=False
    )
    groupby_can = groupby_can[[TransformedSchema.count_of_entries]].apply(
        lambda x: x.astype(int).sum()
    )
    groupby_us = pik_work_location[mask_us].groupby(
        by=[CleanSchema.work_location], dropna=False, as_index=False
    )
    groupby_us = groupby_us[[TransformedSchema.count_of_entries]].apply(
        lambda x: x.astype(int).sum()
    )

    groupby_df_can[TransformedSchema.count_of_entries] = groupby_df_can[
        TransformedSchema.count_of_entries
    ].astype(int)
    groupby_df_us[TransformedSchema.count_of_entries] = groupby_df_us[
        TransformedSchema.count_of_entries
    ].astype(int)
    groupby_can[TransformedSchema.count_of_entries] = groupby_can[
        TransformedSchema.count_of_entries
    ].astype(int)
    groupby_us[TransformedSchema.count_of_entries] = groupby_us[
        TransformedSchema.count_of_entries
    ].astype(int)

    prop_can = pd.merge(
        groupby_df_can, groupby_can, on=[CleanSchema.work_location], how="inner"
    )
    prop_us = pd.merge(
        groupby_df_us, groupby_us, on=[CleanSchema.work_location], how="inner"
    )

    prop_can["prop_can"] = (
        prop_can["count_of_entries_x"] / prop_can["count_of_entries_y"]
    )
    prop_us["prop_us"] = prop_us["count_of_entries_x"] / prop_us["count_of_entries_y"]
    prop_can = prop_can.drop(columns=["count_of_entries_x", "count_of_entries_y"])
    prop_us = prop_us.drop(columns=["count_of_entries_x", "count_of_entries_y"])

    # Assign the trip durations
    prop_can[CleanSchema.duration2] = DURATION2.same_day.value
    prop_us[CleanSchema.duration2] = DURATION2.same_day.value
    prop_can_repeated = pd.concat([prop_can] * 2, ignore_index=True)
    prop_can_repeated[int(prop_can_repeated.shape[0] / 2) :] = prop_can_repeated[
        int(prop_can_repeated.shape[0] / 2) :
    ].assign(
        prop_can=1
        - prop_can_repeated["prop_can"][int(prop_can_repeated.shape[0] / 2) :]
    )
    prop_can_repeated[int(prop_can_repeated.shape[0] / 2) :] = prop_can_repeated[
        int(prop_can_repeated.shape[0] / 2) :
    ].assign(duration2=DURATION2.overnight.value)
    prop_us_repeated = pd.concat([prop_us] * 2, ignore_index=True)
    prop_us_repeated[int(prop_us_repeated.shape[0] / 2) :] = prop_us_repeated[
        int(prop_us_repeated.shape[0] / 2) :
    ].assign(
        prop_us=1 - prop_us_repeated["prop_us"][int(prop_us_repeated.shape[0] / 2) :]
    )
    prop_us_repeated[int(prop_us_repeated.shape[0] / 2) :] = prop_us_repeated[
        int(prop_us_repeated.shape[0] / 2) :
    ].assign(duration2=DURATION2.overnight.value)
    df = pd.concat([df] * 2, ignore_index=True)
    prop = prop_can_repeated.append(prop_us_repeated)
    df = pd.concat([df] * 2, ignore_index=True)
    # Cast work_location to string so the merge with prop can take place
    df[CleanSchema.work_location] = df[CleanSchema.work_location].astype(str)
    df = pd.merge(df, prop, on=[CleanSchema.work_location], how="left")
    work_loc_mask = (
        df[CleanSchema.work_location]
        .isin(list(pik_work_location[CleanSchema.work_location].astype(str)))
        .reset_index(drop=True)
    )

    # If there is not PIK data available at the same work location
    if (work_loc_mask.values == False).any():
        prop_can = (
            groupby_df_can[TransformedSchema.count_of_entries].sum()
            / groupby_can[TransformedSchema.count_of_entries].sum()
        )
        prop_us = (
            groupby_df_us[TransformedSchema.count_of_entries].sum()
            / groupby_us[TransformedSchema.count_of_entries].sum()
        )
        duplicated = df.duplicated().reset_index(drop=True)
        df.loc[
            (~work_loc_mask)
            & (~duplicated)
            & (df[CleanSchema.citizenship] == CITIZENSHIP.canada.value),
            ["prop_can", CleanSchema.duration2],
        ] = [prop_can, DURATION2.same_day.value]
        df.loc[
            (~work_loc_mask)
            & (duplicated)
            & (df[CleanSchema.citizenship] == CITIZENSHIP.canada.value),
            ["prop_can", CleanSchema.duration2],
        ] = [1 - prop_can, DURATION2.overnight.value]
        df.loc[
            (~work_loc_mask)
            & (~duplicated)
            & (df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value),
            ["prop_us", CleanSchema.duration2],
        ] = [prop_us, DURATION2.same_day.value]
        df.loc[
            (~work_loc_mask)
            & (duplicated)
            & (df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value),
            ["prop_us", CleanSchema.duration2],
        ] = [1 - prop_us, DURATION2.overnight.value]
    # Update the counts, given that each row has been separated into two for duration2 either 1 or 2
    df[df[CleanSchema.citizenship] == CITIZENSHIP.canada.value] = df[
        df[CleanSchema.citizenship] == CITIZENSHIP.canada.value
    ].assign(
        count=round(
            df[CleanSchema.count][
                df[CleanSchema.citizenship] == CITIZENSHIP.canada.value
            ]
            * df["prop_can"]
        )
    )
    df[df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value] = df[
        df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value
    ].assign(
        count=round(
            df[CleanSchema.count][
                df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value
            ]
            * df["prop_us"]
        )
    )
    df = df.drop(columns=["prop_can", "prop_us"])
    df = df.dropna()
    # If there are any remaining duplicates as a result of the logic above to assign duration, remove them
    if df.duplicated().any():
        output = df[
            ~df.duplicated(
                subset=[
                    CleanSchema.wloc,
                    CleanSchema.citizenship,
                    CleanSchema.count,
                    CleanSchema.duration2,
                ]
            )
        ].copy()
    else:
        output = df.copy()

    output[CleanSchema.count] = output[CleanSchema.count].astype("Int64")
    df = output.sort_values(CleanSchema.citizenship)

    return df

