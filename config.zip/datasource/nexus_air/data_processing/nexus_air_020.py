import pandas as pd
import numpy as np

from datasource.nexus_air.schema import CleanSchema
from datasource.nexus_air.dim import CITIZENSHIP

def nexus_air_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute citizenship for "other" category.
    Args:
        df:
            A pandas dataframe without the imputed values for citizenship.
    Returns:
        df:
            A pandas dataframe that has imputed values for citizenship
    """
    mask = df[CleanSchema.citizenship] == CITIZENSHIP.other.value
    aux = df[mask].copy()
    Canada = df[(df[CleanSchema.citizenship] == CITIZENSHIP.canada.value)][
        [CleanSchema.wloc, CleanSchema.count]
    ].reset_index()
    United_States = df[
        (df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value)
    ][[CleanSchema.wloc, CleanSchema.count]].reset_index()
    groupby_df = aux.groupby(by=[CleanSchema.wloc], dropna=False, as_index=False)
    groupby_df = groupby_df[[CleanSchema.count]].apply(lambda x: x.astype(int).sum())

    groupby_df[CleanSchema.count] = groupby_df[CleanSchema.count].astype(int)
    Canada[CleanSchema.count] = Canada[CleanSchema.count].astype(int)
    United_States[CleanSchema.count] = United_States[CleanSchema.count].astype(int)
    # mask 2 is checking if there are any rows that fit the rare case criteria
    mask2 = (Canada[CleanSchema.count] == 0) & (United_States[CleanSchema.count] == 0)
    rare_case = groupby_df[mask2].copy()
    # do not want to impute rare case rows the traditional way
    groupby_df = groupby_df[~mask2]

    # Get proportions for Canada and US based on documentation logic
    prop_canada = round(
        groupby_df[CleanSchema.count]
        * (
            Canada[CleanSchema.count]
            / (Canada[CleanSchema.count] + United_States[CleanSchema.count].values)
        )
        .fillna(0)
        .reset_index(drop=True),
        0,
    )

    prop_us = groupby_df[CleanSchema.count].astype(int) - round(
        groupby_df[CleanSchema.count].astype(int)
        * (
            Canada[CleanSchema.count].astype(int)
            / (
                Canada[CleanSchema.count].astype(int)
                + United_States[CleanSchema.count].astype(int).values
            )
        )
        .fillna(0)
        .reset_index(drop=True),
        0,
    )
    prop_canada = prop_canada.fillna(0)
    prop_us = prop_us.fillna(0)

    # Update citizenship values based off the proportions
    df.loc[
        df[df[CleanSchema.citizenship] == CITIZENSHIP.canada.value][
            CleanSchema.count
        ].index.values,
        [CleanSchema.count],
    ] = (
        df[df[CleanSchema.citizenship] == CITIZENSHIP.canada.value][
            CleanSchema.count
        ].astype(int)
        + prop_canada.astype(int).values
    )

    df.loc[
        df[df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value][
            CleanSchema.count
        ].index.values,
        [CleanSchema.count],
    ] = (
        df[df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value][
            CleanSchema.count
        ].astype(int)
        + prop_us.astype(int).values
    )

    # If the rare case occurs
    if not rare_case.empty:
        count_can = np.ceil(rare_case[CleanSchema.count] / 2)
        count_us = rare_case[CleanSchema.count] - count_can

        df.loc[
            df[df[CleanSchema.citizenship] == CITIZENSHIP.canada.value][
                CleanSchema.count
            ]
            .reset_index()[mask2]["index"]
            .values,
            [CleanSchema.count],
        ] = count_can.astype(int).values

        df.loc[
            df[df[CleanSchema.citizenship] == CITIZENSHIP.united_states.value][
                CleanSchema.count
            ]
            .reset_index()[mask2]["index"]
            .values,
            [CleanSchema.count],
        ] = count_us.astype(int).values

    df = df[~mask]
    return df
