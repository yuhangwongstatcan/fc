import pandas as pd

from modules.utils.loaders import Loader
from config.api import DataSource, Stage, Mapping
from config.api import WorkLocationsTransAction

from config.api import Stage
from config.api import WorkLocationsTransAction

from datasource.nexus_air.schema import CleanSchema
from datasource.work_locations_trans_action.schema import (
    ReferenceSchema as TransActionSchema,
)
from datasource.work_locations_trans_action.dim import ACTION
from datasource.mapping.schema import ReferenceSchema as MappingSchema


def nexus_air_010(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove records from the nexus_air raw data that cannot be matched to the work location
    reference file, or for which the file indicates that they are not accepted, until
    they can be reviewed.

    Args:
        df:
            A pandas dataframe with unacceptable work locations
    Returns:
        df:
            A pandas dataframe with unacceptable work locations removed
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    """
    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__nexus_air,
    )
    # Obtain mask of all records in input that conform with work locations acceptability
    invalid_mask = (
        ~(
            df[CleanSchema.work_location].isin(
                work_locations[
                    work_locations[TransActionSchema.action] == ACTION.accept.value
                ][TransActionSchema.work_location].values.astype(str)
            )
        )
        | (df[CleanSchema.work_location].isnull())
        | (
            df[CleanSchema.work_location].isin(
                work_locations[
                    work_locations[TransActionSchema.transportation_type]
                    != "nexus_air__111"
                ][TransActionSchema.work_location].values.astype(str)
            )
        )
    )
    auxiliary_df = df[invalid_mask].copy()
    df = df[~invalid_mask]

    return df, auxiliary_df

def nexus_air_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate the unexpected work locations or modes of transportation for NEXUS Air.

    Args:
        df:
            A pandas dataframe with unacceptable work locations removed
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """

    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__nexus_air__raw__wloc__nexus_air__clean__work_location,
    )
    work_locations = work_locations.rename(
        columns={
            MappingSchema.key: CleanSchema.wloc,
            MappingSchema.value: CleanSchema.work_location,
        }
    )

    auxiliary_df = auxiliary_df[~auxiliary_df.duplicated(subset=[CleanSchema.wloc])]
    auxiliary_df = auxiliary_df.drop(
        columns=[CleanSchema.count, CleanSchema.work_location, CleanSchema.citizenship]
    )
    auxiliary_df = auxiliary_df.copy()

    # Get the date (df should always contain records)
    DATE = df[CleanSchema.date][0]
    # Code the masks for each of the validation scenarios we are looking for.
    MISSING_WORK_LOCATIONS = ~work_locations[CleanSchema.work_location].isin(
        list(df[CleanSchema.work_location].unique())
    )
    # Derive the mask for zero travellers
    # Sum up the output "count" column by work location. If sum==0, that work location has zero nexus travellers
    groupby_df = df.groupby(
        by=[CleanSchema.work_location], dropna=False, as_index=False
    )
    groupby_df = groupby_df[[CleanSchema.count]].apply(lambda x: x.astype(int).sum())
    zero_travellers_work_locations = set(
        groupby_df[groupby_df[CleanSchema.count] == 0][
            CleanSchema.work_location
        ].unique()
    )
    ZERO_WORK_LOCATIONS = work_locations[CleanSchema.work_location].isin(
        zero_travellers_work_locations
    )
    # Get 3 validation dfs in the same schema
    zero_work_locations_df = work_locations[ZERO_WORK_LOCATIONS]
    zero_work_locations_df[CleanSchema.date] = DATE
    zero_work_locations_df["work_location_issue_type"] = "Zero NEXUS Travellers"

    missing_work_locations_df = work_locations[MISSING_WORK_LOCATIONS]
    missing_work_locations_df[CleanSchema.date] = DATE
    missing_work_locations_df["work_location_issue_type"] = "Missing Work Locations"

    auxiliary_df[CleanSchema.work_location] = pd.NA
    auxiliary_df["work_location_issue_type"] = "Unexpected Work Locations"
    all_validation_df = pd.concat(
        [zero_work_locations_df, missing_work_locations_df, auxiliary_df]
    )
    validation_df = all_validation_df[
        [CleanSchema.date, "work_location_issue_type", CleanSchema.wloc]
    ]

    return validation_df
