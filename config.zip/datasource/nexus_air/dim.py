"""
    Program: dim.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Create enumerable classes of dimension variables and their possible values
        to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class CITIZENSHIP(AutoEnum):
    canada = "Canada"
    other = "Other"
    united_states = "United States"


class DURATION2(AutoEnum):
    same_day = "1"
    overnight = "2"
