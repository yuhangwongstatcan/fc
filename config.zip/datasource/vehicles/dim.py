"""
    Program: dim.py

    Author: Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Create lists of dimension values for the VEHICLES table, and enumerable
        classes to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
        At the moment, there are no vehicle-specific dims.
"""

# Importing common dims for ease of use
from datasource.common.dim import (
    DAY,
    MODE,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
    PLATE_REGION,
    DATA_SOURCE
)
