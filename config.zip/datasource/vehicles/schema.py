"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Define schema models using pandera for schema verification of any
        transformed data sources for VEHICLES, as well as the aggregated files
        VEHICLES, VEHICLES_LEADING and VEHICLES_MAIN.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.schema import TravellersVehiclesCommonSchema

from datasource.vehicles.dim import DATA_SOURCE


class AggregatedSchema(TravellersVehiclesCommonSchema):
    """
    Schema for VEHICLES_MAIN and VEHICLES_LEADING is the same as the common schema.
    """
    @staticmethod
    def get_keys():
        return [
            col for col in AggregatedSchema.to_schema().columns.keys()
            if col != AggregatedSchema.count_of_entries
        ]


class TransformedSchema(AggregatedSchema):
    """
    Schema for all transformed VEHICLES files and the aggregated VEHICLES file.
    """

    work_location: Series[pa.String] = pa.Field(
        description="Canada Border Services Agency work location of border crossing",
        coerce=True,
    )
    data_source: Series[pa.String] = pa.Field(
        description="Canada Border Services Agency data source",
        isin=DATA_SOURCE.list(),
        coerce=True,
        raise_warning=True,
    )
    count_of_entries: Series[pa.INT64] = pa.Field(
        description="Count of border crossings", coerce=True,
    )
    @staticmethod
    def get_keys():
        return [
            col for col in TransformedSchema.to_schema().columns.keys()
            if col != TransformedSchema.count_of_entries
        ]


# Define a series of lists that can be used across numerous data sources for
# TRANSFORMED or AGGREGATED data to subset, group by, sort and order columns

# TRANSFORMED columns for subset, reorder or sort
TRANSFORMED_COLUMNS = [
    TransformedSchema.year,
    TransformedSchema.month,
    TransformedSchema.day,
    TransformedSchema.port,
    TransformedSchema.mode,
    TransformedSchema.vehicle_type,
    TransformedSchema.plate_country,
    TransformedSchema.plate_region,
    TransformedSchema.work_location,
    TransformedSchema.data_source,
    TransformedSchema.count_of_entries,
]

# TRANSFORMED columns for groupby (numeric count of entries excluded)
TRANSFORMED_GROUPBY = TRANSFORMED_COLUMNS.copy()
TRANSFORMED_GROUPBY.remove(TransformedSchema.count_of_entries)

# VEHICLES columns for subset, reorder or sort
VEHICLES_COLUMNS = TRANSFORMED_COLUMNS.copy()
VEHICLES_COLUMNS.remove(TransformedSchema.work_location)
VEHICLES_COLUMNS.remove(TransformedSchema.data_source)

# VEHICLES columns for groupby (numeric count of entries excluded)
VEHICLES_GROUPBY = VEHICLES_COLUMNS.copy()
VEHICLES_GROUPBY.remove(TransformedSchema.count_of_entries)

