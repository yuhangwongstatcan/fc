from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput
from modules.utils.uid import PipelineUID

from modules.utils.loaders import Loader

from config.api import DataSource, Stage, S3

from datasource.vehicles.schema import TransformedSchema, AggregatedSchema
from datasource.vehicles.data_processing import *


class PipelineTransformedAggregated(BasePipeline):
    """
    Runs the TRANSFORMED -> AGGREGATED pipeline for the VEHICLES data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Get vehicles dataframe
        vehicles = Loader.query(
            Stage.TRANSFORMED,
            datasource=self.datasource,
            year=self.year,
            month=self.month,
        )
        # Ensure that the output VEHICLES file adheres to the correct schema
        vehicles = TransformedSchema(vehicles)

        # Create the vehicles_main table
        vehicles_main = vehicles_010(vehicles)

        # Create the vehicles_leading table (this rule keeps the subset where
        # data source is IPIL_HWY or PIK)
        vehicles_leading = vehicles_020(vehicles)

        # Ensure that the output MAIN and LEADING dataframes adhere to the correct schema
        vehicles_main = AggregatedSchema(vehicles_main)
        vehicles_leading = AggregatedSchema(vehicles_leading)

        # Save all of the tables produced to the outputs dictionary
        vehicles_output = PipelineOutput(
            data=vehicles,
            stage=Stage.AGGREGATED,
            datasource=DataSource.vehicles,
            basename=S3.get_s3_basename(
                Stage.AGGREGATED,
                DataSource.vehicles.value,
                self.year,
                self.month,
                self.day,
            ),
        )
        vehicles_main_output = PipelineOutput(
            data=vehicles_main,
            stage=Stage.AGGREGATED,
            datasource=DataSource.vehicles_main,
            basename=S3.get_s3_basename(
                Stage.AGGREGATED,
                DataSource.vehicles_main.value,
                self.year,
                self.month,
                self.day,
            ),
        )
        vehicles_leading_output = PipelineOutput(
            data=vehicles_leading,
            stage=Stage.AGGREGATED,
            datasource=DataSource.vehicles_leading,
            basename=S3.get_s3_basename(
                Stage.AGGREGATED,
                DataSource.vehicles_leading.value,
                self.year,
                self.month,
                self.day,
            ),
        )

        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.vehicles.value] = vehicles_output
        self.outputs[DataSource.vehicles_main.value] = vehicles_main_output
        self.outputs[DataSource.vehicles_leading.value] = vehicles_leading_output
