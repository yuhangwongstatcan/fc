import pandas as pd

from modules.utils.datasource import aggregate_statcan_tables
from modules.utils.datasource import sort_aggregated_tables

from datasource.vehicles.schema import (
    TransformedSchema,
    AggregatedSchema,
    VEHICLES_COLUMNS,
    VEHICLES_GROUPBY,
)


def vehicles_010(vehicles: pd.DataFrame) -> pd.DataFrame:
    """
    Starting from the base vehicles table, produces the vehicles_main table.

    Args:
        vehicles:
            The base vehicles table.

    Returns:
        vehicles_main:
            The vehicles table with analysis variables removed, ports adjusted
            to published port and reaggregated across all remaining variables.
            This table is for the MAIN release and includes all data sources.
    """

    # Drop data source column and work location column
    df = vehicles.drop(
        [TransformedSchema.data_source, TransformedSchema.work_location], axis=1
    )

    # Aggregate vehicles table
    df = aggregate_statcan_tables(df, AggregatedSchema, VEHICLES_GROUPBY)

    # Prepare output
    vehicles_main = sort_aggregated_tables(df, AggregatedSchema, VEHICLES_COLUMNS)

    return vehicles_main
