import pandas as pd

from modules.utils.datasource import aggregate_statcan_tables
from modules.utils.datasource import sort_aggregated_tables

from datasource.vehicles.schema import (
    TransformedSchema,
    AggregatedSchema,
    VEHICLES_COLUMNS,
    VEHICLES_GROUPBY,
)

from datasource.common.dim import LEADING_DATASOURCES


def vehicles_020(vehicles: pd.DataFrame) -> pd.DataFrame:
    """
    Starting from the base vehicles table, produces the vehicles_leading table.
    Currently, this only includes the ipil_hwy and pik data sources.

    Args:
        vehicles:
            The base vehicles table.

    Returns:
        vehicles_leading:
            The vehicles table with analysis variables removed, ports adjusted
            to published port and reaggregated across all remaining variables.
            This table is for the LEADING release and includes only certain data sources.
    """

    # Drop data source column and work location columns and keep only leading datasources
    df = vehicles[vehicles[TransformedSchema.data_source].isin(LEADING_DATASOURCES)]
    df = df.drop(
        [TransformedSchema.data_source, TransformedSchema.work_location], axis=1
    )

    # Aggregate vehicles table
    df = aggregate_statcan_tables(df, AggregatedSchema, VEHICLES_GROUPBY)

    # Prepare output
    vehicles_leading = sort_aggregated_tables(df, AggregatedSchema, VEHICLES_COLUMNS)

    return vehicles_leading
