"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        PROVINCES_AND_TERRITORIES reference file.
"""

import pandera as pa
from pandera.typing import Series

from datasource.provinces_and_territories.dim import SGC_REGION_CODE

from datasource.common.types import SafeIntToStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the PROVINCES_AND_TERRITORIES reference file.
    """

    sgc_code: Series[SafeIntToStringType] = pa.Field(
        description="Province or territory of entry",
        coerce=True,
    )
    province_territory_en: Series[pa.String] = pa.Field(
        description="Name of province or territory in English",
        coerce=True,
    )
    province_territory_fr: Series[pa.String] = pa.Field(
        description="Name of province or territory in French",
        coerce=True,
    )
    alpha_code: Series[pa.String] = pa.Field(
        description="Two-letter abbreviation used for provinces and territories at StatCan",
        coerce=True,
    )
    sgc_region_code: Series[SafeIntToStringType] = pa.Field(
        description="Standard geographical classification used to group provinces and territories at StatCan",
        isin=SGC_REGION_CODE.list(),
        coerce=True,
    )
    table_24100055: Series[SafeIntToStringType] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100055",
        coerce=True,
        nullable=True,
    )
    table_24100057: Series[SafeIntToStringType] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100057",
        coerce=True,
        nullable=True,
    )
    table_24100058: Series[SafeIntToStringType] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100058",
        coerce=True,
        nullable=True,
    )
    table_24100059: Series[SafeIntToStringType] = pa.Field(
        description="Coordinate value of the port in CODR Table 24100059",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.sgc_code]
