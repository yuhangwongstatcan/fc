"""
    Program: dim.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Create enumerable classes of dimensions for the PROVINCES_AND_TERRITORIES
        files to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from config.api import AutoEnum


class SGC_REGION_CODE(AutoEnum):
    atlantic = "1"
    quebec = "2"
    ontario = "3"
    prairies = "4"
    british_columbia = "5"
    territories = "6"
