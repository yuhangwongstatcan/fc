"""
    Program: dim.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Create enumerable classes of dimensions for the WORK LOCATIONS TRANS ACTION
        files to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from enum import auto
from config.api import AutoEnum


class ACTION(AutoEnum):
    accept = "A"
    confront = "C"
    R111 = auto()  # Recode to commercial aircraft
    R112 = auto()  # Recode to cargo aircraft
    R121 = auto()  # Recode to private aircraft
    R121_civ = auto()  # Recode to private civilian aircraft
    R121_mil = auto()  # Recode to military aircraft
    R211 = auto()  # Recode to automobile
    R212 = auto()  # Recode to motorcycle
    R213 = auto()  # Recode to other land vehicle
    R214 = auto()  # Recode to truck
    R215 = auto()  # Recode to bus
    R216 = auto()  # Recode to train
    R217 = auto()  # Recode to pedestrian
    R311 = auto()  # Recode to cruise ship or other commercial boat
    R312 = auto()  # Recode to cargo ship
    R313 = auto()  # Recode to ferry (private vehicle)
    R314 = auto()  # Recode to ferry (pedestrian)
    R315 = auto()  # Recode to ferry (unknown)
    R321 = auto()  # Recode to private boat
    test = "T"
    X = auto()  # Unmatched record
    supplementary = "S"
