"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        WORK_LOCATIONS_TRANS_ACTION file which defines the action that should
        be taken with each mode of transportation for each data source.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.types import SafeIntToStringType

from datasource.work_locations_trans_action.dim import ACTION


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the WORK_LOCATIONS_TRANS_ACTION reference file.
    """

    work_location: Series[SafeIntToStringType] = pa.Field(
        description="Canada Border Services Agency work location",
        coerce=True,
    )
    transportation_type: Series[pa.String] = pa.Field(
        description="Mode of transportation",
        coerce=True,
    )
    action: Series[pa.String] = pa.Field(
        description="Action to take with the data, either accept, transform or reject",
        isin=ACTION.list(),
        coerce=True,
        raise_warning=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.work_location, ReferenceSchema.transportation_type]
