import pandas as pd

from config.api import Stage, DataSource, FixedProportions, FixedProportionsRules

from modules.utils.loaders import Loader
from modules.utils.manual_entry_helpers import fixed_proportion_imputation

from datasource.manual_entry_travellers.schema import RawSchema
from datasource.fixed_proportions.schema import (
    ReferenceSchema as FixedProportionsSchema,
)
from datasource.fixed_proportion_rules.schema import ReferenceSchema as RulesSchema


def manual_entry_travellers_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Applies the user-defined "fixed" proportions for applicable missing manual entry
    values. These fixed rules supersede imputation based on current or historical data.

    Args:
        df:
            A pandas dataframe without fixed rules applied.

    Returns:
        df:
            A pandas dataframe with fixed rules applied.
    """
    fixed_proportions = Loader.get(
        Stage.REFERENCE,
        DataSource.fixed_proportions,
        FixedProportions.fixed_proportions,
    )
    fixed_proportions = FixedProportionsSchema(fixed_proportions)

    fixed_proportion_rules = Loader.get(
        Stage.REFERENCE,
        DataSource.fixed_proportion_rules,
        FixedProportionsRules.fixed_proportion_rules,
    )
    fixed_proportion_rules = RulesSchema(fixed_proportion_rules)

    df = fixed_proportion_imputation(
        df,
        fixed_proportion_rules,
        fixed_proportions,
        RawSchema,
        FixedProportionsSchema,
        RulesSchema,
    )

    return df
