import pandas as pd

from datasource.manual_entry_travellers.schema import RawSchema

from datasource.common.dim import VEHICLE_TYPE, PLATE_COUNTRY
from datasource.travellers.dim import ARRIVING_FROM, COUNTRY_OF_RESIDENCE


def manual_entry_travellers_015(df: pd.DataFrame) -> pd.DataFrame:
    """
    Applies any so-called absolute imputation rules. These rules are
    always true and supersede any user-defined fixed rules or imputation.

    Args:
        df:
            A pandas dataframe without absolute rules applied.

    Returns:
        df:
            A pandas dataframe with absolute rules applied.
    """
    # IF plate_country needs to be imputed AND vehicle_type NOT in (211,212,213,214)
    # THEN plate_country = 9
    df.loc[
        df[RawSchema.plate_country].isna()
        & ~df[RawSchema.vehicle_type].isin(
            [
                VEHICLE_TYPE.automobile.value,
                VEHICLE_TYPE.motorcycle.value,
                VEHICLE_TYPE.other_land_vehicle.value,
                VEHICLE_TYPE.truck.value,
            ]
        ),
        RawSchema.plate_country,
    ] = PLATE_COUNTRY.not_available.value

    # IF arriving_from needs to be imputed AND country_of_residence NOT in
    # (11124,11840) AND vehicle_type in (211,212,213,214,215,216,217) THEN
    # arriving_from = 3
    df.loc[
        df[RawSchema.arriving_from].isna()
        & ~df[RawSchema.country_of_residence].isin(
            [
                COUNTRY_OF_RESIDENCE.canada.value,
                COUNTRY_OF_RESIDENCE.united_states.value,
            ]
        )
        & df[RawSchema.vehicle_type].isin(
            [
                VEHICLE_TYPE.automobile.value,
                VEHICLE_TYPE.motorcycle.value,
                VEHICLE_TYPE.other_land_vehicle.value,
                VEHICLE_TYPE.truck.value,
                VEHICLE_TYPE.bus.value,
                VEHICLE_TYPE.train.value,
                VEHICLE_TYPE.pedestrian.value,
                VEHICLE_TYPE.land_unknown.value,
            ]
        )
        & ~df[RawSchema.country_of_residence].isna(),
        RawSchema.arriving_from,
    ] = ARRIVING_FROM.ovs_via_us.value
    # IF arriving_from needs to be imputed AND country_of_residence in
    # (11124,11840) AND vehicle_type in (211,212,213,214,215,216,217)
    # THEN arriving_from = 1
    df.loc[
        df[RawSchema.arriving_from].isna()
        & df[RawSchema.country_of_residence].isin(
            [
                COUNTRY_OF_RESIDENCE.canada.value,
                COUNTRY_OF_RESIDENCE.united_states.value,
            ]
        )
        & df[RawSchema.vehicle_type].isin(
            [
                VEHICLE_TYPE.automobile.value,
                VEHICLE_TYPE.motorcycle.value,
                VEHICLE_TYPE.other_land_vehicle.value,
                VEHICLE_TYPE.truck.value,
                VEHICLE_TYPE.bus.value,
                VEHICLE_TYPE.train.value,
                VEHICLE_TYPE.pedestrian.value,
                VEHICLE_TYPE.land_unknown.value,
            ]
        ),
        RawSchema.arriving_from,
    ] = ARRIVING_FROM.us_only.value

    return df
