import pandas as pd

from config.api import DataSource, ManualEntryTrackerTravellers

from modules.utils.loaders import Loader

from config.api import Stage

from datasource.manual_entry_tracker_travellers.schema import (
    ReferenceSchema as TrackerSchema,
)
from datasource.manual_entry_travellers.schema import CleanSchema


def manual_entry_travellers_v005(df: pd.DataFrame) -> pd.DataFrame:
    """
    Carries out the manaul entry tracker logic. Checks which rows were present in manual entry
    data that were not present in manual entry tracker

    Args:
        df:
            A pandas dataframe of manual entry data for travellers.

    Returns:
        df:
            A pandas dataframe of manual entry data for travellers.

        auxiliary_df:
            A pandas dataframe of entries from the manual entry tool
            that were not present in the tracker (are not expected).
    """
    tracker = Loader.get(
        Stage.REFERENCE,
        DataSource.manual_entry_tracker_travellers,
        ManualEntryTrackerTravellers.manual_entry_tracker_travellers,
    )

    # Ensure that the tracker file matches the schema
    tracker = TrackerSchema(tracker)

    match = pd.merge(
        df, tracker, how="outer", on=tracker.columns.tolist(), indicator=True
    )
    validation_df = match.query('_merge != "right_only" & _merge != "both"')[
        list(CleanSchema.to_schema().columns.keys())
    ]

    return df, validation_df

