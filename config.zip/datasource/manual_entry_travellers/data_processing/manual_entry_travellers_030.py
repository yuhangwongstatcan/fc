import pandas as pd

from config.api import Stage, DataSource
from modules.utils.loaders import Loader

from modules.utils.manual_entry_helpers import (
    convert_pd_na_to_code_travellers,
    convert_to_travellers_schema,
    impute_unfilled_columns,
)

from datasource.travellers.schema import (
    TransformedSchema,
    AggregatedSchema as TravellersSchema,
    TRANSFORMED_COLUMNS,
)
from datasource.manual_entry_travellers.schema import RawSchema


def manual_entry_travellers_030(df: pd.DataFrame, reference_year: int) -> pd.DataFrame:
    # defining reference year here temoporarily just for testing
    REFERENCE_YEAR = reference_year

    # Get travellers table for the current year
    current = Loader.query(
        Stage.AGGREGATED,
        datasource=DataSource.travellers,
        year=int(df.iloc[0][RawSchema.year]),
        month=int(df.iloc[0][RawSchema.month]),
        day=1,
    )
    current = TravellersSchema(current)

    previous = Loader.query(
        Stage.AGGREGATED,
        datasource=DataSource.travellers,
        year=REFERENCE_YEAR,
        month=int(df.iloc[0][RawSchema.month]),
        day=1,
    )
    previous = TravellersSchema(previous)

    df["province"] = df[RawSchema.port].str.slice(stop=2).astype(int)
    previous["province"] = previous[RawSchema.port].str.slice(stop=2).astype(int)
    current["province"] = current[RawSchema.port].str.slice(stop=2).astype(int)
    
    df = impute_unfilled_columns(df, current, previous, RawSchema, counter=0)
    # Create extra columns so that the output matches the Travellers schema
    df = convert_to_travellers_schema(df)
    # Fill in missing values with the appropriate codes
    df = convert_pd_na_to_code_travellers(df)

    # Drop zeros before returning and reset index
    travellers_df = df[~(df[RawSchema.count_of_entries] == 0)].reset_index(drop=True)

    travellers_df = travellers_df[TRANSFORMED_COLUMNS]

    # Ensure that the output dataframe adheres to the transformed schema
    travellers_df = TransformedSchema(travellers_df)

    return travellers_df
