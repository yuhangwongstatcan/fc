import pandas as pd

from config.api import DataSource, ManualEntryTrackerTravellers

from modules.utils.loaders import Loader

from config.api import Stage

from datasource.manual_entry_tracker_travellers.schema import (
    ReferenceSchema as TrackerSchema,
)


def manual_entry_travellers_v007(df: pd.DataFrame) -> pd.DataFrame:
    """
    Carries out the manaul entry tracker logic. Checks which rows were present in manual entry
    tracker and not in manual entry data

    Args:
        df:
            A pandas dataframe of manual entry data for travellers.

    Returns:
        df:
            A pandas dataframe of manual entry data for travellers.

        auxiliary_df:
            A pandas dataframe of entries from the tracker that were
            not present in the manual entries (missing data).
    """
    # Load the tracker to get the vehicles data we expect to receive
    # for manual entry
    tracker = Loader.get(
        Stage.REFERENCE,
        DataSource.manual_entry_tracker_travellers,
        ManualEntryTrackerTravellers.manual_entry_tracker_travellers,
    )

    # Ensure that the tracker file matches the schema
    tracker = TrackerSchema(tracker)

    match = pd.merge(
        df, tracker, how="outer", on=tracker.columns.tolist(), indicator=True
    )
    validation_df = match.query('_merge != "left_only" & _merge != "both"')[
        tracker.columns
    ]

    return df, validation_df
