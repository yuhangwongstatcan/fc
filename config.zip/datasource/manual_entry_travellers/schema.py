"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define the schema model for the MANUAL ENTRY TRAVELLERS data source.
"""

import pandera as pa
from pandera.typing import Series

from modules.utils.schema_wrappers import FCSchemaModel

from datasource.common.dim import (
    MONTH,
    DAY,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
)
from datasource.travellers.dim import (
    ARRIVING_FROM,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DATA_SOURCE,
)

from datasource.common.types import SafeIntToStringType


class RawSchema(FCSchemaModel):
    """
    Raw schema for the MANUAL ENTRY VEHICLES data source.
    """

    year: Series[SafeIntToStringType] = pa.Field(
        description="Year in which the border crossing occurred",
        str_matches=r"\d{4}",
        coerce=True,
    )
    month: Series[SafeIntToStringType] = pa.Field(
        description="Month in which the border crossing occurred",
        isin=MONTH,
        coerce=True,
    )
    day: Series[SafeIntToStringType] = pa.Field(
        description="Day in which the border crossing occurred",
        isin=DAY.list(),
        coerce=True,
        nullable=True,
    )
    port: Series[SafeIntToStringType] = pa.Field(
        description="Statistics Canada port of the border crossing",
        str_matches=r"\d{5}",
        coerce=True,
    )
    vehicle_type: Series[SafeIntToStringType] = pa.Field(
        description="Vehicle type",
        isin=VEHICLE_TYPE.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    plate_country: Series[SafeIntToStringType] = pa.Field(
        description="Country of vehicle licence plate, if applicable",
        isin=PLATE_COUNTRY.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    arriving_from: Series[SafeIntToStringType] = pa.Field(
        description="Type of arrival, either U.S. only, overseas direct or via U.S.",
        isin=ARRIVING_FROM.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    country_of_residence: Series[SafeIntToStringType] = pa.Field(
        description="Country of residence of arriving traveller",
        str_matches=r"\d{5}",
        coerce=True,
        nullable=True,
    )
    purpose9: Series[SafeIntToStringType] = pa.Field(
        description="Detailed trip purpose",
        isin=PURPOSE9.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    purpose4: Series[SafeIntToStringType] = pa.Field(
        description="Aggregated trip purpose",
        isin=PURPOSE4.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    duration2: Series[SafeIntToStringType] = pa.Field(
        description="Duration of trip, divided into two categories",
        isin=DURATION2.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    data_source: Series[SafeIntToStringType] = pa.Field(
        description="Canada Border Services Agency data source",
        isin=DATA_SOURCE.list(),
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    count_of_entries: Series[pa.INT64] = pa.Field(
        description="Count of border crossings",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [
            RawSchema.year,
            RawSchema.month,
            RawSchema.day,
            RawSchema.port,
            RawSchema.vehicle_type,
            RawSchema.plate_country,
            RawSchema.arriving_from,
            RawSchema.country_of_residence,
            RawSchema.purpose9,
            RawSchema.purpose4,
            RawSchema.duration2,
            RawSchema.data_source,
        ]


class CleanSchema(RawSchema):
    """
    Clean schema for the MANUAL ENTRY VEHICLES data source.
    """


# Define the list of "GREEN" columns which are imputed if they are missing
# They are called "GREEN" columns because they were coloured green in the specifications
# Other types of columns ("BLACK" or "RED") are not imputed even if they are missing
GREEN_COLUMNS = [
    RawSchema.vehicle_type,
    RawSchema.plate_country,
    RawSchema.arriving_from,
    RawSchema.country_of_residence,
    RawSchema.purpose4,
    RawSchema.duration2,
]
