"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        mapping files.
"""

import pandera as pa
from pandera.typing import Series


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the MAPPING reference files.
    """

    key: Series[pa.String] = pa.Field(
        description="Raw data value that needs to be mapped to a Frontier Counts standard",
        coerce=True,
    )
    value: Series[pa.String] = pa.Field(
        description="Frontier Counts standard value to be mapped to",
        coerce=True,
    )
    desc_en: Series[pa.String] = pa.Field(
        description="Description in English",
        coerce=True,
        nullable=True,
    )
    desc_fr: Series[pa.String] = pa.Field(
        description="Description in French",
        coerce=True,
        nullable=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.key]
