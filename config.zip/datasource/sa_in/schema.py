"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema 
        verification of the SA_IN data source.
"""

import pandera as pa
from pandera.typing import Series


class AggregatedSchema(pa.SchemaModel):
    """
    Schema for SA_IN
    """

    SERIES: Series[pa.String] = pa.Field(
        description="Name of the series",
        coerce=True,
    )
    DATE: Series[pa.String] = pa.Field(
        description="Date in the format YYYYMM",
        coerce=True,
    )
    VALUE: Series[pa.String] = pa.Field(
        description="Input value for the series",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [AggregatedSchema.SERIES, AggregatedSchema.DATE]
