"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema verification of the
        FIXED PROPORTION RULES reference file which defines the fixed
        proportion rules (which variables are impacted).
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.types import SafeIntToStringType


class ReferenceSchema(pa.SchemaModel):
    """
    Raw schema for the MANUAL ENTRY VEHICLES data source.
    """

    data_source: Series[SafeIntToStringType] = pa.Field(
        description="Canada Border Services Agency data source",
        coerce=True,
        nullable=True,
    )
    port: Series[pa.String] = pa.Field(
        description="Statistics Canada port of the border crossing",
        str_matches=r"\d{5}",
        coerce=True,
    )
    valid_from: Series[pa.String] = pa.Field(
        description="Date from which the fixed rule is valid.", coerce=True,
    )
    valid_to: Series[pa.String] = pa.Field(
        description="Date to which the fixed rule is valid.", coerce=True,
    )
    vehicle_type: Series[SafeIntToStringType] = pa.Field(
        description="Vehicle type", coerce=True, nullable=True,
    )
    plate_country: Series[SafeIntToStringType] = pa.Field(
        description="Country of vehicle licence plate, if applicable",
        coerce=True,
        raise_warning=True,
        nullable=True,
    )
    arriving_from: Series[SafeIntToStringType] = pa.Field(
        description="Type of arrival, either U.S. only, overseas direct or via U.S.",
        coerce=True,
        nullable=True,
    )
    country_of_residence: Series[SafeIntToStringType] = pa.Field(
        description="Country of residence of arriving traveller",
        coerce=True,
        nullable=True,
    )
    purpose4: Series[SafeIntToStringType] = pa.Field(
        description="Aggregated trip purpose", coerce=True, nullable=True,
    )
    duration2: Series[SafeIntToStringType] = pa.Field(
        description="Duration of trip, divided into two categories",
        coerce=True,
        nullable=True,
    )
    fixed_prop_variable: Series[pa.String] = pa.Field(
        description="Variable for which we are defining fixed proportions in each category.",
        coerce=True,
    )
    rule_id: Series[pa.String] = pa.Field(
        description="Unique ID for a fixed rule.", coerce=True,
    )

    @staticmethod
    def get_keys():
        return [
            ReferenceSchema.data_source,
            ReferenceSchema.port,
            ReferenceSchema.vehicle_type,
            ReferenceSchema.plate_country,
            ReferenceSchema.arriving_from,
            ReferenceSchema.country_of_residence,
            ReferenceSchema.purpose4,
            ReferenceSchema.duration2,
            ReferenceSchema.fixed_prop_variable,
        ]