"""
    Program: schema.py

    Author: Fang Wang, fang.wang@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the NEXUS Highway data source.
"""


from typing import Optional
import pandera as pa
from pandera.typing import Series

from datasource.nexus_hwy.dim import CITIZENSHIP
from datasource.travellers.dim import DURATION2

from datasource.common.types import SafeIntToStringType
from datasource.common.dim import PLATE_COUNTRY


# Define pandera fields
DATE_FIELD = pa.Field(
        description="""Month of arrival in Canada, of the form YYYY-MM-DD,
        with DD fixed as 01""",
        str_matches=r"\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])",
        coerce=True
)

WLOC_FIELD = pa.Field(
        description="Land border",
        coerce=True
)

CITIZENSHIP_FIELD = pa.Field(
    description="Country of residence of travellers",
    isin=CITIZENSHIP.list(),
    coerce=True,
    raise_warning=True
)

WORK_LOCATION_FIELD = pa.Field(
    description="CBSA work location as mapped from the str wloc name",
    str_matches="\d{4}",
    coerce=True,
    nullable=True,
)

PLATE_COUNTRY_FIELD = pa.Field(
    description="""CBSA work location as mapped from the NEXUS Highway reporting
    site text str name""",
    isin=PLATE_COUNTRY.list(),
    coerce=True,
    raise_warning=True
)

DURATION2_FIELD = pa.Field(
    description="""Trip duration of the travellers, either same-day or
    overnight""",
    isin=DURATION2.list(),
    coerce=True,
    nullable=True,
    raise_warning=True
)


# Define schemas
class RawSchema(pa.SchemaModel):
    """
    Schema for NEXUS Highway RAW data.
    """
    date: Series[pa.String] = DATE_FIELD

    wloc: Series[pa.String] = WLOC_FIELD

    citizenship: Series[pa.String] = CITIZENSHIP_FIELD

    count: Series[pa.INT64] = pa.Field(
        description="Count of Nexus arrivals by land",
        ge=0,
        coerce=True
    )

    work_location: Optional[Series[SafeIntToStringType]] = WORK_LOCATION_FIELD
    plate_country: Optional[Series[SafeIntToStringType]] = PLATE_COUNTRY_FIELD
    duration2: Optional[Series[SafeIntToStringType]] = DURATION2_FIELD

    @staticmethod
    def get_keys():
        return [RawSchema.date, RawSchema.wloc, RawSchema.citizenship]



class CleanSchema(RawSchema):
    """
    Schema for NEXUS Highway CLEAN data.
    """
    work_location: Series[SafeIntToStringType] = WORK_LOCATION_FIELD
    plate_country: Series[SafeIntToStringType] = PLATE_COUNTRY_FIELD
    duration2: Series[SafeIntToStringType] = DURATION2_FIELD


class ValidationSchema(pa.SchemaModel):
    """
    Schema for variables appearing in validation output but not RAW or CLEAN NEXUS Highway data
    """
    variable: Optional[Series[pa.String]] = pa.Field(
        description="Name of a NEXUS Highway dimension variable with unexpected values",
        coerce=True,
    )

    unexpected_value: Optional[Series[pa.String]] = pa.Field(
        description="Unexpected value observed in a NEXUS Highway dimension variable",
        coerce=True,
        nullable=True,
    )

    location: Optional[Series[pa.String]] = pa.Field(
        description="Location associated with the invalid record",
        coerce=True,
    )

    count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences of a particular validation case",
        ge=0,
        coerce=True,
    )

    date: Optional[Series[pa.String]] = DATE_FIELD

    work_location_issue_type: Optional[Series[pa.String]] = pa.Field(
        description="Type of data availability issue that caused a work location to be flagged.",
        isin=[
            "Missing Work Locations",
            "Unexpected Work Locations",
            "Zero NEXUS Travellers",
        ],
        coerce=True,
        raise_warning=True
    )

    wloc: Optional[Series[pa.String]] = WLOC_FIELD

    original_vehicle_count: Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences of a particular validation case",
        ge=0,
        coerce=True,
    )

    adjusted_vehicle_count:Optional[Series[pa.INT64]] = pa.Field(
        description="Count of occurrences of a particular validation case",
        ge=0,
        coerce=True,
    )


# Define columns for subsetting dataframes when temporary columns are used
RAWSCHEMA_COLUMNS = [col for col in RawSchema.to_schema().columns.keys() if
                     RawSchema.to_schema().columns[col].required]
NEXUS_HWY_005_COLUMNS = [*RAWSCHEMA_COLUMNS, RawSchema.work_location]
NEXUS_HWY_040_COLUMNS = [*NEXUS_HWY_005_COLUMNS, RawSchema.plate_country]

CLEANSCHEMA_COLUMNS = [col for col in CleanSchema.to_schema().columns.keys()]

NEXUS_HWY_V000_COLUMNS = [ValidationSchema.variable,
                    ValidationSchema.unexpected_value,
                    ValidationSchema.date,
                    ValidationSchema.location,
                    ValidationSchema.count]

NEXUS_HWY_V010_COLUMNS = [ValidationSchema.date,
                    ValidationSchema.work_location_issue_type,
                    ValidationSchema.wloc]

NEXUS_HWY_V020_COLUMNS = [ValidationSchema.date,
                    ValidationSchema.wloc,
                    ValidationSchema.original_vehicle_count,
                    ValidationSchema.adjusted_vehicle_count]