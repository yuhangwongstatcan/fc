"""
**Author(s)**

- Fang Wang - fang.wang@statcan.gc.ca

**Created On:** May 2023

**Description:**

The pipeline definitions for the NEXUS highway data source. Two pipelines are defined in this
module:

1. `RAW` --> `CLEAN`

2. `CLEAN` --> `TRANSFORMED`

"""


import logging

from modules.pipeline import BasePipeline
from modules.pipeline import PipelineOutput

from datasource.nexus_hwy.data_processing import *
from datasource.nexus_hwy.schema import RawSchema, CleanSchema

from datasource.vehicles.schema import TransformedSchema as VehiclesSchema
from datasource.travellers.schema import TransformedSchema as TravellersSchema

from modules.utils.loaders import Loader
from modules.utils.uid import PipelineUID
from modules.pipeline import validation_writer

from config.api import Stage, DataSource, S3


class PipelineRawClean(BasePipeline):
    """
    Runs the RAW -> CLEAN pipeline for the NEXUS highway data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()

        # Read in initial RAW data file and apply the RAW schema to it
        df = Loader.query(
            Stage.RAW, datasource=self.datasource, year=self.year, month=self.month
        )

        # Make sure the input df adheres to the raw schema
        df = RawSchema(df)
        logging.info("Successfully loaded RAW NEXUS highway data")
        print("Successfully loaded RAW NEXUS highway data")

        # VALIDATION: Check for unexpected values in dimension variables
        print("   1.Starting processing nexus_hwy_000")
        validation_df = nexus_hwy_v000(df)
        validation_writer(validation_df, nexus_hwy_v000, self.datasource, self.date)
        logging.info("Finished processing nexus_hwy_000")
        print("   1.Finished processing nexus_hwy_000")

        # Add work location code to NEXUS Highway data
        print("   2.Starting processing nexus_hwy_005")
        df = nexus_hwy_005(df)
        logging.info("Finished processing nexus_hwy_005")
        print("   2.Finished processing nexus_hwy_005")

        # Remove NEXUS Highway records with unexpected work locations
        print("   3.Starting processing nexus_hwy_010")
        df, auxiliary_df = nexus_hwy_010(df)
        # VALIDTION: Check for new or unexpected work locations
        validation_df = nexus_hwy_v010(df, auxiliary_df)
        validation_writer(validation_df, nexus_hwy_v010, self.datasource, self.date)
        logging.info("Finished processing nexus_hwy_010")
        print("   3.Finished processing nexus_hwy_010")

        # Correct number of NEXUS Highway vehicles if higher than travellers
        print("   4.Starting processing nexus_hwy_020")
        df, auxiliary_df = nexus_hwy_020(df)
        # VALIDTION: Check for number of NEXUS Highway vehicles if higher than travellers
        validation_df = nexus_hwy_v020(df, auxiliary_df)
        validation_writer(validation_df, nexus_hwy_v020, self.datasource, self.date)
        logging.info("Finished processing nexus_hwy_020")
        print("   4.Finished processing nexus_hwy_020")

        # Impute citizenship for unknown and other categories in NEXUS Highway
        print("   5.Starting processing nexus_hwy_030")
        df = nexus_hwy_030(df)
        logging.info("Finished processing nexus_hwy_030")
        print("   5.Finished processing nexus_hwy_030")

        # Impute licence plate country in NEXUS Highway
        print("   6.Starting processing nexus_hwy_040")
        df = nexus_hwy_040(df)
        logging.info("Finished processing nexus_hwy_040")
        print("   6.Finished processing nexus_hwy_040")

        # Impute trip duration for NEXUS Highway travellers
        print("   7.Starting processing nexus_hwy_050")
        df = nexus_hwy_050(df)
        logging.info("Finished processing nexus_hwy_050")
        print("   7.Finished processing nexus_hwy_050")

        # Make sure that the output df adheres to the clean schema
        df = CleanSchema(df)

        # Save outputs to outputs dictionary
        nexus_hwy_clean = PipelineOutput(
            data=df,
            stage=Stage.CLEAN,
            datasource=self.datasource,
            basename=S3.get_s3_basename(
                Stage.CLEAN, self.datasource, self.year, self.month, self.day
            ),
        )
        # Add pipeline output to outputs dictionary
        self.outputs[self.datasource.value] = nexus_hwy_clean
        logging.info("Finished processing NEXUS HIGHWAY RAW -> CLEAN pipeline")
        print("Finished processing NEXUS HIGHWAY RAW -> CLEAN pipeline")


class PipelineCleanTransformed(BasePipeline):
    """
    Runs the CLEAN -> TRANSFORMED pipeline for the NEXUS highway data source.
    """

    def pipeline(self):
        # Set the UID once pipeline is called.
        PipelineUID.get_uid()
        # Get the initial pandas data frame
        basename = S3.get_s3_basename(
            Stage.CLEAN,
            datasource=DataSource.nexus_hwy,
            year=self.year,
            month=self.month,
            day=self.day,
        )
        df = Loader.get(Stage.CLEAN, datasource=self.datasource, basename=basename)

        # Make sure the input df adheres to the clean schema
        df = CleanSchema(df)

        # Perform the tranformation to get the vehicles table
        print("   1.Starting processing nexus_hwy_060")
        vehicles = nexus_hwy_060(df)
        logging.info("Finished processing nexus_hwy_060")
        print("   1.Finished processing nexus_hwy_060")
        vehicles = VehiclesSchema(vehicles)

        # Perform the tranformation to get the travellers table
        print("   2.Starting processing nexus_hwy_060")
        travellers = nexus_hwy_070(df)
        logging.info("Finished processing nexus_hwy_060")
        print("   2.Finished processing nexus_hwy_060")
        travellers = TravellersSchema(travellers)

        # Save vehicles/travellers outputs to dictionary
        vehicles_output = PipelineOutput(
            data=vehicles,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.vehicles,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )
        travellers_output = PipelineOutput(
            data=travellers,
            stage=Stage.TRANSFORMED,
            datasource=DataSource.travellers,
            basename=S3.get_s3_basename(
                Stage.TRANSFORMED, self.datasource, self.year, self.month, self.day
            ),
        )

        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.vehicles.value] = vehicles_output
        self.outputs[DataSource.travellers.value] = travellers_output
        logging.info("Finished processing NEXUS HIGHWAY CLEAN -> TRANSFORMED pipeline")
        print("Finished processing NEXUS HIGHWAY CLEAN -> TRANSFORMED pipeline")
