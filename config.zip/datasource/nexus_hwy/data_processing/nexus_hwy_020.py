"""
Implements the nexus_hwy_020 business rule and validation
"""

import pandas as pd
from datasource.nexus_hwy.dim import CITIZENSHIP
from datasource.nexus_hwy.schema import (
    RawSchema,
    NEXUS_HWY_005_COLUMNS,
    NEXUS_HWY_V020_COLUMNS,
    ValidationSchema
)

def nexus_hwy_020(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensures the total number of vehicles is less than or equal to the the
    total number of passengers at a given port.

    Args:
        df:
            a pandas dataframe that possibly contains entries with total
            vehicles greater than total passengers.
    Returns:
        df:
            A pandas dataframe that ensures total vehicles <= total passengers.
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            entries with total vehicles greater than total passengers.
    """

    df = df.sort_values(RawSchema.wloc).reset_index(drop=True)
    mask = df[RawSchema.citizenship]==CITIZENSHIP.vehicle.value
    travellers = df[~mask].copy()
    
    # Get rows that citizenship is VEHICLE
    vehicles = df[mask].reset_index()
    if not vehicles.empty:
        # group and sum travellers
        groupby_df = travellers.groupby(by=[RawSchema.wloc, RawSchema.work_location],dropna=False, as_index= False)
        groupby_df = groupby_df[[RawSchema.count]].apply(lambda x: x.astype(int).sum()).astype({
            RawSchema.count: "Int64",
        })
        travellers = travellers.sort_values(RawSchema.wloc).reset_index(drop=True)
        vehicles = vehicles.sort_values(RawSchema.wloc).reset_index(drop=True)
        # Determine if there are rows where traveller count is less than vehicles 
        mask2 = groupby_df[RawSchema.count] < vehicles[RawSchema.count]

        df[RawSchema.count] = df[RawSchema.count].copy()

        # Output the auxiliary file for the validation in cases where travellers < vehicles
        auxiliary_df = pd.merge(vehicles[mask2],groupby_df[mask2],on=[RawSchema.wloc])
        auxiliary_df = auxiliary_df.rename(columns={"count_x": ValidationSchema.original_vehicle_count, "count_y": ValidationSchema.adjusted_vehicle_count})

        # Where travellers<vehicles, set vehicles equal to number of travellers 
        df.loc[df[mask].reset_index()[mask2]["index"].values,[RawSchema.count]] = groupby_df[mask2][RawSchema.count].astype(int).values
        
        df = df[NEXUS_HWY_005_COLUMNS] 
        df = RawSchema(df)
    
    return df, auxiliary_df

def nexus_hwy_v020(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule nexus_hwy_v020

    Args:
        df:
            a pandas dataframe containing records that have had their number of vehicles
            adjusted based on the number of travellers.
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            entries with total vehicles greater than total passengers.
    Returns:
        validation_df:
            The return value of nexus_hwy_v020
    """

    validation_df = auxiliary_df[NEXUS_HWY_V020_COLUMNS].copy()
    validation_df = ValidationSchema(validation_df)

    return validation_df