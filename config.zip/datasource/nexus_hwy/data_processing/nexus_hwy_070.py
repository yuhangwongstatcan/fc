"""
Implements the nexus_hwy_070 Business Rule
"""
import pandas as pd

from config.api import DataSource, Stage
from modules.utils.loaders import Loader

from datasource.nexus_hwy.dim import CITIZENSHIP
from datasource.nexus_hwy.schema import CleanSchema
from datasource.common.dim import (
    PLATE_REGION,
    DAY,
    MODE,
    VEHICLE_TYPE,
    DATA_SOURCE
)

from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema

from datasource.travellers.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)

from datasource.travellers.dim import (
    ARRIVING_FROM,
    PURPOSE9,
    PURPOSE4,
    DURATION2,
    DURATION3,
    DURATION5,
    TRAVELLER_TYPE,
    COUNTRY_OF_RESIDENCE
)


def nexus_hwy_070(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Bryan Southwell - `bryan.southwell.brown@canada.ca`

    **Created On:** May, 2021

    **Description:**

    Performs the business logic that transforms cleaned nexus_hwy data into PIK's contribution
    to the travellers table.

    Args:
        df: pd.DataFrame
    Returns:
        Output:
            An instance of RuleOutput containing nexus_hwy's contribution to the travellers table.
    """
    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations,
        None
    )
    work_locations = WorkLocationsSchema(work_locations)  
      
    # expected_worklocations = pd.read_csv('./tests/mock_minio/reference/work_locations_trans_action/work_locations__pik.csv')
    df = df[df[CleanSchema.citizenship]!=CITIZENSHIP.vehicle.value]
    
    # 1. Add a data source column and set it to PIK
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.Nexus_Highway.value

    df[
        [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
    ] = df[CleanSchema.date].str.split("-", expand=True)

    df[TransformedSchema.month] = df[TransformedSchema.month].replace({r"0(\d)":r"\1"}, regex=True)

    df.loc[:,TransformedSchema.day] = DAY.not_available.value
    df.loc[:, TransformedSchema.work_location] = df[
        TransformedSchema.work_location
    ].copy()
    df = pd.merge(
        df,
        work_locations[
            [
                # WorkLocationsSchema.prov_chr,
                 WorkLocationsSchema.work_location,
                 WorkLocationsSchema.port,         
            ]
        ],
        left_on=CleanSchema.work_location,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )

    df[TransformedSchema.mode] = MODE.land.value
    df[TransformedSchema.vehicle_type] = VEHICLE_TYPE.automobile.value
    df[TransformedSchema.plate_country] = df[CleanSchema.plate_country]
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value
    df[TransformedSchema.arriving_from] = ARRIVING_FROM.us_only.value 

    df.loc[df[CleanSchema.citizenship]==CITIZENSHIP.canada.value, TransformedSchema.country_of_residence] = COUNTRY_OF_RESIDENCE.canada.value  
    df.loc[df[CleanSchema.citizenship]==CITIZENSHIP.united_states.value,TransformedSchema.country_of_residence] =  COUNTRY_OF_RESIDENCE.united_states.value  

    df[TransformedSchema.purpose4] = PURPOSE4.visit.value
    df[TransformedSchema.purpose9] = PURPOSE9.visit.value
    df[TransformedSchema.duration2] = df[CleanSchema.duration2]
    df[TransformedSchema.duration3] = DURATION3.not_available.value
    df[TransformedSchema.duration5] = DURATION5.not_available.value

    mask1 = (df[TransformedSchema.duration2] == DURATION2.same_day.value)
    df.loc[mask1
        , TransformedSchema.traveller_type] = TRAVELLER_TYPE.excursionist.value

    mask2 = (df[TransformedSchema.duration2] == DURATION2.overnight.value)
    df.loc[mask2
        , TransformedSchema.traveller_type] = TRAVELLER_TYPE.tourist.value

    df[TransformedSchema.work_location] = df[CleanSchema.work_location]

    df[TransformedSchema.count_of_entries] = df[CleanSchema.count]
    df = df[   
        [
            TransformedSchema.year,
            TransformedSchema.month,
            TransformedSchema.day,
            WorkLocationsSchema.port,
            TransformedSchema.mode,
            TransformedSchema.vehicle_type,
            TransformedSchema.plate_country,
            TransformedSchema.plate_region,
            TransformedSchema.arriving_from,
            TransformedSchema.country_of_residence,
            TransformedSchema.purpose9,
            TransformedSchema.purpose4,
            TransformedSchema.duration2,
            TransformedSchema.duration3,
            TransformedSchema.duration5,
            TransformedSchema.traveller_type, 
            WorkLocationsSchema.work_location,
            TransformedSchema.data_source,
            TransformedSchema.count_of_entries          
        ]
    ]

    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = df.groupby(by=TRANSFORMED_GROUPBY, dropna=False,).sum().reset_index()

    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS

    # Reorder the re-named columns
    df = df[TRANSFORMED_COLUMNS]

    # Cast correct type to count of entries
    df.loc[:, TransformedSchema.count_of_entries] = df[
        TransformedSchema.count_of_entries
    ].astype("Int64")

    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]

    # Sort entries from left to right
    df = df.sort_values(TRANSFORMED_COLUMNS, ascending=True,)

    df=TransformedSchema(df)
    
    return df
