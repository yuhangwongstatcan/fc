"""
Implements the nexus_hwy_v000 validation Rule
"""
import pandas as pd

from datasource.nexus_hwy.schema import (
    RawSchema, 
    ValidationSchema, 
    NEXUS_HWY_V000_COLUMNS
)

from datasource.nexus_hwy.dim import CITIZENSHIP


def nexus_hwy_v000(df: pd.DataFrame) -> pd.DataFrame:
    """
    Provide a visualization for end users to view a summary of unexpected values for discrete variables in NEXUS Highway.

    Args:
        df:
            a pandas dataframe containing records that possibly contain
            invalid citizenships.
    Returns:
        validation_df:
            Validation file summarizing the unexpected values which will be used in dashboards.

    """
    
    validation_df = df[~df[RawSchema.citizenship].isin(CITIZENSHIP.list())]
    
    validation_df.insert(loc = 0,column = ValidationSchema.variable, value = "citizenship")

    validation_df = validation_df[validation_df["citizenship"]!= "VEHICLE"]

    validation_df = validation_df.rename(
        columns={
           RawSchema.citizenship:ValidationSchema.unexpected_value,
           RawSchema.wloc:ValidationSchema.location
        }
    )

    validation_df = validation_df[NEXUS_HWY_V000_COLUMNS]
    validation_df = ValidationSchema(validation_df)
    validation_df = validation_df.sort_values(ValidationSchema.unexpected_value)

    return validation_df
