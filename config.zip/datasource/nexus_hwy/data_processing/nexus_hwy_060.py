"""
Implements the nexus_hwy_060 Business Rule
"""

import pandas as pd

from datasource.nexus_hwy.schema import CleanSchema
from datasource.nexus_hwy.dim import CITIZENSHIP

from config.api import Stage, DataSource
from modules.utils.loaders import Loader

from datasource.vehicles.schema import (
    TransformedSchema,
    TRANSFORMED_COLUMNS,
    TRANSFORMED_GROUPBY,
)
from datasource.common.dim import (
    PLATE_REGION,
    DAY,
    MODE,
    VEHICLE_TYPE,
    DATA_SOURCE
)

from datasource.work_locations.schema import ReferenceSchema as WorkLocationsSchema


def nexus_hwy_060(df: pd.DataFrame) -> pd.DataFrame:
    """
    **Author(s)**

    - Bryan Southwell - `bryan.southwell@canada.ca`

    **Created On:** June, 2021

    **Description:**

    Ensures that all transformations for the VEHICLE dataset can be done
    correctly from the cleaned nexus_hwy data.

    Args:
        df: pd.DataFrame
            A pandas dataframe with clean data in the CBSA format.
    Returns:
        df: pd.DataFrame:
            A pandas dataframe containing mexus_hwy's contribution to the vehicles table.
    """
    # Get ports list
    work_locations = Loader.get(
        Stage.REFERENCE, 
        DataSource.work_locations,
        None
    )
    work_locations = WorkLocationsSchema(work_locations)  
    
    # 1. Add a data source column and set it to nexus_hwy
    df.loc[:, TransformedSchema.data_source] = DATA_SOURCE.Nexus_Highway.value
    df = df[df[CleanSchema.citizenship]==CITIZENSHIP.vehicle.value]
    
    # 2. Parse %Y/%m/%d string of df_schema.date column into three columns: 'year',
    # 'month', 'day'
    df=df.copy()
    df[
        [TransformedSchema.year, TransformedSchema.month, TransformedSchema.day]
    ] = df[CleanSchema.date].str.split("-", expand=True)

    df[TransformedSchema.month] = df[TransformedSchema.month].replace({r"0(\d)":r"\1"}, regex=True)

    df.loc[:,TransformedSchema.day] = DAY.not_available.value
    
    # 3. Create location variables: input_schema.province, TransformedSchema.port, and
    # TransformedSchema.work_location
    # Merge with port list using 'cport' field
    df.loc[:, TransformedSchema.work_location] = df[
        TransformedSchema.work_location
    ].copy()
    df = pd.merge(
        df,
        work_locations[
            [
                WorkLocationsSchema.port,
                WorkLocationsSchema.work_location,
            ]
        ],
        left_on=CleanSchema.work_location,
        right_on=WorkLocationsSchema.work_location,
        how="left",
    )

    df[TransformedSchema.mode] = MODE.land.value
    df[TransformedSchema.vehicle_type] = VEHICLE_TYPE.automobile.value
    df[TransformedSchema.plate_country] = df[CleanSchema.plate_country]
    df[TransformedSchema.plate_region] = PLATE_REGION.NA.value

    df[TransformedSchema.count_of_entries] = df[CleanSchema.count]
    df = df[   
        [
            TransformedSchema.year,
            TransformedSchema.month,
            TransformedSchema.day,
            WorkLocationsSchema.port,
            TransformedSchema.mode,
            TransformedSchema.vehicle_type,
            TransformedSchema.plate_country,
            TransformedSchema.plate_region, 
            WorkLocationsSchema.work_location,
            TransformedSchema.data_source,
            TransformedSchema.count_of_entries          
        ]
    ]
    
    # This performs a large COUNT(1) GROUP BY all columns operation.
    df = df.groupby(by=TRANSFORMED_GROUPBY, dropna=False,).sum().reset_index()

    # Rename the columns to match the schema file
    df.columns = TRANSFORMED_COLUMNS
    
    # Reorder the re-named columns
    df = df[TRANSFORMED_COLUMNS]

    # Cast correct type to count of entries
    df.loc[:, TransformedSchema.count_of_entries] = df[
        TransformedSchema.count_of_entries
    ].astype("Int64")

    # Drop all entries that are == 0
    df = df[df[TransformedSchema.count_of_entries] > 0]

    # Sort entries from left to right
    df = df.sort_values(TRANSFORMED_COLUMNS, ascending=True,)

    df = TransformedSchema(df)

    return df
