"""
Implements the nexus_hwy_040 business rule
"""

import pandas as pd

from datasource.nexus_hwy.schema import RawSchema,NEXUS_HWY_040_COLUMNS
from datasource.nexus_hwy.dim import CITIZENSHIP
from datasource.common.dim import PLATE_COUNTRY


def nexus_hwy_040(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute licence plate country in NEXUS Highway

    Args:
        df:
            A pandas dataframe without plate_country
    Returns:
        output:
            A pandas dataframe with added PLATE_COUNTRY column
    """

    # Get required counts for proportion calculation (see docs for equation)
    Canadian_travellers = df[df[RawSchema.citizenship]==CITIZENSHIP.canada.value][[RawSchema.work_location, RawSchema.citizenship, RawSchema.count]]
    US_travellers = df[df[RawSchema.citizenship]==CITIZENSHIP.united_states.value][[RawSchema.work_location, RawSchema.citizenship, RawSchema.count]]
    total_vehicles = df[df[RawSchema.citizenship]==CITIZENSHIP.vehicle.value][[RawSchema.work_location, RawSchema.citizenship, RawSchema.count]]
    travellers = df[(df[RawSchema.citizenship]==CITIZENSHIP.canada.value) | (df[RawSchema.citizenship]==CITIZENSHIP.united_states.value)]
    total_travellers = travellers.groupby(by=[RawSchema.work_location],dropna=False, as_index= False)
    total_travellers = total_travellers[[RawSchema.count]].apply(lambda x: x.astype(int).sum())
    work_locations = pd.DataFrame(df[RawSchema.work_location].unique(), columns = [RawSchema.work_location])
    total_travellers = total_travellers.sort_values(by=RawSchema.work_location)
    total_vehicles = total_vehicles.sort_values(by=RawSchema.work_location)
    Canadian_travellers = Canadian_travellers.sort_values(by=RawSchema.work_location)
    US_travellers = US_travellers.sort_values(by=RawSchema.work_location)
    work_locations = work_locations.sort_values(by=RawSchema.work_location).reset_index(drop=True)
    
    # Get Canadian and US proportions 
    prop_can = pd.DataFrame(round(total_vehicles[RawSchema.count].reset_index(drop=True).astype(int)*(
        Canadian_travellers[RawSchema.count].astype(int) / total_travellers[RawSchema.count].astype(int).values).fillna(0).reset_index(drop=True)))
    prop_can = pd.concat([prop_can, work_locations], axis=1)
    prop_US = pd.DataFrame(round(total_vehicles[RawSchema.count].reset_index(drop=True).astype(int)*(
        US_travellers[RawSchema.count].astype(int) / total_travellers[RawSchema.count].astype(int).values).fillna(0).reset_index(drop=True)))
    prop_US = pd.concat([prop_US, work_locations], axis=1)
    prop_can[RawSchema.plate_country] =PLATE_COUNTRY.canada.value
    prop_US[RawSchema.plate_country] =PLATE_COUNTRY.united_states.value
    prop = prop_can.append(prop_US)
    
    # Define a seperate dataframe of the citizenship == "VEHICLE" rows, and then do the necessary replacement via the proportions
    vehicles = df[df[RawSchema.citizenship]==CITIZENSHIP.vehicle.value]
    vehicles_proportioned = pd.merge(vehicles,prop,on=[RawSchema.work_location], how="left")
    vehicles_proportioned["count_x"] = vehicles_proportioned["count_y"].copy()
    vehicles_proportioned = vehicles_proportioned.rename(columns={"count_x":RawSchema.count})
    vehicles_proportioned = vehicles_proportioned.drop(columns=["count_y"])
    vehicles_proportioned[RawSchema.count] = vehicles_proportioned[RawSchema.count].astype(int)
    
    # Drop the citizenship == "VEHICLE" rows from the df as these will be replaced using the vehicles_proportioned df
    df = df[df[RawSchema.citizenship]!=CITIZENSHIP.vehicle.value]
    df = df.assign(plate_country = PLATE_COUNTRY.canada.value)
    df.loc[df[df[RawSchema.citizenship]==CITIZENSHIP.united_states.value][RawSchema.plate_country].index.values,[RawSchema.plate_country]] = PLATE_COUNTRY.united_states.value
    
    # Put the new VEHICLE rows back in the input
    output = df.append(vehicles_proportioned)
    output = output.sort_values(by=[RawSchema.work_location, RawSchema.citizenship])
    output[RawSchema.plate_country] = output[RawSchema.plate_country].astype(str)
    output = output.reset_index(drop=True)

    output = output[NEXUS_HWY_040_COLUMNS]
    output = RawSchema(output)

    return output
