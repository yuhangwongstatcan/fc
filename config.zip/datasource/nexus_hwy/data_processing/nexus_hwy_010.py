"""
Implements the nexus_hwy_010 business rule and validation
"""

import pandas as pd
from datasource.nexus_hwy.schema import (
    RawSchema,
    NEXUS_HWY_V010_COLUMNS,
    ValidationSchema
)

from config.api import (
    DataSource, 
    Stage, 
    Mapping, 
    WorkLocationsTransAction
)

from modules.utils.loaders import Loader

from datasource.work_locations_trans_action.schema import ReferenceSchema as TransActionSchema
from datasource.mapping.schema import ReferenceSchema as MappingSchema

from datasource.work_locations_trans_action.schema import ReferenceSchema as WorkLocationsSchema
from datasource.work_locations_trans_action.dim import ACTION

def nexus_hwy_010(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove records from the NEXUS Highway raw data that cannot be matched to the work location reference file, 
    or for which the file indicates that they are not accepted, until they can be reviewed.

    Args:
        df:
            A pandas dataframe with possibly unmatchable or unaccepted work locations
    Returns:
        df:
            A pandas dataframe with unmatchable or unaccepted work locations removed
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    """
    # Amount to be added to Canada total passengers
    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.work_locations_trans_action,
        WorkLocationsTransAction.work_locations__nexus_hwy,
    )
    
    work_locations = WorkLocationsSchema(work_locations)  

    # Obtain mask of all records in input that do not conform with work locations acceptability 
    invalid_mask = (
        ~(
            df[RawSchema.work_location].isin(
                work_locations[
                    work_locations[TransActionSchema.action]==ACTION.accept.value
                ][TransActionSchema.work_location].values.astype(str)
            )
        ) 
    | (df[RawSchema.work_location].isnull()) 
    | (
        df[RawSchema.work_location].isin(
            work_locations[
                    work_locations[TransActionSchema.transportation_type]
                    !="nexus_hwy__211"
                    ][TransActionSchema.work_location].values.astype(str)
        )
      )
    )
    
    auxiliary_df = df[invalid_mask].copy() 
    df = df[~invalid_mask]  
    
    return df, auxiliary_df


def nexus_hwy_v010(df: pd.DataFrame, auxiliary_df: pd.DataFrame) -> pd.DataFrame:
    """
    Implements the validation associated with the business rule nexus_hwy_v010

    Args:
        df:
            A pandas dataframe with unmatchable or unaccepted work locations removed
        auxiliary_df:
            A pandas dataframe to be parsed by the validation to display
            unexpected work locations or modes of transportation.
    Returns:
        validation_df:
            Validation file to be used in the dashboards.
    """

    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__nexus_hwy__raw__wloc__nexus_hwy__clean__work_location,
    )
    
    # Drop work locations with duplicate "values". Note that this can happen
    # because CBSA changes the names of ports over time, so many "keys" of
    # this mapping will map to the same output work location. Importantly,
    # the Frontier Counts production team understands the plain language name of the
    # port, so we drop duplicates on "value" keeping the first work location.
    work_locations = work_locations[
        ~work_locations.duplicated(subset=[MappingSchema.value])
    ]
  
    auxiliary_df = auxiliary_df[~auxiliary_df.duplicated(subset=[RawSchema.wloc])]
    auxiliary_df = auxiliary_df.drop(columns=[RawSchema.count, RawSchema.work_location, RawSchema.citizenship])
    validation_df = auxiliary_df.copy()


    # Get the date (df should always contain records)
    DATE = df[RawSchema.date][0]
    
    # Code the masks for each of the validation scenarios we are looking for.
    MISSING_WORK_LOCATIONS = ~work_locations[MappingSchema.value].isin(list(df[RawSchema.work_location].unique()))
    
    # Derive the mask for zero travellers
    # Sum up the df "count" column by work location. If sum==0, that work location has zero nexus travellers
    groupby_df = df.groupby(by=[RawSchema.work_location], dropna=False, as_index=False)
    groupby_df = groupby_df[[RawSchema.count]].apply(lambda x: x.astype(int).sum())
    zero_travellers_work_locations = set(groupby_df[groupby_df[RawSchema.count] == 0][RawSchema.work_location].unique())
    ZERO_WORK_LOCATIONS = work_locations[MappingSchema.value].isin(zero_travellers_work_locations)
    
    # Get 3 validation dfs in the same schema
    zero_work_locations_df = work_locations[ZERO_WORK_LOCATIONS]
    zero_work_locations_df = zero_work_locations_df.rename(columns={MappingSchema.key: ValidationSchema.wloc})
    zero_work_locations_df[ValidationSchema.date] = DATE
    zero_work_locations_df[ValidationSchema.work_location_issue_type] = "Zero NEXUS Travellers"
    
    missing_work_locations_df = work_locations[MISSING_WORK_LOCATIONS]
    missing_work_locations_df = missing_work_locations_df.rename(columns={MappingSchema.key: ValidationSchema.wloc})
    missing_work_locations_df[ValidationSchema.date] = DATE
    missing_work_locations_df[ValidationSchema.work_location_issue_type] = "Missing Work Locations"
    
    validation_df[ValidationSchema.unexpected_value] = pd.NA
    validation_df[ValidationSchema.work_location_issue_type] = "Unexpected Work Locations"
    all_validation_df = pd.concat([zero_work_locations_df, missing_work_locations_df, validation_df])
    
    all_validation_df = all_validation_df[NEXUS_HWY_V010_COLUMNS]
    all_validation_df = ValidationSchema(all_validation_df)

    return all_validation_df
    