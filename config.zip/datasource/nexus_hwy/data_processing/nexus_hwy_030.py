"""
Implements the nexus_hwy_030 business rule
"""

import numpy as np
import pandas as pd

from datasource.nexus_hwy.schema import RawSchema
from datasource.nexus_hwy.dim import CITIZENSHIP


def nexus_hwy_030(df: pd.DataFrame) -> pd.DataFrame:
    """
    For cases where the citizenship is listed as "Unknown" or "Other" in NEXUS Highway, impute a
    country of citizenship, as this will later be used as a proxy for country of residence in the database.
    Args:
        df:
            A pandas dataframe without the imputed citizenships
    Returns:
        df:
            A pandas dataframe that has imputed citizenships
    """

    mask = (df[RawSchema.citizenship]==CITIZENSHIP.unknown.value)|(df[RawSchema.citizenship]==CITIZENSHIP.other.value)
    aux = df[mask].copy()
    
    Canada = df[(df[RawSchema.citizenship]==CITIZENSHIP.canada.value)][[RawSchema.wloc,RawSchema.count]].reset_index()
    US = df[(df[RawSchema.citizenship]==CITIZENSHIP.united_states.value)][[RawSchema.wloc,RawSchema.count]].reset_index()
    
    groupby_df = aux.groupby(by=[RawSchema.wloc],dropna=False, as_index= False)
    groupby_df = groupby_df[[RawSchema.count]].apply(lambda x: x.astype(int).sum())
    groupby_df = groupby_df.sort_values(RawSchema.wloc)
    
    Canada = Canada.sort_values(RawSchema.wloc).reset_index(drop=True)
    US = US.sort_values(RawSchema.wloc).reset_index(drop=True)

    groupby_df[RawSchema.count] = groupby_df[RawSchema.count].astype(int)
    Canada[RawSchema.count] = Canada[RawSchema.count].astype(int)
    US[RawSchema.count] = US[RawSchema.count].copy().astype(int)
    
    # Determine if the rare case is present
    mask2 = (Canada[RawSchema.count]==0)&(US[RawSchema.count]==0)
    rare_case = groupby_df[mask2].copy()
    groupby_df = groupby_df[~mask2]
    Canada = Canada[~mask2]
    US = US[~mask2]
    
    # Get proportions for residents of Canada and the United States
    prop_canada = round(
        groupby_df[RawSchema.count]
        * (
            Canada[RawSchema.count]
            / (
                Canada[RawSchema.count]
                + US[RawSchema.count].values
            )
        ),
        0,
    )

    prop_us = groupby_df[RawSchema.count].astype(int) - round(
        groupby_df[RawSchema.count].astype(int)
        * (
            Canada[RawSchema.count].astype(int)
            / (
                Canada[RawSchema.count].astype(int)
                + US[RawSchema.count].astype(int).values
            )
        ),
        0,
    )
    prop_canada = prop_canada.dropna()
    prop_us = prop_us.dropna()
    
    # Redistribute the "Unknown" or "Other" travellers based on the proportions
    df.loc[df[df[RawSchema.citizenship]==CITIZENSHIP.canada.value].sort_values(RawSchema.wloc).reset_index()[~mask2]["index"].values,RawSchema.count] = (df[
        df[RawSchema.citizenship]==CITIZENSHIP.canada.value].sort_values(by=RawSchema.wloc).reset_index(drop=True)[~mask2][RawSchema.count].astype(int)+prop_canada.astype(int).values).tolist()
    df.loc[df[df[RawSchema.citizenship]==CITIZENSHIP.united_states.value].sort_values(RawSchema.wloc).reset_index()[~mask2]["index"].values,RawSchema.count] = (df[
         df[RawSchema.citizenship]==CITIZENSHIP.united_states.value].sort_values(by=RawSchema.wloc).reset_index(drop=True)[~mask2][RawSchema.count].astype(int)+prop_us.astype(int).values).tolist()
    
    # If the rare case where both Canada and United States have zero resident available
    if not rare_case.empty:
        # Rule: if there is an odd number of travellers (i.e. count / 2 produces
        # a decimal number with .5), then round up to the nearest integer for
        # Canada, then allocate the remaining half to US.
        count_can = np.ceil(rare_case[RawSchema.count]/2).astype("Int64")
        count_us = rare_case[RawSchema.count]-count_can

        df.loc[df[df[RawSchema.citizenship]==CITIZENSHIP.canada.value].sort_values(RawSchema.wloc)[RawSchema.count].reset_index()[mask2]["index"].values,[RawSchema.count]] = count_can.astype(int).values

        df.loc[df[df[RawSchema.citizenship]==CITIZENSHIP.united_states.value].sort_values(RawSchema.wloc)[RawSchema.count].reset_index()[mask2]["index"].values,[RawSchema.count]] = count_us.astype(int).values

    df = df[~mask].copy().reset_index(drop=True)
    
    return df

