"""
Implements the nexus_hwy_005 business rule
"""

import pandas as pd

from datasource.nexus_hwy.schema import RawSchema, NEXUS_HWY_005_COLUMNS
from datasource.mapping.schema import ReferenceSchema as MappingSchema

from config.api import DataSource, Stage, Mapping
from modules.utils.loaders import Loader


def nexus_hwy_005(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add the four digit CBSA work location code to the NEXUS Highway input data, 
    which will be used with the nexus_hwy work location reference file to determine 
    which data is accepted.

    Args:
        df:
            A pandas dataframe without the four digit CBSA work location code
    Returns:
        df:
            A pandas dataframe that includes the four digit CBSA work location code
    """

    work_locations = Loader.get(
        Stage.REFERENCE,
        DataSource.mapping,
        Mapping.map__nexus_hwy__raw__wloc__nexus_hwy__clean__work_location,
    )

    work_locations = MappingSchema(work_locations)

    work_locations = work_locations.rename(
        columns={
            MappingSchema.key:RawSchema.wloc
        }
    ).drop([MappingSchema.desc_en, MappingSchema.desc_fr], axis=1)

    df = df.reset_index(drop=True)
    merged = pd.merge(df, work_locations, on=[RawSchema.wloc], how="left")

    df[RawSchema.work_location] = merged["value"]
    
    # Output a dataframe with the RawSchema + the work_location column
    df = df[NEXUS_HWY_005_COLUMNS]
    df = RawSchema(df)
  
    return df