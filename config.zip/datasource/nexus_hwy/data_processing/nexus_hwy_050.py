"""
Implements the nexus_hwy_050 business rule
"""

import pandas as pd
from datasource.nexus_hwy.schema import (
    RawSchema, 
    CleanSchema,
    CLEANSCHEMA_COLUMNS
)

from datasource.nexus_hwy.dim import CITIZENSHIP
from datasource.travellers.dim import DURATION2


def nexus_hwy_050(df: pd.DataFrame) -> pd.DataFrame:
    """
    IAssign a trip duration of same day or overnight to travellers in NEXUS Highway.

    Args:
        df:
            A pandas dataframe without trip duration
    Returns:
        output:
            A pandas dataframe that has imputed values for duration2 column
    """
    
     # Some work locations have specific same-day traveller proportions for Canadian
    # and U.S. travellers
    proportions = {
        "work_location": ["3141", "8174", "8150", "8173", "8132", "8135"],
        "prop_can": [0.95, 0.95, 0.95, 0.95, 0.7, 0.7],
        "prop_us": [0.95, 0.95, 0.95, 0.95, 0.6, 0.6],
    }
    proportions_df = pd.DataFrame(proportions)
    vehicles = df[df[RawSchema.citizenship] == CITIZENSHIP.vehicle.value]
    df = df[df[RawSchema.citizenship] != CITIZENSHIP.vehicle.value]
    temp = pd.merge(
        df, proportions_df, on=[RawSchema.work_location], how="left"
    ).astype({RawSchema.count: "Int64",})

    # For any work locations that do not have a specific same-day traveller proportion
    # for Canadian and U.S. travellers, 80% same-day is used
    temp.loc[temp["prop_can"].isnull(), ["prop_can", "prop_us"]] = 0.8

    mask_can = temp[RawSchema.citizenship] == CITIZENSHIP.canada.value
    mask_us = temp[RawSchema.citizenship] == CITIZENSHIP.united_states.value

    # Calculate the count of same-day travellers by multiplying the same-day proportion
    # and the total number of travellers for both Canadian and U.S. travellers
    temp.loc[mask_can, "count_sd"] = round(
        temp[RawSchema.count][mask_can] * temp[mask_can]["prop_can"]
    ).astype(int)
    temp.loc[mask_us, "count_sd"] = round(
        temp[RawSchema.count][mask_us] * temp[mask_us]["prop_us"]
    ).astype(int)

    # Duplicate dataset since each row needs to be split into two for same-day and overnight
    # Same-day simply has the same-day count copied into the count variable
    sameday = temp.copy()
    sameday["count"] = sameday["count_sd"].astype(int)
    sameday[RawSchema.duration2] = DURATION2.same_day.value

    # Overnight receives the remainder of the count. This allows us to respect the original
    # total count no matter what happens with rounding.
    overnight = temp.copy()
    overnight["count"] = (overnight["count"] - overnight["count_sd"]).astype(int)
    overnight[RawSchema.duration2] = DURATION2.overnight.value

    output = sameday.append(overnight)
    output = output.drop(columns=["prop_can", "prop_us", "count_sd"])
    output = output.append(vehicles)
    output[RawSchema.work_location] = output[
        RawSchema.work_location
    ].astype(str)
    output = output.sort_values(
        by=[
            RawSchema.wloc,
            RawSchema.citizenship,
            RawSchema.duration2,
        ]
    )

    output = output[CLEANSCHEMA_COLUMNS]
    output = CleanSchema(output)

    return output
