"""
    Program: dim.py

    Author: Fang Wang, fang.wang@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema verification of RAW
        and CLEAN data for the NEXUS HWY data source.
"""


from config.api import AutoEnum


class CITIZENSHIP(AutoEnum):
    canada = "Canada"
    other = "Other"
    united_states = "United States"
    unknown = "Unknown"
    vehicle = "VEHICLE"