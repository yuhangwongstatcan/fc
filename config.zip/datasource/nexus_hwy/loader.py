#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thursday Nov 19 12:13:20 2020
@authors:  Andres Solis Montero
"""
import re
import tempfile
import shutil
import glob
import pandas as pd
import calendar
from os.path import join
from os.path import basename

from pandas.core.frame import DataFrame

from modules.s3client import S3Client
from config.api import LoadingRules, S3Location
from config.api import DataSource
from config.api import Stage
from config.api import S3
from config.argo import ArgoStatusCodes
from modules.utils.schema import tuplify
from modules.utils.data_manipulation import upload_files

from datasource.nexus_hwy.schema import RawSchema as HighwaySchema
from datasource.nexus_hwy.dim import CITIZENSHIP as Highway_CITIZENSHIP

from datasource.nexus_air.schema import RawSchema as AirSchema
from datasource.nexus_air.dim import CITIZENSHIP as Air_CITIZENSHIP

# List of columns to sort NEXUS Highway by for raw
NEXUS_HWY_SORT_COLUMNS = HighwaySchema.get_keys()

# List of columns to sort NEXUS Air by for raw
NEXUS_AIR_SORT_COLUMNS = AirSchema.get_keys()


def exel_conf():
    return {
        0: {
            "name": "NEXUS vs all Conveyances",
            "idx": 0,
            "rows": {"start": 4, "end": None},
            "cols": {"start": 1, "end": 22},
            "ffill": ["Land Border"],
            "replace": [{"column": "Program", "key": "NEXUS", "value": "VEHICLE"}],
            "index": ["Land Border", "Program"],
        },
        1: {
            "name": "NEXUS Land Citizenship",
            "idx": 1,
            "rows": {"start": 4, "end": None},
            "cols": {"start": 1, "end": 16},
            "ffill": ["Land Border"],
            "index": ["Land Border", "Citizenship"],
        },
        2: {
            "name": "NEXUS Air Citizenship",
            "idx": 2,
            "rows": {"start": 4, "end": None},
            "cols": {"start": 1, "end": 16},
            "ffill": ["Airport"],
            "index": ["Airport", "Citizenship"],
        },
    }


def read_excel(filename: str, excel_conf: dict) -> dict[DataFrame]:
    """
    Uses a configuration to extract DataFrames from excel sheets.
    Common applications that are applied:
    1. FFILL
    2. TRIM/CLEAN index columns
    3. REPLACE values from columns
    4. Sets Header and Indexes
    Returns a dictionary of DataFrames, each key represents a Excel sheet.
    """
    sheet_dfs = {}
    for k, c in excel_conf.items():
        c = tuplify(c)
        df = pd.read_excel(filename, sheet_name=c.idx, engine="openpyxl")
        sheet = df.iloc[c.rows.start : c.rows.end, c.cols.start : c.cols.end]
        columns = sheet.iloc[0].replace("*", "", regex=False)
        sheet = sheet.iloc[1:]
        sheet.columns = columns
        # remove all new lines
        NEW_LINES = "\s*\n\s*"
        # remove leading and trailing spaces, plus parenthesis comments
        TRIM = "(^\s+)|(\s+$)|(\s*\([^\(\)]*\)\s*$)"
        sheet.loc[:, c.index] = sheet.loc[:, c.index].replace(
            NEW_LINES, " ", regex=True
        )
        sheet.loc[:, c.index] = sheet.loc[:, c.index].replace(TRIM, "", regex=True)
        sheet.loc[:, c.ffill] = sheet.loc[:, c.ffill].ffill(axis=0)

        if hasattr(c, "replace") and c.replace:
            for ins in c.replace:
                sheet.loc[sheet[ins.column] == ins.key, ins.column] = ins.value
        sheet = sheet.set_index(c.index)
        sheet_dfs[k] = sheet
    return sheet_dfs


def filter(
    date: str, month: str, dim: list, df: DataFrame, not_wloc: list, not_cship: list
):
    """
    Iterates over the extracted dataframe, using its (wloc,citizenship) index.
    Skips rows where wloc contains any of the substrings in not_wloc or
    citizenship is not included in the dim list.
    """
    # There is a known upstream mistake where the column headers occasionally
    # contain leading/trailing whitespaces. The reassignment of columns ensures
    # that no such cases are carried forward in the code.
    df.columns = [col.strip() for col in df.columns]
    data = []
    for (wloc, cship), row in df.iterrows():
        # Check if outer column contains valid value
        if not any(map(wloc.upper().__contains__, not_wloc)):
            # Check if inner column contains valid value (is a string and is not in any of the exclusion conditions)
            if isinstance(cship, str) and not any(
                map(cship.upper().__contains__, not_cship)
            ):
                data.append([date, wloc, cship, row[month]])
                # print(date, wloc, cship, row[month])
    return data


def loader(client: S3Client, stage: Stage, location: S3Location) -> bool:
    """
    Extracts Transform and Load pik data from the momentary S3Location.
    This is the loader entry point for the pik datasource.


    Args:
        client: an instance of S3Client.
        location: an instance of S3Location.

    Returns: True
    """
    downloaddir = client.get_dir(location)
    lr = LoadingRules.load()
    rule = lr.get(DataSource.nexus_hwy)[0]
    rule_pattern = re.compile(rule.pattern)

    abbr2name = {
        abbr.upper(): full
        for abbr, full in zip(calendar.month_abbr, calendar.month_name)
        if abbr
    }
    abbr2number = {
        abbr.upper(): index for index, abbr in enumerate(calendar.month_abbr) if abbr
    }

    nexus_hwy_files = []
    nexus_air_files = []

    nexus_hwy_folder = tempfile.mkdtemp()
    nexus_air_folder = tempfile.mkdtemp()

    for f in glob.glob(join(downloaddir, "*.xlsx")):
        try:
            m, year = rule_pattern.match(basename(f)).groups()
        except Exception:
            return False

        m = m[:3].upper()

        m_number = abbr2number[m]
        month = abbr2name[m]
        try:
            sheets = read_excel(f, exel_conf())

            nexus_hwy_fn = join(
                nexus_hwy_folder,
                S3.get_s3_basename(stage, DataSource.nexus_hwy, year, m_number, 1),
            )
            nexus_air_fn = join(
                nexus_air_folder,
                S3.get_s3_basename(stage, DataSource.nexus_air, year, m_number, 1),
            )

            nexus_hwy_data = []
            nexus_air_data = []

            date = f"{int(year):04}-{int(m_number):02}-01"

            not_wloc = ["ROLL-UP", "REGION"]
            not_cship = ["% NEXUS", "ALL PASSAGES", "TOTAL"]

            nexus_hwy_data.extend(
                filter(
                    date,
                    month,
                    Highway_CITIZENSHIP.list(),
                    sheets[0],
                    not_wloc,
                    not_cship,
                )
            )
            nexus_hwy_data.extend(
                filter(
                    date,
                    month,
                    Highway_CITIZENSHIP.list(),
                    sheets[1],
                    not_wloc,
                    not_cship,
                )
            )

            nexus_air_data.extend(
                filter(
                    date,
                    month,
                    Air_CITIZENSHIP.list(),
                    sheets[2],
                    not_wloc,
                    not_cship,
                )
            )
        except Exception:
            import traceback as tb
            print("Error reading nexus_hwy file: ", f)
            fname = f.replace(downloaddir, "")
            fname = fname.replace("/", "")
            dst = S3.get_error_location(DataSource.nexus_hwy, fname)
            src = S3.obj_to_loc(Stage.INBOX.value.bucket, "inbox/" + fname)
            print("Moving to error location:", dst)
            client.mv_loc(src, dst)
            tb.print_exc()
            print("Exit on error.")
            ArgoStatusCodes.exit_error_location()
            return False

        nexus_hwy_df = DataFrame(nexus_hwy_data)
        nexus_hwy_df.to_csv(nexus_hwy_fn, header=False, index=False)
        nexus_air_df = DataFrame(nexus_air_data)
        nexus_air_df.to_csv(nexus_air_fn, header=False, index=False)

        nexus_hwy_files.append(nexus_hwy_fn)
        nexus_air_files.append(nexus_air_fn)

    upload_files(
        client,
        nexus_hwy_files,
        stage,
        DataSource.nexus_hwy,
        HighwaySchema,
        NEXUS_HWY_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )
    upload_files(
        client,
        nexus_air_files,
        stage,
        DataSource.nexus_air,
        AirSchema,
        NEXUS_AIR_SORT_COLUMNS,
        fallback_on_conflicts=True,
    )

    shutil.rmtree(downloaddir)
    shutil.rmtree(nexus_hwy_folder)
    shutil.rmtree(nexus_air_folder)
    return True
