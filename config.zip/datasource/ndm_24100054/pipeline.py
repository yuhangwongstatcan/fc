import pandas as pd

from modules.pipeline import BasePipeline, PipelineOutput
from modules.utils.uid import PipelineUID
from modules.utils.loaders import Loader

from config.api import S3, Stage, DataSource

from datasource.ndm_adjusted.schema import AggregatedSchema as AdjustedSchema
from datasource.ndm_24100054.schema import AggregatedSchema as NDMOutputSchema
from datasource.ndm_24100054_ref.schema import ReferenceSchema


class PipelineAggregated(BasePipeline):
    """
    Produces the NDM output for table 24-10-0054, which is derived from ndm_adjusted.
    """

    def pipeline(self):
        # Get the pipeline UID
        PipelineUID.get_uid()

        basename = S3.get_s3_basename(
            Stage.AGGREGATED,
            datasource=DataSource.ndm_adjusted,
            year=self.year,
            month=self.month,
            day=self.day,
        )
        # Get ndm_adjusted and reference tables
        ndm_adjusted = Loader.get(Stage.AGGREGATED, DataSource.ndm_adjusted, basename)
        ndm_adjusted = AdjustedSchema(ndm_adjusted)

        ndm_24100054_ref = Loader.get(
            Stage.REFERENCE, DataSource.ndm_24100054_ref, None
        )
        ndm_24100054_ref = ReferenceSchema(ndm_24100054_ref)

        ndm_24100054 = pd.merge(
            left=ndm_24100054_ref,
            right=ndm_adjusted,
            how="inner",
            left_on=AdjustedSchema.vector,
            right_on=ReferenceSchema.vector,
        )
        # Prepare the NDM tables to be exported in their desired format.
        # ndm_24100054
        ndm_24100054[NDMOutputSchema.ReferencePeriod] = ndm_24100054[
            AdjustedSchema.reference_period
        ].str.replace("-", "")
        ndm_24100054[NDMOutputSchema.ReferencePeriod2] = pd.NA
        ndm_24100054[NDMOutputSchema.Value] = ndm_24100054[AdjustedSchema.ndm_value]
        ndm_24100054 = ndm_24100054[list(NDMOutputSchema.to_schema().columns.keys())]

        # ---------------------------------------------
        # Save output tables to MinIO
        # ---------------------------------------------

        ndm_24100054_out = PipelineOutput(
            data=ndm_24100054,
            stage=Stage.AGGREGATED,
            datasource=DataSource.ndm_24100054,
            basename=S3.get_s3_basename(
                Stage.AGGREGATED,
                DataSource.ndm_24100054,
                self.year,
                self.month,
                self.day,
            ),
            fallback_on_conflicts=False,
            fallback_on_historical=True,
        )

        # Add pipeline output to outputs dictionary
        self.outputs[DataSource.ndm_24100054.value] = ndm_24100054_out
