"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for the NDM_24100054 aggregate files.
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.schema import NDMOutputCommonSchema


class AggregatedSchema(NDMOutputCommonSchema):
    """
    Schema for the NDM_24100054 aggregate files.
    """

    dim1: Series[pa.String] = pa.Field(
        description="Geography: Canada and provinces (1-14)",
        coerce=True,
    )
    dim2: Series[pa.String] = pa.Field(
        description="Traveller characteristics (1-17)",
        coerce=True,
    )
    dim3: Series[pa.String] = pa.Field(
        description="Traveller type (1-3)",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [
            AggregatedSchema.ReferencePeriod,
            AggregatedSchema.dim1,
            AggregatedSchema.dim2,
            AggregatedSchema.dim3,
        ]
