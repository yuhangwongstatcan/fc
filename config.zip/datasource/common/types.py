"""
    Program: types.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define custom or more complex type coercions that can be
        used in schemas across the codebase.
"""

import logging
from typing import Any

import pandas as pd

from pandera import dtypes
from pandera.engines import pandas_engine


@pandas_engine.Engine.register_dtype  # step 1
@dtypes.immutable  # step 2
class SafeIntToStringType(pandas_engine.STRING):
    """
    Convert float --> int --> str to truncate the decimal part of the number
    before casting to string. This is necessary because some Int-like variables
    can have missing values, which causes pandas to cast them to float, so when
    they are coerced to string, they have an unintended decimal.
    """

    def coerce(self, data_container: pd.Series) -> pd.Series:
        try:
            series = data_container.astype("Int64")
            series = series.astype(pd.StringDtype())
        except (TypeError, ValueError) as e:
            series = data_container.astype(pd.StringDtype())
            logging.info(
                f"Encountered type exception {e}. Coercing directly to string."
            )
            print("Encountered type exception: ", e)
            print("Coercing directly to string.")
        return series

    def coerce_value(self, value: Any) -> Any:
        """
        Raises type error if value is an invalid SafeIntToString type
        """
        if isinstance(value, str) and not value.isnumeric():
            raise TypeError(f"Value {value} is an invalid SafeIntToString type.")
        return value


@pandas_engine.Engine.register_dtype  # step 1
@dtypes.immutable  # step 2
class Padded1ZeroStringType(pandas_engine.STRING):
    """
    Convert from int to string and pad with one zero.
    This is necessary because some Int-like variables are actually categorical
    string variables with leading zeros (e.g. "000" means something / 0 does not),
    but when the CSV are read in, pandas truncates the variables.
    """

    def coerce(self, data_container: pd.Series) -> pd.Series:
        try:
            series = data_container.astype("Int64")
            series = series.astype(pd.StringDtype()).str.zfill(2)
        except TypeError as e:
            series = data_container.astype(pd.StringDtype()).str.zfill(2)
        return series


@pandas_engine.Engine.register_dtype  # step 1
@dtypes.immutable  # step 2
class Padded2ZeroStringType(pandas_engine.STRING):
    """
    Convert from int to string and pad with two zeros.
    This is necessary because some Int-like variables are actually categorical
    string variables with leading zeros (e.g. "000" means something / 0 does not),
    but when the CSV are read in, pandas truncates the variables.
    """

    def coerce(self, data_container: pd.Series) -> pd.Series:
        try:
            series = data_container.astype("Int64")
            series = series.astype(pd.StringDtype()).str.zfill(3)
        except TypeError as e:
            series = data_container.astype(pd.StringDtype()).str.zfill(3)
        return series


@pandas_engine.Engine.register_dtype  # step 1
@dtypes.immutable  # step 2
class Padded3ZeroStringType(pandas_engine.STRING):
    """
    Convert from int to string and pad with three zeros.
    This is necessary because some Int-like variables are actually categorical
    string variables with leading zeros (e.g. "000" means something / 0 does not),
    but when the CSV are read in, pandas truncates the variables.
    """

    def coerce(self, data_container: pd.Series) -> pd.Series:
        try:
            series = data_container.astype("Int64")
            series = series.astype(pd.StringDtype()).str.zfill(4)
        except TypeError as e:
            series = data_container.astype(pd.StringDtype()).str.zfill(4)
        return series


@pandas_engine.Engine.register_dtype  # step 1
@dtypes.immutable  # step 2
class Padded4ZeroStringType(pandas_engine.STRING):
    """
    Convert from int to string and pad with four zeros.
    This is necessary because some Int-like variables are actually categorical
    string variables with leading zeros (e.g. "000" means something / 0 does not),
    but when the CSV are read in, pandas truncates the variables.
    """

    def coerce(self, data_container: pd.Series) -> pd.Series:
        try:
            series = data_container.astype("Int64")
            series = series.astype(pd.StringDtype()).str.zfill(5)
        except TypeError as e:
            series = data_container.astype(pd.StringDtype()).str.zfill(5)
        return series


@pandas_engine.Engine.register_dtype  # step 1
@dtypes.immutable  # step 2
class Padded5ZeroStringType(pandas_engine.STRING):
    """
    Convert from int to string and pad with five zeros.
    This is necessary because some Int-like variables are actually categorical
    string variables with leading zeros (e.g. "000" means something / 0 does not),
    but when the CSV are read in, pandas truncates the variables.
    """

    def coerce(self, data_container: pd.Series) -> pd.Series:
        try:
            series = data_container.astype("Int64")
            series = series.astype(pd.StringDtype()).str.zfill(6)
        except TypeError as e:
            series = data_container.astype(pd.StringDtype()).str.zfill(6)
        return series


@pandas_engine.Engine.register_dtype  # step 1
@dtypes.immutable  # step 2
class CapitalXOrNullType(pandas_engine.STRING):
    """
    Some fields' valid values are either "X" or blank. This will enforce this by setting all values that are not a
    lowercase or uppercase X to N/A
    """

    def coerce(self, data_container: pd.Series) -> pd.Series:
        try:
            series = data_container.astype(pd.StringDtype()).str.upper()
            series = series.where(cond=series == "X", other=pd.NA)
        except (TypeError, ValueError) as e:
            series = data_container.astype(pd.StringDtype())
            logging.info(f"Encountered type exception {e}. Coercing to string.")
            print("Encountered type exception: ", e)
            print("Coercing directly to string.")
        return series
