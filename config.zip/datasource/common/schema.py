"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca
            Tristan Garry, tristan.garry@statcan.gc.ca

    Created: March 2023

    Purpose:
        Define a common schema model using pandera as a base to create schema 
        models for TRAVELLERS, TRAVELLERS MAIN, TRAVELLERS LEADING, and VEHICLES

        Define a common schema model for NDM adjusted tables. 
"""

import pandera as pa
from pandera.typing import Series

from datasource.common.dim import (
    MONTH,
    DAY,
    MODE,
    VEHICLE_TYPE,
    PLATE_COUNTRY,
    PLATE_REGION,
)
from datasource.common.dim import SYMBOL, SECURITYLEVEL, STATUS

from modules.utils.schema_wrappers import FCSchemaModel


class TravellersVehiclesCommonSchema(FCSchemaModel):
    """
    Schema for TRAVELLERS_MAIN and TRAVELLER_LEADING.
    """

    year: Series[pa.String] = pa.Field(
        description="Year in which the border crossing occurred",
        str_matches=r"\d{4}",
        coerce=True,
    )
    month: Series[pa.String] = pa.Field(
        description="Month in which the border crossing occurred",
        isin=MONTH,
        coerce=True,
    )
    day: Series[pa.String] = pa.Field(
        description="Day in which the border crossing occurred",
        isin=DAY.list(),
        coerce=True,
    )
    port: Series[pa.String] = pa.Field(
        description="Statistics Canada port of the border crossing",
        str_matches=r"\d{5}",
        coerce=True,
    )
    mode: Series[pa.String] = pa.Field(
        description="Mode of transportation",
        isin=MODE.list(),
        coerce=True,
        raise_warning=True,
    )
    vehicle_type: Series[pa.String] = pa.Field(
        description="Vehicle type",
        isin=VEHICLE_TYPE.list(),
        coerce=True,
        raise_warning=True,
    )
    plate_country: Series[pa.String] = pa.Field(
        description="Country of vehicle licence plate, if applicable",
        isin=PLATE_COUNTRY.list(),
        coerce=True,
        raise_warning=True,
    )
    plate_region: Series[pa.String] = pa.Field(
        description="State, province or territory of vehicle licence plate, if applicable",
        isin=PLATE_REGION.list(),
        coerce=True,
        raise_warning=True,
    )
    count_of_entries: Series[pa.INT64] = pa.Field(
        description="Count of border crossings",
        gt=0,
        coerce=True,
    )


class NDMReferenceCommonSchema(pa.SchemaModel):
    vector: Series[pa.String] = pa.Field(
        description="Unique identifier of a series in the CODR table.",
        coerce=True,
    )
    Symbol: Series[pa.String] = pa.Field(
        description="Indicator of preliminary or revised data.",
        isin=SYMBOL.list(),
        coerce=True,
    )
    Status: Series[pa.String] = pa.Field(
        description="Indicator for availability and quality of data.",
        isin=STATUS.list(),
        coerce=True,
    )
    SecurityLevel: Series[pa.String] = pa.Field(
        description="Indicator of confidentiality of data points.",
        isin=SECURITYLEVEL.list(),
        coerce=True,
    )


class NDMOutputCommonSchema(pa.SchemaModel):
    ReferencePeriod: Series[pa.String] = pa.Field(
        description="Reference date, in format YYYYMMDD.",
        coerce=True,
    )
    ReferencePeriod2: Series[pa.String] = pa.Field(
        description="Always empty for Frontier Counts. Used if reference period covers multiple years.",
        coerce=True,
    )
    Value: Series[pa.String] = pa.Field(
        description="Total for a specific vector.",
        coerce=True,
    )
    Symbol: Series[pa.String] = pa.Field(
        description="Indicator of preliminary or revised data.",
        isin=SYMBOL.list(),
        coerce=True,
    )
    Status: Series[pa.String] = pa.Field(
        description="Indicator for availability and quality of data.",
        isin=STATUS.list(),
        coerce=True,
    )
    SecurityLevel: Series[pa.String] = pa.Field(
        description="Indicator of confidentiality of data points.",
        isin=SECURITYLEVEL.list(),
        coerce=True,
    )
