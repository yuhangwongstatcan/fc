"""
    Program: dim.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: February 2023

    Purpose:
        Create lists of dimension values for the TRAVELLERS table, and enumerable
        classes to be used in the data processing pipelines instead of hard-coding
        values for certain variables.
"""

from typing import List

from enum import auto
from config.api import AutoEnum


MONTH: List[str] = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]

MONTH_ZEROS: List[str] = [
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "08",
    "09",
    "10",
    "11",
    "12",
]


class DAY(AutoEnum):
    d1 = "1"
    d2 = "2"
    d3 = "3"
    d4 = "4"
    d5 = "5"
    d6 = "6"
    d7 = "7"
    d8 = "8"
    d9 = "9"
    d10 = "10"
    d11 = "11"
    d12 = "12"
    d13 = "13"
    d14 = "14"
    d15 = "15"
    d16 = "16"
    d17 = "17"
    d18 = "18"
    d19 = "19"
    d20 = "20"
    d21 = "21"
    d22 = "22"
    d23 = "23"
    d24 = "24"
    d25 = "25"
    d26 = "26"
    d27 = "27"
    d28 = "28"
    d29 = "29"
    d30 = "30"
    d31 = "31"
    not_available = "99"


class MODE(AutoEnum):
    air = "1"
    land = "2"
    water = "3"
    not_available = "9"


class VEHICLE_TYPE(AutoEnum):
    commercial_aircraft = "111"
    cargo_aircraft = "112"
    private_aircraft = "121"
    air_unknown = "199"
    automobile = "211"
    motorcycle = "212"
    other_land_vehicle = "213"
    truck = "214"
    bus = "215"
    train = "216"
    pedestrian = "217"
    land_unknown = "299"
    cruise_ship = "311"
    cargo_ship = "312"
    ferry_private_vehicle = "313"
    ferry_pedestrian = "314"
    ferry_unknown = "315"
    private_boat = "321"
    water_unknown = "399"
    not_available = "999"


class PLATE_COUNTRY(AutoEnum):
    canada = "1"
    united_states = "2"
    mexico = "3"
    puerto_rico = "4"
    other = "8"
    not_available = "9"


class PLATE_REGION(AutoEnum):
    AB = auto()  # Alberta
    AK = auto()  # Alaska
    AL = auto()  # Alabama
    AR = auto()  # Arkansas
    AZ = auto()  # Arizona
    BC = auto()  # British Columbia
    CA = auto()  # California
    CG = auto()  # Canadian Government
    CO = auto()  # Colorado
    CT = auto()  # Connecticut
    DC = auto()  # District of Columbia
    DE = auto()  # Delaware
    FL = auto()  # Florida
    GA = auto()  # Georgia
    HI = auto()  # Hawaii
    IA = auto()  # Iowa
    ID = auto()  # Idaho
    IL = auto()  # Illinois
    IN = auto()  # Indiana
    KS = auto()  # Kansas
    KY = auto()  # Kentucky
    LA = auto()  # Louisiana
    MA = auto()  # Massachusetts
    MB = auto()  # Manitoba
    MD = auto()  # Maryland
    ME = auto()  # Maine
    MI = auto()  # Michigan
    MN = auto()  # Minnesota
    MO = auto()  # Missouri
    MS = auto()  # Mississippi
    MT = auto()  # Montana
    MX = auto()  # Mexico
    NA = auto()  # Not available
    NB = auto()  # New Brunswick
    NC = auto()  # North Carolina
    ND = auto()  # North Dakota
    NE = auto()  # Nebraska
    NH = auto()  # New Hampshire
    NJ = auto()  # New Jersey
    NL = auto()  # Newfoundland and Labrador
    NM = auto()  # New Mexico
    NS = auto()  # Nova Scotia
    NT = auto()  # Northwest Territories
    NU = auto()  # Nunavut
    NV = auto()  # Nevada
    NY = auto()  # New York
    OH = auto()  # Ohio
    OK = auto()  # Oklahoma
    ON = auto()  # Ontario
    OR = auto()  # Oregon
    PA = auto()  # Pennsylvania
    PE = auto()  # Prince Edward Island
    PR = auto()  # Puerto Rico
    QC = auto()  # Quebec
    RI = auto()  # Rhode Island
    SC = auto()  # South Carolina
    SD = auto()  # South Dakota
    SK = auto()  # Saskatchewan
    TN = auto()  # Tennessee
    TX = auto()  # Texas
    UT = auto()  # Utah
    VA = auto()  # Virginia
    VT = auto()  # Vermont
    WA = auto()  # Washington
    WI = auto()  # Wisconsin
    WV = auto()  # West Virginia
    WY = auto()  # Wyoming
    XX = auto()  # Other
    YT = auto()  # Yukon


class DATA_SOURCE(AutoEnum):
    IPIL_Highway = "11"
    IPIL_Air = "12"
    PIK = "13"
    Nexus_Highway = "14"
    Nexus_Air = "15"
    TRC = "16"
    ORA = "17"
    Entry_Exit = "18"
    NGHH = "19"
    E311 = "51"
    E63 = "52"
    E63_1 = "53"
    E62 = "54"
    E62B = "55"
    E62T = "56"
    Overseas_Summary_Report = "57"
    Bus_Report = "58"
    Other = "59"
    Not_Available = "99"


# Common dimensions for NDM tables


class SYMBOL(AutoEnum):
    no_symbol = "0"
    preliminary = "1"
    revised = "3"


class SECURITYLEVEL(AutoEnum):
    public = "0"
    secure = "1"  # Data are supressed and represented by an X


class STATUS(AutoEnum):
    normal = "0"
    not_available = "1"  # Represented by two dots
    rounded_at_zero = "2"
    quality_A = "3"
    quality_B = "4"
    quality_C = "5"
    quality_D = "6"
    quality_E = "7"
    quality_F = "8"


LEADING_DATASOURCES = [DATA_SOURCE.IPIL_Highway.value, DATA_SOURCE.PIK.value]
