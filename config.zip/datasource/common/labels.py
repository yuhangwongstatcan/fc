"""
    Program: labels.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: June 2023

    Purpose:
        Assigns labels to each value of the VEHICLES and TRAVELLERS table,
        which are used to enhance the user experience the web app with readable
        labels, and can also be used to beautify report outputs from the system.
"""

MONTH = {
    "1": "January",
    "2": "February",
    "3": "March",
    "4": "April",
    "5": "May",
    "6": "June",
    "7": "July",
    "8": "August",
    "9": "September",
    "10": "October",
    "11": "November",
    "12": "December",
}

DAY = {
    "99": "Not available",
    "1": "1",
    "2": "2",
    "3": "3",
    "4": "4",
    "5": "5",
    "6": "6",
    "7": "7",
    "8": "8",
    "9": "9",
    "10": "10",
    "11": "11",
    "12": "12",
    "13": "13",
    "14": "14",
    "15": "15",
    "16": "16",
    "17": "17",
    "18": "18",
    "19": "19",
    "20": "20",
    "21": "21",
    "22": "22",
    "23": "23",
    "24": "24",
    "25": "25",
    "26": "26",
    "27": "27",
    "28": "28",
    "29": "29",
    "30": "30",
    "31": "31",
}

MODE = {"1": "Air", "2": "Land", "3": "Water", "9": "Not available"}

VEHICLE_TYPE = {
    "111": "Commercial aircraft",
    "112": "Cargo aircraft",
    "121": "Private aircraft",
    "199": "Air (Not available)",
    "211": "Automobile",
    "212": "Motorcycle",
    "213": "Other land vehicle",
    "214": "Truck",
    "215": "Bus",
    "216": "Train",
    "217": "Pedestrian",
    "299": "Land (Not available)",
    "311": "Cruise ship or other commercial boat",
    "312": "Cargo ship",
    "313": "Ferry (Private vehicle)",
    "314": "Ferry (Pedestrian)",
    "315": "Ferry (Unknown)",
    "321": "Private boat",
    "399": "Water (Not available)",
    "999": "Not available",
}

PLATE_COUNTRY = {
    "1": "Canada",
    "2": "United States",
    "3": "Mexico",
    "4": "Puerto Rico",
    "8": "Other",
    "9": "Not available",
}

PLATE_REGION = {
    "AB": "Alberta",
    "AK": "Alaska",
    "AL": "Alabama",
    "AR": "Arkansas",
    "AZ": "Arizona",
    "BC": "British Columbia",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DC": "District of Columbia",
    "DE": "Delaware",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "IA": "Iowa",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "MA": "Massachusetts",
    "MB": "Manitoba",
    "MD": "Maryland",
    "ME": "Maine",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MO": "Missouri",
    "MS": "Mississippi",
    "MT": "Montana",
    "MX": "Mexico",
    "NA": "Not available",
    "NB": "New Brunswick",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "NE": "Nebraska",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NL": "Newfoundland and Labrador",
    "NM": "New Mexico",
    "NS": "Nova Scotia",
    "NT": "Northwest Territories",
    "NU": "Nunavut",
    "NV": "Nevada",
    "NY": "New York",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "ON": "Ontario",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "PE": "Prince Edward Island",
    "PR": "Puerto Rico",
    "QC": "Quebec",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "SK": "Saskatchewan",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VA": "Virginia",
    "VT": "Vermont",
    "WA": "Washington",
    "WI": "Wisconsin",
    "WV": "West Virginia",
    "WY": "Wyoming",
    "XX": "Other",
    "YT": "Yukon",
}

ARRIVING_FROM = {
    "1": "United States only",
    "2": "Other country direct",
    "3": "Other country via the United States",
    "9": "Not available",
}

PURPOSE9 = {
    "11": "Personal",
    "12": "Business and professional",
    "13": "Study",
    "19": "Visit, not otherwise specified",
    "21": "Crew",
    "31": "Work",
    "41": "Immigration",
    "42": "Military",
    "43": "Other purpose",
    "99": "Not available",
}

PURPOSE4 = {
    "1": "Visit",
    "2": "Crew",
    "3": "Work",
    "4": "Other non-tourism",
    "9": "Not available",
}

DURATION2 = {"1": "Same day", "2": "Overnight", "9": "Not available"}

DURATION3 = {
    "11": "Same day",
    "21": "One night",
    "22": "Two or more nights",
    "99": "Not available",
}

DURATION5 = {
    "11": "Same day",
    "21": "1-2 nights",
    "22": "3-7 nights",
    "23": "8-364 nights",
    "24": "365 or more nights",
    "99": "Not available",
}

TRAVELLER_TYPE = {
    "1": "Excursionist",
    "2": "Tourist",
    "3": "Other traveller",
    "9": "Not available",
}

DATA_SOURCE = {
    "11": "IPIL Highway",
    "12": "IPIL Air",
    "13": "PIK",
    "14": "NEXUS Highway",
    "15": "NEXUS Air",
    "16": "TRC",
    "17": "ORA",
    "18": "Entry-Exit",
    "51": "E311",
    "52": "E63",
    "53": "E63-1",
    "54": "E62",
    "55": "E62B",
    "56": "E62T",
    "57": "Overseas summary report",
    "58": "Bus report",
    "59": "Other",
    "99": "Not available",
}
