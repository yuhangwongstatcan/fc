"""
    Program: schema.py

    Author: Jacob Doering, jacob.doering@statcan.gc.ca

    Created: April 2023

    Purpose:
        Define schema models using pandera for schema verification 
        of the NDM_SA reference files.
"""

import pandera as pa
from pandera.typing import Series


class ReferenceSchema(pa.SchemaModel):
    """
    Schema for the NDM_SA reference files.
    """

    series: Series[pa.String] = pa.Field(
        description="Name of the seasonal adjustment series.",
        coerce=True,
    )
    query_in: Series[pa.String] = pa.Field(
        description="Query required to extract series from the database.",
        coerce=True,
    )
    vectors_out: Series[pa.String] = pa.Field(
        description="NDM vectors corresponding to the seasonal adjustment series.",
        coerce=True,
    )

    @staticmethod
    def get_keys():
        return [ReferenceSchema.series]
