"""
Utility functions for running reports and saving them in Excel
"""
import os
import logging
import calendar
import pandas as pd

from pydantic import BaseModel
from typing import Dict, List

from config.api import Stage, DataSource

from modules.s3client import S3Client
from config.api import S3Location, DEFAULT_BUCKET, S3, Mode


#  _____              _         _   _ _ _ _   _
# | ____|_  _____ ___| |  _   _| |_(_) (_) |_(_) ___  ___
# |  _| \ \/ / __/ _ \ | | | | | __| | | | __| |/ _ \/ __|
# | |___ >  < (_|  __/ | | |_| | |_| | | | |_| |  __/\__ \
# |_____/_/\_\___\___|_|  \__,_|\__|_|_|_|\__|_|\___||___/


class SheetConfig(BaseModel):
    name: str
    index: str
    columns: str
    reports: List[Dict[str, pd.DataFrame]]

    class Config:
        arbitrary_types_allowed = True


class ExcelConfig(BaseModel):
    """
    Pydantic model to validate that the structure is as expected

    In the reports parameter, each list indicates a row

    Ex:
     [{"name": "Sheet 1 Name", "index": "Index1", "columns": "Columns1", "reports": [{"report1": report1_df}, {"report2": report2_df}]},
     {"name": "Sheet 2 Name", "index": "Index2", "columns": "Columns2", "reports": [{"report3": report3_df, "report4": report4_df}]},]
    """

    data: List[SheetConfig]


def report_to_excel(
    basename: str,
    config: ExcelConfig,
    year: int,
    month: int,
):
    """
    Turns the in-memory outputs from the CAD reports to an Excel file in the /tmp directory
    Assumes a Linux filesystem

    Args:
        basename (str): The identifier for the report to be saved as
        config (ExcelConfig): A complete ExcelConfig to build the report from
        year (int): Reference year
        month (int): Reference month
    """
    # Generate filename and delete the old file if it exists
    tmp_filename = f"/tmp/{basename}_{year}{str(month).zfill(2)}.xlsx"
    try:
        os.remove(tmp_filename)
    except OSError:
        pass

    # Instantiate the ExcelWriter writer and workbook
    report_writer = pd.ExcelWriter(tmp_filename, engine="xlsxwriter")
    report_workbook = report_writer.book

    # Define workbook-wide formatters
    align_format = report_workbook.add_format()
    align_format.set_align("left")

    bolded_format = report_workbook.add_format()
    bolded_format.set_bold()

    # Define cell format for right alignment
    right_align_format = report_workbook.add_format()
    right_align_format.set_align("right")

    for sheet in config.data:
        logging.info(f"Generating {sheet.name} xlsx report")
        start_row = 1

        for row in sheet.reports:
            start_col = 0
            max_records_in_set = 0

            for report in row:
                report_data = row[report]

                report_data.index.name = sheet.index
                report_data.columns.name = sheet.columns
                # report_data = report_data.applymap(format_with_commas)
                report_data.to_excel(
                    report_writer,
                    sheet_name=sheet.name,
                    startrow=start_row,
                    startcol=start_col,
                )

                # Format Index columns and write table titles
                worksheet = report_writer.sheets[sheet.name]
                worksheet.set_column(start_col, start_col, 50, align_format)
                worksheet.write(start_row, start_col, report, bolded_format)

                # Get the number of columns in the DataFrame
                num_cols = len(report_data.columns)

                # Iterate over each column and set the width and format
                for idx, column in enumerate(report_data.columns):
                    # Set column width to be max length of data or column name length
                    # and right align
                    max_len = max(
                        report_data[column].astype(str).str.len().max(), len(column)
                    )
                    max_len = max_len + 2  # Adding a little extra space for padding
                    worksheet.set_column(
                        idx + start_col + 1,
                        idx + start_col + 1,
                        max_len,
                        right_align_format,
                    )

                start_col += report_data.shape[1] + 2

                max_records_in_set = max(max_records_in_set, report_data.shape[0])

            start_row += max_records_in_set + 3

    report_writer.close()
    logging.info("XLSX report successfully saved to /tmp")


def format_table_reports(df: pd.DataFrame, worksheet):
    """
    Formats a dataframe as an Excel table and writes it to the worksheet

    Args:
        df (pd.DataFrame): A pandas dataframe to be written as an Excel table
        worksheet (_type_): An XlsxWriter worksheet

    Returns:
        _type_: An WlsxWriter worksheet with a table written to it
    """
    # Get the dimensions of the dataframe.
    (max_row, max_col) = df.shape

    # Create a list of column headers, to use in add_table().
    column_settings = []
    for header in df.columns:
        column_settings.append({"header": header})

    # Add the table.
    worksheet.add_table(0, 0, max_row, max_col - 1, {"columns": column_settings})

    # Make the columns wider for clarity.
    worksheet.set_column(0, max_col - 1, 12)

    return worksheet


#     _                                _   _ _ _ _   _
#    / \    _____   _ _ __ ___   _   _| |_(_) (_) |_(_) ___  ___
#   / _ \  |_  / | | | '__/ _ \ | | | | __| | | | __| |/ _ \/ __|
#  / ___ \  / /| |_| | | |  __/ | |_| | |_| | | | |_| |  __/\__ \
# /_/   \_\/___|\__,_|_|  \___|  \__,_|\__|_|_|_|\__|_|\___||___/


def write_report_to_azure(report: str, client: S3Client, year: int, month: int):
    """
    Writes a file written to the /tmp directory to Azure

    Args:
        report (str): The report name
        client (S3Client): A valid S3 client
        year (int): The reference year
        month (int): The reference month
    """
    basename = f"{report}_{year}{str(month).zfill(2)}.xlsx"
    local_file = f"/tmp/{basename}"
    if os.path.exists(local_file):
        report_loc = S3Location(
            DEFAULT_BUCKET,
            S3.prefix(
                Stage.PRE_RELEASE,
                Mode.file,
                DataSource.cad_reports,
                year=f"{year}",
                month=f"{month}",
            ).prefix,
            basename,
        )
        client.fput_loc(report_loc, local_file)
        logging.info(f"Successfully wrote {basename} to the default bucket")
        return 0
    else:
        logging.error(
            f"""
        {basename} not saved to the default bucket
        Please ensure that the pre-release pipeline passed and that the reports were generated
        """
        )
        return 1
