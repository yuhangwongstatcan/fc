"""
Functions for loading and extracting the correct reference periods for the CAD reports
"""
import pandas as pd

from modules.utils.loaders import Loader
from config.api import DataSource
from config.api import Stage


def load_reference_periods(
    year: int, month: int, base_year: str = "2019"
) -> pd.DataFrame:
    """
    Extracts the reference periods necessary for the main and leading CAD reports

    Args:
        year (int): Reference year for latest reference period
        month (int): Preference year for latest reference month

    Returns:
        pd.DataFrame: A Pandas dataframe containing all the necessary data for the CAD reports
    """
    # Determine previous month to extract previous month in current year and base year
    previous_month = month - 1 if month - 1 > 0 else 12

    # Get same month for all years up to and including the base year
    start_date = f"{base_year}-{month}-01"
    end_date = f"{year}-{str(month).zfill(2)}-01"
    month_list = pd.period_range(start=start_date, end=end_date, freq="Y")
    reference_period_list = [
        (reference_period.year, month) for reference_period in month_list
    ]

    # Add previous month in current year and base year
    reference_period_list.append((base_year, previous_month))
    reference_period_list.append((year, previous_month))

    df_list = []

    for reference_period in reference_period_list:
        df_list.append(
            Loader.query(
                stage=Stage.AGGREGATED,
                datasource=DataSource.travellers,
                year=int(reference_period[0]),
                month=int(reference_period[1]),
            )
        )

    total_df = pd.concat(df_list, ignore_index=True)

    return total_df


def load_all_reference_periods(
    year: int, month: int, base_year: str = "2019"
) -> pd.DataFrame:
    """
    Extracts the reference periods necessary for the main and leading CAD reports

    Args:
        year (int): Reference year for latest reference period
        month (int): Preference year for latest reference month

    Returns:
        pd.DataFrame: A Pandas dataframe containing all the necessary data for the CAD reports
    """
    start_date = f"{base_year}-{month}-01"
    end_date = f"{year}-{str(month).zfill(2)}-01"
    month_list = pd.period_range(start=start_date, end=end_date, freq="M")
    reference_period_list = [
        (reference_period.year, month) for reference_period in month_list
    ]

    df_list = []

    for reference_period in reference_period_list:
        df_list.append(
            Loader.query(
                stage=Stage.AGGREGATED,
                datasource=DataSource.travellers,
                year=int(reference_period[0]),
                month=int(reference_period[1]),
            )
        )

    total_df = pd.concat(df_list)

    return total_df
