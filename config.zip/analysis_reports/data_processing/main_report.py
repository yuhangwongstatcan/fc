"""
Functions used to generate the reports used by the analysis team for 
writing the main release Daily
"""
import pandas as pd
from typing import Tuple

from modules.utils.loaders import Loader
from config.api import Stage, DataSource, Countries, Continents

from analysis_reports.data_processing import helpers
from analysis_reports.utilities import SheetConfig
from datasource.common.labels import VEHICLE_TYPE as VEHICLE_TYPE_LABELS
from datasource.travellers.dim import (
    COUNTRY_OF_RESIDENCE,
    MODE,
    TRAVELLER_TYPE,
    ARRIVING_FROM,
)
from datasource.travellers.dim import VEHICLE_TYPE as VEHICLE_TYPE_DIM
from datasource.travellers.schema import TransformedSchema
from datasource.countries.schema import ReferenceSchema as CountriesSchema
from datasource.countries_continent.schema import ReferenceSchema as ContinentSchema


def vehicle_analysis(data: pd.DataFrame, year: int, month: int) -> SheetConfig:
    """
    Creates the vehicle analysis pivot tables

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        year(int): Reference year
        month (int): Reference month

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    data = data[
        data[TransformedSchema.month] == str(month)
    ].copy()  # Running .copy() so we don't mutate the original data

    # Code labels for residency
    can_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )
    us_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.united_states.value
    )

    ovs_resident = ~(can_resident | us_resident)

    from_us = (
        data[TransformedSchema.arriving_from]
        == ARRIVING_FROM.us_only.value
    )
    from_ovs_direct = (
        data[TransformedSchema.arriving_from]
        == ARRIVING_FROM.ovs_direct.value
    )
    from_ovs_via_us = (
        data[TransformedSchema.arriving_from]
        == ARRIVING_FROM.ovs_via_us.value
    )
    from_ovs_total = (from_ovs_direct | from_ovs_via_us)
    can_resident_from_ovs = (can_resident & from_ovs_total)
    can_resident_from_us = (can_resident & from_us)

    #data.loc[can_resident, "residency"] = "CAN resident"
    data.loc[can_resident_from_ovs, "residency"] = "CAN resident from OVS"
    data.loc[can_resident_from_us, "residency"] = "CAN resident from US"
    data.loc[us_resident, "residency"] = "US resident"
    data.loc[ovs_resident, "residency"] = "Overseas"

    # Code labels for mode
    mode_frame = data.copy()  # Running .copy() so we don't mutate the original data

    air = mode_frame[TransformedSchema.mode] == MODE.air.value
    land = mode_frame[TransformedSchema.mode] == MODE.land.value
    water = mode_frame[TransformedSchema.mode] == MODE.water.value

    mode_frame.loc[air, TransformedSchema.mode] = "Air - Total"
    mode_frame.loc[land, TransformedSchema.mode] = "Land - Total"
    mode_frame.loc[water, TransformedSchema.mode] = "Water - Total"

    na_mask = mode_frame[TransformedSchema.mode] == MODE.not_available.value
    mode_frame = mode_frame[~na_mask]

  

    # Pivot tables
    # Append the vehicle type resolution to the mode
    can_from_ovs_output = helpers.pivot_groupby(
        mode_frame[can_resident_from_ovs],
        index=TransformedSchema.mode,
        columns=TransformedSchema.year,
    )
    can_from_ovs_output = can_from_ovs_output.append(
        helpers.pivot_groupby(
            data[can_resident_from_ovs],
            index=TransformedSchema.vehicle_type,
            columns=TransformedSchema.year,
        ).sort_values(by=str(year), ascending=False)
    ).fillna(0)

    can_from_us_output = helpers.pivot_groupby(
        mode_frame[can_resident_from_us],
        index=TransformedSchema.mode,
        columns=TransformedSchema.year,
    )
    can_from_us_output = can_from_us_output.append(
        helpers.pivot_groupby(
            data[can_resident_from_us],
            index=TransformedSchema.vehicle_type,
            columns=TransformedSchema.year,
        ).sort_values(by=str(year), ascending=False)
    ).fillna(0)

    us_output = helpers.pivot_groupby(
        mode_frame[us_resident],
        index=TransformedSchema.mode,
        columns=TransformedSchema.year,
    )
    us_output = us_output.append(
        helpers.pivot_groupby(
            data[us_resident],
            index=TransformedSchema.vehicle_type,
            columns=TransformedSchema.year,
        ).sort_values(by=str(year), ascending=False)
    ).fillna(0)

    ovs_output = helpers.pivot_groupby(
        mode_frame[ovs_resident],
        index=TransformedSchema.mode,
        columns=TransformedSchema.year,
    )
    ovs_output = ovs_output.append(
        helpers.pivot_groupby(
            data[ovs_resident],
            index=TransformedSchema.vehicle_type,
            columns=TransformedSchema.year,
        ).sort_values(by=str(year), ascending=False)
    ).fillna(0)
    
    can_output = can_from_us_output.add(can_from_ovs_output, fill_value=0)
    all_visitors = us_output.add(ovs_output, fill_value=0).add(can_output, fill_value=0)
    non_resident_output = us_output.add(ovs_output, fill_value=0)
    combined_output = pd.concat(
        [can_from_us_output, can_from_ovs_output, can_output, us_output, ovs_output, all_visitors, non_resident_output], axis=1, keys=["CAN from US", "CAN from OVS", "CAN (from US + OVS)", "US", "OVS", "All visitors", "Non Resident"]
    ).fillna(0)

    combined_output.loc["Ferry - Total", :] = (
        combined_output.loc[VEHICLE_TYPE_DIM.ferry_private_vehicle.value]
        + combined_output.loc[VEHICLE_TYPE_DIM.ferry_pedestrian.value]
        + combined_output.loc[VEHICLE_TYPE_DIM.ferry_unknown.value]
    )

    combined_output.loc["Total - all vehicles", :] = (
        combined_output.loc["Air - Total"]
        + combined_output.loc["Land - Total"]
        + combined_output.loc["Water - Total"]
    )

    combined_output.drop(
        [
            VEHICLE_TYPE_DIM.ferry_private_vehicle.value,
            VEHICLE_TYPE_DIM.ferry_pedestrian.value,
            VEHICLE_TYPE_DIM.ferry_unknown.value,
        ],
        axis=0,
        inplace=True,
    )

    combined_output.index = combined_output.index.to_series().replace(
        VEHICLE_TYPE_LABELS
    )
    combined_output.columns = combined_output.columns.set_names([None, None])
    new_index = ["Total - all vehicles", "Commercial aircraft", "Cargo aircraft", "Private aircraft", "Air - Total", "Automobile", 
                 "Motorcycle", "Bus", "Train", "Pedestrian", "Other land vehicle", "Land (Not available)", "Land - Total", 
                 "Cruise ship or other commercial boat", "Cargo ship", "Ferry - Total", "Private boat", "Water - Total"]
    combined_output = combined_output.reindex(new_index)

    vehicle_trips_config = {
        "name": "Vehicle Trips Report",
        "index": "",
        "columns": "",
        "reports": [{"Trips by vehicle type": combined_output}],
    }

    return SheetConfig(**vehicle_trips_config)


def geography_analysis(data: pd.DataFrame, year: int, month: int) -> SheetConfig:
    """
    Creates the overseas geography analysis pivot tables

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        year(int): Reference year
        month (int): Reference month

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    data = data[
        data[TransformedSchema.month] == str(month)
    ].copy()  # Running .copy() so we don't mutate the original data

    # Remove out of scope countries (Canada and US)
    country_exclusion_mask = data[TransformedSchema.country_of_residence].isin(
        [COUNTRY_OF_RESIDENCE.canada.value, COUNTRY_OF_RESIDENCE.united_states.value]
    )

    data = data[~country_exclusion_mask]

    data = data[
        [
            TransformedSchema.year,
            TransformedSchema.country_of_residence,
            TransformedSchema.count_of_entries,
        ]
    ]

    # Pivot tables
    country_output = helpers.pivot_groupby(
        data,
        index=TransformedSchema.country_of_residence,
        columns=TransformedSchema.year,
    )
    # Select top 15 countries
    country_output = country_output.sort_values(by=str(year), ascending=False).head(15)

    country_perc_output = country_output / country_output.sum(axis=0)
    country_perc_output = country_perc_output.applymap(helpers.decimal_to_percentage)

    # Identify continent based on 1st digit of country code
    data["continent"] = data[TransformedSchema.country_of_residence].str[:1]
    continent_output = helpers.pivot_groupby(
        data, index="continent", columns=TransformedSchema.year
    )
    continent_output = continent_output.sort_values(by=str(year), ascending=False)

    continent_perc_output = continent_output / continent_output.sum(axis=0)
    continent_perc_output = continent_perc_output.applymap(helpers.decimal_to_percentage)

    # Recode countries and continent
    COUNTRIES = CountriesSchema(
        Loader.get(
            Stage.REFERENCE,
            DataSource.countries,
            Countries.countries,
        )
    )
    COUNTRIES = COUNTRIES.set_index(CountriesSchema.country_of_residence)[
        CountriesSchema.country_name_en
    ].to_dict()

    CONTINENT = ContinentSchema(
        Loader.get(
            Stage.REFERENCE,
            DataSource.countries_continent,
            Continents.countries__continent,
        )
    )
    CONTINENT = CONTINENT.set_index(ContinentSchema.continent)[
        ContinentSchema.continent_en
    ].to_dict()

    country_output.index = country_output.index.to_series().replace(COUNTRIES)
    country_perc_output.index = country_perc_output.index.to_series().replace(COUNTRIES)
    continent_output.index = continent_output.index.to_series().replace(CONTINENT)
    continent_perc_output.index = continent_perc_output.index.to_series().replace(CONTINENT)

    geography_config = {
        "name": "Geography Report",
        "index": "Geography",
        "columns": "Year",
        "reports": [
            {
                "Top 15 Countries": country_output,
                "Top 15 Countries (%)": country_perc_output
                
            },
            {
                "Continents": continent_output,
                "Continents (%)": continent_perc_output
            }
        ],
    }

    return SheetConfig(**geography_config)


def trip_duration_analysis(data: pd.DataFrame, month: int) -> SheetConfig:
    """
    Creates the trip duration analysis pivot tables

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        month (int): Reference month

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    data = data[
        data[TransformedSchema.month] == str(month)
    ].copy()  # Running .copy() so we don't mutate the original data

    # Select in-scope mode
    land_mask = data[TransformedSchema.mode] == MODE.land.value

    data = data[land_mask]

    # Code residency and duration
    can_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )
    us_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.united_states.value
    )

    same_day = (
        data[TransformedSchema.traveller_type] == TRAVELLER_TYPE.excursionist.value
    )
    overnight = data[TransformedSchema.traveller_type] == TRAVELLER_TYPE.tourist.value

    data.loc[same_day, TransformedSchema.traveller_type] = "Same day"
    data.loc[overnight, TransformedSchema.traveller_type] = "Overnight"

    data.loc[can_resident, "residency"] = "CAN resident"
    data.loc[us_resident, "residency"] = "US resident"

    data = data[
        [
            TransformedSchema.year,
            TransformedSchema.traveller_type,
            TransformedSchema.vehicle_type,
            "residency",
            TransformedSchema.count_of_entries,
            TransformedSchema.arriving_from,
        ]
    ]

    # Pivot tables
    # Overall land travel
    can_output = helpers.pivot_groupby(
        data[can_resident],
        index=TransformedSchema.traveller_type,
        columns=TransformedSchema.year,
    )

    can_perc_output = can_output / can_output.sum(axis=0)
    can_perc_output = can_perc_output.applymap(helpers.decimal_to_percentage)
    us_output = helpers.pivot_groupby(
        data[us_resident],
        index=TransformedSchema.traveller_type,
        columns=TransformedSchema.year,
    )

    us_perc_output = us_output / us_output.sum(axis=0)
    us_perc_output = us_perc_output.applymap(helpers.decimal_to_percentage)
    # Car travel
    car_mask = data[TransformedSchema.vehicle_type] == VEHICLE_TYPE_DIM.automobile.value
    fromUS_mask = data[TransformedSchema.arriving_from] == ARRIVING_FROM.us_only.value
    can_car_output = helpers.pivot_groupby(
        data[can_resident & car_mask & fromUS_mask],
        index=TransformedSchema.traveller_type,
        columns=TransformedSchema.year,
    )

    can_car_perc_output = can_car_output / can_car_output.sum(axis=0)
    can_car_perc_output = can_car_perc_output.applymap(helpers.decimal_to_percentage)
    us_car_output = helpers.pivot_groupby(
        data[us_resident & car_mask],
        index=TransformedSchema.traveller_type,
        columns=TransformedSchema.year,
    )

    us_car_perc_output = us_car_output / us_car_output.sum(axis=0)
    us_car_perc_output = us_car_perc_output.applymap(helpers.decimal_to_percentage)

    trip_duration_config = {
        "name": "Trip Duration Report",
        "index": "Traveller Type",
        "columns": "Year",
        "reports": [
            {
                "CAN Residents - Land Only": can_output,
                "CAN Residents (%) - Land Only": can_perc_output,
            },
            {
                "CAN Residents from US- Car Only": can_car_output,
                "CAN Residents from US(%) - Car Only": can_car_perc_output,
            },
            {
                "US Residents - Land Only": us_output,
                "US Residents (%) - Land Only": us_perc_output,
            },
            {
                "US Residents - Car Only": us_car_output,
                "US Residents (%) - Car Only": us_car_perc_output,
            },
        ],
    }

    return SheetConfig(**trip_duration_config)


def arriving_from_analysis(data: pd.DataFrame, month: int) -> SheetConfig:
    """
    Creates the arriving from analysis pivot tables

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        month (int): Reference month

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    current_month = month
    current_month_mask = data[TransformedSchema.month] == str(current_month)

    data = data[current_month_mask].copy()  # Running .copy() so we don't mutate the original data

    # Select in-scope residency
    can_resident_mask = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )

    data = data[can_resident_mask]

    # Create a reference period column to distinguish months
    data["reference_period"] = (
        data[TransformedSchema.year] + "/" + data[TransformedSchema.month].str.zfill(2)
    )

    # Determine slices for each table
    to_us_mask = data[TransformedSchema.arriving_from] == ARRIVING_FROM.us_only.value
    to_ovs_mask = data[TransformedSchema.arriving_from].isin(
        [ARRIVING_FROM.ovs_direct.value, ARRIVING_FROM.ovs_via_us.value]
    )

    # Code mode
    air = data[TransformedSchema.mode] == MODE.air.value
    land = data[TransformedSchema.mode] == MODE.land.value
    water = data[TransformedSchema.mode] == MODE.water.value
    na_mask = data[TransformedSchema.mode] == MODE.not_available.value

    data.loc[air, TransformedSchema.mode] = "Air"
    data.loc[land, TransformedSchema.mode] = "Land"
    data.loc[water, TransformedSchema.mode] = "Water"

    data = data[~na_mask]

    # Pivot tables
    to_us_output = helpers.pivot_groupby(
        data[to_us_mask], index=TransformedSchema.mode, columns="reference_period"
    )
    to_us_output.loc["Total"] = to_us_output.sum(numeric_only=True)

    total_frame = data.copy()  # Running .copy() so we don't mutate the original data
    total_frame[TransformedSchema.mode] = "Total"
    to_ovs_output = helpers.pivot_groupby(
        total_frame[to_ovs_mask],
        index=TransformedSchema.mode,
        columns="reference_period",
    )

    arriving_from_config = {
        "name": "Destination Report",
        "index": "Mode",
        "columns": "Reference Period",
        "reports": [
            {"Canadian-resident - from US": to_us_output},
            {"Canadian-resident - from Overseas (direct + via US)": to_ovs_output},
        ],
    }

    return SheetConfig(**arriving_from_config)


EXPORTED_MEMBERS = [
    vehicle_analysis,
    geography_analysis,
    trip_duration_analysis,
    arriving_from_analysis,
]
