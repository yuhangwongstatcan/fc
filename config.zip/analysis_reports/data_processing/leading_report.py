"""
Functions used to generate the reports used by the analysis team for 
writing the leading release Daily

To set which functions are exported to release.py edit the EXPORTED_MEMBERS list at the bottom of the file
"""
import calendar
import pandas as pd
from typing import Tuple, Optional

from analysis_reports.data_processing import helpers
from analysis_reports.utilities import SheetConfig

from datasource.travellers.dim import (
    DATA_SOURCE,
    VEHICLE_TYPE,
    COUNTRY_OF_RESIDENCE,
    TRAVELLER_TYPE,
    ARRIVING_FROM,
)
from datasource.travellers.schema import TransformedSchema


def airport_analysis(data: pd.DataFrame, month: int) -> SheetConfig:
    """
    Creates the airport analysis pivot tables

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        month (int): Reference month

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    data = data[
        data[TransformedSchema.month] == str(month)
    ].copy()  # Running .copy() so we don't mutate the original data

    # Select the correct data source and vehicle
    pik_mask = data[TransformedSchema.data_source] == DATA_SOURCE.PIK.value
    plane_mask = (
        data[TransformedSchema.vehicle_type] == VEHICLE_TYPE.commercial_aircraft.value
    )

    data = data[pik_mask & plane_mask]

    data = data[
        [
            TransformedSchema.year,
            TransformedSchema.country_of_residence,
            TransformedSchema.work_location,
            TransformedSchema.count_of_entries,
        ]
    ]

    # Create and code slices for correct work locations
    t1_mask = data[TransformedSchema.work_location].isin(["3549790", "4971"])
    t3_mask = data[TransformedSchema.work_location].isin(["3549792", "4974"])
    calg_mask = data[TransformedSchema.work_location].isin(["4870190", "7011"])

    auxiliary_frame = data[t1_mask | t3_mask]
    auxiliary_frame.loc[:, "airport"] = "Toronto Pearson - Total"

    data.loc[t1_mask, "airport"] = "Toronto Pearson - Terminal 1 (4971)"
    data.loc[t3_mask, "airport"] = "Toronto Pearson - Terminal 3 (4974)"

    data.loc[calg_mask, "airport"] = "Calgary (7011)"
    data = data.dropna()

    data = data.append(auxiliary_frame)

    resident_mask = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )

    # Pivot tables
    resident_output = helpers.pivot_groupby(
        data[resident_mask], index="airport", columns=TransformedSchema.year
    )

    non_resident_output = helpers.pivot_groupby(
        data[~resident_mask], index="airport", columns=TransformedSchema.year
    )

    airport_config = {
        "name": "T1-T3 Airport Report",
        "index": "Airport",
        "columns": "Year",
        "reports": [
            {"Canadian-resident visitors": resident_output},
            {"Non-resident visitors": non_resident_output},
        ],
    }

    return SheetConfig(**airport_config)


def total_trips_analysis(
    data: pd.DataFrame, month: int, base_year: Optional[str] = "2019"
) -> SheetConfig:
    """
    Creates the total trips analysis pivot tables

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        month (int): Reference month
        base_year (str): The base year for the percent change calculations. Defaults to "2019".

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    data = data[
        data[TransformedSchema.month] == str(month)
    ].copy()  # Running .copy() so we don't mutate the original data

    ### Code residency
    can_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )
    us_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.united_states.value
    )
    from_us = (
        data[TransformedSchema.arriving_from]
        == ARRIVING_FROM.us_only.value
    )
    from_ovs_direct = (
        data[TransformedSchema.arriving_from]
        == ARRIVING_FROM.ovs_direct.value
    )
    from_ovs_via_us = (
        data[TransformedSchema.arriving_from]
        == ARRIVING_FROM.ovs_via_us.value
    )
    from_ovs = (from_ovs_direct | from_ovs_via_us)
    can_resident_from_ovs = (can_resident & from_ovs)
    can_resident_from_us = (can_resident & from_us)
    overseas_resident = ~(can_resident | us_resident)

    data.loc[can_resident_from_ovs, "residency"] = "CAN resident - from OVS"
    data.loc[can_resident_from_us, "residency"] = "CAN resident - from US"
    #data.loc[can_resident, "residency"] = "CAN resident total"
    data.loc[us_resident, "residency"] = "US resident"
    data.loc[overseas_resident, "residency"] = "Overseas resident"

    air_mask = (
        data[TransformedSchema.vehicle_type] == VEHICLE_TYPE.commercial_aircraft.value
    )
    land_mask = data[TransformedSchema.vehicle_type] == VEHICLE_TYPE.automobile.value

    t1_mask = ~data[TransformedSchema.work_location].isin(["3549790", "4971"])

    ### Pivot tables & percent change tables
    ## All inputs
    # Calculate numbers
    total_output = helpers.pivot_groupby(
        data, index="residency", columns=TransformedSchema.year
    )
    total_can_resident = total_output.loc[["CAN resident - from OVS", "CAN resident - from US"]].sum()
    total_output.loc["CAN resident"] = total_can_resident
    total_output = total_output.loc[["CAN resident",
                                    "Overseas resident", 
                                    "US resident",
                                    ]]
    total_output_perc = total_output.div(total_output[base_year], axis=0)

    # Format
    # total_output = total_output.applymap(helpers.format_with_commas)
    total_output_perc = total_output_perc.drop(
        base_year, axis=1, inplace=False
    ).applymap(helpers.decimal_to_percentage)
    # # All reports should have the same columns in the same order so we can
    # # generate the column names once:
    formatted_perc_columns = [
        f"{col} / {base_year}" for col in total_output_perc.columns
    ]
    total_output_perc.columns = formatted_perc_columns

    ## Air with T1
    air_output = helpers.pivot_groupby(
        data[air_mask], index="residency", columns=TransformedSchema.year
    )
    total_can_resident = air_output.loc[["CAN resident - from OVS", "CAN resident - from US"]].sum()
    air_output.loc["CAN resident total"] = total_can_resident
    air_output = air_output.loc[["CAN resident - from OVS", 
                                    "CAN resident - from US", 
                                    "CAN resident total",
                                    "Overseas resident", 
                                    "US resident",
                                    ]]
    air_output.loc["Non-resident (Overseas + US)", :] = (
        air_output.loc["Overseas resident", :] + air_output.loc["US resident", :]
    )
    air_output_perc = air_output.div(air_output[base_year], axis=0)

    # Format
    # air_output = air_output.applymap(helpers.format_with_commas)
    air_output_perc = air_output_perc.drop(base_year, axis=1, inplace=False).applymap(
        helpers.decimal_to_percentage
    )
    air_output_perc.columns = formatted_perc_columns

    ## Air without T1
    air_output_no_t1 = helpers.pivot_groupby(
        data[air_mask & t1_mask], index="residency", columns=TransformedSchema.year
    )
    total_can_resident = air_output_no_t1.loc[["CAN resident - from OVS", "CAN resident - from US"]].sum()
    air_output_no_t1.loc["CAN resident"] = total_can_resident
    air_output_no_t1 = air_output_no_t1.loc[["CAN resident",
                                    "Overseas resident", 
                                    "US resident",
                                    ]]
    air_output_no_t1.loc["Non-resident (Overseas + US)", :] = (
        air_output_no_t1.loc["Overseas resident", :]
        + air_output_no_t1.loc["US resident", :]
    )
    air_output_no_t1_perc = air_output_no_t1.div(air_output_no_t1[base_year], axis=0)

    # Format
    # air_output_no_t1 = air_output_no_t1.applymap(helpers.format_with_commas)
    air_output_no_t1_perc = air_output_no_t1_perc.drop(
        base_year, axis=1, inplace=False
    ).applymap(helpers.decimal_to_percentage)
    air_output_no_t1_perc.columns = formatted_perc_columns

    ## Land
    land_output = helpers.pivot_groupby(
        data[land_mask], index="residency", columns=TransformedSchema.year
    )
    total_can_resident = land_output.loc[["CAN resident - from US"]].sum()
    land_output.loc["CAN resident"] = total_can_resident
    land_output = land_output.loc[["CAN resident",
                                    "Overseas resident", 
                                    "US resident",
                                    ]]
    land_output_perc = land_output.div(land_output[base_year], axis=0)

    # Format
    # land_output = land_output.applymap(helpers.format_with_commas)
    land_output_perc = land_output_perc.drop(base_year, axis=1, inplace=False).applymap(
        helpers.decimal_to_percentage
    )
    land_output_perc.columns = formatted_perc_columns

    total_trips_config = {
        "name": "Canada-US Trips Report",
        "index": "Residency",
        "columns": "Year",
        "reports": [
            {
                "Arrivals by air (PIK) (incl. T1) & automobile (IPIL)": total_output,
                f"% of {base_year}": total_output_perc,
            },
            {
                "Arrivals by automobile (IPIL)": land_output,
                f"% of {base_year}": land_output_perc,
            },
            {
                "Arrivals by air (PIK) (incl. T1)": air_output,
                f"% of {base_year}": air_output_perc,
            },
            {
                "Arrivals by air (PIK) (excl. T1)": air_output_no_t1,
                f"% of {base_year}": air_output_no_t1_perc,
            },
        ],
    }

    return SheetConfig(**total_trips_config)


def trip_duration_analysis(data: pd.DataFrame, year: int, month: int) -> SheetConfig:
    """
    Creates the trip duration analysis pivot tables

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        year(int): Reference year
        month (int): Reference month

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    # Select correct data source and vehicle
    ipil_mask = data[TransformedSchema.data_source] == DATA_SOURCE.IPIL_Highway.value
    car_mask = data[TransformedSchema.vehicle_type] == VEHICLE_TYPE.automobile.value

    data = data[
        ipil_mask & car_mask
    ].copy()  # Running .copy() so we don't mutate the original data

    # Code and identify residency and traveller type
    can_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )
    us_resident = (
        data[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.united_states.value
    )

    same_day = (
        data[TransformedSchema.traveller_type] == TRAVELLER_TYPE.excursionist.value
    )
    overnight = data[TransformedSchema.traveller_type] == TRAVELLER_TYPE.tourist.value

    data.loc[same_day, TransformedSchema.traveller_type] = "Same day"
    data.loc[overnight, TransformedSchema.traveller_type] = "Overnight"

    data.loc[can_resident, "residency"] = "CAN resident"
    data.loc[us_resident, "residency"] = "US resident"

    curr_mask = (data[TransformedSchema.month] == str(month)) & (
        data[TransformedSchema.year] == str(year)
    )

    previous_month = month - 1 if month - 1 > 0 else 12

    prev_mask = (data[TransformedSchema.month] == str(previous_month)) & (
        data[TransformedSchema.year] == str(year)
    )

    # Pivot table - Current
    trip_duration_output_curr = helpers.pivot_groupby(
        data[(can_resident | us_resident) & curr_mask],
        index=TransformedSchema.traveller_type,
        columns="residency",
    )

    perc_trip_duration_output_curr = (
        trip_duration_output_curr / trip_duration_output_curr.sum(axis=0)
    )

    perc_trip_duration_output_curr = perc_trip_duration_output_curr.applymap(
        helpers.decimal_to_percentage
    )

    # Pivot table - Previous month
    trip_duration_output_prev = helpers.pivot_groupby(
        data[(can_resident | us_resident) & prev_mask],
        index=TransformedSchema.traveller_type,
        columns="residency",
    )

    perc_trip_duration_output_prev = (
        trip_duration_output_prev / trip_duration_output_prev.sum(axis=0)
    )

    perc_trip_duration_output_prev = perc_trip_duration_output_prev.applymap(
        helpers.decimal_to_percentage
    )

    trip_duration_config = {
        "name": "Trip Duration Report",
        "index": "Duration",
        "columns": "Residency",
        "reports": [
            {
                f"Trip Duration (automobile) - {calendar.month_name[month]}": trip_duration_output_curr,
                f"% Trip Duration (automobile) - {calendar.month_name[month]}": perc_trip_duration_output_curr,
            },
            {
                f"Trip Duration (automobile) - {calendar.month_name[previous_month]}": trip_duration_output_prev,
                f"% Trip Duration (automobile) - {calendar.month_name[previous_month]}": perc_trip_duration_output_prev,
            },
        ],
    }

    return SheetConfig(**trip_duration_config)


def recovery_analysis(
    data: pd.DataFrame, year: int, month: int, base_year="2019"
) -> SheetConfig:
    """
    Calculates the recovery for canadian airports against a base year,
    excluding Pearson Terminal 1

    Args:
        data (pd.DataFrame): Pandas dataframe containing all necessary reference periods
        year(int): Reference year
        month (int): Reference month
        base_year (str, optional): _description_. Defaults to "2019".

    Returns:
        SheetConfig: Filled in configuration ready for writing to Excel
    """
    ## Airport processing

    # Create masks for data source and vehicle type, excluding T1
    pik_mask = data[TransformedSchema.data_source] == DATA_SOURCE.PIK.value
    airplane_mask = (
        data[TransformedSchema.vehicle_type] == VEHICLE_TYPE.commercial_aircraft.value
    )
    t1_mask = data[TransformedSchema.work_location].isin(["3549790", "4971"])

    data_air = data[pik_mask & airplane_mask & ~t1_mask]

    # Regenerate reference period masks for smaller dataset
    base_year_mask = data_air[TransformedSchema.year] == base_year
    current_year = str(year)
    current_year_mask = data_air[TransformedSchema.year] == current_year

    previous_month = month - 1 if month - 1 > 0 else 12
    previous_month_mask = data_air[TransformedSchema.month] == str(previous_month)
    current_month = month
    current_month_mask = data_air[TransformedSchema.month] == str(current_month)

    # Recode reference period to human-readable month name
    data_air.loc[previous_month_mask, TransformedSchema.month] = calendar.month_name[
        previous_month
    ]
    data_air.loc[current_month_mask, TransformedSchema.month] = calendar.month_name[
        current_month
    ]

    # Code residency
    resident_mask_air = (
        data_air[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )

    data_air.loc[resident_mask_air, "residency"] = "CAN resident"
    data_air.loc[~resident_mask_air, "residency"] = "Non-resident (US + Overseas)"

    # Pivot tables
    current_year_air_output = helpers.pivot_groupby(
        data_air[current_year_mask], index="residency", columns=TransformedSchema.month
    )
    base_year_air_output = helpers.pivot_groupby(
        data_air[base_year_mask], index="residency", columns=TransformedSchema.month
    )

    # Calculate the recovery as current year / base year
    percent_air_output = current_year_air_output / base_year_air_output

    # Format columns based on prod team preference
    formatted_air_output_columns = [
        f"{col} {current_year} / {col} {base_year}"
        for col in percent_air_output.columns
    ]

    percent_air_output.columns = formatted_air_output_columns

    percent_air_output = percent_air_output.applymap(helpers.decimal_to_percentage)

    ## Land processing

    # Select data source and vehicle type
    ipil_mask = data[TransformedSchema.data_source] == DATA_SOURCE.IPIL_Highway.value
    car_mask = data[TransformedSchema.vehicle_type] == VEHICLE_TYPE.automobile.value

    data_land = data[ipil_mask & car_mask]

    # Regenerate reference period masks for smaller dataset
    base_year_mask = data_land[TransformedSchema.year] == base_year
    current_year = str(year)
    current_year_mask = data_land[TransformedSchema.year] == current_year

    previous_month = month - 1 if month - 1 > 0 else 12
    previous_month_mask = data_land[TransformedSchema.month] == str(previous_month)
    current_month = month
    current_month_mask = data_land[TransformedSchema.month] == str(current_month)

    # Recode reference period to human-readable month name
    data_land.loc[previous_month_mask, TransformedSchema.month] = calendar.month_name[
        previous_month
    ]
    data_land.loc[current_month_mask, TransformedSchema.month] = calendar.month_name[
        current_month
    ]

    # Code residency
    resident_mask_land = (
        data_land[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.canada.value
    )
    us_resident = (
        data_land[TransformedSchema.country_of_residence]
        == COUNTRY_OF_RESIDENCE.united_states.value
    )

    data_land.loc[resident_mask_land, "residency"] = "CAN resident"
    data_land.loc[us_resident, "residency"] = "US resident"

    data_land = data_land[
        [TransformedSchema.month, "residency", TransformedSchema.count_of_entries]
    ]

    # Pivot tables
    current_year_land_output = helpers.pivot_groupby(
        data_land[current_year_mask], index="residency", columns=TransformedSchema.month
    )
    base_year_land_output = helpers.pivot_groupby(
        data_land[base_year_mask], index="residency", columns=TransformedSchema.month
    )

    # Calculate the recovery as current year / base year
    percent_land_output = current_year_land_output / base_year_land_output

    # Format columns based on prod team preference
    formatted_land_output_columns = [
        f"{col} {current_year} / {col} {base_year}"
        for col in percent_land_output.columns
    ]

    percent_land_output.columns = formatted_land_output_columns

    percent_land_output = percent_land_output.applymap(helpers.decimal_to_percentage)

    recovery_config = {
        "name": "Recovery Report",
        "index": "Residency",
        "columns": TransformedSchema.month,
        "reports": [
            {"Airport Recovery (excluding YYZ T1)": percent_air_output},
            {"Automobile Recovery": percent_land_output},
        ],
    }

    return SheetConfig(**recovery_config)


EXPORTED_MEMBERS = [
    total_trips_analysis,
    recovery_analysis,
    airport_analysis,
    trip_duration_analysis,
]
