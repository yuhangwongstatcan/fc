# -*- coding: utf-8 -*-
"""
**Author(s)**

- Andres Solis Montero - `andres.solismontero@canada.ca`

- Collin Brown - `collin.brown@canada.ca`

**Created On:** Thursday Nov 19 12:13:20 2020

**Description:**

The `config` module contains a variety of configuration utilities and enumerators. All Enum classes
that are used throughout the project are here. The `S3` proxy class for generating S3Locations
is defined here as well.
"""
import os
import re
import json
import pandas as pd
from enum import Enum
from enum import auto
from typing import Dict
from typing import Optional
from typing import List
from datetime import datetime
from collections import namedtuple
from dataclasses import dataclass
from os.path import join
from os.path import basename
from os.path import dirname

from dataclasses import fields
from dataclasses import field
from config.env import environ
from functools import lru_cache

"""
S3 Locations relevant to our application.
"""
S3Location = namedtuple(
    "S3Location", ["bucket", "prefix", "basename"], defaults=["", "", ""]
)

DEFAULT_BUCKET = environ().DEFAULT_BUCKET
"""Whenever a default bucket is appropriate; making global variable in config
   to avoid hard-coding a bucket name throughout the codebase."""

DATE_FORMAT = "(\d{4})-(\d{2})-(\d{2})"
"""Regex for date formats used in the system."""
DATETIME_STR_FORMAT = "%Y_%m_%d_%H_%M_%S.%f"
"""Format string to use when a datetime string is required."""
TIME_BASE_DATASOURCE_PATTERN = "(\d{4})(\d{2})(\d{2})?.*.csv"
"""Regex for file name to use for time-based data sources."""

CURRENT_YEAR_THRESHOLD = 0.5
PREV_YEAR_THRESHOLD = 0.5
"""
Constants for the manual entry imputation
current year threshold determines whether there are enough data to proceed with
imputation using current year reference distribution. Prev year threshold determines
whether the previous year reference distirbution contains enough data to proceed
with imputation
"""


class AutoEnum(Enum):
    """
    An Enumerator class that lets the value of the enumerable member be the
    name of the member to which it is assigned.

    Args:
        Enum (_type_): Extends `enum.Enum`

    Example usage:

    ```python
    from enum import auto
    # ...
    class SomeEnum(AutoEnum):
        some_value = auto()
        # ...
    ```
    """

    def _generate_next_value_(name, start, count, last_values):
        return name

    @classmethod
    def list(cls) -> List[str]:
        """
        Lists all of the values that belong to a given instance of AutoEnum.

        Returns:
            List[str]: A list of the members of the given AutoEnum instance.
        """
        return list(map(lambda c: c.value, cls))


class ConfigFile(str, Enum):
    """
    The names of all of the configuration files used in Frontier Counts.
    ConfigFile is an enumerator that holds string values.
    """

    rules = "rules.json"
    dependencies = "minio.config.json"
    secrets = "secrets.json"
    test = "fctest.config.json"
    integration_test = "integration.config.json"
    stages = "stages.json"
    stages_alpha = "stages-alpha.json"


class NDMValidations(AutoEnum):
    """
    Enumerator to define the kinds of validations related to downstream validations.
    """

    data_integrity = auto()

    @classmethod
    def aslist(cls) -> List:
        """
        Gets all Enum members as list.
        """
        return [d.name for d in cls]


class StageName(AutoEnum):
    """
    Which stage name to refer to.
    """

    INBOX = auto()
    ERROR = auto()
    ARCHIVE = auto()
    PROCESSING = auto()
    VALIDATION = auto()
    DATA = auto()
    STAGING = auto()
    OUTBOX = auto()
    REFERENCE = auto()
    RAW = auto()
    CLEAN = auto()
    TRANSFORMED = auto()
    AGGREGATED = auto()
    PRE_RELEASE = auto()
    RELEASE = auto()
    # INTEGRITY = auto()


class StageFactory:
    """
    Class with getter and factory method to get available stages of processing.
    """

    @staticmethod
    @lru_cache
    def get(stage: StageName) -> S3Location:
        return StageFactory.load()[stage]

    @staticmethod
    @lru_cache
    def load() -> "StageFactory":
        with open(join(dirname(__file__), ConfigFile.stages)) as f:
            stages = json.load(f)
        return {StageName[k]: S3Location(**v) for k, v in stages.items()}


class Stage(Enum):
    """
    Enumerator to refer to the stage of processing.
    """

    INBOX = StageFactory.get(StageName.INBOX)
    ERROR = StageFactory.get(StageName.ERROR)
    ARCHIVE = StageFactory.get(StageName.ARCHIVE)
    PROCESSING = StageFactory.get(StageName.PROCESSING)
    VALIDATION = StageFactory.get(StageName.VALIDATION)
    DATA = StageFactory.get(StageName.DATA)
    STAGING = StageFactory.get(StageName.STAGING)
    OUTBOX = StageFactory.get(StageName.OUTBOX)
    REFERENCE = StageFactory.get(StageName.REFERENCE)
    RAW = StageFactory.get(StageName.RAW)
    CLEAN = StageFactory.get(StageName.CLEAN)
    TRANSFORMED = StageFactory.get(StageName.TRANSFORMED)
    AGGREGATED = StageFactory.get(StageName.AGGREGATED)
    PRE_RELEASE = StageFactory.get(StageName.PRE_RELEASE)
    RELEASE = StageFactory.get(StageName.RELEASE)
    # INTEGRITY = StageFactory.get(StageName.INTEGRITY)


class Mode(AutoEnum):
    conflicts = auto()
    historical = auto()
    file = ""

    def staging(self, stage: Stage) -> S3Location:
        return S3Location(
            bucket=stage.value.bucket,
            prefix=join(stage.value.prefix, self.value, ""),
            basename="",
        )


class DataSource(AutoEnum):
    """
    An enumerator for the various data sources in the system.
    """

    # Time-based data sources
    ipil_hwy = auto()
    ipil_air = auto()
    nghh = auto()
    nexus_air = auto()
    nexus_hwy = auto()
    pik = auto()
    pik_report = auto()
    # Manual Entry Data Sources
    e62 = auto()
    e62b = auto()
    e63_residual = auto()  # e63 data that cannot be passed through regular pipeline
    e63_1_residual = auto()
    overseas_summary_report = auto()
    passport_count = auto()
    ad_hoc_data_additions = auto()  # e.g. emails, faxes, etc.
    correction = auto()  # negative entries to correct for over counted values
    e63_1 = auto()
    e63 = auto()
    trc = auto()
    e311 = auto()
    

    # File-based data sources
    ports = auto()
    port_areas = auto()
    port_notes = auto()
    countries = auto()
    countries_region = auto()
    countries_continent = auto()
    pik_airports = auto()
    plate_region = auto()
    provinces_and_territories = auto()
    us_states = auto()
    work_locations = auto()
    work_locations_trans = auto()
    work_locations_action = auto()
    work_locations_trans_action = auto()
    nghh_imputation = auto()
    e311_cutoff_dates = auto()
    fixed_proportions = auto()
    fixed_proportion_rules = auto()
    manual_entry_tracker_travellers = auto()
    manual_entry_tracker_vehicles = auto()
    # NDM related tables
    ndm_calculations = auto()
    ndm_metadata = auto()
    ndm_vectors = auto()
    ndm_24100050_ref = auto()
    ndm_24100051_ref = auto()
    ndm_24100052_ref = auto()
    ndm_24100053_ref = auto()
    ndm_24100054_ref = auto()
    ndm_24100056_ref = auto()
    ndm_24100057_ref = auto()
    ndm_24100058_ref = auto()
    ndm_24100059_ref = auto()
    ndm_sa = auto()

    # Manual Entry
    manual_entry_travellers = auto()
    manual_entry_vehicles = auto()

    # Product file-based datasource generated for SA
    sa_parameters = auto()
    sa_out = auto()
    sa_in = auto()

    # Transformed Data sources
    travellers = auto()
    vehicles = auto()
    # Aggregated Data Sources - Leading
    travellers_leading = auto()
    vehicles_leading = auto()
    # Aggregated Data Sources - Main
    travellers_main = auto()
    vehicles_main = auto()

    ndm_unadjusted = auto()
    ndm_adjusted = auto()
    ndm_24100050 = auto()
    ndm_24100051 = auto()
    ndm_24100052 = auto()
    ndm_24100053 = auto()
    ndm_24100054 = auto()
    ndm_24100055 = auto()
    ndm_24100056 = auto()
    ndm_24100057 = auto()
    ndm_24100058 = auto()
    ndm_24100059 = auto()

    # Separating data sources from dimensions and mappings
    dimension = auto()
    mapping = auto()
    # Other values
    unknown = auto()
    # NDM excluded
    ndm_excluded = auto()
    vector_concordance = auto()
    coordinate_concordance = auto()
    ndm_24100050_dim_description = auto()
    ndm_24100051_dim_description = auto()
    ndm_24100052_dim_description = auto()
    ndm_24100053_dim_description = auto()
    ndm_24100054_dim_description = auto()
    ndm_24100050_old_dim = auto()
    ndm_24100051_old_dim = auto()
    ndm_24100052_old_dim = auto()
    ndm_24100053_old_dim = auto()
    ndm_24100054_old_dim = auto()
    # Validation Configurations
    ndm_integrity_config = auto()
    ndm_integrity_leading_config = auto()
    ndm_integrity_between_tables = auto()
    # Other time based data sources that are not currently registered with the system
    entry_exit = auto()
    ora = auto()
    bus_report = auto()
    e62t = auto()
    other = auto()
    check_inbox = auto()
    # Analysis team reports
    cad_reports = auto()

    @classmethod
    def aslist(cls) -> List:
        """
        Gets all Enum members as list.
        """
        return [d.name for d in cls]

    @classmethod
    def timebased(cls) -> Dict:
        _ = [
            DataSource.e311,
            DataSource.e63_1,
            DataSource.trc,
            DataSource.e63,
            DataSource.ipil_hwy,
            DataSource.ipil_air,
            DataSource.nghh,
            DataSource.nexus_air,
            DataSource.nexus_hwy,
            DataSource.pik,
            DataSource.pik_report,
            DataSource.trc,
            DataSource.e311,
            DataSource.travellers,
            DataSource.vehicles,
            DataSource.travellers_leading,
            DataSource.vehicles_leading,
            DataSource.travellers_main,
            DataSource.vehicles_main,
            DataSource.ndm_unadjusted,
            DataSource.ndm_adjusted,
            DataSource.manual_entry_travellers,
            DataSource.manual_entry_vehicles,
            DataSource.ndm_24100050,
            DataSource.ndm_24100051,
            DataSource.sa_in,
            DataSource.ndm_24100052,
            DataSource.ndm_24100053,
            DataSource.ndm_24100054,
            DataSource.sa_out,
            DataSource.ndm_24100055,
            DataSource.ndm_24100056,
            DataSource.ndm_24100057,
            DataSource.ndm_24100058,
            DataSource.ndm_24100059,
            DataSource.cad_reports,
        ]
        return {d: d for d in _}


class OutputFile(str, Enum):
    """
    An enumerator to store filenames that are output from the system.
    """

    sa_in = f"{DataSource.sa_in.name.upper()}.csv"
    sa_parameters = f"{DataSource.sa_parameters.name.upper()}.csv"


class VectorConcordance(AutoEnum):
    """
    Define the concordance tables between old-new NDM tables.
    This was used in a legacy task of migrating historical data
    from the old system to the new system.
    """

    vector_concordance_ndm_24100050 = auto()
    vector_concordance_ndm_24100051 = auto()
    vector_concordance_ndm_24100052 = auto()
    vector_concordance_ndm_24100053 = auto()
    vector_concordance_ndm_24100054 = auto()


class CoordinateConcordance(AutoEnum):
    """
    Define concordance for NDM dimensions b/t the old system and
    the new system.
    This was used in a legacy task of migrating historical data
    from the old system to the new system.
    """

    coordinate_concordance_ndm_24100050 = auto()
    coordinate_concordance_ndm_24100051 = auto()
    coordinate_concordance_ndm_24100052 = auto()
    coordinate_concordance_ndm_24100053 = auto()
    coordinate_concordance_ndm_24100054 = auto()


class Mapping(AutoEnum):
    """
    **Created On:** [date]

    **Description:**

    An enumerator for all of the mappings between different table columns.

    **Naming Convention:**

    Since a mapping relates the same column across two tables, we follow the naming convention
    of indicating the two tables between which the mapping of the column occurs.
    """

    map__ipil_air__raw__citizenship_code__ipil_air__clean__country_of_residence = auto()
    map__nghh__raw__citizenship_code__nghh__clean__country_of_residence = auto()
    map__trc__raw__country__trc__clean__country_of_residence = auto()
    map__trc__raw__reporting_location__trc__clean__work_location = auto()
    map__all__any__sccai_alpha_3__countries__reference__country_of_residence = auto()
    map__all__any__sccai_alpha_2__countries__reference__country_of_residence = auto()
    map__pik__raw__rescntry__pik__clean__country_of_residence = auto()
    map__ipil_hwy__clean__vehi__travellers__transformed__vehicle_type = auto()
    map__ipil_hwy__clean__vehi__vehicles__transformed__vehicle_type = auto()
    map__ipil_hwy__clean__country__travellers__transformed__country_of_residence = (
        auto()
    )
    map__ipil_hwy__clean__country__travellers__transformed__plate_country = auto()
    map__ipil_hwy__clean__country__vehicles__transformed__plate_country = auto()
    map__nexus_hwy__raw__wloc__nexus_hwy__clean__work_location = auto()
    map__nexus_air__raw__wloc__nexus_air__clean__work_location = auto()
    # NDM Validation mappings
    map__24100050__validation__24100050__aggregated__dim1 = auto()
    map__24100052__validation__24100052__aggregated__dim1 = auto()
    map__24100053__validation__24100053__aggregated__dim1 = auto()


class WorkLocationsTransportation(AutoEnum):
    """
    Used in the 010 business rules that perform recoding based on
    vehicle types and ports of entry.
    """

    work_locations_trans__trc = auto()
    work_locations_trans__pik = auto()
    work_locations_trans__nexus_hwy = auto()
    work_locations_trans__nexus_air = auto()
    work_locations_trans__ipil_hwy = auto()
    work_locations_trans__ipil_air = auto()
    work_locations_trans__nghh = auto()
    work_locations_trans__e311 = auto()
    work_locations_trans__e63 = auto()
    work_locations_trans__e63_1 = auto()


class WorkLocationsAction(AutoEnum):
    """
    Used in the 010 business rules that perform recoding based on
    vehicle types and ports of entry.
    """

    work_locations_action__trc = auto()
    work_locations_action__pik = auto()
    work_locations_action__ipil_hwy = auto()
    work_locations_action__ipil_air = auto()
    work_locations_action__nghh = auto()
    work_locations_action__nexus_air = auto()
    work_locations_action__nexus_hwy = auto()
    work_locations_action__e311 = auto()
    work_locations_action__e63 = auto()
    work_locations_action__e63_1 = auto()


class WorkLocationsTransAction(AutoEnum):
    """
    Used in the 010 business rules that perform recoding based on
    vehicle types and ports of entry.
    """

    work_locations__trc = auto()
    work_locations__pik = auto()
    work_locations__nexus_hwy = auto()
    work_locations__nexus_air = auto()
    work_locations__ipil_hwy = auto()
    work_locations__ipil_air = auto()
    work_locations__nghh = auto()
    work_locations__e311 = auto()
    work_locations__e63 = auto()
    work_locations__e63_1 = auto()


class Countries(AutoEnum):
    countries = auto()


class Continents(AutoEnum):
    countries__continent = auto()


class WorkLocations(AutoEnum):
    work_locations = auto()


class Ports(AutoEnum):
    ports = auto()


class FixedProportions(AutoEnum):
    fixed_proportions = auto()


class FixedProportionsRules(AutoEnum):
    fixed_proportion_rules = auto()


class ManualEntryTrackerTravellers(AutoEnum):
    manual_entry_tracker_travellers = auto()


class ManualEntryTrackerVehicles(AutoEnum):
    manual_entry_tracker_vehicles = auto()


class GroupByAggTypes(AutoEnum):
    """Valid aggregation types for group by in pandas."""

    count = auto()
    sum = auto()


class OutputType(AutoEnum):
    """
    The kind of output to expect from an instance of RuleOutput.
    These are used by the business rules and validations.
    """

    BusinessRule = auto()
    Validation = auto()


class FixedProportionVars(AutoEnum):
    """
    An enumerator indicating the fixed proportion variables for the webapp
    form to enter fixed proportion variables.
    """

    vehicle_type = auto()
    plate_country = auto()
    arriving_from = auto()
    country_of_residence = auto()
    purpose4 = auto()
    duration2 = auto()

    @classmethod
    def aslist(cls) -> List:
        """
        Gets all Enum members as list.
        """
        return [d.name for d in cls]


@dataclass
class RuleOutput:
    """
    A data class to represent the output from a validation.

    Attributes:
        output:
            the pd dataframe corresponding to the output of the business rule
        validation:
            the pd dataframe corresponding to the output of the validation
        auxiliary:
            An optional dataframe that can be used to pass auxiliary data from business rules to
            validations.
        datasource:
            the name of the datasource for the validation (gotten from the
            DataSource enumerator)
    """

    output: pd.DataFrame
    datasource: DataSource
    validation: Optional[pd.DataFrame] = None
    auxiliary: Optional[pd.DataFrame] = None
    date: Optional[str] = None

    @property
    def type(self):
        if self.validation is None:
            return OutputType.BusinessRule
        else:
            return OutputType.Validation


class ValParams(object):
    @staticmethod
    def kwargs(c: dataclass, kwargs: dict) -> dict:
        return {f.name: kwargs[f.name] for f in fields(c) if f.name in kwargs}


@dataclass
class PatternRule:
    datasource: str = None
    stage: str = None
    pattern: str = None
    entrypoint: str = None
    regex: bool = False
    enabled: bool = False


@dataclass
class LoadingRules(object):
    rules: List[PatternRule] = field(default_factory=List)

    @staticmethod
    def load():
        path = join(os.path.dirname(__file__), ConfigFile.rules)
        with open(path) as r:
            json_lr = json.load(r)
        lr = [PatternRule(**ValParams.kwargs(PatternRule, rule)) for rule in json_lr]
        lr = sorted(lr, key=lambda r: r.regex)
        return LoadingRules(lr)

    def get(self, datasource: DataSource = None):
        return [
            rule
            for rule in self.rules
            if (datasource is None)
            or (datasource and rule.datasource == datasource.value)
        ]


class S3:
    """
    Util functions to generate unique files following our folder structures and organization. The
    set of static methods here uses our S3Locations to generate the correct folder structure.

    !!! check
        **Developers should always use the `S3` proxy class instead of hard-coding S3 buckets,
        prefixes, or basenames.** This will significantly reduce the overhead associated with
        remembering naming conventions and also substantially reduce the probability of making an
        error when hard-coding path names.

    !!! quote
        There are two hard problems in computer science: naming things, cache invalidation, and
        off-by-one errors.
    """

    @staticmethod
    def get_processing_location(datasource: DataSource, name: str) -> S3Location:
        """
        **Description:**

        Generates the temporary S3 processing location for a data source input file. S3 Processing
        locations are stored based on the datetime (i.e., `2020_10_10_4:30:25.3434343`) with
        nanosecond precision to avoid naming conflicts.

        Args:
            datasource: DataSource
                The data source for which the processing location applies.
            name: str
                The name of the object for which the processing location applies.

        Returns:
            S3Location:
                The `S3Location` of the object that is being processed.
        """

        return S3.prefix(
            Stage.PROCESSING, Mode.file, datasource, basename=basename(name)
        )

    @staticmethod
    def get_archive_location(datasource: DataSource, name: str) -> S3Location:
        """
        **Description:**

        Generates the archive S3 location for a dataset input file. S3 archive locations are stored
        based on the current date (i.e., 2020/10/10) andthe data source.

        Args:
            datasource: DataSource
                The data source for which the archive location applies.
            name: str
                The name of the object for which the archive location applies.

        Returns:
            S3Location:
                The `S3Location` of the object that is being archived.
        """
        current = datetime.now()
        return S3.prefix(
            Stage.ARCHIVE,
            Mode.file,
            datasource,
            year=current.year,
            month=current.month,
            day=current.day,
            basename=basename(name),
        )

    @staticmethod
    def get_error_location(datasource: DataSource, name: str) -> S3Location:
        """
        **Description:**

        Genrates the error location for an data source input file. S3 Error locations are stored based
        on the current date (i.e., 2020/10/10) and the data source. If a file wasn't recognized as
        one of our data sources it's stored under the unknown DataSource.

        **Example:**

        ```
        input:
            DataSource.unknown (DataSource)
            filename.ext (str)
        output:
            bucket=DEFAULT_BUCKET, prefix='error/unknown/2020/10/20/' basename='filename.ext' (S3Location)
        ```

        Args:
            datasource: DataSource
                The datasource for which this error location applies.
            name: str
                The basename of the file (object) for which the error location applies.

        Returns:
            S3Location:
                The `S3Location` of the file containing the error.
        """
        current = datetime.now()

        return S3.prefix(
            Stage.ERROR,
            Mode.file,
            datasource,
            year=current.year,
            month=current.month,
            day=current.day,
            basename=basename(name),
        )

    @staticmethod
    def __yyyymmdd__(basename: str, is_file: bool = True) -> str:
        """
        **Description:**

        Given a date string of the form `YYYY-MM-DD` or a file name of the form
        `YYYY-MM-DD.[dat|csv]`, and returns a 3-tuple of `(YYYY, MM, DD)`.

        Allows for the specification of file or date string.


        Args:
            basename: str
                A string formatted as YYYY-MM-DD that may or may not contain a file extension (e.g.
                `.dat`, ``, etc). Valid Values are any string of the form "YYYY-MM-DD"; this
                method assumes that such a string is being passed as a basename.
            is_file: bool=True
                An optional keyword that applies a slightly different regular expression to the
                basename depending on whether the basename passed is a filename or a string.

        Returns:
            str:
                A 3-tuple of strings containing `(YYYY, MM, DD)`.
        """
        if is_file:
            g = re.match(TIME_BASE_DATASOURCE_PATTERN, basename)
        else:
            g = re.match(DATE_FORMAT, basename)
        return g.groups() if g else g

    @staticmethod
    def prefix(
        stage: Stage,
        mode: Mode,
        datasource: DataSource,
        *args,
        year: str = "",
        month: str = "",
        day: str = "",
        basename: str = "",
    ) -> S3Location:
        """
        **Description:**

        Generates a S3Location with the correct prefix location for different Stages, Modes, and DataSources.

        Examples:
            ```
            S3.prefix(Stage.RAW, Mode.conflicts, DataSource.ipil_hwy, year='2020', month'10')
            ```

        Args:
            stage: Stage
                Current Data Stage
            mode: Mode
                One of the three possible Modes: conflicts, historical, file
            datasource: DataSource
                The DataSource

        Kwargs:
            year: str=''
                The year value as a 4 char string, this value is dropped if the datasource is file-based
            month: str=''
                The month value as a 2 char string, this value is dropped if the datasource is file-based
            day: str=''
                The day value as a 2 char string, this value is dropped if the datasource is file-based
            basename: str=''
                optional basename string

        Returns:
            S3Location:
                [description]. Valid Values are [values]
        """
        loc = mode.staging(stage)

        # In the proccessing Stage there is not difference between filebased or timebased
        # data source. The path is just an unique temporary path based on time
        if Stage.PROCESSING == stage:
            tmp = datetime.now().strftime(DATETIME_STR_FORMAT)
            return S3Location(
                loc.bucket, join(loc.prefix, datasource.value, tmp, ""), basename
            )
        # No extra args are needed if the Mode is in conflicts or file.
        if Mode.conflicts == mode or Mode.file == mode:
            args = ()
        # Time based and File based prefix construction
        if datasource in DataSource.timebased():
            year = f"{int(year):04d}" if year else ""
            month = f"{int(month):02d}" if month else ""
            day = f"{int(day):02d}" if day else ""
            return S3Location(
                loc.bucket,
                join(loc.prefix, datasource.value, year, month, day, *args, ""),
                basename,
            )
        else:
            return S3Location(
                loc.bucket, join(loc.prefix, datasource.value, *args, ""), basename
            )

    @staticmethod
    def get_s3_basename(
        stage: Stage, datasource: DataSource, year: int, month: int, day: int
    ) -> str:
        """
        **Description:**

        Given a stage and a basename, applies the appropriate naming scheme for that stage and
        returns the modified basename. The purpose of this method is to remove the need for the
        programmer to remember the naming conventions for basenames in each stage.

        **Examples:**

        ```
        basename = S3.get_s3_basename(
                Stage.TRANSFORMED, DataSource.ipil_hwy, self.year, self.month, self.day
            )
        ```

        Args:
            stage: Stage
                The Stage of the object for which we are generating a basename.
            datasource: DataSource
                The DataSource of the object for which we are generating a basename.
            year: int
                The year of the object for which we are generating a basename.
            month: int
                The month of the object for which we are generating a basename.
            day: int
                The day of the object for which we are generating a basename.

        Returns:
            str:
                The basename (string) to use for the file given the stage.

        Raises:
            ValueError: If invalid stage is passed will raise ValueError.
        """
        new_basename = ""
        year, month, day = int(year), int(month), int(day) if day else 1
        if stage.name == Stage.RAW.name:
            new_basename = f"{year}{month:02d}{day:02d}.csv"
        elif stage.name == Stage.CLEAN.name:
            new_basename = f"{year}{month:02d}{day:02d}.csv"
        elif stage.name == Stage.TRANSFORMED.name:
            new_basename = f"{year}{month:02d}{day:02d}.{datasource.value}.csv"
        elif stage.name == Stage.AGGREGATED.name:
            new_basename = f"{year}{month:02d}.csv"
        elif stage.name == Stage.PRE_RELEASE.name:
            new_basename = f"{year}{month:02d}.csv"
        elif stage.name == Stage.RELEASE.name:
            new_basename = f"{year}{month:02d}.csv"
        elif stage.name == Stage.VALIDATION.name:
            new_basename = f"{year}{month:02d}.csv"
        else:
            raise ValueError(f"Variable `stage` must be one of {Stage.aslist()}")
        return new_basename

    @staticmethod
    def get_manual_entry_basename(
        form: "webapp.models.capture.DataCapture", stage: Stage, datasource: DataSource
    ) -> str:
        """
        Helper method to get the basename for Manual Entry
        """
        # Get current timestamp for file name
        now = datetime.now()
        dt_string = now.strftime("%Y-%m-%d %H:%M:%S")
        # From business context, we know that each occurance of form.port.data will
        # contain exactly one 5 digit sequence, which is the port number.
        port_number = re.findall(r"(\d{5})", form.port.data).pop()
        # Country of residence does not apply if capture type is "vehicle"
        country = (
            form.country_of_residence.data
            if form.capture_type.data == "travellers"
            else None
        )
        return f"{port_number}-{form.data_source.data}-{form.vehicle_type.data}-{country}-{dt_string}.csv"

    @staticmethod
    def get_loc(stage: Stage, datasource: DataSource, basename: str) -> S3Location:
        """
        **Description:**

        For any valid stage, data source, and basename, this method returns the corresponding
        `S3Location`. This is one of the main public methods that the `S3` proxy class offers.

        **Examples**

        ```
        loc = S3.get_loc(stage, datasource, basename)
        ```

        Args:
            stage: Stage
                The stage of the object that we want to generate the `S3Location` for.
            datasource: DataSource
                The datasource of the object that we want to generate the `S3Location` for.
            basename: str
                The basename of the object that we want to generate the `S3Location` for.

        Returns:
            S3Location:
                The `S3Location` that corresponds to the given `Stage`, `DataSource`, and
                `basename` that were passed to this method.
        """
        # Try and get the year, month, day of the basename. If this doesn't
        # exist, __yyyymmdd__ will return None.
        year, month = None, None

        date = S3.__yyyymmdd__(basename)
        if date:
            year, month, _ = date

        return S3.prefix(
            stage, Mode.file, datasource, year=year, month=month, basename=basename
        )

    @staticmethod
    def get_loc2(
        stage: Stage, data_source: DataSource, year: int, month: int, day: int = 1
    ) -> S3Location:
        """
        **Description:**

        An thin wrapper for S3.get_loc that calls S3.get_s3_basename given year, month, date
        information.

        Args:
            stage: Stage
                [description]. Valid Values are [values]
            data_source: DataSource
                [description]. Valid Values are [values]
            year: int
                [description]. Valid Values are [values]
            month: int
                [description]. Valid Values are [values]

        Kwargs:
            day: int=1
                [description]. Valid Values are [values]

        Returns:
            S3Location:
                [description]. Valid Values are [values]
        """
        basename = S3.get_s3_basename(stage, data_source, year, month, 1)
        return S3.get_loc(stage, data_source, basename)

    @staticmethod
    def get_conflicts_loc(
        stage: Stage, datasource: DataSource, basename: str
    ) -> S3Location:
        """
        For any valid stage, data source, and basename, this method returns the corresponding
        `S3Location` for when there is a conflict. This is one of the main public methods that the
        `S3` proxy class offers. This method should be used to generate the appropriate location
        whenever there is a conflict in an S3 storage location.

        **Example**

        ```
        if exists and fallback_on_conflicts:
            loc = S3.get_conflicts_loc(stage, datasource, basename)
        ```

        Args:
            stage: Stage
                The stage of the object that we want to generate the conflict `S3Location` for.
            datasource: DataSource
                The datasource of the object that we want to generate the conflict `S3Location`
                for.
            basename: str
                The basename of the object that we want to generate the conflict `S3Location` for.

        Returns:
            S3Location:
                The `S3Location` that corresponds to the given `Stage`, `DataSource`, and
                `basename` that were passed to this method.
        """
        # Get conflicts bucket/prefix for the given stage

        year, month = None, None
        date = S3.__yyyymmdd__(basename)
        if date:
            year, month, day = date
        return S3.prefix(
            stage, Mode.conflicts, datasource, year=year, month=month, basename=basename
        )

    @staticmethod
    def get_historical_loc(
        stage: Stage, datasource: DataSource, basename: str
    ) -> S3Location:
        """
        **Description:**

        Gets the historical location for a given stage, datasource, and basename.

        Historical prefixes include the file in the prefix name and the basename is a timestamp
        (nanoseconds) to identify the specific file.

        **Example**

        ```
        if exists and fallback_on_conflicts:
            loc = S3.get_conflicts_loc(stage, datasource, basename)
        elif exists and fallback_on_historical:
            _ = S3.get_historical_loc(stage, datasource, basename)
        ```

        Args:
            stage: Stage
                The stage of the object that we want to generate the historical `S3Location` for.
            datasource: DataSource
                The datasource of the object that we want to generate the historical `S3Location`
                for.
            basename: str
                The basename of the object that we want to generate the historical `S3Location` for.

        Returns:
            S3Location:
                The `S3Location` that corresponds to the given `Stage`, `DataSource`, and
                `basename` that were passed to this method.
        """
        year, month, day = None, None, None
        date = S3.__yyyymmdd__(basename)
        if date:
            year, month, day = date
        # Get the basename as timestamp

        current = datetime.now().strftime(DATETIME_STR_FORMAT)
        return S3.prefix(
            stage,
            Mode.historical,
            datasource,
            basename,
            year=year,
            month=month,
            basename=current,
        )

    @staticmethod
    def obj_to_loc(bucket: str, obj: str) -> S3Location:
        """
        **Description:**

        A helper method that is used to translate between the S3 `obj` type and our
        project-specific `S3Location` type. This is the inverse method to `S3.loc_to_obj`.

        **Example:**
            ```
            # List all the objects from the Stage.INBOX location
            objs = client.ls_objs(
                Stage.INBOX.value.bucket,
                recursive=True,
                prefix=Stage.INBOX.value.prefix,
                only_files=True,
                default_folder_file=False,
            )

            # Recode all objs to MatchObj instances with S3Location, and all metadata
            # from the loading rule dataframe
            unmatched = [
                MatchedObj(
                    matched=False,
                    location=S3.obj_to_loc(Stage.INBOX.value.bucket, obj.object_name),
                    rule=None,
                )
                for obj in objs
            ]
            ```

        Args:
            bucket: str
                The name of the S3 bucket where the object is located.
            obj: str
                The `obj` string returned by an S3 client.

        Returns:
            S3Location:
                The instance of `S3Location` that corresponds to the given `bucket` and `obj`
                strings passed.
        """
        return S3Location(bucket, join(dirname(obj), ""), basename(obj))

    @staticmethod
    def loc_to_obj(location: S3Location) -> str:
        """
        **Description:**

        A helper method that is used to translate between  our project-specific `S3Location` type
        and the S3 `obj` type and. This is the inverse method to `S3.obj_to_loc`.

        **Example:**
            ```
            for obj in unmatched:
                path = S3.loc_to_obj(obj.location)
                if (not rule.regex and pattern == path) or (rule.regex and compiled.match(path)):
                    obj.matched = True
                    obj.rule = rule
                    matches.append(obj)
                else:
                    nmatches.append(obj)
            ```

        Args:
            location: S3Location
                An instance of our project-specific `S3Location` where we want to get the
                corresponding path as a string.

        Returns:
            str
                An `obj` string that can be used in an S3 client or other use case that requires
                a path as a string.
        """
        return join(location.prefix, location.basename)
