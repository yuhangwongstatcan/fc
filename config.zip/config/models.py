from __future__ import annotations
import json
from pathlib import Path
from typing import List

from pydantic import BaseModel


class NdmSaHardCodedCase(BaseModel):
    total: str
    group: List[str]


class NdmSaConfig(BaseModel):
    AAAA: List[str]
    xx: List[str]
    aa: List[str]
    bb: List[str]
    cc: List[str]
    dd: List[str]
    ZZZZ: List[str]
    WWWW: List[str]
    hard_coded_cases: List[NdmSaHardCodedCase]

    @classmethod
    def factory(cls) -> NdmSaConfig:
        with open(Path("config", "ndm_sa_rounding.json"), "r") as fd:
            obj = json.load(fd)
        return NdmSaConfig(**obj)
