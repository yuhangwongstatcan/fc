from enum import Enum
import os
from pathlib import Path
from pydantic import BaseSettings
from pydantic import Field
from pydantic import SecretStr
from functools import lru_cache

from pydantic.types import FilePath
from pydantic import HttpUrl


class ServiceAccountJWT(FilePath):
    """
    A pydantic model for the JWT associated with the current pod's service
    account.
    """

    @classmethod
    def validate(cls, value: Path) -> str:
        """Checks that path to mounted JWT is valid.
           Kubernetes automatically mounts a token associated with the pod's
           service account to a known location on the container filesystem of
           each container in the pod.

        Args:
            value (Path): Path to JWT for service account.

        Returns:
            str: Validated string path to JWT for service account.
        """
        value = super().validate(value=value)
        return value


class StatusCodeVars(str, Enum):
    CONFLICT_LOCATION = "CONFLICT_LOCATION"
    ERROR_LOCATION = "ERROR_LOCATION"
    UNKNOWN_LOCATION = "UNKNOWN_LOCATION"


class StatusCodeConfig(BaseSettings):
    # Variables to set the status of conflicts/error location/uknown location
    CONFLICT_LOCATION: bool = Field(False, env="CONFLICT_LOCATION")
    ERROR_LOCATION: bool = Field(False, env="ERROR_LOCATION")
    UNKNOWN_LOCATION: bool = Field(False, env="UNKNOWN_LOCATION")


class GlobalConfig(BaseSettings):
    FC_USE_MOCK_MINIO: str = Field(None, env="FC_USE_MOCK_MINIO")
    FC_VERBOSE: str = Field(None, env="FC_VERBOSE")
    FC_CPU_COUNT: str = Field(os.cpu_count(), env="FC_CPU_COUNT")

    FC_FLASK_SECRET_KEY: SecretStr
    LOGOUT_URL: HttpUrl
    APP_VERSION: str
    DEPLOYMENT: str

    S3PROXY_URL: str
    S3PROXY_ACCESS_KEY: str
    S3PROXY_SECRET_KEY: SecretStr
    DEFAULT_BUCKET: str
    ARGO_HOST: str
    ARGO_NAMESPACE: str
    ARGO_TEMPLATE_NAME: str
    ARGO_TEMPLATE_ENTRYPOINT: str
    ARGO_SERVICE_ACCOUNT: str
    DOC_BASE_URL: str
    FLASK_BASE_URL: str
    # Ingresses for each service
    S3PROXY_INGRESS: str
    ARGO_INGRESS: str

    # JWT token for the webapp service account that is mounted to a
    # container filesystem location.
    WEBAPP_SERVICE_ACCOUNT_JWT: ServiceAccountJWT

    class Config:
        env_file: str = ".env"


@lru_cache
def environ():
    return GlobalConfig()
