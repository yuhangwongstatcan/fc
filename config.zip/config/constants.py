# -*- coding: utf-8 -*-
"""
**Author(s)**
- Collin Brown - `collin.brown@canada.ca`

**Created On:** Thursday December 9, 2021

**Description:**

This module contains hard-coded constants that are used throughout the codebase.

This is module is intended to hold application-level constants that are not
appropriate to store in external configuration. The reason to centralize constants
here is to avoid distributing hard-coded constants throughout the codebase.
"""
import datetime

#  ___ ____ ___ _       _   ___        ____   __
# |_ _|  _ \_ _| |     | | | \ \      / /\ \ / /
#  | || |_) | || |     | |_| |\ \ /\ / /  \ V /
#  | ||  __/| || |___  |  _  | \ V  V /    | |
# |___|_|  |___|_____| |_| |_|  \_/\_/     |_|

COUNTRY_NOT_APPLICABLE = "Not applicable"
"""
The country/province constants below are used in the business rule `ipil_hwy_155.py`
to avoid hard-coding values.

When the country is not applicable in the `ipil_hwy` dataset.
"""

COUNTRY_OVERSEAS = "Overseas"
"""
When the country is an overseas country in the `ipil_hwy` dataset.
"""

COUNTRY_CANADA = "Canada"
"""
When the country is Canada in the `ipil_hwy` dataset.
"""

COUNTRY_USA = "United States of America"
"""
When the country is the United States of America in the `ipil_hwy` dataset.
"""

BC_YT = "BC-YT"
"""
Represents provinces British Columbia and Yukon Territory in `ipil_hwy`.
"""

AB = "AB"
SK_MB = "SK-MB"
ON = "ON"
QC = "QC"
NB_NS = "NB-NS"
"""
Province codes in `ipil_hwy`
"""

#  _____ ____   ____
# |_   _|  _ \ / ___|
#   | | | |_) | |
#   | | |  _ <| |___
#   |_| |_| \_\\____|

TRC_040_PROPORTION_DEFAULT = 0.5
"""
This constant relates to business rule `trc_040.py`.
"""


#  _   _ ____  __  __
# | \ | |  _ \|  \/  |
# |  \| | | | | |\/| |
# | |\  | |_| | |  | |
# |_| \_|____/|_|  |_|

SA_IN_START_DATE = datetime.datetime.strptime("2010-01-01", "%Y-%m-%d")
"""
The start date that is used to create the cumulative seasonal adjustment table
(i.e. the `SA_IN.csv` file).
"""
