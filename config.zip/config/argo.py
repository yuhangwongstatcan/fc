"""
Configuration related to Argo Workflows.
"""
import os
import sys
from enum import Enum
import json
from enum import Enum

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field
from pydantic.utils import ROOT_KEY

from config.env import StatusCodeVars


class ArgoStatusCodes(Enum):
    """
    The dashboard page of the web application presents the "status" of workflows
    that have been run by the Frontier Counts team. By default, Argo provides a
    set of standard statuses including "success", "failure", and "pending". Since
    there are a number of application-specific outcomes, which are outlined
    briefly below.

    1. `SUCCESS` - application exited with code 0 (*NIX default code for success).
    2. `RUNTIME_FAILURE` - application failed for an unexpected reason with exit code 1
    (*NIX default code for runtime error).
    3. `CONFLICT` - there was a conflict when a pipeline or the "check inbox" program
    was run, the program exits with status code 3.
    4. `ERROR_LOCATION` - a file in the inbox was triaged to the "error" location,
    indicating that there was an error while processing the data. The program
    exists with status code 4.
    5. `UNKNOWN_LOCATION` - a file in the inbox had a file name that did not match
    one of the expected naming conventions. The program exits with status code 5.

    There are a number of points where a certain condition is discovered that will
    trigger one of the workflow exit codes, but the program needs to continue running
    to perform some actions (e.g. cleaning up/moving some data to different S3
    locations prior to exiting the process). In such cases we set specific environment
    variables and check them later in the program after the necessary "cleanup" tasks
    have taken place.

    When a process exits with one of the non-standard exit codes, the Argo Workflows
    metadata contains a field indicating the process exit code of the main container
    run in the workflow pod. This exit code can be used to render a special icon + label
    on the dashboard page indicating that the workflow finished with a non-standard exit
    code. A production team member can then take the appropriate action without needing
    to investigate the Argo Workflow logs and/or figure out which MinIO files were
    written to various locations.

    This enumerator declares the 5 status codes described above and provides a series
    of class methods that get/set environment variables.
    """

    # *NIX defaults
    SUCCESS = "0"
    RUNTIME_FAILURE = "1"
    # Specific to Frontier Counts
    CONFLICT = "3"
    ERROR_LOCATION = "4"
    UNKNOWN_LOCATION = "5"

    @classmethod
    def exit_conflict(cls):
        """Exit the process with the CONFLICT status code (3)
        """
        sys.exit(int(ArgoStatusCodes.CONFLICT.value))

    @classmethod
    def exit_error_location(cls):
        """Exit the process with the ERROR_LOCATION status code (4)
        """
        sys.exit(int(ArgoStatusCodes.ERROR_LOCATION.value))

    @classmethod
    def exit_unknown_location(cls):
        """Exit the process with the UNKNOWN_LOCATION status code (5)
        """
        sys.exit(int(ArgoStatusCodes.UNKNOWN_LOCATION.value))

    @classmethod
    def set_conflict_env(cls):
        """Set an environment variable to indicate that a conflict occurred.
        """
        os.environ[StatusCodeVars.CONFLICT_LOCATION.value] = "True"

    @classmethod
    def set_error_location_env(cls):
        """Set an environment variable to indicate that a file was triaged
        to the `/error` location.
        """
        os.environ[StatusCodeVars.ERROR_LOCATION.value] = "True"

    @classmethod
    def set_unknown_location_env(cls):
        """Set an environment variable to indicate that a file was triaged
        to the `/unknown` location.
        """
        os.environ[StatusCodeVars.UNKNOWN_LOCATION.value] = "True"


class FrontierCountsStatusCodes(Enum):
    """This enumerator indicates the plain language name that will be displayed
    on the dashboard page when a given status code is generated.
    """

    # *NIX defaults
    SUCCESS = "succeeded"
    RUNTIME_FAILURE = "failed"
    RUNNING = "running"
    TERMINATING = "terminating"
    # Specific to Frontier Counts
    CONFLICT = "Conflict"
    ERROR_LOCATION = "Error File"
    UNKNOWN_LOCATION = "Unknown File"


STATUS_CODE_MAP = {
    ArgoStatusCodes.CONFLICT.value: FrontierCountsStatusCodes.CONFLICT.value,
    ArgoStatusCodes.ERROR_LOCATION.value: FrontierCountsStatusCodes.ERROR_LOCATION.value,
    ArgoStatusCodes.UNKNOWN_LOCATION.value: FrontierCountsStatusCodes.UNKNOWN_LOCATION.value,
}


class PipelineConfigs(Enum):
    composite_pipelines = "composite_pipelines.json"
    ndm_pipelines = "ndm_pipelines.json"


class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__dict__ = self


class ArgoFCBaseModel(BaseModel):
    """
    A pydantic model that overrides some of the magic methods in
    `pydantic.BaseModel`. The purpose of this model is to allow
    instances that subclass `ArgoFCBaseModel` to operate on instance
    attributes using native Python syntax for lists and dictionaries.
    """

    def __init__(__pydantic_self__, **data: Any) -> None:
        if __pydantic_self__.__custom_root_type__ and data.keys() != {ROOT_KEY}:
            data = {ROOT_KEY: data}
        super().__init__(**data)

    def __iter__(self):
        return iter(self.__root__)

    def __getitem__(self, item):
        return self.__root__[item]

    def __len__(self):
        return len(self.__root__)


class FCWorkflowOptions(BaseModel):
    """
    A simple pydantic model for an Argo Workflow specific to Frontier Counts.

    Attributes:
        name (str): A unique name to give the Frontier Counts workflow. This is
        used by the `depends` keyword to indicate a dependency in the computation DAG.
        cli_script (str): The name of the CLI script that should be invoked by
        the workflow.
        pipeline_class (Optional[str]): The pipeline class passed to the
        `run_pipeline.py` CLI program (only applicable for workflows that invoke
        the `run_pipeline.py` program).
        data_source (Optional[str]): the datasource parameter passed to the
        `run_pipeline.py` CLI program (only applicable for workflows that invoke
        the `run_pipeline.py` program).
        depends (Optional[str]): the name of the workflow that the current
        workflow depends on (only applicable if there is a workflow that depends
        on the successful completion of another workflow).
    """

    name: str
    cli_script: str
    # If it's another CLI script there may be no need for a pipeline class
    # or a datasource.
    pipeline_class: Optional[str]
    data_source: Optional[str]
    depends: Optional[str]

    def get_cli_args(self, cmd: List[str]) -> str:
        """Get the CLI args to run the workflow. Note that some arguments are
        passed at runtime while others can be constructed from the configuration.

        Args:
            cmd (List[str]): List of arguments that are concatenated with some
            configuration-specific arguments.

        Returns:
            str: String with all of the arguments concatenated.
        """
        args = [
            f"--pipeline-class {self.pipeline_class}",
            f"--data-source {self.data_source}",
        ] + cmd
        return " ".join(arg for arg in args if arg is not None)


class ArgoWorkflowDagTask(ArgoFCBaseModel):
    """A given workflow configuration may simply be a list of `FCWorkflowOptions`
    objects.
    """

    __root__: List[FCWorkflowOptions]


class ArgoWorkflowRecursiveDagTask(ArgoFCBaseModel):
    """
    A pydantic model for recursively defined Dag Tasks from the configuration
    specified in `src/config/composite_pipelines.json`.
    """

    __root__: List[str]

    @classmethod
    def validate(cls, val: List[Union[str, Dict[str, str]]]) -> ArgoWorkflowDagTask:
        """
        Recursively validates workflow dags that reference other workflow dags.
        All workflows in FCCompositePipeline will therefore be a single flat
        list of workflows.

        Args:
            val List[Union[str, Dict[str, str]]]: The list of workflows specified
            by the given configuration key.

        Raises:
            ValueError: The inner function `parse_wf_list` will raise a `ValueError`
            if an expected key is not present in the `config/composite_pipelines.json`
            configuration.

        Returns: an instance of `ArgoWorkflowDagTask`.
        """
        with open("config/composite_pipelines.json", "r") as fd:
            obj = json.load(fd)

        def parse_wf_list(wf_list, obj):
            """
            Recursively parses workflow lists that reference other workflow lists.
            Returns a flat list of all FCWorkflowOptions that are referenced in
            the hierarchical configuration.
            """
            if isinstance(wf_list[0], dict):
                return wf_list
            workflows = []
            for item in wf_list:
                if item not in obj.keys():
                    raise ValueError(
                        f"""
                        Key {item} not in configuration. Please check
                        config/composite_pipelines.json to verify that the keys you
                        are expected are present.
                        """
                    )
                workflows = workflows + parse_wf_list(obj[item], obj)
            return workflows

        # Now construct an instance of ArgoWorkflowDagTask from all of the workflows
        # added to workflow_dag_tasks.
        return ArgoWorkflowDagTask.parse_obj([wf for wf in parse_wf_list(val, obj)])


class FCCompositePipeline(ArgoFCBaseModel):
    __root__: Dict[str, Union[ArgoWorkflowDagTask, ArgoWorkflowRecursiveDagTask]]


class ArgoConfig(BaseModel):
    api_version: str = Field(default="argoproj.io/v1alpha1")
    pod_metadata_annotations: Dict[str, str] = Field(
        default={}
    )
    image_pull_secrets: List[str] = Field(default=["cnp-image-pull-secret"])


def fc_composite_pipelines(
    config_name: PipelineConfigs = PipelineConfigs.composite_pipelines,
) -> AttrDict:
    """
    Returns an instance of AttrDict where each key maps to an instance of
    ArgoCompositePipeline. Unlike regular python dictionaries, instances of AttrDict
    can be accessed through attributes.

    This allows full access to the composite pipeline configuration without
    hard-coding any strings or using dictionary accesses. For example:

    ```python
    composite_pipelines = fc_composite_pipelines()
    # Access the pipeline class for the first argument of the first job of the
    # first stage of the ipil_hwy_combined pipeline.
    composite_pipelines.ipil_hwy_combined[0][0].pipeline_class
    ```
    """
    with open(f"config/{config_name.value}", "r") as fd:
        obj = json.load(fd)

    composite_pipelines = FCCompositePipeline(**obj)
    return AttrDict(**composite_pipelines.__root__)

