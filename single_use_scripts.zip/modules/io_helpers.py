from pathlib import Path

import pandas as pd
import pandera as pa


def safe_read_pandas(path: Path, Schema: pa.SchemaModel) -> pd.DataFrame:
    """
    Given path to CSV, return df validated against a pandera schema.
    """
    safe_df = Schema(pd.read_csv(path))
    return safe_df.fillna(pd.NA)
