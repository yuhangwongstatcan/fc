#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------
#
# @author: Andres Solis Montero
# -----------------------------------------------------------
import logging
import time

from os import environ
from config.env import environ
from flask import Flask
from flask import g
from flask import request
from flask import url_for
from flask_session import Session
# from flask_talisman import Talisman

logger = logging.getLogger("frontiercounts.audit")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    )
    logger.addHandler(handler)

# WebApp
app = Flask(__name__)

# Enforce secure cookie attributes globally
app.config['SESSION_COOKIE_SECURE'] = True      # Send only over HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True    # Hide cookie from JavaScript (XSS protection)
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'   # Options: 'Lax', 'Strict', or 'None'

from webapp import config

# WebApp Session
Session(app)

@app.before_request
def log_before_request():
    g.start_time = time.time()
    logger.info(
        "request_start method=%s path=%s query=%s remote_addr=%s",
        request.method,
        request.path,
        dict(request.args),
        request.remote_addr,
    )

@app.after_request
def log_after_request(response):
    duration_ms = round((time.time() - g.start_time) * 1000, 2)
    logger.info(
        "request_end method=%s path=%s status=%s duration_ms=%s",
        request.method,
        request.path,
        response.status_code,
        duration_ms,
    )
    return response


# Override url_for inside templates to account for kubernetes prefix
def prefix(suffix=""):
    return environ().FLASK_BASE_URL + suffix


def prefix_url_for(*args, **kargs):
    return prefix(url_for(*args, **kargs))


@app.context_processor
def override_url_for():
    return dict(url_for=prefix_url_for)


# Add CSP security headers to every page response
# See https://content-security-policy.com/ for an explanation of why this
# header is necessary.
@app.after_request
def set_response_headers(resp):
    resp.headers["Content-Security-Policy"] = (
        # "default-src 'self'; script-src 'self'; style-src 'self'; img-src * data:"
        "default-src 'self'; script-src 'self'; style-src 'self';  img-src 'self' data:"
    )
    resp.headers["Cache-Control"] = "no-cache, no-store,  must-revalidate"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = 0
    return resp


# WebApp View routes
from webapp import views

# WebApp Controller routes

from webapp.controllers import ctrl_diff
from webapp.controllers import ctrl_conflicts
from webapp.controllers import ctrl_historical
from webapp.controllers import ctrl_dashboard
    